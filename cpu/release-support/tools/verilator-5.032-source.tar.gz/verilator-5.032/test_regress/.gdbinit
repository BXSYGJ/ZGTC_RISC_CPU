source ../src/.gdbinit

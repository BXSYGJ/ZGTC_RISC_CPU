"""Audit completed CoreMark and PDS runs without changing frozen experiment inputs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native_path(value: str) -> Path:
    if re.match(r"^[A-Za-z]:[/\\]", value) and str(ROOT).startswith("/mnt/"):
        return Path("/mnt") / value[0].lower() / value[3:].replace("\\", "/")
    if value.startswith("/mnt/") and re.match(r"^[A-Za-z]:", str(ROOT)):
        return Path(value[5].upper() + ":/" + value[7:])
    return Path(value)


def require(condition, message: str):
    if not condition:
        raise ValueError(message)


def audit_simulation(directory: Path):
    record = read_json(directory / "RUN.json")
    build = read_json(directory / "BUILD.json")
    uart = (directory / "uart.log").read_text(encoding="utf-8")
    stdout = (directory / "simulation.log").read_text(encoding="utf-8")
    name = directory.name
    require(record["exit_status"] == 0, name + ": simulator exit status")
    # An early screening harness counted the required short-duration message as
    # an error. Recheck the saved UART directly and retain that receipt difference.
    duration_message = "Must execute for at least 10 secs" in uart
    unexpected_errors = [line for line in uart.splitlines() if "ERROR" in line
                         and "Must execute for at least 10 secs" not in line]
    require(not unexpected_errors, name + ": UART runtime errors")
    require(all(value for key, value in record["checks"].items()
                if key != "no_crc_or_runtime_error"), name + ": checks")
    legacy_duration_classification = not record["checks"]["no_crc_or_runtime_error"] and duration_message
    require(record["checks"]["no_crc_or_runtime_error"] or legacy_duration_classification,
            name + ": unexplained historical error classification")
    require(record["stdout"] == stdout, name + ": stdout receipt mismatch")
    require(build["firmware_hex_sha256"].lower() == sha(directory / "firmware.hex"), name + ": firmware hash")
    require(record["firmware"] == build, name + ": build receipt mismatch")
    counters = re.search(r"cycles_hex=([0-9a-fA-F]{16}) retired_hex=([0-9a-fA-F]{16})", uart)
    require(counters is not None, name + ": UART counters")
    cycles, retired = (int(counters[i], 16) for i in (1, 2))
    require((cycles, retired) == (record["timed_cycles"], record["retired"]), name + ": UART/observer disagreement")
    crcs = re.findall(r"\[0\](?:crc(?:list|matrix|state)|crcfinal)\s*:\s*(0x[0-9a-fA-F]+)", uart)
    require(crcs == record["crc_fields"] and len(crcs) == 4, name + ": CRC receipt mismatch")
    expected = {"V0": ["0xe714", "0x1fd7", "0x8e3a"], "V1": ["0xe3c1", "0x0747", "0x8d84"]}
    require(crcs[:3] == expected[build["role"]], name + ": algorithm CRCs")
    known_final = {100: {"V0": "0x988c"}, 6000: {"V0": "0xa14c", "V1": "0x18e1"}}
    if build["role"] in known_final.get(build["iterations"], {}):
        require(crcs[3] == known_final[build["iterations"]][build["role"]], name + ": final CRC")
    score = build["iterations"] * 1_000_000 / cycles
    require(abs(score - record["coremark_per_mhz"]) < 1e-12, name + ": score formula")
    formal = cycles >= 1_451_250_000 and "Correct operation validated." in uart and "ERROR" not in uart
    require(formal == record["formal_ten_seconds"], name + ": duration receipt")
    require(49152 <= record["minimum_sp"] <= 65536, name + ": stack bound")
    return {
        "name": name, "path": str(directory), "role": build["role"], "profile": build["profile"],
        "iterations": build["iterations"], "cycles": cycles, "retired": retired,
        "coremark_per_mhz": score, "coremark_at_145125MHz": score * 145.125,
        "seconds_at_145125MHz": cycles / 145125000, "crc_fields": crcs,
        "formal_ten_seconds": formal, "firmware_sha256": sha(directory / "firmware.hex"),
        "historical_duration_diagnostic_reclassified": legacy_duration_classification,
        "rtl_sha256": record["rtl_sha256"], "exit_status": record["exit_status"],
    }


def audit_physical(directory: Path):
    record = read_json(directory / "BUILD_RESULT.json")
    if not record["Status"].startswith("completed_"):
        return {"name": directory.name, "status": record["Status"]}
    timing = record["Timing"]
    require(timing is not None, directory.name + ": missing timing")
    require(record["ConfiguredCpuClockHz"] == 145125000, directory.name + ": configured frequency")
    require(record["SetupUncertaintyNs"] == 0.15, directory.name + ": uncertainty")
    report_path = directory / "implementation" / "report_timing" / "pds_soc_top.rtr"
    require(sha(report_path) == timing["ReportSHA256"].lower(), directory.name + ": timing report hash")
    report = report_path.read_text(encoding="utf-8")
    require("clock uncertainty" in report and "-0.150" in report, directory.name + ": uncertainty report")
    require(len(timing["Checks"]) == 10, directory.name + ": missing timing categories")
    passed = all(row["WorstSlackNs"] >= 0 and row["TotalNegativeSlackNs"] == 0 and row["FailingEndpoints"] == 0
                 for rows in timing["Checks"].values() for row in rows)
    require(passed == timing["AllReportedChecksPass"], directory.name + ": timing pass receipt")
    require((record["Status"] == "completed_timing_pass") == passed, directory.name + ": status")
    require(("Design Summary : All Constraints Met." in report) == passed, directory.name + ": report result")
    bitstream = native_path(record["Bitstream"]["Path"])
    require(sha(bitstream) == record["Bitstream"]["SHA256"].lower(), directory.name + ": bitstream hash")
    require(sha(directory / "inputs" / "firmware.hex") == record["FirmwareSHA256"].lower(), directory.name + ": physical firmware")
    for entry in read_json(directory / "INPUT_HASHES.json"):
        require(sha(directory / "inputs" / entry["RelativePath"]) == entry["SHA256"].lower(), directory.name + ": input " + entry["RelativePath"])
    slow = min(row["WorstSlackNs"] for row in timing["Checks"]["Setup_Slow"])
    return {"name": directory.name, "path": str(directory), "status": record["Status"],
            "frequency_mhz": 145.125, "setup_uncertainty_ns": 0.15, "slow_setup_ns": slow,
            "resources": record["Resources"], "bitstream": str(bitstream),
            "bitstream_sha256": sha(bitstream), "firmware_sha256": record["FirmwareSHA256"].lower(),
            "core_sha256": sha(directory / "inputs" / "rtl" / "rv32_core.sv"),
            "btb_sha256": sha(directory / "inputs" / "rtl" / "rv32_btb.sv"),
            "all_ten_timing_checks_pass": passed}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="work/RESULTS_AUDIT.json")
    args = parser.parse_args()
    frozen = read_json(ROOT / "EXPERIMENT.json")["BaselineFiles"]
    for item in frozen:
        require(sha(ROOT / item["Path"]) == item["SHA256"].lower(), "Frozen baseline changed: " + item["Path"])
    simulations = [audit_simulation(path.parent) for path in sorted((ROOT / "work").glob("*/RUN.json"))]
    physical = [audit_physical(path.parent) for path in sorted((ROOT / "work").glob("physical-*/BUILD_RESULT.json"))]
    result = {"frozen_baseline_files_verified": len(frozen), "simulations": simulations, "physical": physical}
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"AUDIT_PASS frozen={len(frozen)} simulations={len(simulations)} physical={len(physical)}")
    for entry in simulations:
        if entry["iterations"] >= 6000:
            print(f"FORMAL {entry['name']} cycles={entry['cycles']} CM/MHz={entry['coremark_per_mhz']:.9f} valid={entry['formal_ten_seconds']}")


if __name__ == "__main__":
    main()

﻿# 3.51 CoreMark/MHz 原始资料核验

核验日期：2026-11-17。

原文：Yiyang Chang, Yiming Liu, Chong Peng, Jiarui Guo, Yi Zhao, Design of a Configurable Five-Stage Pipeline Processor Core Based on RV32IM, Electronics 2024, 13(1), 120。网页发布日期为 2023-12-28。
DOI：https://doi.org/10.3390/electronics13010120
出版商：https://www.mdpi.com/2079-9292/13/1/120

正文第12页表2给出 CoreMark/MHz = 3.51、DMIPS/MHz = 1.48；同页文字报告 Artix-7 FPGA 原型时钟 200 MHz。表2配置写作 low-power mode with MUL and DIV。

架构机制：五级流水线、可配置特权模式/CSR、乘除扩展、LOAD/MUL结果旁路；图10描述TCM/cache和AXI接口。

当前公开全文没有列出可供获取的该论文RTL链接、固定源码版本、完整CoreMark编译命令、运行种子、迭代次数与计时日志。精确逐字节复现所需的输入仍有缺项；可复用的是其流水线、旁路和存储接口设计经验。

本地单发射实验使用 ultraembedded/riscv 的公开RV32IM实现作为机制重建，固定提交7ae6f803e30f78c6ea3121e73c3adf50ff912730。作者仓库当前README给出2.94 CoreMark/MHz。该目录名 biriscv_repro_145 是早期命名，实际集成的是单发射riscv_core。
https://github.com/ultraembedded/riscv

biRISC-V另一个双发射仓库当前README给出4.1 CoreMark/MHz：
https://github.com/ultraembedded/biriscv

本轮工作采用用户允许的PaceRV优化路线，并保留RV32IM机制重建的代码、时序报告和实验日志。

论文文件：
D:/AAAFPGA\ZGTC_RISC_CPU\cpu_paper\ccfa-workfiles\literature\nju-access-tool-browser-search\downloads\rv32im_configurable_five_stage_2024.pdf
PDF SHA256: bffefffcdeeb2e964b114b438d9e8aeee5948c55c1efe282c23c48f2bd847eb9
全文抽取文件：
D:/AAAFPGA\ZGTC_RISC_CPU\cpu_paper\ccfa-workfiles\literature\nju-access-tool-browser-search\downloads\rv32im_configurable_five_stage_2024.txt

Zotero下载/导入批次：816b63ed1d324cc196b8b6e2a1f19174
父条目：24QQ4VA2；附件：GL6DBBET；已回读验证附件和分类。
分类：用户指定下载文献 / 计算机体系结构 / RISC-V FPGA软核（S3KUFD4L）。
本轮导入与分类均完成。

复查命令：使用已安装academic-browser-search的resolve_paper(10.3390/electronics13010120)、download_paper以及zotero_sync；网页使用background browser-search Extract。

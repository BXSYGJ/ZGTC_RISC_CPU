﻿# PaceRV optimized release

Device PG2L200H-6FBB676; RV32IMC; clock145.125MHz; setup uncertainty0.150ns.
V0: 3.484719042 CoreMark/MHz; V1: 3.480411318; both6000iterations and validated intervals>10seconds.
Actual routed V0 slow setup +0.030ns; all10internal timing categories pass.
New bitstream has real RTL simulation and PDS route evidence. New live-board UART sampling remains pending.

## Reproduce in the existing workspace

Workspace: `D:\AAAFPGA\ZGTC_RISC_CPU\pds_minimal_blink_200h\pacerv_h3_optimization`. Copied scripts retain their original workspace bindings; simulation/rtl and simulation/sim archive the exact simulator inputs.
`firmware/V0` and `firmware/V1` contain the measured images and compiler/build/run receipts. `physical_inputs` contains the actual PDS input snapshot.
`bitstreams/V0.sbit` matches the V0 firmware hash. V1 firmware is archived; a V1 bitstream is included only when a matching independent physical build is recorded.
`evidence/RTL_BINDING.json` verifies each common physical/simulation RTL file; representation changes require exact source normalization and the SAT/cycle-equivalence evidence.
CoreMark/MHz is calculated from the atomic cycle snapshot: iterations*1000000/cycles; the inherited UART integer-seconds rate is retained verbatim in uart.log.

```powershell
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$paceRoot = [System.IO.Path]::GetFullPath('D:/AAAFPGA/ZGTC_RISC_CPU/pds_minimal_blink_200h/pacerv_h3_optimization')
try {
    & python.exe ([System.IO.Path]::Combine($paceRoot, 'scripts', 'audit_results.py'))
    if ($LASTEXITCODE -ne 0) { throw 'Result audit failed' }
} catch { Write-Error $_; exit 1 }
```

The original frozen H3 baseline remains in the workspace; the release contains copies. Each RTL proposal includes its own tested rollback script and recorded parent hash.

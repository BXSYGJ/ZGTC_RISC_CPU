"""Package an audited, completed experiment without modifying baseline sources."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from audit_results import audit_physical, audit_simulation, read_json, require, sha


def simulation_identity(rtl: Path, load_bubble: int) -> str:
    recipe = read_json(ROOT / "recipe.json")
    inputs = [rtl / Path(item).name for item in recipe["simulation"]["argv"]
              if "/simulation/inputs/rtl/" in item]
    inputs += [ROOT / item.split("{RELEASE}/")[1] for item in recipe["simulation"]["argv"]
               if "/simulation/inputs/sim/" in item]
    digest = hashlib.sha256()
    for path in inputs:
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    digest.update(str(load_bubble).encode())
    return digest.hexdigest()


def canonical_core(path: Path) -> str:
    """Accept only recorded attributes and the formally proven equality regrouping."""
    text = path.read_text(encoding="utf-8-sig")
    text = text.replace("    wire [4:0] id_rs1,id_rd;\n    (* syn_maxfan=8 *) wire [4:0] id_rs2;",
                        "    wire [4:0] id_rs1,id_rs2,id_rd;")
    for name in ("id_zero_taken",):
        text = text.replace(f"(* syn_maxfan=8 *) wire {name}", f"wire {name}")
    for name in ("frontend_redirect_address_select", "ex_transfer_capacity", "fetch_accept_space"):
        text = text.replace(f"(* syn_keep=1, syn_maxfan=8 *) wire {name}", f"(* syn_keep=1 *) wire {name}")
    group = ("    (* syn_keep=1 *) wire [7:0] id_operand_equal_nibbles;\n"
             "    generate for(genvar id_equal_nibble=0;id_equal_nibble<8;id_equal_nibble=id_equal_nibble+1) begin: id_equal_lut4\n"
             "        assign id_operand_equal_nibbles[id_equal_nibble]=\n"
             "            id_operand_a[id_equal_nibble*4+:4]==id_operand_b[id_equal_nibble*4+:4];\n"
             "    end endgenerate\n"
             "    wire id_operand_pair_equal=&id_operand_equal_nibbles;\n")
    if group in text:
        require(text.count(group) == 1, "Repeated equality cone")
        text = text.replace(group, "").replace("id_operand_pair_equal;", "id_operand_a==id_operand_b;")
    return text


def bind_rtl(v0: dict, v1: dict, physical_path: Path) -> dict:
    record = read_json(ROOT / "work" / v0["name"] / "RUN.json")
    candidates = [ROOT / "simulation" / "inputs" / "rtl"]
    candidates += sorted((ROOT / "candidates").glob("*/rtl"))
    matches = [path for path in candidates if simulation_identity(path, record["load_use_bubble"]) == v0["rtl_sha256"]]
    require(len(matches) == 1, "Simulation RTL must match exactly one frozen source directory")
    simulation = matches[0]
    actual = physical_path / "inputs" / "rtl"
    evidence = []
    for path in sorted(simulation.glob("*.sv")):
        other = actual / path.name
        require(other.is_file(), "Missing physical RTL " + path.name)
        same = sha(path) == sha(other)
        if not same:
            require(path.name == "rv32_core.sv", "Unverified physical/simulation RTL mismatch: " + path.name)
            require(canonical_core(path) == canonical_core(other), "Physical core changes exceed proven representation edits")
            lut4 = ROOT / "rtl_proposals" / "timing_id_equal_lut4"
            proof = read_json(lut4 / "FORMAL_EQUIVALENCE.json")
            require(proof["exit_status"] == 0, "Equality SAT proof failed")
            require(proof["core_sha256"] == sha(lut4 / "rv32_core.sv"), "SAT proof source hash")
            for folder, name in (("timing_id_fanout8", "BENCHMARK_EQUIVALENCE.json"),
                                 ("timing_id_equal_lut4", "INTERFACE_EQUIVALENCE.json")):
                check = read_json(ROOT / "rtl_proposals" / folder / name)
                require(check["trace_comparison"]["exit_status"] == 0 and check["uart_comparison"]["exit_status"] == 0,
                        "Recorded benchmark equality failed")
                require(len(check["records"]) == 2, "Expected paired benchmark runs")
                for field in ("timed_cycles", "retired", "trace_sha256", "uart_sha256"):
                    require(check["records"][0][field] == check["records"][1][field], "Equivalence receipt disagrees: " + field)
                if "interface_comparison" in check:
                    require(check["interface_comparison"]["exit_status"] == 0, "Interface equivalence failed")
                    require(check["records"][0]["interface_sha256"] == check["records"][1]["interface_sha256"], "Interface digest")
                evidence.append(str(Path("evidence") / "rtl" / folder / name))
        evidence.append({"name": path.name, "simulation_sha256": sha(path), "physical_sha256": sha(other),
                         "binding": "identical" if same else "exact canonical source equality plus SAT and recorded cycle/retirement equivalence"})
    require(v0["rtl_sha256"] == v1["rtl_sha256"], "V0/V1 simulator identity")
    return {"simulation_directory": str(simulation), "simulation_identity": v0["rtl_sha256"],
            "load_use_bubble": record["load_use_bubble"], "checks": evidence}


def copy_file(source: Path, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    require(sha(source) == sha(destination), "Copy hash mismatch: " + str(destination))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--v0", required=True)
    parser.add_argument("--v1", required=True)
    parser.add_argument("--physical", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--archive-timing-fail", action="store_true",
                        help="Archive a completed timing-failed image with an explicit experimental status")
    args = parser.parse_args()
    for value in (args.v0, args.v1, args.physical, args.output):
        require(Path(value).name == value and value not in (".", ".."), "Expected a directory name")
    v0_path, v1_path, physical_path = [ROOT / "work" / value for value in (args.v0, args.v1, args.physical)]
    v0, v1 = audit_simulation(v0_path), audit_simulation(v1_path)
    physical = audit_physical(physical_path)
    require(v0["role"] == "V0" and v1["role"] == "V1", "Role binding")
    require(v0["formal_ten_seconds"] and v1["formal_ten_seconds"], "Both full runs must pass")
    require(v0["rtl_sha256"] == v1["rtl_sha256"], "V0/V1 RTL mismatch")
    timing_pass = physical["all_ten_timing_checks_pass"]
    require(timing_pass or args.archive_timing_fail, "Physical timing must pass for a qualified release")
    require(not args.archive_timing_fail or not timing_pass, "Timing-fail archive requires an actually failed route")
    require(v0["firmware_sha256"] == physical["firmware_sha256"], "V0/physical firmware mismatch")
    binding = bind_rtl(v0, v1, physical_path)
    out = ROOT / "optimized_releases" / args.output
    require(not out.exists(), "Release already exists: " + str(out))
    out.mkdir(parents=True)
    shutil.copytree(physical_path / "inputs", out / "physical_inputs")
    copy_file(physical_path / "implementation" / "generate_bitstream" / "pds_soc_top.sbit", out / "bitstreams" / "V0.sbit")
    for role, source in (("V0", v0_path), ("V1", v1_path)):
        for name in ("firmware.elf", "firmware.bin", "firmware.hex", "firmware.map", "firmware.dis", "BUILD.json", "RUN.json", "uart.log", "simulation.log", "compiler.log"):
            copy_file(source / name, out / "firmware" / role / name)
    for name in ("BUILD_RESULT.json", "INPUT_HASHES.json"):
        copy_file(physical_path / name, out / "evidence" / "physical" / name)
    for folder in ("report_timing", "place_route"):
        source = physical_path / "implementation" / folder
        for item in source.iterdir():
            if item.is_file() and item.suffix.lower() in (".rtr", ".prr", ".txt", ".log", ".json"):
                copy_file(item, out / "evidence" / "physical" / folder / item.name)
    for proposal in ("id_equal", "history6", "id_equal_load_alu", "loop16", "timing_id_fanout8", "timing_id_equal_lut4", "timing_ex_fetch_fanout8"):
        source = ROOT / "rtl_proposals" / proposal
        for name in ("rv32_core.sv", "rv32_btb.sv", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh", "BASELINE_FILE.sv",
                     "BENCHMARK_EQUIVALENCE.json", "INTERFACE_EQUIVALENCE.json", "FORMAL_EQUIVALENCE.json", "NATIVE_REPLICA_AUDIT.json",
                     "core_token_tb.sv", "comparator_tb.sv", "equivalence_miter.sv", "prove_id_equal.ys"):
            if (source / name).exists():
                copy_file(source / name, out / "evidence" / "rtl" / proposal / name)
    for name in ("experiment.py", "audit_results.py", "package_optimized.py", "Build-PacePds.ps1"):
        copy_file(ROOT / "scripts" / name, out / "reproduction" / name)
    copy_file(ROOT / "work" / "RESULTS_AUDIT.json", out / "evidence" / "RESULTS_AUDIT.json")
    for role in ("V0", "V1"):
        shutil.copytree(ROOT / "firmware" / role / "inputs", out / "firmware" / role / "inputs")
    shutil.copytree(Path(binding["simulation_directory"]), out / "simulation" / "rtl")
    shutil.copytree(ROOT / "simulation" / "inputs" / "sim", out / "simulation" / "sim")
    (out / "evidence" / "RTL_BINDING.json").write_text(json.dumps(binding, indent=2) + "\n", encoding="utf-8-sig")
    for name in ("SOURCE_IDENTITY.json", "SOURCE_VERIFICATION.md"):
        copy_file(ROOT.parent / "source_research" / "paper351" / name, out / "evidence" / "paper351" / name)
    baseline = read_json(ROOT / "PERFORMANCE.json")[0]
    readme = [
        "# PaceRV optimized release", "",
        f"Device PG2L200H-6FBB676; RV32IMC; clock145.125MHz; setup uncertainty0.150ns.",
        f"V0: {v0['coremark_per_mhz']:.9f} CoreMark/MHz; V1: {v1['coremark_per_mhz']:.9f}; both6000iterations and validated intervals>10seconds.",
        f"Actual routed V0 slow setup {physical['slow_setup_ns']:+.3f}ns; timing status: {physical['status']}.",
        "All10internal timing categories pass." if timing_pass else "Experimental timing-failed archive: the configured145.125MHz is nominal; routed timing closure remains pending.",
        "New bitstream has real RTL simulation and PDS route evidence. New live-board UART sampling remains pending.", "",
        "## Reproduce in the existing workspace", "",
        f"Workspace: `{ROOT}`. Copied scripts retain their original workspace bindings; simulation/rtl and simulation/sim archive the exact simulator inputs.",
        "`firmware/V0` and `firmware/V1` contain the measured images and compiler/build/run receipts. `physical_inputs` contains the actual PDS input snapshot.",
        "`bitstreams/V0.sbit` matches the V0 firmware hash. V1 firmware is archived; a V1 bitstream is included only when a matching independent physical build is recorded.",
        "`evidence/RTL_BINDING.json` verifies each common physical/simulation RTL file; representation changes require exact source normalization and the SAT/cycle-equivalence evidence.",
        "CoreMark/MHz is calculated from the atomic cycle snapshot: iterations*1000000/cycles; the inherited UART integer-seconds rate is retained verbatim in uart.log.", "",
        "```powershell",
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
        f"$paceRoot = [System.IO.Path]::GetFullPath('{ROOT.as_posix()}')",
        "try {",
        "    & python.exe ([System.IO.Path]::Combine($paceRoot, 'scripts', 'audit_results.py'))",
        "    if ($LASTEXITCODE -ne 0) { throw 'Result audit failed' }",
        "} catch { Write-Error $_; exit 1 }",
        "```", "",
        "The original frozen H3 baseline remains in the workspace; the release contains copies. Each RTL proposal includes its own tested rollback script and recorded parent hash.",
    ]
    (out / "README.md").write_text("\n".join(readme) + "\n", encoding="utf-8-sig")
    manifest = {
        "schema": "pacerv-optimized-release/v1", "device": "PG2L200H-6FBB676", "isa": "RV32IMC",
        "qualification_status": "timing_passed" if timing_pass else "experimental_timing_failed",
        "frequency_hz": 145125000, "clock_uncertainty_ns": 0.15,
        "V0": v0, "V1": v1, "physical": physical,
        "rtl_binding": binding,
        "baseline_coremark_per_mhz": baseline["coremark_per_mhz"],
        "improvement_percent": (v0["coremark_per_mhz"] / baseline["coremark_per_mhz"] - 1) * 100,
        "live_board_status": "New image not programmed or captured in this task; real RTL simulation and actual PDS route verified",
        "reproduction_workspace": str(ROOT),
        "reproduction_scripts": "Run original scripts from reproduction_workspace; the copied scripts retain workspace-relative source bindings",
        "files": [{"path": str(path.relative_to(out)).replace("\\", "/"), "sha256": sha(path), "bytes": path.stat().st_size}
                  for path in sorted(out.rglob("*")) if path.is_file()],
    }
    (out / "MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8-sig")
    for item in read_json(out / "MANIFEST.json")["files"]:
        require(sha(out / item["path"]) == item["sha256"], "Packaged artifact hash mismatch")
    print("PACKAGE_PASS " + str(out))
    print(f"V0 CM/MHz={v0['coremark_per_mhz']:.9f} V1 CM/MHz={v1['coremark_per_mhz']:.9f} setup={physical['slow_setup_ns']:+.3f}ns")


if __name__ == "__main__":
    main()

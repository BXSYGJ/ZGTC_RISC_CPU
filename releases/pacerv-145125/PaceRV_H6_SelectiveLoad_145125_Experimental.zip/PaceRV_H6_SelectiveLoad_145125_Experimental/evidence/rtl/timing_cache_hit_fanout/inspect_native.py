"""Read the concrete original cache hit drivers before choosing a fanout edit."""
from pathlib import Path
import hashlib
import json
import re

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
NET=ROOT/'work'/'physical-noif-nocross-loadalu-history6-local-s1'/'implementation'/'netlist.v'
text=NET.read_text(encoding='utf-8-sig')
modules=re.split(r'(?m)(?=^module\s)',text)
drivers=[]
for module in modules:
    header=re.match(r'module\s+(\S+)',module)
    if not header:
        continue
    for signal in ['hit0','hit1']:
        output=re.search(r'\.(?:Z|COUT)\s*\('+signal+r'\)',module)
        if not output:
            continue
        start=module.rfind('\n    GTP_',0,output.start())+1
        end=module.find(');',output.end())+2
        cell=module[start:end]
        primitive=re.match(r'\s*(GTP_\w+)',cell).group(1)
        line=text[:text.index(module)+start].count('\n')+1
        consumers=re.findall(r'\.(I[0-5]|CIN|A\d*|D\d*)\s*\('+signal+r'\)',module)
        drivers.append(dict(module=header.group(1),signal=signal,primitive=primitive,line=line,cell=cell,local_input_connections=len(consumers),carry_input_connected=bool(re.search(r'\.CIN\s*\([^)]*\S[^)]*\)',cell))))
assert len(drivers)==2
assert all(d['primitive']=='GTP_LUT6CARRY' and d['carry_input_connected'] for d in drivers)
warning_path=ROOT/'work'/'physical-noif-nocross-loadalu-h6-fanout8-local-s1'/'synthesis'/'synthesize'/'run.log'
if not warning_path.exists():
    candidates=list((ROOT/'work'/'physical-noif-nocross-loadalu-h6-fanout8-local-s1').rglob('run.log'))
    warning_path=next((p for p in candidates if "wasn't replicated" in p.read_text(encoding='utf-8-sig',errors='replace')),None)
warning_lines=[]
if warning_path:
    warning_lines=[line for line in warning_path.read_text(encoding='utf-8-sig',errors='replace').splitlines() if "wasn't replicated" in line and 'id_zero_taken' in line]
path=ROOT/'work'/'cf2-physical-frontend-flat-local-s1'/'implementation'/'report_timing'/'pds_soc_top.rtr'
report=path.read_text(encoding='utf-8-sig')
fanout_lines=[line.strip() for line in report.splitlines() if '/hit1' in line][:3]
record=dict(original_native_netlist=str(NET),netlist_sha256=hashlib.sha256(NET.read_bytes()).hexdigest(),drivers=drivers,prior_id_replication_warning_file=str(warning_path),prior_id_replication_warning_lines=warning_lines,current_flat_route_report=str(path),flat_route_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),flat_hit1_path_lines=fanout_lines,cache_annotations_added=False,cache_synthesis_probe_started=False,conclusion='Original hit0/hit1 are LUT6CARRY Z outputs driven by equality carry chains. Earlier ID equality output of the same primitive class was not replicated when maxfan8 was applied. A cache-specific maxfan synthesis outcome has not yet been measured. Await root selection before implementing an attribute-only candidate or an explicit comparator change.')
(AREA/'NATIVE_DRIVER_FINDINGS.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
md=['# Cache hit native-driver findings','',record['conclusion'],'',f'Original netlist SHA256: `{record["netlist_sha256"]}`','']
for driver in drivers:
    md += [f'## {driver["module"]}.{driver["signal"]}',f'Primitive: {driver["primitive"]}; original netlist line {driver["line"]}; CIN connected; module-local primitive input connections {driver["local_input_connections"]}.','```verilog',driver['cell'],'```','']
md += ['## Actual earlier tool output','',*warning_lines,'','## Actual current routed fanout','',*fanout_lines,'','Cache source and prior files remain unchanged. No PDS probe was started.']
(AREA/'NATIVE_DRIVER_FINDINGS.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
for p in [AREA/'NATIVE_DRIVER_FINDINGS.json',AREA/'NATIVE_DRIVER_FINDINGS.md']:
    assert p.read_bytes()
print('CACHE_NATIVE_DRIVER_FINDINGS_PASS hit0=GTP_LUT6CARRY hit1=GTP_LUT6CARRY carry_input=connected source_modified=0 probe_started=0')

﻿# Native cache mapping audit

Tag equality carry chains have become kept small LUT groups and root hit LUTs. Maxfan8 was implemented with identity LUT1 buffers; no duplicate hit-function LUTs were generated. Root hit logic still precedes buffer delay. Routed timing must be assessed separately.

Netlist SHA256: `bc75fc1b1c87b63ef0afd9d42a0212408234498ed9f4febe501d6842fca79427`

## rv32_cache
Kept group LUTs: 4; identity hit buffers: 7; duplicate hit-function LUTs: 0.

| Signal | Primitive | Role | Primitive consumers |
|---|---|---|---:|
| hit0 | GTP_LUT3 | root_hit_logic | 8 |
| hit1 | GTP_LUT6 | root_hit_logic | 5 |
| hit1_1 | GTP_LUT1 | identity_buffer | 8 |
| hit1_2 | GTP_LUT1 | identity_buffer | 8 |
| hit1_3 | GTP_LUT1 | identity_buffer | 8 |
| hit1_4 | GTP_LUT1 | identity_buffer | 8 |
| hit1_5 | GTP_LUT1 | identity_buffer | 8 |
| hit1_6 | GTP_LUT1 | identity_buffer | 8 |
| hit1_7 | GTP_LUT1 | identity_buffer | 8 |

## rv32_cache_1
Kept group LUTs: 6; identity hit buffers: 5; duplicate hit-function LUTs: 0.

| Signal | Primitive | Role | Primitive consumers |
|---|---|---|---:|
| hit0 | GTP_LUT6 | root_hit_logic | 7 |
| hit1 | GTP_LUT6 | root_hit_logic | 7 |
| hit1_1 | GTP_LUT1 | identity_buffer | 8 |
| hit1_2 | GTP_LUT1 | identity_buffer | 8 |
| hit1_3 | GTP_LUT1 | identity_buffer | 8 |
| hit1_4 | GTP_LUT1 | identity_buffer | 8 |
| hit1_5 | GTP_LUT1 | identity_buffer | 8 |


Final routed result: setup WNS -0.799 ns, TNS -93.743 ns,422 failing endpoints; all other nine classes pass. Actual PDS exit0. Worstpath crosses Dcachehit1 root,identity hit1_1 buffer,EX/FETCH and frontend before IcachepairRADDR. Original highscore seed1 stays -0.218ns. See ROUTED_RESULT.json.

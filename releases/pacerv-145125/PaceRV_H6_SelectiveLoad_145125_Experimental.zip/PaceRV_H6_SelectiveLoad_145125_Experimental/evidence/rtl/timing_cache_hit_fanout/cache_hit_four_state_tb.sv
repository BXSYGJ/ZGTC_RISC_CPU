module cache_hit_four_state_tb;
parameter TAG_BITS=6;
reg [TAG_BITS-1:0] lookup_tag0,lookup_tag1,request_tag;
reg lookup_valid0,lookup_valid1;
wire hit0,hit1;
cache_hit_groups #(.TAG_BITS(TAG_BITS)) dut(.*);
wire reference0=lookup_valid0 && lookup_tag0==request_tag;
wire reference1=lookup_valid1 && lookup_tag1==request_tag;
integer checks=0,i,k,j;
task check; begin #1; if(hit0!==reference0 || hit1!==reference1) $fatal(1,"Cache group comparison mismatch width=%0d case=%0d",TAG_BITS,checks); checks=checks+1; end endtask
initial begin
for(i=0;i<10000;i=i+1) begin
lookup_tag0=$random;lookup_tag1=$random;request_tag=$random;lookup_valid0=$random;lookup_valid1=$random;check;
end
for(i=0;i<10000;i=i+1) begin
lookup_tag0=$random;lookup_tag1=$random;request_tag=$random;lookup_valid0=$random;lookup_valid1=$random;
for(k=0;k<TAG_BITS;k=k+1) begin
if(($random & 3)==0) lookup_tag0[k]=($random & 1) ? 1'bx : 1'bz;
if(($random & 3)==0) lookup_tag1[k]=($random & 1) ? 1'bx : 1'bz;
if(($random & 3)==0) request_tag[k]=($random & 1) ? 1'bx : 1'bz;
end
if(($random & 3)==0) lookup_valid0=($random & 1) ? 1'bx : 1'bz;
if(($random & 3)==0) lookup_valid1=($random & 1) ? 1'bx : 1'bz;
check;
end
$display("CACHE_GROUP_FOUR_STATE_PASS width=%0d cases=%0d",TAG_BITS,checks);$finish;
end
endmodule

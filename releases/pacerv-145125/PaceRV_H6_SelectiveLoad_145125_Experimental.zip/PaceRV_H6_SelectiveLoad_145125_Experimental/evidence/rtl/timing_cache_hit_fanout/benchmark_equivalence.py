"""Use the established trace harness with exact original source as this baseline."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import time

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
HELPER=AREA.parent/'timing_ex_fetch_fanout8'/'benchmark_equivalence.py'
spec=importlib.util.spec_from_file_location('prior_trace_harness',HELPER)
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
BASELINE=Path('/tmp/pacerv_timing_ex_fetch_fanout8_interface_equivalence/BASELINE')
prior=json.loads((AREA.parent/'timing_ex_fetch_fanout8'/'INTERFACE_EQUIVALENCE.json').read_text(encoding='utf-8-sig'))
prior_record=prior['records'][0]
prior_build=json.loads((BASELINE/'BUILD.json').read_text())
for path in (BASELINE/'inputs').iterdir():
    if path.is_file():
        assert h.digest(path)==prior_build['input_sha256'][path.name],path
for name,key in [('retirement.bin','trace_sha256'),('interface.bin','interface_sha256'),('uart.log','uart_sha256')]:
    assert h.digest(BASELINE/name)==prior_record[key],name
assert h.digest(h.FIRMWARE)==prior['firmware_sha256']
changes=[]
for path in sorted(h.SOURCE.glob('*.sv')):
    old=BASELINE/'inputs'/path.name
    if old.read_bytes()!=path.read_bytes():
        changes.append(path.name)
        assert path.name=='rv32_core.sv'
        expected=(AREA.parent/'timing_id_equal_lut4'/'rv32_core.sv').read_bytes()
        assert old.read_bytes()==expected
assert changes==['rv32_core.sv']
# That earlier baseline has the original final architecture plus proven-equivalent
# fanout attributes and LUT4 equality. Its full100cycle interface trace is already
# bound to the original functional source by the saved evidence chain.
baseline_binding=dict(source_inventory={path.name:h.digest(path) for path in sorted(h.SOURCE.glob('*.sv'))},cached_baseline_inventory=prior_build['input_sha256'],representation_changes=changes,representation_chain=[str(AREA.parent/'timing_id_fanout8'/'BENCHMARK_EQUIVALENCE.json'),str(AREA.parent/'timing_id_equal_lut4'/'INTERFACE_EQUIVALENCE.json')],cached_baseline_rehashed=True)

# Use its exact observer, driver and vendor harness, while replacing all RTL
# with the original final functional source and this one cache refactor.
WORK=Path('/tmp/pacerv_timing_cache_hit_fanout_interface_equivalence')
directory=WORK/'MODIFIED'
inputs=directory/'inputs'
inputs.mkdir(parents=True,exist_ok=True)
for path in (BASELINE/'inputs').iterdir():
    if path.is_file():
        shutil.copy2(path,inputs/path.name)
sources=[]
for path in sorted(h.SOURCE.glob('*.sv')):
    replacement=AREA/'rv32_cache.sv' if path.name=='rv32_cache.sv' else path
    shutil.copy2(replacement,inputs/path.name)
    sources.append(inputs/path.name)
sources += [inputs/'native_selected_observer.sv',inputs/'GTP_DRM36K_E1.v',inputs/'GTP_GRS.v']
shutil.copy2(h.FIRMWARE,directory/'firmware.hex')
command=prior_build['command']
transformed=[]
for token in command:
    transformed.append(token.replace(str(BASELINE),str(directory)))
# Recheck the original harness order and file set; it is independent from the
# extracted combinational miter and the23case core driver.
assert transformed[0]==str(h.VERILATOR)
build=h.command_run(transformed,directory,directory/'build.log',900)
build['input_sha256']={path.name:h.digest(path) for path in inputs.iterdir() if path.is_file()}
build['firmware_sha256']=h.digest(directory/'firmware.hex')
(directory/'BUILD.json').write_text(json.dumps(build,indent=2),encoding='utf-8')
print('CACHE_HIT_MODIFIED_BENCHMARK_COMPILED',flush=True)
record=h.execute(directory)
comparisons={}
for name in ('retirement.bin','interface.bin','uart.log'):
    comparisons[name]=h.command_run(['cmp','-s',str(BASELINE/name),str(directory/name)],WORK,WORK/(name+'-compare.log'),120)
assert record['trace_sha256']==prior_record['trace_sha256']
assert record['interface_sha256']==prior_record['interface_sha256']
assert record['uart_sha256']==prior_record['uart_sha256']
evidence=dict(changed_field='Cache kept two-bit equality groups and maxfan8 hit',firmware=str(h.FIRMWARE),firmware_sha256=h.digest(h.FIRMWARE),baseline_binding=baseline_binding,cached_baseline=prior_record,modified=record,modified_build=build,comparisons=comparisons,result='All100iteration retirement event bytes, all per-cycle qualified I/D payload and handshake bytes, UART, measured interval and retired count match the rehashed original-equivalent baseline')
(AREA/'INTERFACE_EQUIVALENCE.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
shutil.copy2(directory/'run.log',AREA/'modified-interface-benchmark.log')
verification=json.loads((AREA/'VERIFICATION.txt').read_text(encoding='utf-8-sig'))
verification['full100interface_equivalence']=evidence
(AREA/'VERIFICATION.txt').write_text(json.dumps(verification,indent=2),encoding='utf-8')
print('CACHE_HIT_INTERFACE_EQUIVALENCE_PASS cycles=28482039 retired=27236534 full_retirement_trace=identical full_cycle_interface=identical uart=identical exit=0',flush=True)

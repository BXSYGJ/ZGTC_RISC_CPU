﻿[CmdletBinding()]
param()
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$env:WSL_UTF8 = '1'
$ErrorActionPreference = 'Stop'
try {
    $rollbackPath = [System.IO.Path]::Combine($PSScriptRoot,'ROLLBACK.sh')
    $rollbackLines = @(
        '#!/usr/bin/env pwsh',
        '[CmdletBinding()]',
        'param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)',
        '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8',
        '$OutputEncoding = [System.Text.UTF8Encoding]::new($true)',
        '$ErrorActionPreference = ''Stop''',
        'try {',
        '    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)',
        '    $target = [System.IO.Path]::GetFullPath($TargetPath)',
        '    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw ''Target file missing'' }',
        '    Copy-Item -LiteralPath $baseline -Destination $target -Force',
        '    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash',
        '    if ($hash -ne ''C9D73D59E80A70399DF214DFBBE3316083E6DF0D33974E1564795A4AE875D6C1'') { throw ''Restored source hash differs'' }',
        '    Write-Output (''CACHE_HIT_ROLLBACK_PASS SHA256='' + $hash)',
        '    exit 0',
        '} catch { Write-Error $_; exit 1 }'
    )
    [System.IO.File]::WriteAllLines($rollbackPath,$rollbackLines,[System.Text.UTF8Encoding]::new($true))
    $modifiedPath = [System.IO.Path]::Combine($PSScriptRoot,'rv32_cache.sv')
    $restorePath = [System.IO.Path]::Combine($PSScriptRoot,'rollback_test.sv')
    Copy-Item -LiteralPath $modifiedPath -Destination $restorePath -Force
    $baselinePath = [System.IO.Path]::Combine($PSScriptRoot,'BASELINE_FILE.sv')
    $rollbackCommand = '& { param($scriptPath,$targetPath,$baselinePath) $body = [System.IO.File]::ReadAllText($scriptPath); $scriptBlock = [scriptblock]::Create($body); & $scriptBlock -TargetPath $targetPath -BaselinePath $baselinePath }'
    $rollbackOutput = & pwsh.exe -NoProfile -Command $rollbackCommand $rollbackPath $restorePath $baselinePath 2>&1 | ForEach-Object { $_.ToString() }
    $rollbackExit = $LASTEXITCODE
    if ($rollbackExit -ne 0) { throw ($rollbackOutput -join [Environment]::NewLine) }
    $rollbackRecord = [ordered]@{Command=('pwsh.exe -NoProfile -Command ' + $rollbackCommand);Arguments=@($rollbackPath,$restorePath,$baselinePath);Input='Separate copy of modified cache';LiteralOutput=($rollbackOutput -join [Environment]::NewLine);ExitStatus=$rollbackExit;RestoredSHA256=(Get-FileHash -LiteralPath $restorePath -Algorithm SHA256).Hash}
    [System.IO.File]::WriteAllText([System.IO.Path]::Combine($PSScriptRoot,'ROLLBACK_RESULT.json'),($rollbackRecord | ConvertTo-Json -Depth 5),[System.Text.UTF8Encoding]::new($true))
    $linuxRoot = '/mnt/d/AAAFPGA/ZGTC_RISC_CPU/pds_minimal_blink_200h/pacerv_h3_optimization/rtl_proposals/timing_cache_hit_fanout'
    & wsl.exe -d Ubuntu-22.04 --cd / --exec chmod +x ($linuxRoot + '/ROLLBACK.sh')
    if ($LASTEXITCODE -ne 0) { throw 'Rollback executable mode failed' }
    & wsl.exe -d Ubuntu-22.04 --cd / --exec python3 ($linuxRoot + '/verify.py')
    if ($LASTEXITCODE -ne 0) { throw 'Verification failed' }
    foreach ($name in @('rv32_cache.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')) {
        $path = [System.IO.Path]::Combine($PSScriptRoot,$name)
        if ([string]::IsNullOrWhiteSpace([System.IO.File]::ReadAllText($path))) { throw ('Empty artifact: '+$path) }
    }
} catch { Write-Error $_; exit 1 }

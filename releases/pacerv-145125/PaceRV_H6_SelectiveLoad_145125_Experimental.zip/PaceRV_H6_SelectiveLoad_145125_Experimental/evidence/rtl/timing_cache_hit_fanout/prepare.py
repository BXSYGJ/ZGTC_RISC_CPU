"""Replace cache tag equality carry chains with kept two-bit equality groups."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
SOURCE=ROOT/'candidates'/'id_equal_load_alu_history6'/'rtl'
original=(SOURCE/'rv32_cache.sv').read_bytes()
baseline=original.decode('utf-8-sig')
assert hashlib.sha256(original).hexdigest()=='c9d73d59e80a70399df214dfbbe3316083e6df0d33974e1564795a4ae875d6c1'
before='''    wire hit0=lookup_valid0 && lookup_tag0==request_tag;
    wire hit1=lookup_valid1 && lookup_tag1==request_tag;'''
after='''    // Keep each small tag comparison as a separate LUT cone so the final
    // hit predicate can be replicated without duplicating a carry chain.
    localparam integer HIT_COMPARE_GROUPS=(TAG_BITS+1)/2;
    (* syn_keep=1 *) wire [HIT_COMPARE_GROUPS-1:0] hit0_tag_groups,hit1_tag_groups;
    genvar hit_group;
    generate for(hit_group=0;hit_group<HIT_COMPARE_GROUPS;hit_group=hit_group+1) begin : hit_compare
        localparam integer SLICE_WIDTH=(TAG_BITS-2*hit_group)>=2 ? 2 : 1;
        assign hit0_tag_groups[hit_group]=lookup_tag0[2*hit_group +: SLICE_WIDTH]==request_tag[2*hit_group +: SLICE_WIDTH];
        assign hit1_tag_groups[hit_group]=lookup_tag1[2*hit_group +: SLICE_WIDTH]==request_tag[2*hit_group +: SLICE_WIDTH];
    end endgenerate
    (* syn_keep=1,syn_maxfan=8 *) wire hit0=lookup_valid0 && (&hit0_tag_groups);
    (* syn_keep=1,syn_maxfan=8 *) wire hit1=lookup_valid1 && (&hit1_tag_groups);'''
assert baseline.count(before)==1
candidate=baseline.replace(before,after)
assert candidate.replace(after,before).encode('utf-8')==original
(AREA/'BASELINE_FILE.sv').write_bytes(original)
(AREA/'rv32_cache.sv').write_bytes(candidate.encode('utf-8'))
(AREA/'DIFF_FILE.diff').write_text(''.join(difflib.unified_diff(baseline.splitlines(True),candidate.splitlines(True),fromfile='BASELINE_FILE.sv',tofile='rv32_cache.sv')),encoding='utf-8')
rtl=ROOT/'candidates'/'timing_cache_hit_fanout'/'rtl'
physical=ROOT/'candidates'/'timing_cache_hit_fanout'/'physical_rtl'
rtl.mkdir(parents=True,exist_ok=True)
physical.mkdir(parents=True,exist_ok=True)
for path in SOURCE.glob('*.sv'):
    shutil.copy2(AREA/path.name if path.name=='rv32_cache.sv' else path,rtl/path.name)
original_physical=ROOT/'work'/'physical-noif-nocross-loadalu-history6-local-s1'/'inputs'/'rtl'
for path in original_physical.glob('*.sv'):
    shutil.copy2(AREA/path.name if path.name=='rv32_cache.sv' else path,physical/path.name)
assert len(list(physical.glob('*.sv')))==18
change=dict(baseline=str(SOURCE/'rv32_cache.sv'),baseline_sha256=hashlib.sha256(original).hexdigest(),modified_sha256=hashlib.sha256(candidate.encode('utf-8')).hexdigest(),changed_field='hit0/hit1 equality: kept two-bit tag groups, reduction AND plus lookup_valid, final syn_keep=1 and syn_maxfan=8',exact_inverse_restores_source=True,rtl_directory=str(rtl),physical_rtl_directory=str(physical),before=before,after=after)
(AREA/'CHANGE.json').write_text(json.dumps(change,indent=2),encoding='utf-8')
tests=ROOT.parents[1]/'cpu'/'sim'
for name in ('cache_tb.sv','cache_error_bounds_tb.sv'):
    text=(tests/name).read_text(encoding='utf-8-sig')
    # Existing scalar cache tests predate the companion fetch input. Bind the
    # new unused input explicitly; all behavior/checks are the existing tests.
    anchor='    reg [31:0] req_address=0,req_data=0;'
    assert text.count(anchor)==1
    text=text.replace(anchor,anchor+'\n    wire [31:0] req_pair_address=req_address+32\'d4;\n    wire [31:0] rsp_pair_data;\n    wire [1:0] rsp_is_c,rsp_pair_is_c;\n    wire rsp_pair_valid;')
    if name=='cache_error_bounds_tb.sv':
        # Native cache dirty bits for invalid lines can remain X. Snapshot
        # preservation therefore requires case equality, as its existing LRU
        # check already does; binary equality rejects identical X snapshots.
        snapshot='cache.valid==saved_valid && cache.dirty==saved_dirty'
        assert text.count(snapshot)==1
        text=text.replace(snapshot,'cache.valid===saved_valid && cache.dirty===saved_dirty')
    (AREA/name).write_text(text,encoding='utf-8')
shutil.copy2(AREA.parent/'timing_ex_fetch_fanout8'/'core_token_tb.sv',AREA/'core_token_tb.sv')
# Miter uses exactly the selected comparator block. No cache state assumptions
# enter its proof; the tag and valid values are independent input bits.
head='module cache_hit_groups #(parameter TAG_BITS=6) (input wire [TAG_BITS-1:0] lookup_tag0,lookup_tag1,request_tag,input wire lookup_valid0,lookup_valid1,output wire hit0,hit1);\n'
group=after.replace('    (* syn_keep=1,syn_maxfan=8 *) wire hit0=','    assign hit0=').replace('    (* syn_keep=1,syn_maxfan=8 *) wire hit1=','    assign hit1=')
(AREA/'cache_hit_groups.sv').write_text(head+group+'\nendmodule\n',encoding='utf-8')
(AREA/'cache_hit_miter.sv').write_text('''module cache_hit_miter #(parameter TAG_BITS=6)(input wire [TAG_BITS-1:0] lookup_tag0,lookup_tag1,request_tag,input wire lookup_valid0,lookup_valid1,output wire same);
wire hit0,hit1;
cache_hit_groups #(.TAG_BITS(TAG_BITS)) dut(.lookup_tag0(lookup_tag0),.lookup_tag1(lookup_tag1),.request_tag(request_tag),.lookup_valid0(lookup_valid0),.lookup_valid1(lookup_valid1),.hit0(hit0),.hit1(hit1));
wire reference0=lookup_valid0 && lookup_tag0==request_tag;
wire reference1=lookup_valid1 && lookup_tag1==request_tag;
assign same=(hit0==reference0) && (hit1==reference1);
endmodule
''',encoding='utf-8')
(AREA/'cache_hit_four_state_tb.sv').write_text('''module cache_hit_four_state_tb;
parameter TAG_BITS=6;
reg [TAG_BITS-1:0] lookup_tag0,lookup_tag1,request_tag;
reg lookup_valid0,lookup_valid1;
wire hit0,hit1;
cache_hit_groups #(.TAG_BITS(TAG_BITS)) dut(.*);
wire reference0=lookup_valid0 && lookup_tag0==request_tag;
wire reference1=lookup_valid1 && lookup_tag1==request_tag;
integer checks=0,i,k,j;
task check; begin #1; if(hit0!==reference0 || hit1!==reference1) $fatal(1,"Cache group comparison mismatch width=%0d case=%0d",TAG_BITS,checks); checks=checks+1; end endtask
initial begin
for(i=0;i<10000;i=i+1) begin
lookup_tag0=$random;lookup_tag1=$random;request_tag=$random;lookup_valid0=$random;lookup_valid1=$random;check;
end
for(i=0;i<10000;i=i+1) begin
lookup_tag0=$random;lookup_tag1=$random;request_tag=$random;lookup_valid0=$random;lookup_valid1=$random;
for(k=0;k<TAG_BITS;k=k+1) begin
if(($random & 3)==0) lookup_tag0[k]=($random & 1) ? 1'bx : 1'bz;
if(($random & 3)==0) lookup_tag1[k]=($random & 1) ? 1'bx : 1'bz;
if(($random & 3)==0) request_tag[k]=($random & 1) ? 1'bx : 1'bz;
end
if(($random & 3)==0) lookup_valid0=($random & 1) ? 1'bx : 1'bz;
if(($random & 3)==0) lookup_valid1=($random & 1) ? 1'bx : 1'bz;
check;
end
$display("CACHE_GROUP_FOUR_STATE_PASS width=%0d cases=%0d",TAG_BITS,checks);$finish;
end
endmodule
''',encoding='utf-8')
print('CACHE_HIT_GROUPS_PREPARED '+change['modified_sha256'])

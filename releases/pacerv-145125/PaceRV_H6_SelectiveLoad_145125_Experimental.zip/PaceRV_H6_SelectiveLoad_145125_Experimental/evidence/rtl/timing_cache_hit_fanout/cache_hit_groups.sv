module cache_hit_groups #(parameter TAG_BITS=6) (input wire [TAG_BITS-1:0] lookup_tag0,lookup_tag1,request_tag,input wire lookup_valid0,lookup_valid1,output wire hit0,hit1);
    // Keep each small tag comparison as a separate LUT cone so the final
    // hit predicate can be replicated without duplicating a carry chain.
    localparam integer HIT_COMPARE_GROUPS=(TAG_BITS+1)/2;
    (* syn_keep=1 *) wire [HIT_COMPARE_GROUPS-1:0] hit0_tag_groups,hit1_tag_groups;
    genvar hit_group;
    generate for(hit_group=0;hit_group<HIT_COMPARE_GROUPS;hit_group=hit_group+1) begin : hit_compare
        localparam integer SLICE_WIDTH=(TAG_BITS-2*hit_group)>=2 ? 2 : 1;
        assign hit0_tag_groups[hit_group]=lookup_tag0[2*hit_group +: SLICE_WIDTH]==request_tag[2*hit_group +: SLICE_WIDTH];
        assign hit1_tag_groups[hit_group]=lookup_tag1[2*hit_group +: SLICE_WIDTH]==request_tag[2*hit_group +: SLICE_WIDTH];
    end endgenerate
    assign hit0=lookup_valid0 && (&hit0_tag_groups);
    assign hit1=lookup_valid1 && (&hit1_tag_groups);
endmodule

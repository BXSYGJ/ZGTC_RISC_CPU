"""Read the terminal routed result and attach its exact evidence to the proposal."""
from pathlib import Path
import hashlib
import json
import re

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
BUILD=ROOT/'work'/'cf5-physical-cache-hit-fanout-local-s1'
result=json.loads((BUILD/'BUILD_RESULT.json').read_text(encoding='utf-8-sig'))
assert result['Status']=='completed_timing_fail'
timing=result['Timing']
report=BUILD/'implementation'/'report_timing'/'pds_soc_top.rtr'
text=report.read_text(encoding='utf-8-sig')
assert hashlib.sha256(report.read_bytes()).hexdigest().upper()==timing['ReportSHA256'].upper()
slow=timing['Checks']['Setup_Slow'][0]
assert slow['WorstSlackNs']==-0.799 and slow['FailingEndpoints']==422
others={key:value for key,value in timing['Checks'].items() if key!='Setup_Slow'}
assert len(others)==9 and all(row['WorstSlackNs']>=0 and row['FailingEndpoints']==0 for rows in others.values() for row in rows)
invocation=json.loads((BUILD/'implementation'/'INVOCATION.json').read_text(encoding='utf-8-sig'))
assert invocation['ExitStatus']==0
bit=Path(result['Bitstream']['Path'])
assert hashlib.sha256(bit.read_bytes()).hexdigest().upper()==result['Bitstream']['SHA256'].upper()
first=text[text.index('Startpoint  :'):]
first=first[:first.index('Slack (VIOLATED)')+80]
record=dict(status=result['Status'],configured_hz=result['ConfiguredCpuClockHz'],uncertainty_ns=result['SetupUncertaintyNs'],slow_setup=slow,other_nine_checks_pass=True,actual_tool_exit_status=invocation['ExitStatus'],actual_command=invocation,report=str(report),report_sha256=timing['ReportSHA256'],worst_path=first,bitstream=result['Bitstream'],resources=result['Resources'],native_mapping='Kept2bit tag groups and final plain LUT hit logic, followed by identity LUT1 maxfan buffers; worst path passes hit1_1_buf',comparison_original_highscore_wns_ns=-0.218,conclusion='Grouped cache comparator and buffer fanout representation is functionally exact but worsens this routed result to -0.799ns. Keep original final highscore seed1 as smaller-violation implementation; no additional seed selected by this agent.')
(AREA/'ROUTED_RESULT.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
verification=json.loads((AREA/'VERIFICATION.txt').read_text(encoding='utf-8-sig'))
verification['native_mapping_audit']['MeasuredStatus']='Synthesis and final routed timing measured; see ROUTED_RESULT.json'
verification['routed_physical_result']=record
(AREA/'VERIFICATION.txt').write_text(json.dumps(verification,indent=2),encoding='utf-8-sig')
status=(AREA/'STATUS.md').read_text(encoding='utf-8-sig')
status=status.replace('Status: READY_VERIFIED_FOR_PHYSICAL_BUILD','Status: PHYSICAL_COMPLETE_TIMING_FAIL')
status+='\nFinal physical route completed_timing_fail actualtool exit0;145.125MHz/0.150ns unchanged. WNS-0.799ns TNS-93.743ns failing422; allnineotherchecks pass. Worstpath Dcachetaggroup->hit1->identitybuffer->EX/FETCH->frontend->IcachepairRADDR,11levels logic1.938ns route5.258ns.\n'
status+='Original final highscore seed1 WNS-0.218 remains smaller violation. Candidate/source/equivalence artifacts retained; no new seed or source edit started.\n'
(AREA/'STATUS.md').write_text(status,encoding='utf-8-sig')
for name in ['rv32_cache.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh','ROUTED_RESULT.json','STATUS.md']:
    assert (AREA/name).read_bytes()
print('CACHE_ROUTED_RESULT_VERIFIED status=completed_timing_fail WNS=-0.799 TNS=-93.743 failing=422 other_checks=9 exit=0')

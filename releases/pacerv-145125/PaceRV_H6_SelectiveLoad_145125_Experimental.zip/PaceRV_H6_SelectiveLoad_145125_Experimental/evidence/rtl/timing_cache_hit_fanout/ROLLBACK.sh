﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)
    $target = [System.IO.Path]::GetFullPath($TargetPath)
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Target file missing' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($hash -ne 'C9D73D59E80A70399DF214DFBBE3316083E6DF0D33974E1564795A4AE875D6C1') { throw 'Restored source hash differs' }
    Write-Output ('CACHE_HIT_ROLLBACK_PASS SHA256=' + $hash)
    exit 0
} catch { Write-Error $_; exit 1 }

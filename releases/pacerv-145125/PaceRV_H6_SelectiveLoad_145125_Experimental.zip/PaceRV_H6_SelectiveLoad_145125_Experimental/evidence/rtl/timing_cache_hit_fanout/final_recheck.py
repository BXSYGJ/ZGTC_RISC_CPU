"""Bind logical candidate, physical overlay, original inventory and test inputs."""
from pathlib import Path
import difflib
import hashlib
import json

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
SOURCE=ROOT/'candidates'/'id_equal_load_alu_history6'/'rtl'
CANDIDATE=ROOT/'candidates'/'timing_cache_hit_fanout'/'rtl'
ORIGINAL_PHYSICAL=ROOT/'work'/'physical-noif-nocross-loadalu-history6-local-s1'/'inputs'/'rtl'
PHYSICAL=ROOT/'candidates'/'timing_cache_hit_fanout'/'physical_rtl'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
modified=[]
source_records=[]
for path in sorted(SOURCE.glob('*.sv')):
    new=CANDIDATE/path.name
    if path.read_bytes()!=new.read_bytes():
        modified.append(path.name)
    source_records.append(dict(name=path.name,baseline_sha256=sha(path),candidate_sha256=sha(new)))
assert modified==['rv32_cache.sv']
physical_records=[]
physical_modified=[]
for path in sorted(ORIGINAL_PHYSICAL.glob('*.sv')):
    new=PHYSICAL/path.name
    if path.read_bytes()!=new.read_bytes():
        physical_modified.append(path.name)
    if (CANDIDATE/path.name).exists():
        assert new.read_bytes()==(CANDIDATE/path.name).read_bytes()
    physical_records.append(dict(name=path.name,baseline_sha256=sha(path),candidate_sha256=sha(new)))
assert len(physical_records)==18 and physical_modified==['rv32_cache.sv']
frozen=json.loads((ROOT/'EXPERIMENT.json').read_text(encoding='utf-8-sig'))['BaselineFiles']
for item in frozen:
    assert sha(ROOT/item['Path']).upper()==item['SHA256'].upper(),item['Path']
test_inputs=[]
tests=ROOT.parents[1]/'cpu'/'sim'
for name in ['cache_tb.sv','cache_error_bounds_tb.sv']:
    old=(tests/name).read_text(encoding='utf-8-sig')
    new=(AREA/name).read_text(encoding='utf-8-sig')
    test_inputs.append(dict(original=str(tests/name),original_sha256=sha(tests/name),local=str(AREA/name),local_sha256=sha(AREA/name),diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/'+name,tofile='local/'+name))))
    inverse=new.replace('\n    wire [31:0] req_pair_address=req_address+32\'d4;\n    wire [31:0] rsp_pair_data;\n    wire [1:0] rsp_is_c,rsp_pair_is_c;\n    wire rsp_pair_valid;','')
    if name=='cache_error_bounds_tb.sv':
        inverse=inverse.replace('cache.valid===saved_valid && cache.dirty===saved_dirty','cache.valid==saved_valid && cache.dirty==saved_dirty')
    assert inverse==old
record=dict(logical_source_files=len(source_records),logical_only_changed=modified,physical_source_files=len(physical_records),physical_only_changed=physical_modified,logical_inputs=source_records,physical_inputs=physical_records,frozen_files_verified=len(frozen),test_input_adaptations=test_inputs,test_adaptation_rationale='Existing cache tests predate companion ports, now bound explicitly. Bounds snapshot uses case equality to preserve identical native invalid-line dirty X values; original prior failure log retained. No cache behavior assertions are removed.',new_candidate_only='Cache hit comparator representation and synthesis keep/maxfan attributes',core_frontend_predictor_unchanged=True)
(AREA/'FINAL_RECHECK.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
for name in ['rv32_cache.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh','FINAL_RECHECK.json']:
    assert (AREA/name).read_bytes()
print('CACHE_HIT_FINAL_RECHECK_PASS logical_files=17 physical_files=18 only_changed=rv32_cache.sv frozen_files=182')

"""Reuse the already verified PowerShell launcher and trace harness patterns."""
from pathlib import Path
AREA=Path(__file__).resolve().parent
old=AREA.parent/'timing_frontend_flat'
text=(old/'Verify.ps1').read_text(encoding='utf-8-sig')
text=text.replace('210B5BA9280C3840AAFC27E7C3E35616085EFDE310793DC1661CC72F50984128','C9D73D59E80A70399DF214DFBBE3316083E6DF0D33974E1564795A4AE875D6C1')
text=text.replace('FRONTEND_ROLLBACK_PASS','CACHE_HIT_ROLLBACK_PASS').replace('rv32_rvc_frontend.sv','rv32_cache.sv').replace('timing_frontend_flat','timing_cache_hit_fanout').replace('modified frontend','modified cache').replace('Frontend','Cache')
(AREA/'Verify.ps1').write_text(text,encoding='utf-8-sig')
text=(old/'benchmark_equivalence.py').read_text(encoding='utf-8-sig')
text=text.replace('rv32_rvc_frontend.sv','rv32_cache.sv').replace('timing_frontend_flat','timing_cache_hit_fanout').replace('Frontend complete parallel case-decode request select','Cache kept two-bit equality groups and maxfan8 hit').replace('FRONTEND_','CACHE_HIT_').replace('frontend','cache')
(AREA/'benchmark_equivalence.py').write_text(text,encoding='utf-8')
print('CACHE_HIT_SCRIPTS_PREPARED')

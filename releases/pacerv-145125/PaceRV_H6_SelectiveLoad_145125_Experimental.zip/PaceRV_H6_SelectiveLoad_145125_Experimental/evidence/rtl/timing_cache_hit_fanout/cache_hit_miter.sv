module cache_hit_miter #(parameter TAG_BITS=6)(input wire [TAG_BITS-1:0] lookup_tag0,lookup_tag1,request_tag,input wire lookup_valid0,lookup_valid1,output wire same);
wire hit0,hit1;
cache_hit_groups #(.TAG_BITS(TAG_BITS)) dut(.lookup_tag0(lookup_tag0),.lookup_tag1(lookup_tag1),.request_tag(request_tag),.lookup_valid0(lookup_valid0),.lookup_valid1(lookup_valid1),.hit0(hit0),.hit1(hit1));
wire reference0=lookup_valid0 && lookup_tag0==request_tag;
wire reference1=lookup_valid1 && lookup_tag1==request_tag;
assign same=(hit0==reference0) && (hit1==reference1);
endmodule

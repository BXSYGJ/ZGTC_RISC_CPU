"""Check generic cache comparator equivalence and existing full cache behavior."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
SOURCE=ROOT/'candidates'/'id_equal_load_alu_history6'/'rtl'
change=json.loads((AREA/'CHANGE.json').read_text(encoding='utf-8-sig'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def run(argv,label):
    start=time.monotonic()
    result=subprocess.run(argv,cwd=AREA,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240)
    (AREA/(label+'.log')).write_text(result.stdout,encoding='utf-8')
    record=dict(command=argv,input_directory=str(AREA),literal_output=result.stdout,exit_status=result.returncode,seconds=time.monotonic()-start)
    if result.returncode:
        raise RuntimeError(f'{label} exit={result.returncode}: {result.stdout[-3000:]}')
    return record
formal=[]
four=[]
for width in [1,2,3,6,7,16,28]:
    expression=f'read_verilog -sv cache_hit_groups.sv cache_hit_miter.sv; chparam -set TAG_BITS {width} cache_hit_miter; prep -top cache_hit_miter -flatten; sat -verify -prove same 1 -show-inputs'
    record=run(['yosys','-p',expression],f'formal-{width}')
    assert 'SAT proof finished - no model found: SUCCESS!' in record['literal_output']
    formal.append(record)
    run(['iverilog','-g2012','-s','cache_hit_four_state_tb',f'-Pcache_hit_four_state_tb.TAG_BITS={width}','-o',f'four-state-{width}.vvp','cache_hit_groups.sv','cache_hit_four_state_tb.sv'],f'four-state-{width}-compile')
    record=run(['vvp',f'four-state-{width}.vvp'],f'four-state-{width}')
    assert f'CACHE_GROUP_FOUR_STATE_PASS width={width} cases=20000' in record['literal_output']
    four.append(record)
print('CACHE_HIT_FORMAL_PASS widths=1,2,3,6,7,16,28 all_binary_inputs=unconstrained',flush=True)
print('CACHE_HIT_FOUR_STATE_PASS widths=7 cases=140000',flush=True)

common=[str(p) for p in sorted(SOURCE.glob('*.sv')) if p.name!='rv32_cache.sv']
core=[]
cache=[]
baseline_core_trace=None
cache_outputs={}
tests=[('rw-fast-packed','cache_tb',{'ADDRESS_BITS':16,'READONLY':0,'FAST_READ_HIT':1,'FAST_WRITE_HIT':1,'READ_OVERLAP':1,'CACHE_SET_BITS':6,'GEOMETRY_STREAM':1}),('ro-fast','cache_tb',{'ADDRESS_BITS':16,'READONLY':1,'FAST_READ_HIT':1,'READ_OVERLAP':1,'CACHE_SET_BITS':9,'GEOMETRY_STREAM':1}),('rw-bounds','cache_error_bounds_tb',{}),('ro-bounds','cache_error_bounds_tb',{'READ_ONLY':1,'SET_BITS':4})]
for variant,file in [('BASELINE','BASELINE_FILE.sv'),('MODIFIED','rv32_cache.sv'),('ROLLBACK','rollback_test.sv')]:
    binary=variant.lower()+'-core.vvp'
    compile_record=run(['iverilog','-g2012','-s','core_token_tb','-o',binary,'core_token_tb.sv',file,*common],variant.lower()+'-core-compile')
    record=run(['vvp',binary],variant.lower()+'-core')
    assert 'CORE_TOKEN_PASS early=1 mode=1 scenarios=23' in record['literal_output']
    trace=[line for line in record['literal_output'].splitlines() if line.startswith(('CYCLE ','ARCH ','TRAP ','CORE_CASE_PASS '))]
    if baseline_core_trace is None:
        baseline_core_trace=trace
    assert trace==baseline_core_trace
    core.append(dict(name=variant,source=file,source_sha256=sha(AREA/file),compile=compile_record,run=record,trace_lines=len(trace)))
    for label,top,params in tests:
        binary=f'{variant.lower()}-{label}.vvp'
        argv=['iverilog','-g2012','-s',top,'-o',binary,*[f'-P{top}.{key}={value}' for key,value in params.items()],top+'.sv',file,str(SOURCE/'rv32_burst_ram.sv')]
        compilation=run(argv,f'{variant.lower()}-{label}-compile')
        record=run(['vvp',binary],f'{variant.lower()}-{label}')
        assert 'PASS ' in record['literal_output']
        if variant=='BASELINE':
            cache_outputs[label]=record['literal_output']
        assert record['literal_output']==cache_outputs[label],label+' differs'
        cache.append(dict(name=variant,label=label,source=file,compile=compilation,run=record))
    print(variant+' CORE_TOKEN_PASS scenarios=23 CACHE_BEHAVIOR_PASS configs=4 exit=0',flush=True)
assert sha(SOURCE/'rv32_cache.sv')==change['baseline_sha256']
assert sha(AREA/'rv32_cache.sv')==change['modified_sha256']
assert sha(AREA/'rollback_test.sv')==change['baseline_sha256']
assert (AREA/'rv32_cache.sv').read_text().replace(change['after'],change['before']).encode('utf-8')==(AREA/'BASELINE_FILE.sv').read_bytes()
evidence=dict(changed_field=change['changed_field'],MODIFIED_FILE=str(AREA/'rv32_cache.sv'),DIFF_FILE=str(AREA/'DIFF_FILE.diff'),VERIFICATION=str(AREA/'VERIFICATION.txt'),ROLLBACK=str(AREA/'ROLLBACK.sh'),baseline_sha256=change['baseline_sha256'],modified_sha256=change['modified_sha256'],exact_inverse_restores_source=True,formal_tests=formal,four_state_tests=four,core_tests=core,cache_behavior_tests=cache,rollback_test_action=json.loads((AREA/'ROLLBACK_RESULT.json').read_text(encoding='utf-8-sig')),restored_behavior='Original cache source bytes and all4 cache behavior outputs restored on separate copy; all23 core cycle/architecture traces match; active candidate retains modified hash')
(AREA/'VERIFICATION.txt').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
summary=dict(formal_widths=[1,2,3,6,7,16,28],four_state_cases=140000,core_scenarios=23,core_trace_lines=len(baseline_core_trace),cache_configs_per_variant=4,baseline_modified_rollback_equal=True)
(AREA/'DIRECTED_EQUIVALENCE.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print('CACHE_HIT_DIRECTED_EQUIVALENCE_PASS formal=7 four_state=140000 scenarios=23 cache_configs=4 BASELINE/MODIFIED/ROLLBACK exit=0',flush=True)

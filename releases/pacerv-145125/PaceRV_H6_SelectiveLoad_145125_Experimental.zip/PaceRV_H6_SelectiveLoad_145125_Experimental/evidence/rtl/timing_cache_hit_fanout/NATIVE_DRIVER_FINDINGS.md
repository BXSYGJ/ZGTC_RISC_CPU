# Cache hit native-driver findings

Original hit0/hit1 are LUT6CARRY Z outputs driven by equality carry chains. Earlier ID equality output of the same primitive class was not replicated when maxfan8 was applied. A cache-specific maxfan synthesis outcome has not yet been measured. Await root selection before implementing an attribute-only candidate or an explicit comparator change.

Original netlist SHA256: `409821ade0d75a3050baa8efe9bbce3685b516b7bf60b1f8e5d5472bd2c61966`

## rv32_cache_1.hit0
Primitive: GTP_LUT6CARRY; original netlist line 94537; CIN connected; module-local primitive input connections 2.
```verilog
    GTP_LUT6CARRY /* \N7.eq_2  */ #(
            .INIT(64'b1001000000001001000000000000000000000000000000000000000000000000), 
            .I5_TO_CARRY("FALSE"), 
            .I5_TO_LUT("FALSE"))
        \N7.eq_2  (
            .COUT (),
            .Z (hit0),
            .CIN (\N7.co [2] ),
            .I0 (request_address[14]),
            .I1 (lookup_tag0[4]),
            .I2 (request_address[15]),
            .I3 (lookup_tag0[5]),
            .I4 (lookup_valid0),
            .I5 ());
```

## rv32_cache_1.hit1
Primitive: GTP_LUT6CARRY; original netlist line 94591; CIN connected; module-local primitive input connections 42.
```verilog
    GTP_LUT6CARRY /* \N9.eq_2  */ #(
            .INIT(64'b1001000000001001000000000000000000000000000000000000000000000000), 
            .I5_TO_CARRY("FALSE"), 
            .I5_TO_LUT("FALSE"))
        \N9.eq_2  (
            .COUT (),
            .Z (hit1),
            .CIN (\N9.co [2] ),
            .I0 (request_address[14]),
            .I1 (lookup_tag1[4]),
            .I2 (request_address[15]),
            .I3 (lookup_tag1[5]),
            .I4 (lookup_valid1),
            .I5 ());
```

## Actual earlier tool output

W: syn_maxfan of lutcarry board/soc/core/N434.eq_16 is more than 8 on net board/soc/core/id_zero_taken, but wasn't replicated.
W: syn_maxfan of lutcarry board/soc/core/N434.eq_16 is more than 8 on net board/soc/core/id_zero_taken, but wasn't replicated.
W: syn_maxfan of lutcarry board/soc/core/N434.eq_16 is more than 8 on net board/soc/core/id_zero_taken, but wasn't replicated.
W: syn_maxfan of lutcarry board/soc/core/N434.eq_16 is more than 8 on net board/soc/core/id_zero_taken, but wasn't replicated.
W: syn_maxfan of lutcarry N434.eq_16 is more than 10000 on net id_zero_taken, but wasn't replicated.
W: syn_maxfan of lutcarry N434.eq_16 is more than 10000 on net id_zero_taken, but wasn't replicated.

## Actual current routed fanout

net (fanout=49)       0.611       7.261         board/soc/memory_system/caches[0].enabled.cache_1/hit1
net (fanout=49)       0.611       7.261         board/soc/memory_system/caches[0].enabled.cache_1/hit1
net (fanout=49)       0.611       7.261         board/soc/memory_system/caches[0].enabled.cache_1/hit1

Cache source and prior files remain unchanged. No PDS probe was started.

"""Audit actual mapped cache group LUTs and distinguish buffers from replicas."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
HELPER=AREA.parent/'timing_id_equal_lut4'/'audit_native_replicas.py'
spec=importlib.util.spec_from_file_location('native_parser',HELPER)
p=importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
BUILD=ROOT/'work'/'cf5-physical-cache-hit-fanout-local-s1'
NET=BUILD/'implementation'/'netlist.v'
units=p.modules(NET.read_text(encoding='utf-8-sig'))
all_cells={name:p.cells(text) for name,text in units.items()}
instances=[]
for parent,text in units.items():
    for match in re.finditer(r'^    (\w+)\s+(\\\S+|\w+)\s*\([\s\S]*?;',text,re.M):
        if match.group(1) in units:
            connections={port:signal.strip() for port,signal in re.findall(r'\.([^\s()]+)\s*\(([^)]*)\)',match.group(0))}
            instances.append(dict(parent=parent,type=match.group(1),name=match.group(2),connections=connections))
def is_port(module,signal,direction):
    header=units[module].split(');',1)[0]
    return bool(re.search(r'\b'+direction+r'\s+(?:wire\s+|reg\s+)?(?:\[[^]]+\]\s*)?'+re.escape(signal)+r'\s*[,\n]',header))
def leaves(module,signal,seen=None):
    seen=set() if seen is None else seen
    if (module,signal) in seen:
        return []
    seen.add((module,signal))
    result=[]
    for cell in all_cells[module]:
        for pin,value in cell['pins'].items():
            if value==signal and re.fullmatch(r'I\d|CIN|D|CE|S|RADDR\d*|ADDR\d*',pin):
                result.append(module+'/'+cell['name']+'.'+pin)
    # Cache outputs can feed primitives in the memory-system parent. Expand
    # those typed output links, without counting the parent port as a leaf.
    if is_port(module,signal,'output'):
        for instance in instances:
            if instance['type']==module and signal in instance['connections']:
                result += leaves(instance['parent'],instance['connections'][signal],seen)
    for instance in instances:
        if instance['parent']==module:
            for port,value in instance['connections'].items():
                if value==signal and is_port(instance['type'],port,'input'):
                    result += leaves(instance['type'],port,seen)
    return sorted(set(result))

records=[]
for name,expected_groups in [('rv32_cache',2),('rv32_cache_1',3)]:
    cells=all_cells[name]
    groups=[cell for cell in cells if re.fullmatch(r'hit[01]_tag_groups\[\d+\]',cell['pins'].get('Z',''))]
    assert len(groups)==2*expected_groups,(name,len(groups))
    if name=='rv32_cache_1':
        assert all(cell['type']=='GTP_LUT4' for cell in groups)
    else:
        # The last odd I-cache tag bit is combined with its tag-source mux.
        # Record the actual output primitive rather than assuming LUT2.
        assert all(cell['type'] in ('GTP_LUT2','GTP_LUT4','GTP_MUX2LUT7') for cell in groups)
    signals=[cell for cell in cells if re.fullmatch(r'hit[01](?:_\d+)?',cell['pins'].get('Z',''))]
    hits=[]
    for driver in signals:
        signal=driver['pins']['Z']
        input_values={key:value for key,value in driver['pins'].items() if re.fullmatch(r'I\d|CIN',key)}
        is_buffer=driver['type']=='GTP_LUT1' and driver['init']=='10'
        leaf=leaves(name,signal)
        hits.append(dict(signal=signal,driver_type=driver['type'],driver=driver['name'],init=driver['init'],inputs=input_values,classification='identity_buffer' if is_buffer else 'root_hit_logic',primitive_consumers=leaf,primitive_consumer_count=len(leaf)))
    roots=[hit for hit in hits if hit['classification']=='root_hit_logic']
    assert {hit['signal'] for hit in roots}=={'hit0','hit1'}
    assert all(hit['driver_type'] in ('GTP_LUT3','GTP_LUT4','GTP_LUT5','GTP_LUT6') for hit in roots)
    buffers=[hit for hit in hits if hit['classification']=='identity_buffer']
    assert all(0<len(hit['primitive_consumers'])<=8 for hit in buffers)
    records.append(dict(module=name,expected_tag_groups=expected_groups,group_luts=groups,hit_drivers=hits,buffer_count=len(buffers),same_function_logic_replicas=0,root_hit_driver_has_carry_input=False,odd_tag_group_source='Icache oddgroup output merged with tag-source mux' if name=='rv32_cache' else 'All six Dcache two-bit comparison outputs are GTP_LUT4'))

frozen=json.loads((BUILD/'INPUT_HASHES.json').read_text(encoding='utf-8-sig'))
for entry in frozen:
    assert p.digest(BUILD/'inputs'/entry['RelativePath']).upper()==entry['SHA256'].upper(),entry['RelativePath']
assert p.digest(BUILD/'inputs'/'rtl'/'rv32_cache.sv')==p.digest(AREA/'rv32_cache.sv')
record=dict(result='NATIVE_CACHE_GROUP_MAPPING_VERIFIED',netlist=str(NET),netlist_sha256=p.digest(NET),physical_cache_sha256=p.digest(BUILD/'inputs'/'rtl'/'rv32_cache.sv'),source_binding='Exact modified cache source; all frozen physical input hashes rechecked',modules=records,interpretation='Tag equality carry chains have become kept small LUT groups and root hit LUTs. Maxfan8 was implemented with identity LUT1 buffers; no duplicate hit-function LUTs were generated. Root hit logic still precedes buffer delay. Routed timing must be assessed separately.')
(AREA/'NATIVE_MAPPING_AUDIT.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
md=['# Native cache mapping audit','',record['interpretation'],'',f'Netlist SHA256: `{record["netlist_sha256"]}`','']
for module in records:
    md += [f'## {module["module"]}',f'Kept group LUTs: {len(module["group_luts"])}; identity hit buffers: {module["buffer_count"]}; duplicate hit-function LUTs: 0.','', '| Signal | Primitive | Role | Primitive consumers |','|---|---|---|---:|']
    for hit in module['hit_drivers']:
        md.append(f'| {hit["signal"]} | {hit["driver_type"]} | {hit["classification"]} | {hit["primitive_consumer_count"]} |')
    md.append('')
(AREA/'NATIVE_MAPPING_AUDIT.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
for path in [AREA/'NATIVE_MAPPING_AUDIT.json',AREA/'NATIVE_MAPPING_AUDIT.md']:
    assert path.read_bytes()
print('NATIVE_CACHE_GROUP_MAPPING_VERIFIED group_outputs=10 dcache_group_lut4=6 root_hits=4 true_logic_replicas=0 identity_buffers='+str(sum(module['buffer_count'] for module in records))+' max_buffer_leaf_fanout=8 exit=0')

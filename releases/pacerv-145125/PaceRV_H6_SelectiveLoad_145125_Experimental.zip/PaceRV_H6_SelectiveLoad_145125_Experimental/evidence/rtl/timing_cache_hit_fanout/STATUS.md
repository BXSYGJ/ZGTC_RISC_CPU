﻿# Cache tag grouped comparison candidate
Status: PHYSICAL_COMPLETE_TIMING_FAIL
Baseline cache SHA256 C9D73D59E80A70399DF214DFBBE3316083E6DF0D33974E1564795A4AE875D6C1
Modified cache SHA256 FF4F453F2681E2B10F108789B96597F35DC2EC3946C48DD9ADF6CD748D1D53E4
Only cache hit0/hit1 comparator representation plus syn_keep/maxfan8 changed. No core/frontend/predictor/register modifications.
Use -RtlDirectory candidates/timing_cache_hit_fanout/physical_rtl (18files; original physical highscore inputs except cache only).
Group2bitcomparison each kept; generic finalodd1bitgroup; finalhit kept maxfan8. ActualDcache6tagbits=>3groups; Icache3tagbits=>2groups.
Formal7widths1,2,3,6,7,16,28 allbinaryinputs pass; fourstate140000 pass.
Core23 BASELINE/MODIFIED/ROLLBACK fulltrace equal; all4cacheconfigs for all3variants exactoutputequal exit0.
Cache RW64sets: PASS cache writable geometry sets=64 checks=55615 commands=763
Cache RO512sets: PASS cache geometry sets=512 checks=2292
RWbounds539checks and RObounds840checks pass. Tests exercise hits/refill/dirtywriteback/flush/readerror/writeerror/burstlength/addressrange/backpressure.
Full100CoreMark firmware unchanged; cycles28482039 retired27236534; fullretirement660073608bytes and fullinterface1154008520bytes and UART exactequal; exit0.
FullretirementSHA2566e80d074a15b4d27e74f6927031d78c92812d5f06ad358df50409e19bc8fa456
FullinterfaceSHA256ada07351738481787313ff032ca5bcbb720d619187856e8847347bb0058c2167
Rollback separatecopy restores baselinehash and exactbehavior; activecachemodifiedretained.
All182frozenbaselinefile hashes match; all18physical/17logicalRTL inventoried.
Four artifacts and evidence reopened. PowerShell7parse and UTF8BOM pass; ROLLBACK.sh is PowerShell.
No PDS started by this task. Root owns one synthesis/route and native LUT driver replication audit.
Test input portbinding and fourstatesnapshot adaptations fully recorded FINAL_RECHECK.json; oldcachebounds baselineXsnapshotfailure retained.

Native synthesis audit: exact cache/source binding verified, Dcache6LUT4groupoutputs, root4hits plainLUT3/6, maxfan8 realized by12identityLUT1buffers,0duplicatehitlogic. See NATIVE_MAPPING_AUDIT.json. Final route measured; see ROUTED_RESULT.json.

Final physical route completed_timing_fail actualtool exit0;145.125MHz/0.150ns unchanged. WNS-0.799ns TNS-93.743ns failing422; allnineotherchecks pass. Worstpath Dcachetaggroup->hit1->identitybuffer->EX/FETCH->frontend->IcachepairRADDR,11levels logic1.938ns route5.258ns.
Original final highscore seed1 WNS-0.218 remains smaller violation. Candidate/source/equivalence artifacts retained; no new seed or source edit started.

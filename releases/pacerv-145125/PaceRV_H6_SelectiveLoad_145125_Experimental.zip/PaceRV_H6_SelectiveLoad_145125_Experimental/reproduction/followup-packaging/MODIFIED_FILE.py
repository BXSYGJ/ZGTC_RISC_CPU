"""Package selected completed PaceRV runs with exact RTL and proof binding."""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import re
import sys

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from audit_results import audit_simulation, audit_physical, read_json, require, sha

spec = importlib.util.spec_from_file_location("preserved_package", AREA / "BASELINE_FILE.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT = ROOT
simulation_identity = base.simulation_identity
canonical_core = base.canonical_core
copy_file = base.copy_file
SUFFIXES = {".json", ".sv", ".v", ".ys", ".diff", ".txt", ".md", ".ps1", ".sh", ".py", ".log", ".tcl", ".rtr", ".prr"}


def cache_proof(area=None):
    area = area or ROOT / "rtl_proposals/timing_cache_hit_fanout"
    change = read_json(area / "CHANGE.json")
    before, after = area / "BASELINE_FILE.sv", area / "rv32_cache.sv"
    require(sha(before) == change["baseline_sha256"].lower() and sha(after) == change["modified_sha256"].lower(), "Cache proof source hashes")
    text = after.read_text(encoding="utf-8-sig")
    require(text.count(change["after"]) == 1 and text.replace(change["after"], change["before"]) == before.read_text(encoding="utf-8-sig"),
            "Cache exact inverse source transform")
    receipt = read_json(area / "VERIFICATION.txt")
    require(receipt["baseline_sha256"] == sha(before) and receipt["modified_sha256"] == sha(after), "Cache verification source binding")
    require(len(receipt["formal_tests"]) == len(receipt["four_state_tests"]) == 7, "Cache proof widths")
    for item in receipt["formal_tests"]:
        require(item["exit_status"] == 0 and "SAT proof finished - no model found: SUCCESS!" in item["literal_output"], "Cache SAT result")
    require(all(item["exit_status"] == 0 and "cases=20000" in item["literal_output"] for item in receipt["four_state_tests"]), "Cache four-state result")
    directed = read_json(area / "DIRECTED_EQUIVALENCE.json")
    require(directed["baseline_modified_rollback_equal"] and directed["core_scenarios"] == 23
            and directed["cache_configs_per_variant"] == 4 and directed["four_state_cases"] == 140000, "Cache directed equality")
    interface = read_json(area / "INTERFACE_EQUIVALENCE.json")
    a, b = interface["cached_baseline"], interface["modified"]
    require(a["exit_status"] == b["exit_status"] == interface["modified_build"]["exit_status"] == 0, "Cache interface status")
    for field in ("timed_cycles", "retired", "trace_sha256", "trace_bytes", "interface_sha256", "interface_bytes", "uart_sha256"):
        require(a[field] == b[field], "Cache interface equality: " + field)
    require(all(item["exit_status"] == 0 for item in interface["comparisons"].values()), "Cache comparison exits")
    require(interface["modified_build"]["input_sha256"]["rv32_cache.sv"] == sha(after)
            and interface["baseline_binding"]["source_inventory"]["rv32_cache.sv"] == sha(before), "Cache interface source binding")
    rollback = read_json(area / "ROLLBACK_RESULT.json")
    require(rollback["ExitStatus"] == 0 and rollback["RestoredSHA256"].lower() == sha(before), "Cache rollback result")
    return {"proposal": "timing_cache_hit_fanout", "baseline_sha256": sha(before), "modified_sha256": sha(after),
            "formal_widths": directed["formal_widths"], "four_state_cases": 140000, "interface_cycles": a["timed_cycles"],
            "trace_sha256": a["trace_sha256"], "interface_sha256": a["interface_sha256"]}


def simple_proof(core_hash):
    area = ROOT / "rtl_proposals/load_simple"
    change = read_json(area / "CHANGE.json")
    require(change["candidate_sha256"].lower() == core_hash == sha(area / "rv32_core.sv"), "Selective load source hash")
    directed = read_json(area / "DIRECTED_VERIFICATION.json")
    require(directed["architectural_match"] and directed["all_exit_zero"] and directed["formal_add_xor_all_inputs"]
            and directed["scenarios"] == 23 and directed["modified_sha256"].lower() == core_hash, "Selective load directed proof")
    decoder = read_json(area / "DECODER_CLASSIFICATION.json")
    require(decoder["exit_status"] == 0 and decoder["core_sha256"].lower() == core_hash
            and "SAT proof finished - no model found: SUCCESS!" in decoder["literal_output"], "Selective load decoder SAT")
    require(all(item["expected_failure_observed"] and item["exit_status"] != 0
                for item in read_json(area / "NEGATIVE_CONTROLS.json")), "Selective load negative controls")
    rollback = read_json(area / "ROLLBACK_SH_RESULT.json")
    require(rollback["exit_status"] == 0 and rollback["restored_sha256"].lower() == change["baseline_sha256"].lower(), "Selective load rollback")
    return {"proposal": "load_simple", "modified_sha256": core_hash, "scenarios": 23}


def core_proofs():
    area = ROOT / "rtl_proposals/timing_id_equal_lut4"
    proof = read_json(area / "FORMAL_EQUIVALENCE.json")
    require(proof["exit_status"] == 0 and proof["core_sha256"].lower() == sha(area / "rv32_core.sv"), "Core representation SAT binding")
    results = []
    for folder, name in (("timing_id_fanout8", "BENCHMARK_EQUIVALENCE.json"), ("timing_id_equal_lut4", "INTERFACE_EQUIVALENCE.json")):
        receipt = read_json(ROOT / "rtl_proposals" / folder / name)
        require(receipt["trace_comparison"]["exit_status"] == receipt["uart_comparison"]["exit_status"] == 0 and len(receipt["records"]) == 2, "Core comparison receipt")
        for field in ("timed_cycles", "retired", "trace_sha256", "uart_sha256"):
            require(receipt["records"][0][field] == receipt["records"][1][field], "Core representation equality: " + field)
        if "interface_comparison" in receipt:
            require(receipt["interface_comparison"]["exit_status"] == 0 and receipt["records"][0]["interface_sha256"]
                    == receipt["records"][1]["interface_sha256"], "Core interface equality")
        results.append({"proposal": folder, "receipt": name, "sha256": sha(ROOT / "rtl_proposals" / folder / name)})
    return results


def compare_rtl(simulation, actual):
    checks, proofs = [], []
    require(len(list(simulation.glob("*.sv"))) == 17, "Expected 17 simulation RTL files")
    for path in sorted(simulation.glob("*.sv")):
        other = actual / path.name
        require(other.is_file(), "Missing physical RTL " + path.name)
        same, binding = sha(path) == sha(other), "identical"
        if not same and path.name == "rv32_core.sv":
            require(canonical_core(path) == canonical_core(other), "Physical core changes exceed proven representation edits")
            proofs.extend(core_proofs())
            binding = "exact core normalization plus SAT and cycle/interface equivalence"
        elif not same and path.name == "rv32_cache.sv":
            proof = cache_proof()
            require({sha(path), sha(other)} == {proof["baseline_sha256"], proof["modified_sha256"]}, "Cache proof pair hash")
            proofs.append(proof)
            binding = "exact cache inverse plus SAT, four-state, directed and full-interface equivalence"
        else:
            require(same, "Unverified physical/simulation RTL mismatch: " + path.name)
        checks.append({"name": path.name, "simulation_sha256": sha(path), "physical_sha256": sha(other), "binding": binding})
    change = read_json(ROOT / "rtl_proposals/timing_cache_hit_fanout/CHANGE.json")
    if sha(actual / "rv32_cache.sv") == change["modified_sha256"] and not any(p["proposal"] == "timing_cache_hit_fanout" for p in proofs):
        proofs.append(cache_proof())
    change = read_json(ROOT / "rtl_proposals/load_simple/CHANGE.json")
    if sha(actual / "rv32_core.sv") == change["candidate_sha256"]:
        proofs.append(simple_proof(sha(actual / "rv32_core.sv")))
    return checks, proofs


def bind_rtl(v0, v1, physical_path):
    require(v0["rtl_sha256"] == v1["rtl_sha256"], "V0/V1 simulator identity")
    record = read_json(ROOT / "work" / v0["name"] / "RUN.json")
    candidates = [ROOT / "simulation/inputs/rtl"] + sorted((ROOT / "candidates").glob("*/rtl"))
    matches = [p for p in candidates if simulation_identity(p, record["load_use_bubble"]) == v0["rtl_sha256"]]
    require(matches, "Simulation identity has no frozen source directory")
    actual = physical_path / "inputs/rtl"
    matches.sort(key=lambda d: (sum(not (actual / p.name).is_file() or sha(p) != sha(actual / p.name) for p in d.glob("*.sv")), str(d)))
    checks, proofs = compare_rtl(matches[0], actual)
    return {"simulation_directory": str(matches[0]), "simulation_identity": v0["rtl_sha256"], "load_use_bubble": record["load_use_bubble"],
            "identical_source_directories": [str(p) for p in matches], "common_files": len(checks), "checks": checks, "proofs": proofs}


def copy_small(source, destination):
    if not source.is_dir():
        return
    for item in sorted(source.iterdir()):
        if item.is_file() and item.suffix.lower() in SUFFIXES and item.stat().st_size <= 32 * 1024 * 1024:
            copy_file(item, destination / item.name)


def validate_selection(v0_name, v1_name, physical_name, archive_failed):
    a, b, p = [ROOT / "work" / name for name in (v0_name, v1_name, physical_name)]
    v0, v1, physical = audit_simulation(a), audit_simulation(b), audit_physical(p)
    require(v0["role"] == "V0" and v1["role"] == "V1", "Role binding")
    require(v0["formal_ten_seconds"] and v1["formal_ten_seconds"] and v0["iterations"] == v1["iterations"] == 6000, "Both full 6000-iteration runs must pass")
    require(physical["status"].startswith("completed_"), "Physical build incomplete")
    passed = physical["all_ten_timing_checks_pass"]
    require(passed or archive_failed, "Physical timing must pass for a qualified release")
    require(not archive_failed or not passed, "Timing-fail archive requires an actually failed route")
    require(v0["firmware_sha256"] == physical["firmware_sha256"], "V0/physical firmware mismatch")
    for role, folder in (("V0", a), ("V1", b)):
        for relative, expected in read_json(folder / "BUILD.json")["source_hashes"].items():
            require(sha(ROOT / "firmware" / role / "inputs" / relative) == expected.lower(), "Firmware source mismatch: " + relative)
    return v0, v1, physical, bind_rtl(v0, v1, p)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("v0", "v1", "physical", "output"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--archive-timing-fail", action="store_true")
    args = parser.parse_args()
    for value in (args.v0, args.v1, args.physical, args.output):
        require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", value) is not None and value not in (".", ".."), "Expected a directory name")
    v0, v1, physical, binding = validate_selection(args.v0, args.v1, args.physical, args.archive_timing_fail)
    frozen = read_json(ROOT / "EXPERIMENT.json")["BaselineFiles"]
    for entry in frozen:
        require(sha(ROOT / entry["Path"]) == entry["SHA256"].lower(), "Frozen baseline changed: " + entry["Path"])
    base.bind_rtl = bind_rtl
    package_output = io.StringIO()
    with redirect_stdout(package_output):
        base.main()
    out = ROOT / "optimized_releases" / args.output
    for proposal in ("load_simple", "timing_cache_hit_fanout"):
        copy_small(ROOT / "rtl_proposals" / proposal, out / "evidence/rtl" / proposal)
    p = ROOT / "work" / args.physical
    for name in ("TIMING_SUMMARY.json", "Build-PacePds.snapshot.ps1"):
        copy_file(p / name, out / "evidence/physical" / name)
    copy_small(p / "synthesis", out / "evidence/physical/synthesis")
    for name in ("MODIFIED_FILE.py", "BASELINE_FILE.py", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh", "ROLLBACK.ps1", "verify_package.py", "create_zip.py"):
        copy_file(AREA / name, out / "reproduction/followup-packaging" / name)
    audit = {"V0": v0, "V1": v1, "physical": physical, "frozen_baseline_files_verified": len(frozen)}
    for name in ("SELECTED_AUDIT.json", "RESULTS_AUDIT.json"):
        (out / "evidence" / name).write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8-sig")
    manifest = read_json(out / "MANIFEST.json")
    manifest.update(schema="pacerv-optimized-release/v2", name=args.output, timing_checks=read_json(p / "BUILD_RESULT.json")["Timing"]["Checks"],
                    frozen_baseline_files_verified=len(frozen), rtl_binding=binding,
                    standalone_verifier="python reproduction/followup-packaging/verify_package.py --folder PATH")
    manifest["files"] = [{"path": file.relative_to(out).as_posix(), "sha256": sha(file), "bytes": file.stat().st_size}
                         for file in sorted(out.rglob("*")) if file.is_file() and file.name != "MANIFEST.json"]
    (out / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8-sig")
    verify_spec = importlib.util.spec_from_file_location("standalone_package_verifier", AREA / "verify_package.py")
    verifier = importlib.util.module_from_spec(verify_spec)
    verify_spec.loader.exec_module(verifier)
    verifier.verify_folder(out)
    print(package_output.getvalue(), end="")
    print(f"FOLLOWUP_PACKAGE_PASS files={len(manifest['files'])} common_rtl={binding['common_files']} timing_pass={physical['all_ten_timing_checks_pass']}")


if __name__ == "__main__":
    main()

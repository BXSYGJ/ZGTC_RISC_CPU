"""Create a bounded PaceRV package ZIP and reopen every archived member."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from verify_package import require, verify_folder, verify_zip


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--folder", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    folder = args.folder.resolve()
    output = args.output.resolve() if args.output else folder.with_suffix(".zip")
    require(output.suffix.lower() == ".zip" and not output.is_relative_to(folder), "ZIP output must be outside the package folder")
    require(not output.exists(), "ZIP already exists")
    before = verify_folder(folder)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                archive.write(path, folder.name + "/" + path.relative_to(folder).as_posix())
    after = verify_zip(output)
    require(before == after, "ZIP evidence differs from source folder")
    digest = hashlib.sha256()
    with output.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    receipt = {"path": str(output), "bytes": output.stat().st_size, "sha256": digest.hexdigest(), "reopened_verification": after, "exit_status": 0}
    output.with_suffix(".zip.verification.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8-sig")
    print("ZIP_VERIFY_PASS " + json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()

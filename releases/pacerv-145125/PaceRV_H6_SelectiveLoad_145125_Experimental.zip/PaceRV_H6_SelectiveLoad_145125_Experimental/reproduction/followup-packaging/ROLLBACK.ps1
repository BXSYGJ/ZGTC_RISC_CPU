﻿param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$TargetPath,
    [ValidateNotNullOrEmpty()]
    [string]$ArtifactDirectory = $PSScriptRoot
)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
try {
    $artifactRoot = [System.IO.Path]::GetFullPath($ArtifactDirectory)
    $target = [System.IO.Path]::GetFullPath($TargetPath)
    $baseline = [System.IO.Path]::Combine($artifactRoot, 'BASELINE_FILE.py')
    $modified = [System.IO.Path]::Combine($artifactRoot, 'MODIFIED_FILE.py')
    $changePath = [System.IO.Path]::Combine($artifactRoot, 'CHANGE.json')
    $change = Get-Content -LiteralPath $changePath -Raw -Encoding utf8 | ConvertFrom-Json
    $prefix = $artifactRoot.TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
    if (-not $target.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Rollback target must be an independent local copy' }
    if ($target -in @($baseline, $modified)) { throw 'Rollback target must preserve the baseline and active modified artifact' }
    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash.ToLowerInvariant() -ne $change.baseline_file_sha256) { throw 'Baseline hash mismatch' }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $change.modified_file_sha256) { throw 'Target is not the recorded modified copy' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $restored = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($restored -ne $change.baseline_file_sha256) { throw 'Restored hash mismatch' }
    if ((Get-FileHash -LiteralPath $modified -Algorithm SHA256).Hash.ToLowerInvariant() -ne $change.modified_file_sha256) { throw 'Active modified artifact changed' }
    Write-Output ('FOLLOWUP_ROLLBACK_PASS SHA256=' + $restored)
    exit 0
} catch {
    Write-Error $_
    exit 1
}

"""Audit only existing SG51 formal6000 processes; close evidence once both finish."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,re
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SOURCE=ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d'
PHYSICAL=ROOT/'work/sg51-regfile-compare-mux-lut6d-lut3-s1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ref=lambda p:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
launch=read(HERE/'LAUNCH_VERIFICATION_FROZEN.txt');c=read(HERE/'CHANGE.json');model=read(HERE/'MODEL_READY.json')
spec=importlib.util.spec_from_file_location('rawaudit',ROOT/'scripts/audit_results.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
for folder,count in [('rtl',17),('physical_rtl',18)]:assert len(c[folder])==count and {p.name:sha(p) for p in (SOURCE/folder).glob('*.sv')}==c[folder]
for group in launch['source_proofs'].values():assert sha(Path(group['original']['path']))==group['original']['sha256']==sha(Path(group['snapshot']['path']))
for name in ('original_recipe','original_standard_builder','extended_builder','model_support'):assert sha(Path(launch[name]['path']))==launch[name]['sha256']
assert sha(Path(model['executable']))==model['executable_sha256']==launch['executable_sha256']
support=read(Path(launch['model_support']['path']));extra=[Path(p) for p in support['simulation_model_sources']]
for p in extra:assert sha(p)==support['simulation_model_sha256'][str(p.relative_to(Path(launch['model_support']['path']).parent))]
recipe=read(ROOT/'recipe.json');inputs=[SOURCE/'rtl'/Path(x).name for x in recipe['simulation']['argv'] if '/simulation/inputs/rtl/' in x]+[ROOT/x.split('{RELEASE}/')[1] for x in recipe['simulation']['argv'] if '/simulation/inputs/sim/' in x]+extra
digest=hashlib.sha256()
for p in inputs:digest.update(p.name.encode());digest.update(p.read_bytes())
digest.update(b'1');assert digest.hexdigest()==model['rtl_sha256']==launch['standard_simulation_rtl_identity']
physical=a.audit_physical(PHYSICAL);assert physical['all_ten_timing_checks_pass'] and physical['resources']['LUT']==6571
for name,h in c['physical_rtl'].items():assert sha(PHYSICAL/'inputs/rtl'/name)==h
completed=[];pending=[]
for role in ('V0','V1'):
    target=ROOT/'work'/('sg51-regfile-compare-mux-lut6d-i6000-'+role);process=read(target/'PROCESS.json')
    if not (target/'RUN.json').exists() or not (HERE/('LONG_'+role+'_RESULT.json')).exists():pending.append(dict(role=role,process=process));continue
    raw=a.audit_simulation(target);run=read(target/'RUN.json');result=read(HERE/('LONG_'+role+'_RESULT.json'));reuse=read(target/'FIRMWARE_REUSE.json');binding=reuse['source_binding']
    assert raw['iterations']==6000 and raw['formal_ten_seconds'] and raw['seconds_at_145125MHz']>10 and raw['coremark_per_mhz']>3.5
    assert raw['rtl_sha256']==binding['rtl_sha256']==process['rtl_sha256']==model['rtl_sha256']
    assert process['status']=='COMPLETED' and process['native_exit_status']==0 and result['process']==process
    assert result['status']=='PASS_GT3P5' and result['run']==run and result['run_json_sha256']==sha(target/'RUN.json')
    assert binding['rtl_17_sha256']==c['rtl'] and binding['physical_rtl_18_sha256']==c['physical_rtl']
    assert binding['short_verification_sha256']==sha(HERE/'LAUNCH_VERIFICATION_FROZEN.txt')
    assert binding['executable_sha256']==model['executable_sha256'] and sha(Path(binding['executable']))==model['executable_sha256']
    original=ROOT/'work'/('cf4-loadsimple-tune5-i6000-'+role)
    artifacts={}
    for name in ('BUILD.json','firmware.hex','firmware.bin','firmware.elf','firmware.map','firmware.dis','compiler.log'):
        assert (original/name).read_bytes()==(target/name).read_bytes();artifacts[name]=dict(original=ref(original/name),copied=ref(target/name))
    assert (target/'uart.log').read_bytes()==(ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)/'uart.log').read_bytes()
    prior=read(ROOT/('rtl_proposals/load_simple_loop16_h4/LONG_'+role+'_RESULT.json'))['run']
    for key in ('timed_cycles','retired','minimum_sp'):assert run[key]==prior[key]
    observer=re.search(r'OBSERVER cycles=(\d+) retired=(\d+) minimum_sp=(\d+)',(target/'simulation.log').read_text());assert observer
    assert tuple(map(int,observer.groups()))==(raw['cycles'],raw['retired'],run['minimum_sp'])
    completed.append(dict(role=role,audit=raw,process=process,source_binding=binding,BUILD=ref(target/'BUILD.json'),RUN=ref(target/'RUN.json'),PROCESS=ref(target/'PROCESS.json'),UART=ref(target/'uart.log'),stdout=ref(target/'simulation.log'),worker_receipt=ref(HERE/('LONG_'+role+'_RESULT.json')),firmware_artifacts=artifacts,complete_SG30_UART_equal=True,H4_cycles_retired_minSP_equal=True))
live=dict(status='PENDING_ORIGINAL_NATIVE6000' if pending else 'PASS_BOTH_ACTUAL6000_AND_MATCHING_6571_TIMING',checked_utc=datetime.now(timezone.utc).isoformat(),pending=pending,completed=completed,physical=physical,source17=c['rtl'],physical18=c['physical_rtl'],exact_model_identity=model['rtl_sha256'],unchanged_original_firmware=True,new_tests_launched_by_audit=0)
write(HERE/'LONG_LIVE_AUDIT.json',live)
if pending:
    print('SG51_LONG_AUDIT_PENDING roles='+','.join(x['role'] for x in pending)+' saved_completed='+str(len(completed))+' matching_physical6571=PASS no_new_launch=1')
else:
    write(HERE/'LONG_FINAL_AUDIT.json',live)
    core=read(HERE/'SOURCE_CORE_VERIFICATION.json');rollback=read(HERE/'SOURCE_ROLLBACK_RESULT.json')
    verification=dict(status=live['status'],changed_field=c['changed_field'],launch=ref(HERE/'LAUNCH_VERIFICATION_FROZEN.txt'),formal6000_final=ref(HERE/'LONG_FINAL_AUDIT.json'),actual6000=completed,matching_physical=physical,source17=c['rtl'],physical18=c['physical_rtl'],source_proofs=launch['source_proofs'],source_BMR_exact_commands_inputs_literals_exits=core['tests'],real_rollback_exact_command_input_literal_exit=rollback,firmware_generation=0,model_recompilation=0,actual_native_launches=2,no_restarts=True)
    write(HERE/'VERIFICATION.txt',verification)
    lines=['SG51 formal6000 and matched6571LUT timing qualification','',
           'Same source17/18, model963a2, originalcf4firmware and145125000Hz/.150ns constraints. Actual matchingphysical packing3seed1:6571LUT/2557FF, setupslow+.099ns, all10timingcategories pass.','',
           '| Role | Cycles | Retired | CoreMark/MHz | Formal seconds | CRCs | Exit |','|---|---:|---:|---:|---:|---|---:|']
    for row in completed:
        raw=row['audit'];lines.append('| '+row['role']+' | '+str(raw['cycles'])+' | '+str(raw['retired'])+' | '+format(raw['coremark_per_mhz'],'.12f')+' | '+format(raw['seconds_at_145125MHz'],'.9f')+' | '+','.join(raw['crc_fields'])+' | 0 |')
    lines+=['','RawUART/CSR/observercounts and fourCRCs agree; bothformalintervals exceed10seconds and bothscores exceed3.5. CompleteUART matches qualifiedSG30; cycles/retired/minSP match qualifiedH4. All7firmware/build artifacts perrole are byte-identical to originalcf4. Original native processes each ran once and completed naturally.','']
    (HERE/'SUMMARY.md').write_text('\n'.join(lines),encoding='utf-8')
    final=dict(status=live['status'],four_artifacts={n:ref(HERE/n) for n in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')},summary=ref(HERE/'SUMMARY.md'),audit=ref(HERE/'LONG_FINAL_AUDIT.json'),source17=c['rtl'],physical18=c['physical_rtl'],model_identity=model['rtl_sha256'],model_executable_sha256=model['executable_sha256'],physical=physical,both6000_GT3P5_and_GT10seconds=True,no_restarts=True)
    write(HERE/'FINAL_RECHECK.json',final);assert read(HERE/'FINAL_RECHECK.json')==final
    for row in list(final['four_artifacts'].values())+[final['summary'],final['audit']]:assert sha(Path(row['path']))==row['sha256']
    print('SG51_LONG_FINAL_PASS both6000_GT3P5=1 bothformal_GT10seconds=1 matching_source17_18=35 physical6571_all10=PASS original_processes=natural_complete all_artifacts=reopened')

﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $target = [System.IO.Path]::GetFullPath($TargetPath)
    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)
    if ($target -eq $baseline) { throw 'Use an independent target copy' }
    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '8AF95F92009BE4979E23FA0BEE77EFF3BC6858357173470A0BDF7DB75326C416') { throw 'Baseline hash mismatch' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($hash -ne '8AF95F92009BE4979E23FA0BEE77EFF3BC6858357173470A0BDF7DB75326C416') { throw 'Restore hash mismatch' }
    Write-Output ('REGFILE_COMPARE_MUX_LUT6D_ROLLBACK_PASS SHA256=' + $hash)
    exit 0
} catch { Write-Error $_; exit 1 }

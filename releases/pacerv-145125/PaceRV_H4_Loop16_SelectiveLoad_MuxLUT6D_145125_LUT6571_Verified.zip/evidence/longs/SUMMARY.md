SG51 formal6000 and matched6571LUT timing qualification

Same source17/18, model963a2, originalcf4firmware and145125000Hz/.150ns constraints. Actual matchingphysical packing3seed1:6571LUT/2557FF, setupslow+.099ns, all10timingcategories pass.

| Role | Cycles | Retired | CoreMark/MHz | Formal seconds | CRCs | Exit |
|---|---:|---:|---:|---:|---|---:|
| V0 | 1712559880 | 1634152429 | 3.503527129224 | 11.800584875 | 0xe714,0x1fd7,0x8e3a,0xa14c | 0 |
| V1 | 1713586192 | 1634361529 | 3.501428774351 | 11.807656792 | 0xe3c1,0x0747,0x8d84,0x18e1 | 0 |

RawUART/CSR/observercounts and fourCRCs agree; bothformalintervals exceed10seconds and bothscores exceed3.5. CompleteUART matches qualifiedSG30; cycles/retired/minSP match qualifiedH4. All7firmware/build artifacts perrole are byte-identical to originalcf4. Original native processes each ran once and completed naturally.

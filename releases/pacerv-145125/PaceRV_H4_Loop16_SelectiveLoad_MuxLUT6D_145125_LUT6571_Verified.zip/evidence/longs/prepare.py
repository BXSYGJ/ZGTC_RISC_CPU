"""Authorize exact frozen SG51 formal6000 on its existing actual compiled model."""
from pathlib import Path
import hashlib,json,shutil
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SOURCE=ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d'
FUNCTIONAL=ROOT/'rtl_proposals/regfile_compare_mux_lut6d'
SHORT=ROOT/'rtl_proposals/regfile_compare_mux_lut6d_performance'
PHYSICAL=ROOT/'work/sg51-regfile-compare-mux-lut6d-lut3-s1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ref=lambda p:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
assert read(FUNCTIONAL/'FINAL_RECHECK.json')['status']=='FUNCTIONAL_READY'
assert read(SHORT/'FINAL_RECHECK.json')['status']=='PASS_REUSED_STANDARD_EXTENDED_MODEL_AND_BOTH_ACTUAL100'
c=read(FUNCTIONAL/'CHANGE.json');model=read(SHORT/'MODEL_READY.json')
assert model['rtl_sha256']=='963a2d5dd9e239ca82b30fcf5a5734aa81c9281950dc9c336ef99af0a347371d'
assert sha(Path(model['executable']))==model['executable_sha256']=='ea512622369973fc8489d43bfa46b895dd1efac7e989657565cc3a77cb0ab8ff'
physical=read(PHYSICAL/'BUILD_RESULT.json')
assert physical['Status']=='completed_timing_pass' and physical['Resources']['LUT']==6571
timing=physical['Timing'];assert timing['AllReportedChecksPass'] and timing['ConfiguredCpuClockHz']==145125000 and timing['SetupUncertaintyNs']==.15
checks=[row for group in timing['Checks'].values() for row in (group if isinstance(group,list) else [group])]
assert len(timing['Checks'])==10 and len(checks)==10 and all(x['WorstSlackNs']>=0 and x['FailingEndpoints']==0 for x in checks)
physical_hashes={x['RelativePath']:x['SHA256'].lower() for x in read(PHYSICAL/'INPUT_HASHES.json')}
for folder,count in [('rtl',17),('physical_rtl',18)]:
    assert len(c[folder])==count and {p.name:sha(p) for p in (SOURCE/folder).glob('*.sv')}==c[folder]
    for name,h in c[folder].items():assert sha(PHYSICAL/'inputs/rtl'/name)==physical_hashes['rtl/'+name]==h
proofs={}
for name in ('FINAL_RECHECK.json','CHANGE.json','VERIFICATION.txt','CORE_VERIFICATION.json','ROLLBACK_RESULT.json','READ_CONE_VERIFICATION.json','MODEL_SUPPORT.json','MODEL_ADAPTATION.json','PRODUCTION_GUARD.json','EXTENDED_MODEL_BUILD.json'):
    src=FUNCTIONAL/name;dst=HERE/('SOURCE_'+name);shutil.copy2(src,dst);proofs[name]=dict(original=ref(src),snapshot=ref(dst))
for name in ('MODIFIED_FILE.sv','BASELINE_FILE.sv','DIFF_FILE.diff','ROLLBACK.sh'):shutil.copy2(FUNCTIONAL/name,HERE/name)
shutil.copy2(SHORT/'FINAL_RECHECK.json',HERE/'SHORT_FINAL_RECHECK.json');shutil.copy2(SHORT/'VERIFICATION.txt',HERE/'SHORT_VERIFICATION_FROZEN.txt')
write(HERE/'CHANGE.json',c);write(HERE/'MODEL_READY.json',model)
binding=dict(status='SOURCE_PROOFS_FROZEN_ACTUAL6000_AUTHORIZED',standard_simulation_rtl_identity=model['rtl_sha256'],executable_sha256=model['executable_sha256'],changed_field=c['changed_field'],source17=c['rtl'],physical18=c['physical_rtl'],source_proofs=proofs,short_actual100_final=ref(HERE/'SHORT_FINAL_RECHECK.json'),short_actual100_verification=ref(HERE/'SHORT_VERIFICATION_FROZEN.txt'),physical_build=ref(PHYSICAL/'BUILD_RESULT.json'),physical_INPUT_HASHES=ref(PHYSICAL/'INPUT_HASHES.json'),physical_resources=physical['Resources'],physical_timing=timing,original_recipe=ref(ROOT/'recipe.json'),original_standard_builder=ref(ROOT/'scripts/experiment.py'),extended_builder=ref(FUNCTIONAL/'experiment_extended.py'),model_sources=read(FUNCTIONAL/'MODEL_SUPPORT.json')['simulation_model_sha256'],model_support=ref(FUNCTIONAL/'MODEL_SUPPORT.json'),authorization='Root explicitly authorized V0/V1 actual6000 after SG51 packing3seed1 completed6571LUT, all10timingPASS. Same firmware, clock145125000, uncertainty.150, original algorithm/profile/driver/observer/flags and threads1/loadbubble1.')
write(HERE/'VERIFICATION.txt',binding);shutil.copy2(HERE/'VERIFICATION.txt',HERE/'LAUNCH_VERIFICATION_FROZEN.txt')
template=(ROOT/'rtl_proposals/loop16_h4_ram_memory_range_longs/long_benchmark.py').read_text()
template=template.replace('candidates/loop16_h4_ram_memory_range/rtl','candidates/loop16_h4_regfile_compare_mux_lut6d/rtl').replace('sg30-ram-memory-range-i6000-','sg51-regfile-compare-mux-lut6d-i6000-').replace("ROOT/'scripts/experiment.py'","ROOT/'rtl_proposals/regfile_compare_mux_lut6d/experiment_extended.py'").replace('MEMORY_RANGE','REGFILE_COMPARE_LUT6D')
template=template.replace("assert result['timed_cycles']==expected['timed_cycles'] and result['retired']==expected['retired']","assert result['timed_cycles']==expected['timed_cycles'] and result['retired']==expected['retired']\nassert result['minimum_sp']==expected['minimum_sp']\nassert (target/'uart.log').read_bytes()==(ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)/'uart.log').read_bytes(), 'Complete formal UART differs from SG30'\nfor name in ('BUILD.json','firmware.hex','firmware.bin','firmware.elf','firmware.map','firmware.dis','compiler.log'):assert (target/name).read_bytes()==(original/name).read_bytes()")
(HERE/'long_benchmark.py').write_text(template,encoding='utf-8')
for row in proofs.values():assert sha(Path(row['original']['path']))==row['original']['sha256']==sha(Path(row['snapshot']['path']))
print('SG51_ACTUAL6000_PREPARED source17_18=35 model963a2=exact physical6571LUT_all10PASS firmware6000=original clock145125000_uncertainty.150=unchanged')

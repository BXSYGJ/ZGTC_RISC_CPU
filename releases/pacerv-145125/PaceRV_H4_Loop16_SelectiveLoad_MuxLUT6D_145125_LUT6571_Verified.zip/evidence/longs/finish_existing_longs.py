"""Wait for the two already launched PIDs; no benchmark launch or restart code."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
utc=lambda:datetime.now(timezone.utc).isoformat()
lock=HERE/'BACKGROUND_FINALIZATION.lock'
with lock.open('x') as out:out.write(str(os.getpid()))
expected={role:read(ROOT/'work'/('sg51-regfile-compare-mux-lut6d-i6000-'+role)/'PROCESS.json') for role in ('V0','V1')}
record=dict(status='MONITORING_EXISTING_NATIVE_PIDS',worker_pid=os.getpid(),started_utc=utc(),command=[sys.executable,'-I',str(Path(__file__).resolve())],existing_runs=expected,benchmarks_launched_or_restarted=False)
def save():(HERE/'BACKGROUND_FINALIZATION_PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();print('SG51_EXISTING_FINALIZER_STARTED PID='+str(os.getpid())+' nativeV0='+str(expected['V0']['native_pid'])+' nativeV1='+str(expected['V1']['native_pid']),flush=True)
try:
    deadline=time.monotonic()+7200
    while True:
        done=True
        for role,original in expected.items():
            target=ROOT/'work'/('sg51-regfile-compare-mux-lut6d-i6000-'+role);current=read(target/'PROCESS.json')
            for key in ('worker_pid','native_pid','started_utc','command'):assert current[key]==original[key],'Original process identity changed: '+role
            assert current['status']!='FAILED','Original native failed: '+role
            if not ((target/'RUN.json').exists() and (HERE/('LONG_'+role+'_RESULT.json')).exists()):
                done=False;proc=Path('/proc')/str(original['native_pid'])
                if proc.exists():
                    argv=(proc/'cmdline').read_bytes().split(b'\0');assert argv[0].decode()==original['command'][0]
                    assert (proc/'cwd').resolve()==target
                else:
                    assert current['status']=='COMPLETED','Original native disappeared without receipt: '+role
                    assert (Path('/proc')/str(original['worker_pid'])).exists(),'Original worker exited without verified LONG result: '+role
        if done:break
        assert time.monotonic()<deadline,'Original process completion deadline exceeded'
        time.sleep(10)
    command=[sys.executable,'-I',str(HERE/'finalize_longs.py')];p=subprocess.run(command,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
    record.update(status='COMPLETED' if p.returncode==0 else 'FAILED_FINAL_AUDIT',finished_utc=utc(),finalize_command=command,finalize_literal_output=p.stdout,finalize_exit_status=p.returncode)
    save();assert p.returncode==0,p.stdout
    print(p.stdout,end='');print('SG51_EXISTING_FINALIZER_COMPLETE original_native_processes_only=1',flush=True)
except Exception as error:
    record.update(status='FAILED',finished_utc=utc(),error=repr(error));save();raise

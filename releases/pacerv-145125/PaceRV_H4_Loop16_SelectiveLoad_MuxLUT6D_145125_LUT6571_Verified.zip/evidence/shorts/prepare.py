"""Freeze existing SG51 model and proofs for two actual100 observations; no rebuild."""
from pathlib import Path
import hashlib,json,shutil
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
PARENT=ROOT/'rtl_proposals/regfile_compare_mux_lut6d';SOURCE=ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ref=lambda p:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
final=read(PARENT/'FINAL_RECHECK.json');assert final['status']=='FUNCTIONAL_READY'
for row in final['four_artifacts'].values():assert sha(Path(row['path']))==row['sha256']
change=read(PARENT/'CHANGE.json');model=read(PARENT/'EXTENDED_MODEL_BUILD.json')
assert model['identity']=='963a2d5dd9e239ca82b30fcf5a5734aa81c9281950dc9c336ef99af0a347371d'
assert sha(Path(model['executable']))==model['executable_sha256']
assert model['load_bubble']==model['threads']==1 and all(p['native_exit_status']==0 for p in model['native_processes'])
copies={}
for name in ('BASELINE_FILE.sv','MODIFIED_FILE.sv','DIFF_FILE.diff','ROLLBACK.sh'):
    src=PARENT/name;dst=HERE/name;assert not dst.exists();shutil.copy2(src,dst);assert src.read_bytes()==dst.read_bytes();copies[name]=dict(original=ref(src),snapshot=ref(dst))
proofs={}
for name in ('CHANGE.json','FINAL_RECHECK.json','VERIFICATION.txt','CORE_VERIFICATION.json','ROLLBACK_RESULT.json','READ_CONE_VERIFICATION.json','MODEL_SUPPORT.json','MODEL_ADAPTATION.json','PRODUCTION_GUARD.json','EXTENDED_RECIPE.json','EXTENDED_MODEL_BUILD.json','MODEL_PROCESS.json'):
    src=PARENT/name;dst=HERE/('SOURCE_'+name);shutil.copy2(src,dst);proofs[name]=dict(original=ref(src),snapshot=ref(dst))
for folder,count in [('rtl',17),('physical_rtl',18)]:
    shutil.copytree(SOURCE/folder,HERE/folder)
    assert {p.name:sha(p) for p in (HERE/folder).glob('*.sv')}==change[folder] and len(change[folder])==count
support=read(PARENT/'MODEL_SUPPORT.json');models=[]
(HERE/'model_dependencies').mkdir()
for path in support['simulation_model_sources']:
    src=Path(path);dst=HERE/'model_dependencies'/src.name;shutil.copy2(src,dst);assert src.read_bytes()==dst.read_bytes();models.append(dict(original=ref(src),snapshot=ref(dst)))
binding=dict(changed_field=change['changed_field'],core_sha256=change['modified_sha256'],parent_core_sha256=change['baseline_sha256'],rtl=change['rtl'],physical_rtl=change['physical_rtl'],candidate=str(SOURCE),functional_source=str(PARENT),proofs=proofs,source_artifacts=copies,models=models,original_builder=ref(ROOT/'scripts/experiment.py'),original_recipe=ref(ROOT/'recipe.json'),extended_builder=ref(PARENT/'experiment_extended.py'))
write(HERE/'SOURCE_BINDING.json',binding)
ready=dict(status='EXISTING_ACTUAL_COMPILED_SG51_MODEL_REUSED',rtl_sha256=model['identity'],executable=model['executable'],executable_sha256=model['executable_sha256'],model_build=read(Path(model['BUILD']['path'])),original_compile_receipt=ref(PARENT/'EXTENDED_MODEL_BUILD.json'),source_proofs=proofs,threads=1,load_bubble=1)
write(HERE/'MODEL_READY.json',ready)
write(HERE/'VERIFICATION.txt',dict(status='EXISTING_MODEL_READY_ACTUAL100_PENDING',source=ref(HERE/'SOURCE_BINDING.json'),model=ref(HERE/'MODEL_READY.json'),firmware_generation=0,new_model_compilation=0))
print('SG51_PERFORMANCE_PREPARED existing_model='+model['identity']+' source17_18=35 compiled_binary=verified firmware_generation=0')

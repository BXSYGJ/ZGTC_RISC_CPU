"""Recompute and freeze completed actual100 evidence without running any test."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ref=lambda p:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
binding=read(HERE/'SOURCE_BINDING.json');model=read(HERE/'MODEL_READY.json')
for row in binding['proofs'].values():assert sha(Path(row['original']['path']))==row['original']['sha256']==sha(Path(row['snapshot']['path']))
for row in binding['source_artifacts'].values():assert sha(Path(row['original']['path']))==row['original']['sha256']==sha(Path(row['snapshot']['path']))
for row in binding['models']:assert sha(Path(row['original']['path']))==row['original']['sha256']==sha(Path(row['snapshot']['path']))
for name in ('original_builder','original_recipe','extended_builder'):assert sha(Path(binding[name]['path']))==binding[name]['sha256']
for folder,count in [('rtl',17),('physical_rtl',18)]:
    assert len(binding[folder])==count
    for base in (HERE,Path(binding['candidate'])):assert {p.name:sha(p) for p in (base/folder).glob('*.sv')}==binding[folder]
assert sha(Path(model['executable']))==model['executable_sha256']
assert model['rtl_sha256']==model['model_build']['source_sha256']
command=model['model_build']['command'];assert command[command.index('-j')+1]=='1' and '-GLOAD_USE_BUBBLE=1' in command
recipe=read(ROOT/'recipe.json');inputs=[]
for x in recipe['simulation']['argv']:
    if '/simulation/inputs/rtl/' in x:inputs.append(HERE/'rtl'/Path(x).name)
inputs += [ROOT/x.split('{RELEASE}/')[1] for x in recipe['simulation']['argv'] if '/simulation/inputs/sim/' in x]
inputs += [Path(row['snapshot']['path']) for row in binding['models']]
digest=hashlib.sha256()
for p in inputs:digest.update(p.name.encode());digest.update(p.read_bytes())
digest.update(b'1');assert digest.hexdigest()==model['rtl_sha256']
write(HERE/'SIMULATION_INPUT_HASHES.json',[ref(p) for p in inputs])
source_final=read(HERE/'SOURCE_FINAL_RECHECK.json');assert source_final['status']=='FUNCTIONAL_READY'
core=read(HERE/'SOURCE_CORE_VERIFICATION.json');rollback=read(HERE/'SOURCE_ROLLBACK_RESULT.json')
assert core['core_scenarios']==23 and core['architecture_lines']==591 and core['all_three_full_literal_outputs_equal']
assert rollback['exit_status']==0 and rollback['restored_sha256']==binding['parent_core_sha256']
sg30=read(ROOT/'rtl_proposals/loop16_h4_ram_memory_range_longs/MODEL_READY.json')
sg36=read(ROOT/'rtl_proposals/loop16_h4_memory_range_branch_keep_runs/MODEL_READY.json')
assert sg30['executable_sha256']==sg36['executable_sha256'] and Path(sg30['executable']).read_bytes()==Path(sg36['executable']).read_bytes()
rows=[]
for role in ('V0','V1'):
    target=ROOT/'work'/('sg51-regfile-compare-mux-lut6d-i100-'+role)
    observed=read(HERE/('SHORT_'+role+'_RESULT.json'));run=read(target/'RUN.json');process=read(target/'PROCESS.json');reuse=read(target/'FIRMWARE_REUSE.json')
    assert observed['run']==run and observed['process']==process
    assert process['status']=='COMPLETED' and process['single_launch'] and process['native_exit_status']==run['exit_status']==0
    assert process['source_identity']==run['rtl_sha256']==model['rtl_sha256'] and run['load_use_bubble']==1
    assert process['executable_sha256']==model['executable_sha256'] and run['firmware']['iterations']==100
    assert all(run['checks'].values()) and not run['formal_ten_seconds'] and run['duration_at_145125MHz_seconds']<1
    assert run['coremark_per_mhz']==100000000/run['timed_cycles']>3.5
    for name,row in reuse['per_file'].items():
        assert sha(Path(row['source']['path']))==row['source']['sha256']==sha(target/name)==row['copied']['sha256']
    assert len(reuse['per_file'])==7 and reuse['new_firmware_builds']==0
    if role=='V0':
        assert len(reuse['all_five_cf4_cf2_byte_checks'])==5
        for row in reuse['all_five_cf4_cf2_byte_checks']:
            assert sha(Path(row['cf4']['path']))==row['cf4']['sha256']==row['BUILD_pointed_cf2']['sha256']==sha(Path(row['BUILD_pointed_cf2']['path']))
        assert Path(reuse['per_file']['firmware.map']['source']['path']).parent.name=='cf2-loop16-tune5-i100-V0'
    else:assert not reuse['all_five_cf4_cf2_byte_checks'] and all(Path(row['source']['path']).parent.name=='cf4-loadsimple-tune5-i100-V1' for row in reuse['per_file'].values())
    old=read(ROOT/('rtl_proposals/loop16_h4_memory_range_branch_keep_runs/SHORT_'+role+'_RESULT.json'))
    for field in ('timed_cycles','retired','minimum_sp','crc_fields'):assert run[field]==old['run'][field]
    assert sha(target/'uart.log')==old['raw_UART']['sha256']
    assert not list(target.glob('*.vcd')) and not list(target.glob('*.fst')) and {p.name for p in target.glob('*.bin')}=={'firmware.bin'}
    rows.append(dict(role=role,iterations=100,timed_cycles=run['timed_cycles'],retired=run['retired'],minimum_sp=run['minimum_sp'],CRC=run['crc_fields'],coremark_per_mhz=run['coremark_per_mhz'],duration_seconds=run['duration_at_145125MHz_seconds'],native_pid=process['native_pid'],worker_pid=process['worker_pid'],native_exit_status=0,command=process['command'],source_identity=run['rtl_sha256'],run=ref(target/'RUN.json'),process=ref(target/'PROCESS.json'),BUILD=ref(target/'BUILD.json'),raw_UART=ref(target/'uart.log'),raw_stdout=ref(target/'simulation.log'),firmware_reuse=ref(target/'FIRMWARE_REUSE.json'),actual_result=ref(HERE/('SHORT_'+role+'_RESULT.json')),complete_parent_UART_cycles_retired_CRC_minSP_equal=True))
verification=dict(status='PASS_REUSED_STANDARD_EXTENDED_MODEL_AND_BOTH_ACTUAL100',updated_utc=datetime.now(timezone.utc).isoformat(),changed_field=binding['changed_field'],core_sha256=binding['core_sha256'],source17=binding['rtl'],physical18=binding['physical_rtl'],model=ref(HERE/'MODEL_READY.json'),simulation_input_hashes=ref(HERE/'SIMULATION_INPUT_HASHES.json'),actual100=rows,original_source_BMR_exact_commands_inputs_literals_exits=core['tests'],real_rollback_exact_command_input_literal_exit=rollback,source_proofs=binding['proofs'],original_source_four_unchanged=True,firmware_provenance='V0 originalcf4 five files verified byte-identical to BUILD-pointedcf2, with map/compiler sidecars copied only into this new run; V1 all7 fromcf4; every file has source and destination SHA.',new_firmware_builds=0,new_model_compiles=0,new_traces=0,new6000_runs=0,PDS_launched=0,duration_scope='Actual100 measured intervals about0.197seconds retain original standard10second diagnostic.',parent_observation_basis='Complete UART/cycles/retired/minimumSP/CRC equal frozenH4/SG25 and savedSG36, whose native model executable is byte-identical to SG30.')
write(HERE/'VERIFICATION.txt',verification)
summary=['SG51 explicit paired comparison mux actual100 verification','',
         'Frozen core75d136/BTB13aa/cacheC9D73/frontend210B5B;17simulation/18physical sources. Existing actual compiled standard extended model reused, threads1/load_bubble1; no recompilation.',
         'Model '+model['rtl_sha256']+'; executableSHA '+model['executable_sha256']+'.','',
         '| Role | Cycles | Retired | CoreMark/MHz(short100) | MinSP | CRC list/matrix/state/final | Exit |','|---|---:|---:|---:|---:|---|---:|']
for row in rows:summary.append('| '+row['role']+' | '+str(row['timed_cycles'])+' | '+str(row['retired'])+' | '+format(row['coremark_per_mhz'],'.12f')+' | '+str(row['minimum_sp'])+' | '+','.join(row['CRC'])+' | 0 |')
summary+=['','Both roles match complete parent UART/cycles/retired/CRC/minimumSP. V0 BUILD points tocf2-loop16-tune5-i100-V0:all five existingcf4 files match byte-for-byte; missing map/compiler sidecars were copied from that exactcf2 only into the new run, with per-file provenance. V1 reuses all seven originalcf4 artifacts.',
          'Each actual100 native process launched once, exited0, and retains PROCESS/RUN/completeUART receipts. Short intervals about0.197seconds retain original10second diagnostic. No firmware generation, model rebuild, new trace, PDS or6000 run. OriginalSG51 functional four artifacts and source proofs remain frozen.','']
(HERE/'SUMMARY.md').write_text('\n'.join(summary),encoding='utf-8')
final=dict(status='PASS_REUSED_STANDARD_EXTENDED_MODEL_AND_BOTH_ACTUAL100',four_artifacts={n:ref(HERE/n) for n in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')},summary=ref(HERE/'SUMMARY.md'),model=ref(HERE/'MODEL_READY.json'),source_binding=ref(HERE/'SOURCE_BINDING.json'),source_BMR=ref(HERE/'SOURCE_CORE_VERIFICATION.json'),source_rollback=ref(HERE/'SOURCE_ROLLBACK_RESULT.json'),actual100=[row['actual_result'] for row in rows],support_scripts={n:ref(HERE/n) for n in ('prepare.py','short100.py','finalize.py')},all_source17_physical18_and_models_unchanged=True,all_parent_complete_UART_counts_CRC_minSP_equal=True,native_both_exit_zero=True,new_firmware_builds=0,new_model_compiles=0,new_traces=0,new6000_runs=0,PDS_launched=0,formal6000_qualified=False)
write(HERE/'FINAL_RECHECK.json',final);assert read(HERE/'FINAL_RECHECK.json')==final
for row in list(final['four_artifacts'].values())+[final[k] for k in ('summary','model','source_binding','source_BMR','source_rollback')]+final['actual100']+list(final['support_scripts'].values()):assert sha(Path(row['path']))==row['sha256']
print('SG51_ACTUAL100_FINAL_PASS V0='+str(rows[0]['timed_cycles'])+'/'+str(rows[0]['retired'])+' V1='+str(rows[1]['timed_cycles'])+'/'+str(rows[1]['retired'])+' complete_UART_CRC_minSP=parent_exact source17_18_models=unchanged original_four=frozen all_artifacts=reopened')

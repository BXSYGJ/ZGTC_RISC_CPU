SG51 explicit paired comparison mux actual100 verification

Frozen core75d136/BTB13aa/cacheC9D73/frontend210B5B;17simulation/18physical sources. Existing actual compiled standard extended model reused, threads1/load_bubble1; no recompilation.
Model 963a2d5dd9e239ca82b30fcf5a5734aa81c9281950dc9c336ef99af0a347371d; executableSHA ea512622369973fc8489d43bfa46b895dd1efac7e989657565cc3a77cb0ab8ff.

| Role | Cycles | Retired | CoreMark/MHz(short100) | MinSP | CRC list/matrix/state/final | Exit |
|---|---:|---:|---:|---:|---|---:|
| V0 | 28550446 | 27236534 | 3.502572254038 | 65152 | 0xe714,0x1fd7,0x8e3a,0x988c | 0 |
| V1 | 28565259 | 27240311 | 3.500755935733 | 65152 | 0xe3c1,0x0747,0x8d84,0x844d | 0 |

Both roles match complete parent UART/cycles/retired/CRC/minimumSP. V0 BUILD points tocf2-loop16-tune5-i100-V0:all five existingcf4 files match byte-for-byte; missing map/compiler sidecars were copied from that exactcf2 only into the new run, with per-file provenance. V1 reuses all seven originalcf4 artifacts.
Each actual100 native process launched once, exited0, and retains PROCESS/RUN/completeUART receipts. Short intervals about0.197seconds retain original10second diagnostic. No firmware generation, model rebuild, new trace, PDS or6000 run. OriginalSG51 functional four artifacts and source proofs remain frozen.

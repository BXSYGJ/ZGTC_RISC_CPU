"""One actual100 per role, using original firmware bytes and original compiled model."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib.util,json,os,shutil,subprocess
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ref=lambda p:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
parser=argparse.ArgumentParser();parser.add_argument('--role',required=True,choices=('V0','V1'));role=parser.parse_args().role
model=read(HERE/'MODEL_READY.json');binding=read(HERE/'SOURCE_BINDING.json')
for folder in ('rtl','physical_rtl'):
    assert {p.name:sha(p) for p in (HERE/folder).glob('*.sv')}==binding[folder]
    assert {p.name:sha(p) for p in (Path(binding['candidate'])/folder).glob('*.sv')}==binding[folder]
for row in binding['proofs'].values():assert sha(Path(row['original']['path']))==row['original']['sha256']==sha(Path(row['snapshot']['path']))
for row in binding['models']:assert sha(Path(row['original']['path']))==row['original']['sha256']==sha(Path(row['snapshot']['path']))
exe=Path(model['executable']);assert sha(exe)==model['executable_sha256']
baseline=read(ROOT/'rtl_proposals/loop16_h4_single_write/FULL100_INTERFACE_EQUIVALENCE.json')
expected=next(x['baseline'] for x in baseline['records'] if x['role']==role)
assert next(x['all_equal'] for x in baseline['records'] if x['role']==role)
original=ROOT/'work'/('cf4-loadsimple-tune5-i100-'+role);build=read(original/'BUILD.json')
five=('BUILD.json','firmware.hex','firmware.bin','firmware.elf','firmware.dis');seven=(*five,'firmware.map','compiler.log')
fallback=None;verification=[]
if role=='V0':
    output=Path(build['command'][build['command'].index('-o')+1]);fallback=output.parent
    assert fallback.name=='cf2-loop16-tune5-i100-V0' and fallback.parent==ROOT/'work'
    for name in five:
        assert (original/name).read_bytes()==(fallback/name).read_bytes()
        verification.append(dict(file=name,cf4=ref(original/name),BUILD_pointed_cf2=ref(fallback/name),byte_identical=True))
target=ROOT/'work'/('sg51-regfile-compare-mux-lut6d-i100-'+role);target.mkdir(exist_ok=False)
provenance={}
for name in seven:
    src=original/name
    if not src.exists():assert role=='V0' and fallback is not None;src=fallback/name
    assert src.exists();shutil.copy2(src,target/name);assert src.read_bytes()==(target/name).read_bytes()
    provenance[name]=dict(source=ref(src),copied=ref(target/name),source_reason='Frozen cf4 original' if src.parent==original else 'Missing cf4 sidecar from BUILD-pointed cf2 after all five original artifacts matched byte-for-byte')
assert sha(target/'firmware.hex')==expected['firmware_sha256'] and build['iterations']==100
write(target/'FIRMWARE_REUSE.json',dict(original_cf4=str(original),BUILD_pointed_fallback=str(fallback) if fallback else None,all_five_cf4_cf2_byte_checks=verification,per_file=provenance,new_firmware_builds=0,unchanged_firmware=True))
process=dict(status='PREPARED',role=role,worker_pid=os.getpid(),source_identity=model['rtl_sha256'],firmware_sha256=sha(target/'firmware.hex'),executable_sha256=sha(exe),single_launch=True)
write(target/'PROCESS.json',process)
spec=importlib.util.spec_from_file_location('sg51_extended',Path(binding['functional_source'])/'experiment_extended.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
def track(command,**kwargs):
    p=subprocess.Popen(command,**kwargs);process.update(status='RUNNING',native_pid=p.pid,command=command,cwd=str(kwargs['cwd']),started_utc=datetime.now(timezone.utc).isoformat());write(target/'PROCESS.json',process)
    code=p.wait();process.update(status='NATIVE_COMPLETED',native_exit_status=code,finished_utc=datetime.now(timezone.utc).isoformat());write(target/'PROCESS.json',process)
    return subprocess.CompletedProcess(command,code)
e.subprocess.run=track;e.run(target,exe,model['rtl_sha256'],40000000,1)
run=read(target/'RUN.json');assert run['exit_status']==0 and all(run['checks'].values())
for field in ('timed_cycles','retired','minimum_sp','crc_fields'):assert run[field]==expected[field],(field,run[field],expected[field])
assert sha(target/'uart.log')==expected['uart_sha256']
parent=read(ROOT/('rtl_proposals/loop16_h4_memory_range_branch_keep_runs/SHORT_'+role+'_RESULT.json'))
for field in ('timed_cycles','retired','minimum_sp','crc_fields'):assert run[field]==parent['run'][field]
assert sha(target/'uart.log')==parent['raw_UART']['sha256']
for name,row in provenance.items():assert Path(row['source']['path']).read_bytes()==(target/name).read_bytes()
assert not run['formal_ten_seconds'] and run['duration_at_145125MHz_seconds']<1
process.update(status='COMPLETED',comparisons_pass=True);write(target/'PROCESS.json',process)
result=dict(status='PASS_ACTUAL100_EXACT_PARENT_COUNTS_UART_CRC',role=role,run=run,process=process,run_receipt=ref(target/'RUN.json'),raw_UART=ref(target/'uart.log'),raw_stdout=ref(target/'simulation.log'),firmware_hex=ref(target/'firmware.hex'),firmware_reuse=ref(target/'FIRMWARE_REUSE.json'),parent_H4_SG25_SG30_counts_UART_CRC_minimumSP_exact=True,firmware_reused_byte_identical=True,new_firmware_builds=0,trace_files_created=False,benchmark6000_launched=False)
write(HERE/('SHORT_'+role+'_RESULT.json'),result);assert read(HERE/('SHORT_'+role+'_RESULT.json'))==result
print('SG51_ACTUAL100_PASS role='+role+' cycles='+str(run['timed_cycles'])+' retired='+str(run['retired'])+' complete_UART_CRC_minSP=parent_exact native_exit=0 firmware_rebuilt=0',flush=True)

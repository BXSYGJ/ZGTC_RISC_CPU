`timescale 1ns/1ps
// Deterministic translation of installed UDP table rows. UDP inputs Z match X.
module INT_LUTMUX4_UDP(dout,s1,s0,di3,di2,di1,di0);
output reg dout;
input s1,s0,di3,di2,di1,di0;
always @* begin
    dout=1'bx;
    if ((s1===1'b0) && (s0===1'b0) && (di0===1'b0)) dout=1'b0;
    if ((s1===1'b0) && (s0===1'b0) && (di0===1'b1)) dout=1'b1;
    if ((s1===1'b0) && (s0===1'b1) && (di1===1'b0)) dout=1'b0;
    if ((s1===1'b0) && (s0===1'b1) && (di1===1'b1)) dout=1'b1;
    if ((s1===1'b0) && (s0!==1'b0 && s0!==1'b1) && (di1===1'b0) && (di0===1'b0)) dout=1'b0;
    if ((s1===1'b0) && (s0!==1'b0 && s0!==1'b1) && (di1===1'b1) && (di0===1'b1)) dout=1'b1;
    if ((s1===1'b1) && (s0===1'b0) && (di2===1'b0)) dout=1'b0;
    if ((s1===1'b1) && (s0===1'b0) && (di2===1'b1)) dout=1'b1;
    if ((s1===1'b1) && (s0===1'b1) && (di3===1'b0)) dout=1'b0;
    if ((s1===1'b1) && (s0===1'b1) && (di3===1'b1)) dout=1'b1;
    if ((s1===1'b1) && (s0!==1'b0 && s0!==1'b1) && (di3===1'b0) && (di2===1'b0)) dout=1'b0;
    if ((s1===1'b1) && (s0!==1'b0 && s0!==1'b1) && (di3===1'b1) && (di2===1'b1)) dout=1'b1;
    if ((s1!==1'b0 && s1!==1'b1) && (s0===1'b0) && (di2===1'b0) && (di0===1'b0)) dout=1'b0;
    if ((s1!==1'b0 && s1!==1'b1) && (s0===1'b0) && (di2===1'b1) && (di0===1'b1)) dout=1'b1;
    if ((s1!==1'b0 && s1!==1'b1) && (s0===1'b1) && (di3===1'b0) && (di1===1'b0)) dout=1'b0;
    if ((s1!==1'b0 && s1!==1'b1) && (s0===1'b1) && (di3===1'b1) && (di1===1'b1)) dout=1'b1;
    if ((s1!==1'b0 && s1!==1'b1) && (s0!==1'b0 && s0!==1'b1) && (di3===1'b0) && (di2===1'b0) && (di1===1'b0) && (di0===1'b0)) dout=1'b0;
    if ((s1!==1'b0 && s1!==1'b1) && (s0!==1'b0 && s0!==1'b1) && (di3===1'b1) && (di2===1'b1) && (di1===1'b1) && (di0===1'b1)) dout=1'b1;
end
endmodule

//////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2014 PANGO MICROSYSTEMS, INC
// ALL RIGHTS RESERVED.
//
// THE SOURCE CODE CONTAINED HEREIN IS PROPRIETARY TO PANGO MICROSYSTEMS, INC.
// IT SHALL NOT BE REPRODUCED OR DISCLOSED IN WHOLE OR IN PART OR USED BY
// PARTIES WITHOUT WRITTEN AUTHORIZATION FROM THE OWNER.
//
//////////////////////////////////////////////////////////////////////////////
//
// Library: General technology primitive
// Filename: GTP_LUT5.v
//
// Functional description: 5-input Look-Up-Table
//
// Parameter description:
//      INIT: init value
//
// Port description:
//
// Revision:
//
//////////////////////////////////////////////////////////////////////////////

`timescale 1 ns / 1 ps

module GTP_LUT5
#(
    parameter [31:0] INIT = 32'h0000_0000
) (
    output wire Z,
    input wire I0, I1, I2, I3, I4
);

    wire x7, x6, x5, x4, y1;
    wire x3, x2, x1, x0, y0;

    INT_LUTMUX4_UDP udp_compat_0 (x7, I1, I0, INIT[31], INIT[30], INIT[29], INIT[28]);
    INT_LUTMUX4_UDP udp_compat_1 (x6, I1, I0, INIT[27], INIT[26], INIT[25], INIT[24]);
    INT_LUTMUX4_UDP udp_compat_2 (x5, I1, I0, INIT[23], INIT[22], INIT[21], INIT[20]);
    INT_LUTMUX4_UDP udp_compat_3 (x4, I1, I0, INIT[19], INIT[18], INIT[17], INIT[16]);
    INT_LUTMUX4_UDP udp_compat_4 (y1, I3, I2, x7, x6, x5, x4);

    INT_LUTMUX4_UDP udp_compat_5 (x3, I1, I0, INIT[15], INIT[14], INIT[13], INIT[12]);
    INT_LUTMUX4_UDP udp_compat_6 (x2, I1, I0, INIT[11], INIT[10], INIT[9], INIT[8]);
    INT_LUTMUX4_UDP udp_compat_7 (x1, I1, I0, INIT[7], INIT[6], INIT[5], INIT[4]);
    INT_LUTMUX4_UDP udp_compat_8 (x0, I1, I0, INIT[3], INIT[2], INIT[1], INIT[0]);
    INT_LUTMUX4_UDP udp_compat_9 (y0, I3, I2, x3, x2, x1, x0);

    INT_LUTMUX2_UDP udp_compat_10 (Z, I4, y1, y0);

endmodule


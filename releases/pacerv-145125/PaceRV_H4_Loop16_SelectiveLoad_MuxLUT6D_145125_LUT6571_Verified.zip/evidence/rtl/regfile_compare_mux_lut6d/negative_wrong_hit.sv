module baseline_read(input trace_write,ex_ready,wb_data_zero,input[4:0]wb_rd,id_rs1,id_rs2,input[31:0]wb_data,register_valid,zero_flat,forwarded_a,forwarded_b,input[1023:0]regs_flat,output[195:0]observed);
reg[31:0]compare_next_a,compare_next_b;wire[31:0]registers[0:31];wire register_zero[0:31];genvar j;generate for(j=0;j<32;j=j+1)begin assign registers[j]=regs_flat[32*j+:32];assign register_zero[j]=zero_flat[j];end endgenerate
wire id_value_a_zero=(trace_write && wb_rd==id_rs1) ? wb_data_zero :
        !id_register_a_valid || register_zero[id_rs1];
wire id_value_b_zero=(trace_write && wb_rd==id_rs2) ? wb_data_zero :
        !id_register_b_valid || register_zero[id_rs2];
wire id_register_a_valid=register_valid[id_rs1];
wire id_register_b_valid=register_valid[id_rs2];
wire mul_id_a_available=id_rs1!=0 && (id_register_a_valid || (trace_write && wb_rd==id_rs1));
wire mul_id_b_available=id_rs2!=0 && (id_register_b_valid || (trace_write && wb_rd==id_rs2));
wire [31:0] mul_id_operand_a=(trace_write && wb_rd==id_rs1) ? wb_data : registers[id_rs1];
wire [31:0] mul_id_operand_b=(trace_write && wb_rd==id_rs2) ? wb_data : registers[id_rs2];
wire [31:0] id_operand_a=(trace_write && wb_rd==id_rs1) ? wb_data : (id_register_a_valid ? registers[id_rs1] : 32'd0);
wire [31:0] id_operand_b=(trace_write && wb_rd==id_rs2) ? wb_data : (id_register_b_valid ? registers[id_rs2] : 32'd0);
    always @* begin
        compare_next_a=ex_ready ? id_operand_a : forwarded_a;
        compare_next_b=ex_ready ? id_operand_b : forwarded_b;
    end

assign observed={compare_next_a,compare_next_b,id_operand_a,id_operand_b,mul_id_operand_a,mul_id_operand_b,mul_id_a_available,mul_id_b_available,id_value_a_zero,id_value_b_zero};
endmodule
module modified_read(input trace_write,ex_ready,wb_data_zero,input[4:0]wb_rd,id_rs1,id_rs2,input[31:0]wb_data,register_valid,zero_flat,forwarded_a,forwarded_b,input[1023:0]regs_flat,output[195:0]observed);
reg[31:0]compare_next_a,compare_next_b;wire[31:0]registers[0:31];wire register_zero[0:31];genvar j;generate for(j=0;j<32;j=j+1)begin assign registers[j]=regs_flat[32*j+:32];assign register_zero[j]=zero_flat[j];end endgenerate
wire id_value_a_zero=(trace_write && wb_rd==id_rs1) ? wb_data_zero :
        !id_register_a_valid || register_zero[id_rs1];
wire id_value_b_zero=(trace_write && wb_rd==id_rs2) ? wb_data_zero :
        !id_register_b_valid || register_zero[id_rs2];
wire id_register_a_valid=register_valid[id_rs1];
wire id_register_b_valid=register_valid[id_rs2];
wire mul_id_a_available=id_rs1!=0 && (id_register_a_valid || (trace_write && wb_rd==id_rs1));
wire mul_id_b_available=id_rs2!=0 && (id_register_b_valid || (trace_write && wb_rd==id_rs2));
wire [31:0] mul_id_operand_a=(trace_write && wb_rd==id_rs1) ? wb_data : registers[id_rs1];
wire [31:0] mul_id_operand_b=(trace_write && wb_rd==id_rs2) ? wb_data : registers[id_rs2];
wire [31:0] id_operand_a=(trace_write && wb_rd==id_rs1) ? wb_data : (id_register_a_valid ? registers[id_rs1] : 32'd0);
wire [31:0] id_operand_b=(trace_write && wb_rd==id_rs2) ? wb_data : (id_register_b_valid ? registers[id_rs2] : 32'd0);
    wire [31:0] compare_mux_lut_a,compare_mux_lut_b;
    genvar compare_pair_bit;
    generate for(compare_pair_bit=0;compare_pair_bit<16;compare_pair_bit=compare_pair_bit+1) begin: g_compare_pair
        GTP_LUT6D #(.INIT(64'hff55aa00d8d8d8d9)) compare_mux_a(
            .I0(ex_ready),.I1(id_operand_a[2*compare_pair_bit]),.I2(forwarded_a[2*compare_pair_bit]),
            .I3(id_operand_a[2*compare_pair_bit+1]),.I4(forwarded_a[2*compare_pair_bit+1]),.I5(1'b1),
            .Z5(compare_mux_lut_a[2*compare_pair_bit]),.Z(compare_mux_lut_a[2*compare_pair_bit+1]));
        always @* begin
            case(^{ex_ready,id_operand_a[2*compare_pair_bit+:2],forwarded_a[2*compare_pair_bit+:2]})
                1'b0,1'b1: compare_next_a[2*compare_pair_bit+:2]=compare_mux_lut_a[2*compare_pair_bit+:2];
                default: compare_next_a[2*compare_pair_bit+:2]=ex_ready ? id_operand_a[2*compare_pair_bit+:2] : forwarded_a[2*compare_pair_bit+:2];
            endcase
        end
        GTP_LUT6D #(.INIT(64'hff55aa00d8d8d8d8)) compare_mux_b(
            .I0(ex_ready),.I1(id_operand_b[2*compare_pair_bit]),.I2(forwarded_b[2*compare_pair_bit]),
            .I3(id_operand_b[2*compare_pair_bit+1]),.I4(forwarded_b[2*compare_pair_bit+1]),.I5(1'b1),
            .Z5(compare_mux_lut_b[2*compare_pair_bit]),.Z(compare_mux_lut_b[2*compare_pair_bit+1]));
        always @* begin
            case(^{ex_ready,id_operand_b[2*compare_pair_bit+:2],forwarded_b[2*compare_pair_bit+:2]})
                1'b0,1'b1: compare_next_b[2*compare_pair_bit+:2]=compare_mux_lut_b[2*compare_pair_bit+:2];
                default: compare_next_b[2*compare_pair_bit+:2]=ex_ready ? id_operand_b[2*compare_pair_bit+:2] : forwarded_b[2*compare_pair_bit+:2];
            endcase
        end
    end endgenerate

assign observed={compare_next_a,compare_next_b,id_operand_a,id_operand_b,mul_id_operand_a,mul_id_operand_b,mul_id_a_available,mul_id_b_available,id_value_a_zero,id_value_b_zero};
endmodule
module regfile_miter(input trace_write,ex_ready,wb_data_zero,input[4:0]wb_rd,id_rs1,id_rs2,input[31:0]wb_data,register_valid,zero_flat,forwarded_a,forwarded_b,input[1023:0]regs_flat,output same);wire[195:0]a,b;baseline_read aa(.trace_write(trace_write),.ex_ready(ex_ready),.wb_data_zero(wb_data_zero),.wb_rd(wb_rd),.id_rs1(id_rs1),.id_rs2(id_rs2),.wb_data(wb_data),.register_valid(register_valid),.zero_flat(zero_flat),.forwarded_a(forwarded_a),.forwarded_b(forwarded_b),.regs_flat(regs_flat),.observed(a));modified_read bb(.trace_write(trace_write),.ex_ready(ex_ready),.wb_data_zero(wb_data_zero),.wb_rd(wb_rd),.id_rs1(id_rs1),.id_rs2(id_rs2),.wb_data(wb_data),.register_valid(register_valid),.zero_flat(zero_flat),.forwarded_a(forwarded_a),.forwarded_b(forwarded_b),.regs_flat(regs_flat),.observed(b));assign same=a==b;endmodule

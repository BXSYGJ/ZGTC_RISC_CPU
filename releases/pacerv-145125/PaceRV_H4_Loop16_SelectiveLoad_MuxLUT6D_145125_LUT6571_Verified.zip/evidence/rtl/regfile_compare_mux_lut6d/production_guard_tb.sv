`timescale 1ns/1ps
module production_guard_tb;reg[4:0]x;reg[31:0]na,nb,fa,fb;wire[63:0]observed;integer i,j,t;
actual_production_mux dut(x[0],na,nb,fa,fb,observed);
initial begin for(i=0;i<1024;i=i+1)begin t=i;for(j=0;j<5;j=j+1)begin case(t%4)0:x[j]=0;1:x[j]=1;2:x[j]=1'bx;3:x[j]=1'bz;endcase t=t/4;end for(j=0;j<16;j=j+1)begin na[2*j]=x[1];na[2*j+1]=x[3];fa[2*j]=x[2];fa[2*j+1]=x[4];end nb=na;fb=fa;#1;if(observed !== {x[0]?na:fa,x[0]?nb:fb})$fatal(1,"ACTUAL_PRODUCTION_PAIR_GUARD_MISMATCH case=%0d",i);end $display("ACTUAL_PRODUCTION_PAIR_GUARD_PASS cases=1024 macro_pairs=32 output_bits=64 checks=65536 XZ=complete");$finish;end endmodule

"""Run unchanged23scenario core harness with frozen13aa parent and real rollback."""
from pathlib import Path
import hashlib
import json
import subprocess

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
PARENT = ROOT / "candidates/loop16_h4_ram_memory_range/rtl"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
change = read(AREA / "CHANGE.json")
assert sha(AREA / "rollback_test.sv") == change["baseline_sha256"]
assert sha(PARENT / "rv32_btb.sv") == change["parent_btb_sha256"]
common = [str(p) for p in sorted(PARENT.glob("*.sv")) if p.name != "rv32_core.sv"]
tests = []
for label, filename in [("BASELINE", "BASELINE_FILE.sv"), ("MODIFIED", "MODIFIED_FILE.sv"), ("ROLLBACK", "rollback_test.sv")]:
    core = AREA / filename
    binary = AREA / (label.lower() + "-core.vvp")
    compile_command = ["iverilog", "-g2012", "-s", "core_token_tb", "-Pcore_token_tb.LOAD_ALU_MODE=2",
                       "-o", str(binary), str(AREA / "core_token_tb.sv"), str(core), *common, *[str(Path(p)) for p in json.loads((AREA/'MODEL_SUPPORT.json').read_text())['simulation_model_sources']]]
    compiled = subprocess.run(compile_command, cwd=AREA, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, timeout=180)
    (AREA / (label.lower() + "-compile.log")).write_text(compiled.stdout, encoding="utf-8")
    assert compiled.returncode == 0, compiled.stdout[-3000:]
    run_command = ["vvp", str(binary)]
    run = subprocess.run(run_command, cwd=AREA, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, timeout=180)
    (AREA / (label.lower() + "-core.log")).write_text(run.stdout, encoding="utf-8")
    assert run.returncode == 0 and "CORE_TOKEN_PASS early=1 mode=1 scenarios=23" in run.stdout, run.stdout[-3000:]
    tests.append(dict(label=label, compile_command=compile_command, compile_literal_output=compiled.stdout,
                      compile_exit_status=compiled.returncode, command=run_command,
                      input=dict(core=str(core), core_sha256=sha(core), mode=2,
                                 btb_sha256=sha(PARENT / "rv32_btb.sv"), harness_sha256=sha(AREA / "core_token_tb.sv")),
                      literal_output=run.stdout, exit_status=run.returncode))
    print(label + " REGFILE_COMPARE_MUX_LUT6D_CORE_PASS scenarios=23 exit=0", flush=True)
assert len({test["literal_output"] for test in tests}) == 1, "Full output/cycle mismatch"
architectural = [[line for line in test["literal_output"].splitlines() if line.startswith("ARCH ")] for test in tests]
assert len(architectural[0]) == 591 and architectural[0] == architectural[1] == architectural[2]
for relative, h in change["protected_parents"].items():
    assert sha(ROOT / relative) == h
result = dict(status="PASS", tests=tests, core_scenarios=23, architecture_lines=591,
              all_three_full_literal_outputs_equal=True, all_three_architectural_traces_equal=True,
              parent_btb_sha256=change["parent_btb_sha256"])
(AREA / "CORE_VERIFICATION.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8-sig")
print("REGFILE_COMPARE_MUX_LUT6D_CORE_FINAL_PASS BMR=3 scenarios=23 full_output=identical ARCH=591 cycles=identical exit=0", flush=True)

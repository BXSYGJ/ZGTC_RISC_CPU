"""Copy completed native build receipts from /tmp into the owned immutable evidence area."""
from pathlib import Path
import hashlib,json,shutil
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
b=load(HERE/'EXTENDED_MODEL_BUILD.json');p=load(HERE/'MODEL_PROCESS.json');f=load(HERE/'FINAL_RECHECK.json')
assert p['status']=='COMPLETE' and p['native_exit_status']==0
dst=HERE/'native_model_receipts';dst.mkdir(exist_ok=True)
rows=[]
for key in ('BUILD','compile_log'):
    src=Path(b[key]['path']);assert sha(src)==b[key]['sha256']
    out=dst/src.name
    if out.exists():assert out.read_bytes()==src.read_bytes()
    else:shutil.copy2(src,out)
    rows.append(dict(source=str(src),saved=str(out),sha256=sha(out)))
exe=Path(b['executable']);assert sha(exe)==b['executable_sha256']
z=dict(status='NATIVE_BUILD_RECEIPTS_FROZEN',identity=b['identity'],executable=str(exe),executable_sha256=sha(exe),actual_native_pid=p['native_pid'],native_exit_status=0,saved_receipts=rows,source_functional_record=dict(path=str(HERE/'FINAL_RECHECK.json'),sha256=sha(HERE/'FINAL_RECHECK.json')),four_artifacts_unchanged=True)
(HERE/'NATIVE_MODEL_RECHECK.json').write_text(json.dumps(z,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'NATIVE_MODEL_RECHECK.json')==z
for row in rows:assert sha(Path(row['saved']))==row['sha256']
for row in f['four_artifacts'].values():assert sha(Path(row['path']))==row['sha256']
print('SG51_NATIVE_MODEL_RECEIPTS_FROZEN identity='+b['identity']+' PID='+str(p['native_pid'])+' native_exit=0 four_artifacts=unchanged')

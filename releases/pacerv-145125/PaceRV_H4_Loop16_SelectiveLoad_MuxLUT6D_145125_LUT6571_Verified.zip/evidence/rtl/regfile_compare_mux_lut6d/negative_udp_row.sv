`timescale 1ns/1ps
// Deterministic translation of installed UDP table rows. UDP inputs Z match X.
module INT_LUTMUX2_UDP_DERIVED(dout,sel,di1,di0);
output reg dout;
input sel,di1,di0;
always @* begin
    dout=1'bx;
    if ((sel===1'b0) && (di0===1'b0)) dout=1'b1;
    if ((sel===1'b0) && (di0===1'b1)) dout=1'b1;
    if ((sel===1'b1) && (di1===1'b0)) dout=1'b0;
    if ((sel===1'b1) && (di1===1'b1)) dout=1'b1;
    if ((sel!==1'b0 && sel!==1'b1) && (di1===1'b0) && (di0===1'b0)) dout=1'b0;
    if ((sel!==1'b0 && sel!==1'b1) && (di1===1'b1) && (di0===1'b1)) dout=1'b1;
end
endmodule

"""Exercise every actual production pair with every possible five-input 4-state tuple."""
from pathlib import Path
import hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((HERE/'CHANGE.json').read_text());src=HERE/'MODIFIED_FILE.sv'
assert sha(src)==c['modified_sha256']
text=src.read_text();body=text[text.index('    wire [31:0] compare_mux_lut_a,compare_mux_lut_b;'):text.index('    // One comparison bank follows')]
assert body==c['edits'][-1][1]
model='module actual_production_mux(input ex_ready,input[31:0]id_operand_a,id_operand_b,forwarded_a,forwarded_b,output[63:0]observed);reg[31:0]compare_next_a,compare_next_b;\n'+body+'assign observed={compare_next_a,compare_next_b};endmodule\n'
(HERE/'actual_production_mux.sv').write_text(model,encoding='utf-8')
tb=['`timescale 1ns/1ps','module production_guard_tb;reg[4:0]x;reg[31:0]na,nb,fa,fb;wire[63:0]observed;integer i,j,t;','actual_production_mux dut(x[0],na,nb,fa,fb,observed);','initial begin for(i=0;i<1024;i=i+1)begin t=i;for(j=0;j<5;j=j+1)begin case(t%4)0:x[j]=0;1:x[j]=1;2:x[j]=1\'bx;3:x[j]=1\'bz;endcase t=t/4;end for(j=0;j<16;j=j+1)begin na[2*j]=x[1];na[2*j+1]=x[3];fa[2*j]=x[2];fa[2*j+1]=x[4];end nb=na;fb=fa;#1;if(observed !== {x[0]?na:fa,x[0]?nb:fb})$fatal(1,"ACTUAL_PRODUCTION_PAIR_GUARD_MISMATCH case=%0d",i);end $display("ACTUAL_PRODUCTION_PAIR_GUARD_PASS cases=1024 macro_pairs=32 output_bits=64 checks=65536 XZ=complete");$finish;end endmodule','']
(HERE/'production_guard_tb.sv').write_text('\n'.join(tb),encoding='utf-8')
models=json.loads((HERE/'MODEL_SUPPORT.json').read_text())['simulation_model_sources']
tests=[]
for label,cmd in [('compile',['iverilog','-g2012','-s','production_guard_tb','-o','production-guard.vvp','production_guard_tb.sv','actual_production_mux.sv',*models]),('run',['vvp','production-guard.vvp'])]:
    p=subprocess.run(cmd,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
    (HERE/('production-guard-'+label+'.log')).write_text(p.stdout,encoding='utf-8');assert p.returncode==0,p.stdout[-3000:]
    tests.append(dict(label=label,command=cmd,literal_output=p.stdout,exit_status=p.returncode))
result=dict(status='PASS_ALL_PAIR_FOURSTATE_INPUTS',production_core_sha256=sha(src),production_compare_body_sha256=hashlib.sha256(body.encode()).hexdigest(),actual_extracted_body_matches_source=True,fourstate_cases_per_pair=1024,macro_pairs=32,output_bit_checks=65536,tests=tests)
(HERE/'PRODUCTION_GUARD.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(tests[-1]['literal_output'],end='')

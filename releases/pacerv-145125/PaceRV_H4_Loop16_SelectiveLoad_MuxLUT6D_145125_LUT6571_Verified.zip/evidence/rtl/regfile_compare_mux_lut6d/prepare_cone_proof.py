"""Bind proven real primitive models into the existing arbitrary-state read-cone proof."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
text=(ROOT/'rtl_proposals/loop16_h4_regfile_id_operand_keep/verify_cones.py').read_text()
text=text.replace("for old,new in change['edits']:inverse=inverse.replace(new,old,1)","for old,new in reversed(change['edits']):inverse=inverse.replace(new,old,1)")
old="    compare=text[text.index('    always @* begin\\n        compare_next_a='):text.index('    // One comparison bank follows')]"
new="    if 'g_compare_pair' in text:\n        compare=text[text.index('    wire [31:0] compare_mux_lut_a,compare_mux_lut_b;'):text.index('    // One comparison bank follows')]\n        expected=change['edits'][-1][1]\n        assert compare==expected or compare==expected.replace(\"64'hff55aa00d8d8d8d8\",\"64'hff55aa00d8d8d8d9\",1)\n    else:\n        compare=text[text.index('    always @* begin\\n        compare_next_a='):text.index('    // One comparison bank follows')]"
assert old in text;text=text.replace(old,new,1)
old="negative=after.replace('wire [31:0] id_operand_a=(trace_write && wb_rd==id_rs1) ?', 'wire [31:0] id_operand_a=(trace_write && wb_rd==id_rs2) ?',1)"
new="negative=after.replace(\"64'hff55aa00d8d8d8d8\",\"64'hff55aa00d8d8d8d9\",1)"
assert old in text;text=text.replace(old,new,1)
needle="change=load(HERE/'CHANGE.json')"
text=text.replace(needle,needle+"\nmodel_support=load(HERE/'MODEL_SUPPORT.json')\nmodels=model_support['simulation_model_sources']\nmodel_arg=' '.join(models)\nassert all(sha(Path(p))==model_support['simulation_model_sha256'][str(Path(p).relative_to(HERE))] for p in models)",1)
text=text.replace("'read_verilog -sv actual_read_cones.sv; prep", "'read_verilog -sv actual_read_cones.sv '+model_arg+'; prep")
text=text.replace("'read_verilog -sv negative_wrong_hit.sv; prep", "'read_verilog -sv negative_wrong_hit.sv '+model_arg+'; prep")
text=text.replace("'actual_read_cones.sv'],'read-fourstate-compile'", "'actual_read_cones.sv',*models],'read-fourstate-compile'")
text=text.replace('source_inverse_outside_two_attributes','source_inverse_outside_two_keeps_and_compare_mux').replace('negative_wrong_port','negative_wrong_INIT')
text=text.replace('Only two syn_keep attributes changed. The inverse proves every storage, sequential event, reset, ISA, hazard, eligibility and counter statement byte-identical; all combinational consumers receive the same four-state values.','The inverse removes exactly two keep attributes and restores the original compare mux block. All other storage, sequential events, reset, ISA, hazard, eligibility and counters are byte-identical. The proven LUT model and original four-state fallback make all196 read-path outputs equal for arbitrary state; sequential consumers therefore retain original cycle semantics.')
text=text.replace('REGFILE_ID_OPERAND_KEEP','REGFILE_COMPARE_MUX_LUT6D')
(HERE/'verify_cones.py').write_text(text,encoding='utf-8')
print('SG51_PRODUCTION_CONE_PROOF_PREPARED outputs=196 derived_model_bound=5 negative=INIT_bit0')

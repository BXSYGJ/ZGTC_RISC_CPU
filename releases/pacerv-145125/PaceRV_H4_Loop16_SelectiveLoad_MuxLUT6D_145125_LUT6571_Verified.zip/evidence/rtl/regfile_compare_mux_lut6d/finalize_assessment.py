"""Preserve actual vendor-model results and independently test four-state guard."""
from pathlib import Path
import hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
deps=['GTP_LUT6D.v','GTP_LUT5.v','GTP_MUX2LUT6.v','INT_LUTMUX2_UDP.v','INT_LUTMUX4_UDP.v']
VENDOR=Path('/mnt/d/PDS_2022.2-SP6.4/arch/vendor/pango/verilog/simulation')
VERILATOR=Path('/tmp/ccfa-native-snapshot-verilator-v5.032-5a262564b1/verilator-5.032/bin/verilator')
records=[]
for name in deps:
    src=VENDOR/name;dst=HERE/'vendor'/name
    assert src.read_bytes()==dst.read_bytes()
    records.append(dict(name=name,installed_source=str(src),snapshot=str(dst),sha256=sha(dst)))
previous=[['iverilog','-g2012','-s','vendor_mux_tb','-o',str(HERE/'vendor-mux.vvp'),str(HERE/'vendor_mux_tb.sv'),*[str(HERE/'vendor'/n) for n in deps]],['vvp',str(HERE/'vendor-mux.vvp')],[str(VERILATOR),'--lint-only','--timing','-Wno-fatal','--top-module','vendor_mux_tb',str(HERE/'vendor_mux_tb.sv'),*[str(HERE/'vendor'/n) for n in deps]]]
tests=[]
for label,cmd,exitcode in zip(['iverilog_compile','actual_model_truth','verilator_lint'],previous,[0,0,1]):
    text=(HERE/(label+'.log')).read_text()
    tests.append(dict(label=label,command=cmd,literal_output=text,exit_status=exitcode,source='Previously executed actual assessment; saved logs reopened; not rerun.'))
assert 'VENDOR_LUT6D_TRUTH_PASS binary_cases=32 INIT=ff55aa00d8d8d8d8' in tests[1]['literal_output']
assert tests[2]['literal_output'].count('Unsupported: Verilog 1995 UDP Tables')==2
tb=['`timescale 1ns/1ps','module guard_fourstate_tb;reg[4:0]x;wire z,z5;reg[1:0]guarded;integer i,j,t,rawdiff;','GTP_LUT6D #(.INIT(64\'hff55aa00d8d8d8d8)) dut(.I0(x[0]),.I1(x[1]),.I2(x[2]),.I3(x[3]),.I4(x[4]),.I5(1\'b1),.Z(z),.Z5(z5));','always @* begin case(^x) 1\'b0,1\'b1:guarded={z,z5};default:guarded={x[0]?x[3]:x[4],x[0]?x[1]:x[2]};endcase end','initial begin rawdiff=0;for(i=0;i<1024;i=i+1)begin t=i;for(j=0;j<5;j=j+1)begin case(t%4)0:x[j]=0;1:x[j]=1;2:x[j]=1\'bx;3:x[j]=1\'bz;endcase t=t/4;end #1;if({z,z5} !== {x[0]?x[3]:x[4],x[0]?x[1]:x[2]})rawdiff=rawdiff+1;if(guarded !== {x[0]?x[3]:x[4],x[0]?x[1]:x[2]})$fatal(1,"guarded mux difference case=%d",i);end $display("LUT6D_GUARD_FOURSTATE_PASS cases=1024 raw_macro_differences=%0d",rawdiff);$finish;end endmodule','']
(HERE/'guard_fourstate_tb.sv').write_text('\n'.join(tb),encoding='utf-8')
new=[('guard_compile',['iverilog','-g2012','-s','guard_fourstate_tb','-o',str(HERE/'guard-fourstate.vvp'),str(HERE/'guard_fourstate_tb.sv'),*[str(HERE/'vendor'/n) for n in deps]]),('guard_fourstate',['vvp',str(HERE/'guard-fourstate.vvp')])]
for label,cmd in new:
    p=subprocess.run(cmd,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout,encoding='utf-8')
    tests.append(dict(label=label,command=cmd,literal_output=p.stdout,exit_status=p.returncode))
    assert p.returncode==0,p.stdout
assert 'LUT6D_GUARD_FOURSTATE_PASS cases=1024' in tests[-1]['literal_output']
baseline={p.relative_to(ROOT).as_posix():sha(p) for folder in ['rtl','physical_rtl'] for p in (ROOT/'candidates/loop16_h4_ram_memory_range'/folder).glob('*.sv')}
assert len(baseline)==35
result=dict(status='ASSESSMENT_COMPLETE_STANDARD_VERILATOR_UDP_OBSTACLE',vendor_sources=records,INIT='ff55aa00d8d8d8d8',port_contract='Z5=INIT_low[I4:I0]; Z=I5?INIT_high[I4:I0]:INIT_low[I4:I0]; I0 is least significant truth-table bit.',tests=tests,parent_source_hashes=baseline,production_candidate_created=False,standard_recipe_changed=False,model_replacement_used=False,black_box_used=False,alternative_official_model='Both installed PDS versions have byte-identical GTP_LUT6D.v; installed simulation implementation uses UDP dependencies. No alternate directly named official behavioral model found in SP6.4 verilog simulation/bsim trees.')
(HERE/'VENDOR_ASSESSMENT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
summary=['SG51 vendor primitive assessment','',
'The installed official GTP_LUT6D model implements Z5 from the low 32 INIT bits and Z from the I5-selected half. For I0=ex_ready, I1=normal0, I2=forward0, I3=normal1, I4=forward1 and I5=1, the correct INIT is 64\'hff55aa00d8d8d8d8.',
'Actual iverilog compilation and all 32 binary truth cases pass. The real vendor model has four-state differences from a ternary for some X/Z data; the reduction-case/default-original-ternary guard passes all 1024 four-state combinations.',
'The standard installed Verilator 5.032 rejects both actual vendor UDP tables (INT_LUTMUX2_UDP and INT_LUTMUX4_UDP) with exit 1. Merely adding the five official dependency files to experiment.py does not create a working standard simulation model.',
'The model files are preserved byte-for-byte with installed-source hashes. The two installed PDS releases have the same GTP_LUT6D model. No pseudo model, ignored black box, changed tool flags or source-selection ifdef is used.',
'This assessment creates no production candidate and changes no original recipe or SG30 source. It launches no PDS, CoreMark benchmark, firmware generation or long simulation.','']
(HERE/'ASSESSMENT.md').write_text('\n'.join(summary),encoding='utf-8')
recheck=dict(status=result['status'],assessment=dict(path=str(HERE/'VENDOR_ASSESSMENT.json'),sha256=sha(HERE/'VENDOR_ASSESSMENT.json')),summary=dict(path=str(HERE/'ASSESSMENT.md'),sha256=sha(HERE/'ASSESSMENT.md')),script=dict(path=str(Path(__file__)),sha256=sha(Path(__file__))),official_model_files=records,parent_source_hashes=baseline)
(HERE/'FINAL_RECHECK.json').write_text(json.dumps(recheck,indent=2)+'\n',encoding='utf-8')
assert json.loads((HERE/'FINAL_RECHECK.json').read_text())==recheck
for k in ('assessment','summary','script'):assert sha(Path(recheck[k]['path']))==recheck[k]['sha256']
for rel,h in baseline.items():assert sha(ROOT/rel)==h
print(tests[-1]['literal_output'],end='')
print('SG51_ASSESSMENT_COMPLETE vendor_truth=PASS guard_fourstate=1024 standard_Verilator=UDP_UNSUPPORTED candidate_not_frozen parent35=unchanged all_evidence=reopened')

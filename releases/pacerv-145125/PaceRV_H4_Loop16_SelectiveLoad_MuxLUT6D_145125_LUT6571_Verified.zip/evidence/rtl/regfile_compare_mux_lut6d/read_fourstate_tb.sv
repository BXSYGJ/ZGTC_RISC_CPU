`timescale 1ns/1ps
module read_fourstate_tb;reg trace_write,ex_ready,wb_data_zero;reg[4:0]wb_rd,id_rs1,id_rs2;reg[31:0]wb_data,register_valid,zero_flat,forwarded_a,forwarded_b;reg[1023:0]regs_flat;wire[195:0]a,b;
baseline_read aa(.trace_write(trace_write),.ex_ready(ex_ready),.wb_data_zero(wb_data_zero),.wb_rd(wb_rd),.id_rs1(id_rs1),.id_rs2(id_rs2),.wb_data(wb_data),.register_valid(register_valid),.zero_flat(zero_flat),.forwarded_a(forwarded_a),.forwarded_b(forwarded_b),.regs_flat(regs_flat),.observed(a));modified_read bb(.trace_write(trace_write),.ex_ready(ex_ready),.wb_data_zero(wb_data_zero),.wb_rd(wb_rd),.id_rs1(id_rs1),.id_rs2(id_rs2),.wb_data(wb_data),.register_valid(register_valid),.zero_flat(zero_flat),.forwarded_a(forwarded_a),.forwarded_b(forwarded_b),.regs_flat(regs_flat),.observed(b));
integer i,j,checks=0;function[0:0]state4(input integer v);begin case(v&3)0:state4=0;1:state4=1;2:state4=1'bx;3:state4=1'bz;endcase end endfunction
initial begin for(i=0;i<8192;i=i+1)begin
trace_write=state4(i);ex_ready=state4(i>>2);wb_data_zero=state4(i>>4);wb_rd=(i>>4)&31;id_rs1=(i>>6)&31;id_rs2=(i>>8)&31;
for(j=0;j<32;j=j+1)begin register_valid[j]=state4(i+j);zero_flat[j]=state4((i>>1)+j);wb_data[j]=state4((i>>2)+j);forwarded_a[j]=state4((i>>3)+j);forwarded_b[j]=state4((i>>4)+j);end
for(j=0;j<1024;j=j+1)regs_flat[j]=state4((i>>3)+j);
if(i%5==0)wb_rd[1]=1'bx;if(i%7==0)id_rs1[3]=1'bz;if(i%11==0)id_rs2[0]=1'bx;
#1;if(a!==b)$fatal(1,"READ_CONE_XZ_CHANGED case=%0d",i);checks=checks+1;
end $display("REGFILE_READ_CONE_FOURSTATE_PASS checks=%0d outputs=196 selectors_XZ=covered data_XZ=covered",checks);$finish;end endmodule

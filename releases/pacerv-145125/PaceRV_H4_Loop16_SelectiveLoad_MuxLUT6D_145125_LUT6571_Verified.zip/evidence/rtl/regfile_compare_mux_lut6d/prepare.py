"""SG51: pack adjacent compare mux bits with proven real-vendor primitives."""
from pathlib import Path
import difflib,hashlib,json,shutil
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
NAME='loop16_h4_regfile_compare_mux_lut6d';DEST=ROOT/'candidates'/NAME
PARENT=ROOT/'candidates/loop16_h4_ram_memory_range'
DONOR=ROOT/'rtl_proposals/loop16_h4_regfile_id_operand_keep'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
model=json.loads((HERE/'MODEL_SUPPORT.json').read_text());assert model['status']=='MODEL_EQUIVALENT_AND_VERILATOR_SUPPORTED'
assert not DEST.exists()
original=(PARENT/'rtl/rv32_core.sv').read_bytes();before=original.decode();after=before;edits=[]
assert sha(PARENT/'rtl/rv32_core.sv')=='8af95f92009be4979e23fa0bee77eff3bc6858357173470a0bdf7db75326c416'
for port in ('a','b'):
    old='    wire [31:0] id_operand_'+port+'='
    new='    (* syn_keep=1 *) wire [31:0] id_operand_'+port+'='
    assert after.count(old)==1;after=after.replace(old,new,1);edits.append([old,new])
old='    always @* begin\n        compare_next_a=ex_ready ? id_operand_a : forwarded_a;\n        compare_next_b=ex_ready ? id_operand_b : forwarded_b;\n    end\n'
assert after.count(old)==1
lines=['    wire [31:0] compare_mux_lut_a,compare_mux_lut_b;','    genvar compare_pair_bit;','    generate for(compare_pair_bit=0;compare_pair_bit<16;compare_pair_bit=compare_pair_bit+1) begin: g_compare_pair']
for port in ('a','b'):
    lines += ["        GTP_LUT6D #(.INIT(64'hff55aa00d8d8d8d8)) compare_mux_"+port+'(',"            .I0(ex_ready),.I1(id_operand_"+port+'[2*compare_pair_bit]),.I2(forwarded_'+port+'[2*compare_pair_bit]),','            .I3(id_operand_'+port+'[2*compare_pair_bit+1]),.I4(forwarded_'+port+"[2*compare_pair_bit+1]),.I5(1'b1),",'            .Z5(compare_mux_lut_'+port+'[2*compare_pair_bit]),.Z(compare_mux_lut_'+port+'[2*compare_pair_bit+1]));','        always @* begin','            case(^{ex_ready,id_operand_'+port+'[2*compare_pair_bit+:2],forwarded_'+port+'[2*compare_pair_bit+:2]})',"                1'b0,1'b1: compare_next_"+port+'[2*compare_pair_bit+:2]=compare_mux_lut_'+port+'[2*compare_pair_bit+:2];','                default: compare_next_'+port+'[2*compare_pair_bit+:2]=ex_ready ? id_operand_'+port+'[2*compare_pair_bit+:2] : forwarded_'+port+'[2*compare_pair_bit+:2];','            endcase','        end']
lines+=['    end endgenerate',''];new='\n'.join(lines)
after=after.replace(old,new,1);edits.append([old,new])
inverse=after
for old,new in reversed(edits):inverse=inverse.replace(new,old,1)
assert inverse.encode()==original
for name,data in [('BASELINE_FILE.sv',original),('MODIFIED_FILE.sv',after.encode()),('rv32_core.sv',after.encode()),('rollback_test.sv',after.encode())]:(HERE/name).write_bytes(data)
(HERE/'DIFF_FILE.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='SG30/core8af.sv',tofile=NAME+'/core.sv')),encoding='utf-8')
protected={}
for parentname in ('loop16_h4_ram_memory_range','loop16_h4_single_write','load_simple_loop16_h4'):
    for folder in ('rtl','physical_rtl'):
        for p in (ROOT/'candidates'/parentname/folder).glob('*.sv'):protected[p.relative_to(ROOT).as_posix()]=sha(p)
change=dict(changed_field='Two existing id_operand result syn_keep attributes plus replacement of compare_next_a/b32bit selection by32adjacent-bit GTP_LUT6D macros with exact original ternary four-state fallback; no sequential/ISA/latency/counter change.',baseline_sha256=sha(HERE/'BASELINE_FILE.sv'),modified_sha256=sha(HERE/'MODIFIED_FILE.sv'),parent_btb_sha256=sha(PARENT/'rtl/rv32_btb.sv'),parent_candidate=str(PARENT),edits=edits,exact_source_inverse=True,protected_parents=protected,model_support=dict(path=str(HERE/'MODEL_SUPPORT.json'),sha256=sha(HERE/'MODEL_SUPPORT.json')),macro_INIT='ff55aa00d8d8d8d8',macro_instances_after_elaboration=32,simulation_model_sha256=model['simulation_model_sha256'])
for folder,count in [('rtl',17),('physical_rtl',18)]:
    shutil.copytree(PARENT/folder,DEST/folder);(DEST/folder/'rv32_core.sv').write_bytes(after.encode())
    change[folder]={p.name:sha(p) for p in sorted((DEST/folder).glob('*.sv'))};assert len(change[folder])==count
shutil.copy2(DONOR/'core_token_tb.sv',HERE/'core_token_tb.sv')
rollback=(DONOR/'ROLLBACK.sh').read_text(encoding='utf-8-sig').replace('REGFILE_ID_OPERAND_KEEP','REGFILE_COMPARE_MUX_LUT6D')
for name in ('ROLLBACK.sh','ROLLBACK.ps1'):(HERE/name).write_text(rollback,encoding='utf-8-sig');(HERE/name).chmod(0o755)
script=(DONOR/'run_rollback.py').read_text().replace('loop16_h4_regfile_id_operand_keep','regfile_compare_mux_lut6d');(HERE/'run_rollback.py').write_text(script,encoding='utf-8')
script=(DONOR/'verify_core.py').read_text().replace('REGFILE_ID_OPERAND_KEEP','REGFILE_COMPARE_MUX_LUT6D')
script=script.replace('*common]',"*common, *[str(Path(p)) for p in json.loads((AREA/'MODEL_SUPPORT.json').read_text())['simulation_model_sources']]]")
assert '*common, *[' in script
(HERE/'verify_core.py').write_text(script,encoding='utf-8')
(HERE/'CHANGE.json').write_text(json.dumps(change,indent=2)+'\n',encoding='utf-8')
(HERE/'VERIFICATION.txt').write_text(json.dumps(dict(status='SOURCE_FROZEN_PROOF_PENDING',changed_field=change['changed_field'],core_sha256=change['modified_sha256']),indent=2)+'\n',encoding='utf-8')
print('SG51_SOURCE_FROZEN core='+change['modified_sha256']+' macros=32 INIT=ff55aa00d8d8d8d8 source17_18=35 model_support=proven')

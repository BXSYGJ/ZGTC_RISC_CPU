`timescale 1ns/1ps
module guard_fourstate_tb;reg[4:0]x;wire z,z5;reg[1:0]guarded;integer i,j,t,rawdiff;
GTP_LUT6D #(.INIT(64'hff55aa00d8d8d8d8)) dut(.I0(x[0]),.I1(x[1]),.I2(x[2]),.I3(x[3]),.I4(x[4]),.I5(1'b1),.Z(z),.Z5(z5));
always @* begin case(^x) 1'b0,1'b1:guarded={z,z5};default:guarded={x[0]?x[3]:x[4],x[0]?x[1]:x[2]};endcase end
initial begin rawdiff=0;for(i=0;i<1024;i=i+1)begin t=i;for(j=0;j<5;j=j+1)begin case(t%4)0:x[j]=0;1:x[j]=1;2:x[j]=1'bx;3:x[j]=1'bz;endcase t=t/4;end #1;if({z,z5} !== {x[0]?x[3]:x[4],x[0]?x[1]:x[2]})rawdiff=rawdiff+1;if(guarded !== {x[0]?x[3]:x[4],x[0]?x[1]:x[2]})$fatal(1,"guarded mux difference case=%d",i);end $display("LUT6D_GUARD_FOURSTATE_PASS cases=1024 raw_macro_differences=%0d",rawdiff);$finish;end endmodule

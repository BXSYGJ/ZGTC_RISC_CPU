"""Name only anonymous UDP-use sites after proving equivalent module definitions."""
from pathlib import Path
import hashlib,json,re,subprocess
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
udp=read(HERE/'MODEL_ADAPTATION.json')
assert udp['full_fourstate']['exit_status']==0 and udp['negative_wrong_truth_row']['exit_status']==1
rows=[]
for name,expected in [('GTP_LUT5.v',11),('GTP_MUX2LUT6.v',1)]:
    src=HERE/'vendor'/name;before=src.read_bytes().decode();i=[0];edits=[]
    def replace(m):
        old=m[0];new=m[1]+m[2]+' udp_compat_'+str(i[0])+m[3]+'('
        i[0]+=1;edits.append([old,new]);return new
    after=re.sub(r'(^[ \t]+)(INT_LUTMUX[24]_UDP)([ \t]+)\(',replace,before,flags=re.M)
    assert len(edits)==expected
    inverse=after
    for old,new in edits:inverse=inverse.replace(new,old,1)
    assert inverse.encode()==src.read_bytes()
    dst=HERE/'derived_vendor'/name;dst.write_bytes(after.encode())
    rows.append(dict(file=name,official=str(src),official_sha256=sha(src),derived=str(dst),derived_sha256=sha(dst),added_instance_names=expected,exact_byte_inverse=True,edits=edits))
names=['GTP_LUT6D','GTP_LUT5','GTP_MUX2LUT6','INT_LUTMUX2_UDP','INT_LUTMUX4_UDP']
official=[];derived=[]
for namespace,group in [('OFFICIAL',official),('DERIVED',derived)]:
    for name in names:
        if namespace=='OFFICIAL' or name=='GTP_LUT6D':src=HERE/'vendor'/(name+'.v')
        else:src=HERE/'derived_vendor'/(name+('.sv' if name.startswith('INT_') else '.v'))
        text=src.read_bytes().decode()
        for ident in names:text=re.sub(r'\b'+ident+r'\b',ident+'_'+namespace,text)
        dst=HERE/(name+'_'+namespace+'_full.v');dst.write_bytes(text.encode());group.append(dst)
tb=['`timescale 1ns/1ps','module full_model_tb;reg[4:0]x;wire zo,z5o,zd,z5d;integer i,j,t,binary;','GTP_LUT6D_OFFICIAL #(.INIT(64\'hff55aa00d8d8d8d8)) o(.I0(x[0]),.I1(x[1]),.I2(x[2]),.I3(x[3]),.I4(x[4]),.I5(1\'b1),.Z(zo),.Z5(z5o));','GTP_LUT6D_DERIVED #(.INIT(64\'hff55aa00d8d8d8d8)) d(.I0(x[0]),.I1(x[1]),.I2(x[2]),.I3(x[3]),.I4(x[4]),.I5(1\'b1),.Z(zd),.Z5(z5d));','initial begin binary=0;for(i=0;i<1024;i=i+1)begin t=i;for(j=0;j<5;j=j+1)begin case(t%4)0:x[j]=0;1:x[j]=1;2:x[j]=1\'bx;3:x[j]=1\'bz;endcase t=t/4;end #1;if({zo,z5o} !== {zd,z5d})$fatal(1,"FULL_MODEL_MISMATCH case=%0d",i);case(^x)1\'b0,1\'b1:begin binary=binary+1;if({zd,z5d} !== {x[0]?x[3]:x[4],x[0]?x[1]:x[2]})$fatal(1,"BINARY_MUX_MISMATCH");end default:begin end endcase end $display("FULL_GTP_LUT6D_EQUIVALENCE_PASS fourstate_cases=1024 binary_cases=%0d original3_models=preserved anonymous_names=12",binary);$finish;end endmodule','']
(HERE/'full_model_tb.sv').write_text('\n'.join(tb),encoding='utf-8')
def run(cmd,label,expected=0):
    p=subprocess.run(cmd,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout,encoding='utf-8');assert p.returncode==expected,p.stdout[-5000:]
    return dict(command=cmd,literal_output=p.stdout,exit_status=p.returncode)
compile=run(['iverilog','-g2012','-s','full_model_tb','-o','full-model.vvp','full_model_tb.sv',*[str(p) for p in official+derived]],'full-model-compile')
proof=run(['vvp','full-model.vvp'],'full-model')
assert 'fourstate_cases=1024 binary_cases=32' in proof['literal_output']
sources=[str(HERE/'vendor/GTP_LUT6D.v'),str(HERE/'derived_vendor/GTP_LUT5.v'),str(HERE/'derived_vendor/GTP_MUX2LUT6.v'),str(HERE/'derived_vendor/INT_LUTMUX2_UDP.sv'),str(HERE/'derived_vendor/INT_LUTMUX4_UDP.sv')]
verilator='/tmp/ccfa-native-snapshot-verilator-v5.032-5a262564b1/verilator-5.032/bin/verilator'
lint=run([verilator,'--lint-only','--timing','-Wno-fatal','--top-module','vendor_mux_tb',str(HERE/'vendor_mux_tb.sv'),*sources],'normalized-verilator-lint')
result=dict(status='MODEL_EQUIVALENT_AND_VERILATOR_SUPPORTED',normalization=rows,UDP_proof=dict(path=str(HERE/'MODEL_ADAPTATION.json'),sha256=sha(HERE/'MODEL_ADAPTATION.json')),full_model_compile=compile,full_model_fourstate=proof,verilator_lint=lint,simulation_model_sources=sources,simulation_model_sha256={str(Path(p).relative_to(HERE)):sha(Path(p)) for p in sources},official_GTP_LUT6D_byte_unchanged=True,generator=dict(path=str(Path(__file__)),sha256=sha(Path(__file__))))
(HERE/'MODEL_SUPPORT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert read(HERE/'MODEL_SUPPORT.json')==result
print(proof['literal_output'],end='');print('SG51_MODEL_SUPPORT_READY UDP4160=PASS full_GTP1024=PASS binary32=PASS negative=exit1 Verilator_lint=exit0 normalization=12_instance_names_only')

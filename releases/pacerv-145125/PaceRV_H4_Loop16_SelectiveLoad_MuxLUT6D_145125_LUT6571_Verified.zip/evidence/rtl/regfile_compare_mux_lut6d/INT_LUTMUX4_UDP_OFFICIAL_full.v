//////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2014 PANGO MICROSYSTEMS, INC
// ALL RIGHTS RESERVED.
//
// THE SOURCE CODE CONTAINED HEREIN IS PROPRIETARY TO PANGO MICROSYSTEMS, INC.
// IT SHALL NOT BE REPRODUCED OR DISCLOSED IN WHOLE OR IN PART OR USED BY
// PARTIES WITHOUT WRITTEN AUTHORIZATION FROM THE OWNER.
//
//////////////////////////////////////////////////////////////////////////////

`timescale 1 ns / 1 ps

primitive INT_LUTMUX4_UDP_OFFICIAL (dout, s1, s0, di3, di2, di1, di0);
    output dout;
    input s1, s0, di3, di2, di1, di0;

    table
    //  s1  s0  di3 di2 di1 di0 : dout
        0   0   ?   ?   ?   0   : 0 ;
        0   0   ?   ?   ?   1   : 1 ;
        0   1   ?   ?   0   ?   : 0 ;
        0   1   ?   ?   1   ?   : 1 ;
        0   x   ?   ?   0   0   : 0 ;
        0   x   ?   ?   1   1   : 1 ;
        1   0   ?   0   ?   ?   : 0 ;
        1   0   ?   1   ?   ?   : 1 ;
        1   1   0   ?   ?   ?   : 0 ;
        1   1   1   ?   ?   ?   : 1 ;
        1   x   0   0   ?   ?   : 0 ;
        1   x   1   1   ?   ?   : 1 ;
        x   0   ?   0   ?   0   : 0 ;
        x   0   ?   1   ?   1   : 1 ;
        x   1   0   ?   0   ?   : 0 ;
        x   1   1   ?   1   ?   : 1 ;
        x   x   0   0   0   0   : 0 ;
        x   x   1   1   1   1   : 1 ;
    endtable

endprimitive


//////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016 PANGO MICROSYSTEMS, INC
// ALL RIGHTS RESERVED.
//
// THE SOURCE CODE CONTAINED HEREIN IS PROPRIETARY TO PANGO MICROSYSTEMS, INC.
// IT SHALL NOT BE REPRODUCED OR DISCLOSED IN WHOLE OR IN PART OR USED BY
// PARTIES WITHOUT WRITTEN AUTHORIZATION FROM THE OWNER.
//
//////////////////////////////////////////////////////////////////////////////
//
// Library: General technology primitive
// Filename: GTP_LUT6D_OFFICIAL.v
//
// Functional description: 6-input Look-Up-Table with double output
//
// Parameter description:
//      INIT: init value
//
// Port description:
//
// Revision:
//
//////////////////////////////////////////////////////////////////////////////

`timescale 1 ns / 1 ps

module GTP_LUT6D_OFFICIAL
#(
    parameter [63:0] INIT = 64'h0000_0000_0000_0000
) (
    output wire Z, Z5,
    input wire I0, I1, I2, I3, I4, I5
);

    wire z5a, z5b;

    GTP_LUT5_OFFICIAL #(.INIT(INIT[31:0]))
        l5a (.I0(I0), .I1(I1), .I2(I2), .I3(I3), .I4(I4), .Z(z5a));

    GTP_LUT5_OFFICIAL #(.INIT(INIT[63:32]))
        l5b (.I0(I0), .I1(I1), .I2(I2), .I3(I3), .I4(I4), .Z(z5b));

    GTP_MUX2LUT6_OFFICIAL mxl6 (.I0(z5a), .I1(z5b), .S(I5), .Z(Z));
    buf (Z5, z5a);

endmodule


SG51 actual vendor mapping

Actual synthesis: SG30 parent6142 LUT/2561 FF/471 dramLUT; SG51 6121/2561/471, LUT change -21.
Exactly32 explicit GTP_LUT6D instances survive (16 adjacent-bit pairs on each operand port). All32 INIT values are ff55aa00d8d8d8d8 and every I0..I5/Z/Z5 connection matches production source exactly.
All64 macro outputs directly drive the corresponding original ex_operand_a/b flip-flop D pins. The four-state fallback adds no binary hardware between macro and operand FF.
Register data32RAM, zero metadata2RAM and register_valid32FF remain unchanged. Comparison mux output cells change from64LUT6 to32LUT6D. Other local mapping explains the difference between gross32mux cells saved and net21LUT reduction.
Module LUT deltas: {"rv32_alu": 0, "rv32_btb": 5, "rv32_cache": -1, "rv32_cache_1": 2, "rv32_core": -19, "rv32_decode": 2, "rv32_machine": -5, "rv32_memory_system": 1, "rv32_muldiv": 1, "rv32_peripherals": 0, "rv32_rvc_frontend": -9, "rv32_soc": 2}. Full primitive-type changes are in SYNTHESIS_AUDIT.json.
All17 simulation/18physical files match actual synthesis inputs and INPUT_HASHES. Frozen functional four artifacts, core75d136 and all proved model dependencies remain unchanged.
This audit reads existing raw logs and VM only. PDS route and benchmark qualification remain root-owned.

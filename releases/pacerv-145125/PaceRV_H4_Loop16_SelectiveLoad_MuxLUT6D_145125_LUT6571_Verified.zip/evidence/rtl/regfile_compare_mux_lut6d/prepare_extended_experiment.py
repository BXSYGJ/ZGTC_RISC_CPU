"""Copy standard builder, add only five verified simulation dependencies and their digest."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=ROOT/'scripts/experiment.py';before=original.read_text();after=before
edits=[("ROOT = Path(__file__).resolve().parents[1]","ROOT = Path(__file__).resolve().parents[2]\nMODEL_SUPPORT_PATH = Path(__file__).with_name('MODEL_SUPPORT.json')"),
       ("    digest = hashlib.sha256()\n    for p in inputs:","    extra_models = [Path(p) for p in json.loads(MODEL_SUPPORT_PATH.read_text())['simulation_model_sources']]\n    inputs += extra_models\n    digest = hashlib.sha256()\n    for p in inputs:"),
       ("    command[command.index('-j')+1] = str(threads)","    command += [str(p) for p in extra_models]\n    command[command.index('-j')+1] = str(threads)")]
for old,new in edits:assert after.count(old)==1;after=after.replace(old,new,1)
inverse=after
for old,new in reversed(edits):inverse=inverse.replace(new,old,1)
assert inverse==before
dst=HERE/'experiment_extended.py';dst.write_text(after,encoding='utf-8')
record=dict(status='EXACT_STANDARD_BUILDER_PLUS_VERIFIED_MODELS',original=dict(path=str(original),sha256=sha(original)),derived=dict(path=str(dst),sha256=sha(dst)),edits=edits,source_inverse_exact=True,extra_models=json.loads((HERE/'MODEL_SUPPORT.json').read_text())['simulation_model_sources'],unchanged_contract='Same native driver, observer, all standard RTL files, tool executable/flags, load_bubble1 and threads1. Identity appends all five verified primitive model filenames and actual bytes before unchanged bubble digest. No original recipe or standard builder changed.',recipe=dict(path=str(ROOT/'recipe.json'),sha256=sha(ROOT/'recipe.json')))
(HERE/'EXTENDED_RECIPE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('SG51_EXTENDED_STANDARD_RECIPE_PREPARED exact_inverse=1 model_dependencies=5 original_recipe=unchanged')

"""Actual production read-cones: exact inverse, SAT, X/Z and negative control."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
change=load(HERE/'CHANGE.json')
model_support=load(HERE/'MODEL_SUPPORT.json')
models=model_support['simulation_model_sources']
model_arg=' '.join(models)
assert all(sha(Path(p))==model_support['simulation_model_sha256'][str(Path(p).relative_to(HERE))] for p in models)
before=(HERE/'BASELINE_FILE.sv').read_text()
after=(HERE/'MODIFIED_FILE.sv').read_text()
assert sha(HERE/'BASELINE_FILE.sv')==change['baseline_sha256'] and sha(HERE/'MODIFIED_FILE.sv')==change['modified_sha256']
inverse=after
for old,new in reversed(change['edits']):inverse=inverse.replace(new,old,1)
assert inverse==before
def statements(text):
    found=[]
    for name in ('id_wb_read_hit_a','id_wb_read_hit_b','id_value_a_zero','id_value_b_zero','id_register_a_valid','id_register_b_valid','mul_id_a_available','mul_id_b_available','mul_id_operand_a','mul_id_operand_b','id_operand_a','id_operand_b'):
        match=re.search(r'^    (?:\(\*[^\n]*?\*\) )?wire(?: \[31:0\])? '+name+r'=(.*?);',text,re.M|re.S)
        if match:found.append('wire '+('[31:0] ' if name in ('mul_id_operand_a','mul_id_operand_b','id_operand_a','id_operand_b') else '')+name+'='+match[1]+';')
    assert len(found)==(12 if 'id_wb_read_hit_a' in text else 10),len(found)
    if 'g_compare_pair' in text:
        compare=text[text.index('    wire [31:0] compare_mux_lut_a,compare_mux_lut_b;'):text.index('    // One comparison bank follows')]
        expected=change['edits'][-1][1]
        assert compare==expected or compare==expected.replace("64'hff55aa00d8d8d8d8","64'hff55aa00d8d8d8d9",1)
    else:
        compare=text[text.index('    always @* begin\n        compare_next_a='):text.index('    // One comparison bank follows')]
    return '\n'.join(found)+'\n'+compare
ports='input trace_write,ex_ready,wb_data_zero,input[4:0]wb_rd,id_rs1,id_rs2,input[31:0]wb_data,register_valid,zero_flat,forwarded_a,forwarded_b,input[1023:0]regs_flat,output[195:0]observed'
def model(name,text):
    common='reg[31:0]compare_next_a,compare_next_b;wire[31:0]registers[0:31];wire register_zero[0:31];genvar j;generate for(j=0;j<32;j=j+1)begin assign registers[j]=regs_flat[32*j+:32];assign register_zero[j]=zero_flat[j];end endgenerate\n'
    out='assign observed={compare_next_a,compare_next_b,id_operand_a,id_operand_b,mul_id_operand_a,mul_id_operand_b,mul_id_a_available,mul_id_b_available,id_value_a_zero,id_value_b_zero};'
    return 'module '+name+'('+ports+');\n'+common+statements(text)+'\n'+out+'\nendmodule\n'
connection='.trace_write(trace_write),.ex_ready(ex_ready),.wb_data_zero(wb_data_zero),.wb_rd(wb_rd),.id_rs1(id_rs1),.id_rs2(id_rs2),.wb_data(wb_data),.register_valid(register_valid),.zero_flat(zero_flat),.forwarded_a(forwarded_a),.forwarded_b(forwarded_b),.regs_flat(regs_flat)'
miter='module regfile_miter('+ports.replace(',output[195:0]observed',',output same')+');wire[195:0]a,b;baseline_read aa('+connection+',.observed(a));modified_read bb('+connection+',.observed(b));assign same=a==b;endmodule\n'
positive=model('baseline_read',before)+model('modified_read',after)+miter
(HERE/'actual_read_cones.sv').write_text(positive,encoding='utf-8')
def run(command,label,expected=0):
    p=subprocess.run(command,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout,encoding='utf-8')
    assert p.returncode==expected,p.stdout[-3000:]
    return dict(command=command,input_directory=str(HERE),literal_output=p.stdout,exit_status=p.returncode)
proof=run(['yosys','-p','read_verilog -sv actual_read_cones.sv '+model_arg+'; prep -top regfile_miter -flatten; memory_map; opt; sat -verify -prove same 1 -show-inputs'],'read-cone-SAT')
assert 'SAT proof finished - no model found: SUCCESS!' in proof['literal_output']
negative=after.replace("64'hff55aa00d8d8d8d8","64'hff55aa00d8d8d8d9",1)
assert negative!=after
(HERE/'negative_wrong_hit.sv').write_text(model('baseline_read',before)+model('modified_read',negative)+miter,encoding='utf-8')
neg=run(['yosys','-p','read_verilog -sv negative_wrong_hit.sv '+model_arg+'; prep -top regfile_miter -flatten; memory_map; opt; sat -verify -prove same 1 -show-inputs'],'negative-wrong-hit',1)
assert 'proof did fail' in neg['literal_output']
tb=['`timescale 1ns/1ps','module read_fourstate_tb;reg trace_write,ex_ready,wb_data_zero;reg[4:0]wb_rd,id_rs1,id_rs2;reg[31:0]wb_data,register_valid,zero_flat,forwarded_a,forwarded_b;reg[1023:0]regs_flat;wire[195:0]a,b;',
    'baseline_read aa('+connection+',.observed(a));modified_read bb('+connection+',.observed(b));',
    'integer i,j,checks=0;function[0:0]state4(input integer v);begin case(v&3)0:state4=0;1:state4=1;2:state4=1\'bx;3:state4=1\'bz;endcase end endfunction',
    'initial begin for(i=0;i<8192;i=i+1)begin',
    'trace_write=state4(i);ex_ready=state4(i>>2);wb_data_zero=state4(i>>4);wb_rd=(i>>4)&31;id_rs1=(i>>6)&31;id_rs2=(i>>8)&31;',
    'for(j=0;j<32;j=j+1)begin register_valid[j]=state4(i+j);zero_flat[j]=state4((i>>1)+j);wb_data[j]=state4((i>>2)+j);forwarded_a[j]=state4((i>>3)+j);forwarded_b[j]=state4((i>>4)+j);end',
    'for(j=0;j<1024;j=j+1)regs_flat[j]=state4((i>>3)+j);',
    'if(i%5==0)wb_rd[1]=1\'bx;if(i%7==0)id_rs1[3]=1\'bz;if(i%11==0)id_rs2[0]=1\'bx;',
    '#1;if(a!==b)$fatal(1,"READ_CONE_XZ_CHANGED case=%0d",i);checks=checks+1;',
    'end $display("REGFILE_READ_CONE_FOURSTATE_PASS checks=%0d outputs=196 selectors_XZ=covered data_XZ=covered",checks);$finish;end endmodule','']
(HERE/'read_fourstate_tb.sv').write_text('\n'.join(tb),encoding='utf-8')
compiled=run(['iverilog','-g2012','-s','read_fourstate_tb','-o','read-fourstate.vvp','read_fourstate_tb.sv','actual_read_cones.sv',*models],'read-fourstate-compile')
four=run(['vvp','read-fourstate.vvp'],'read-fourstate')
assert 'REGFILE_READ_CONE_FOURSTATE_PASS checks=8192' in four['literal_output']
result=dict(status='PASS_EXACT_SOURCE_INVERSE_SAT_FOURSTATE',actual_sources={name:sha(HERE/name) for name in ('BASELINE_FILE.sv','MODIFIED_FILE.sv')},
            source_inverse_outside_two_keeps_and_compare_mux=True,all196_read_output_bits_compared=True,arbitrary_full_register_file_state=True,
            SAT=proof,negative_wrong_INIT=neg,fourstate_compile=compiled,fourstate=four,
            sequential_consequence='The inverse removes exactly two keep attributes and restores the original compare mux block. All other storage, sequential events, reset, ISA, hazard, eligibility and counters are byte-identical. The proven LUT model and original four-state fallback make all196 read-path outputs equal for arbitrary state; sequential consumers therefore retain original cycle semantics.')
(HERE/'READ_CONE_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'READ_CONE_VERIFICATION.json')==result
print('REGFILE_COMPARE_MUX_LUT6D_CONES_PASS inverse=exact SAT_outputs=196 arbitrary_state=all fourstate=8192 negative=rejected',flush=True)

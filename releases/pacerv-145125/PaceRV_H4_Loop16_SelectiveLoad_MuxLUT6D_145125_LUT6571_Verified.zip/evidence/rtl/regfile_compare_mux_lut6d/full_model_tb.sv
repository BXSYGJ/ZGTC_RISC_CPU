`timescale 1ns/1ps
module full_model_tb;reg[4:0]x;wire zo,z5o,zd,z5d;integer i,j,t,binary;
GTP_LUT6D_OFFICIAL #(.INIT(64'hff55aa00d8d8d8d8)) o(.I0(x[0]),.I1(x[1]),.I2(x[2]),.I3(x[3]),.I4(x[4]),.I5(1'b1),.Z(zo),.Z5(z5o));
GTP_LUT6D_DERIVED #(.INIT(64'hff55aa00d8d8d8d8)) d(.I0(x[0]),.I1(x[1]),.I2(x[2]),.I3(x[3]),.I4(x[4]),.I5(1'b1),.Z(zd),.Z5(z5d));
initial begin binary=0;for(i=0;i<1024;i=i+1)begin t=i;for(j=0;j<5;j=j+1)begin case(t%4)0:x[j]=0;1:x[j]=1;2:x[j]=1'bx;3:x[j]=1'bz;endcase t=t/4;end #1;if({zo,z5o} !== {zd,z5d})$fatal(1,"FULL_MODEL_MISMATCH case=%0d",i);case(^x)1'b0,1'b1:begin binary=binary+1;if({zd,z5d} !== {x[0]?x[3]:x[4],x[0]?x[1]:x[2]})$fatal(1,"BINARY_MUX_MISMATCH");end default:begin end endcase end $display("FULL_GTP_LUT6D_EQUIVALENCE_PASS fourstate_cases=1024 binary_cases=%0d original3_models=preserved anonymous_names=12",binary);$finish;end endmodule

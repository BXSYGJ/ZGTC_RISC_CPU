"""Freeze SG51 functional evidence and reopen every bound artifact."""
from pathlib import Path
import hashlib,json,stat
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
DEST=ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d'
PARENT=ROOT/'candidates/loop16_h4_ram_memory_range'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ref=lambda p:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
c=read(HERE/'CHANGE.json');core=read(HERE/'CORE_VERIFICATION.json');cone=read(HERE/'READ_CONE_VERIFICATION.json');rb=read(HERE/'ROLLBACK_RESULT.json');model=read(HERE/'MODEL_SUPPORT.json');udp=read(HERE/'MODEL_ADAPTATION.json');guard=read(HERE/'PRODUCTION_GUARD.json');build=read(HERE/'EXTENDED_MODEL_BUILD.json');recipe=read(HERE/'EXTENDED_RECIPE.json')
assert core['core_scenarios']==23 and core['architecture_lines']==591 and core['all_three_full_literal_outputs_equal']
assert all(t['compile_exit_status']==t['exit_status']==0 for t in core['tests'])
assert len({t['literal_output'] for t in core['tests']})==1
assert cone['source_inverse_outside_two_keeps_and_compare_mux'] and cone['all196_read_output_bits_compared'] and cone['arbitrary_full_register_file_state']
assert cone['SAT']['exit_status']==0 and 'no model found: SUCCESS!' in cone['SAT']['literal_output']
assert cone['negative_wrong_INIT']['exit_status']==1 and cone['fourstate']['exit_status']==0
assert 'checks=8192 outputs=196' in cone['fourstate']['literal_output']
assert udp['full_fourstate']['exit_status']==0 and 'checks=4160' in udp['full_fourstate']['literal_output'] and udp['negative_wrong_truth_row']['exit_status']==1
assert model['status']=='MODEL_EQUIVALENT_AND_VERILATOR_SUPPORTED' and model['verilator_lint']['exit_status']==0
assert 'fourstate_cases=1024 binary_cases=32' in model['full_model_fourstate']['literal_output']
assert sum(row['added_instance_names'] for row in model['normalization'])==12 and all(row['exact_byte_inverse'] for row in model['normalization'])
assert guard['fourstate_cases_per_pair']==1024 and guard['macro_pairs']==32 and guard['output_bit_checks']==65536
assert all(row['exit_status']==0 for row in guard['tests'])
assert rb['exit_status']==0 and rb['restored_sha256']==c['baseline_sha256'] and rb['active_modified_sha256']==c['modified_sha256']
assert sha(HERE/'rollback_test.sv')==c['baseline_sha256'] and sha(HERE/'MODIFIED_FILE.sv')==c['modified_sha256']
inverse=(HERE/'MODIFIED_FILE.sv').read_bytes().decode()
for old,new in reversed(c['edits']):inverse=inverse.replace(new,old,1)
assert inverse.encode()==(HERE/'BASELINE_FILE.sv').read_bytes()==(PARENT/'rtl/rv32_core.sv').read_bytes()
for relative,h in c['protected_parents'].items():assert sha(ROOT/relative)==h
for folder,count in [('rtl',17),('physical_rtl',18)]:
    actual={p.name:sha(p) for p in (DEST/folder).glob('*.sv')};assert len(actual)==count and actual==c[folder]
    for name,h in actual.items():
        assert h==c['modified_sha256'] if name=='rv32_core.sv' else (DEST/folder/name).read_bytes()==(PARENT/folder/name).read_bytes()
for row in model['normalization']:
    original=Path(row['official']).read_bytes();modified=Path(row['derived']).read_bytes().decode()
    for old,new in row['edits']:modified=modified.replace(new,old,1)
    assert modified.encode()==original
for k in ('original','derived','recipe'):assert sha(Path(recipe[k]['path']))==recipe[k]['sha256']
assert sha(Path(build['executable']))==build['executable_sha256'] and build['load_bubble']==1 and build['threads']==1
assert build['native_processes'] and all(p['native_exit_status']==0 for p in build['native_processes'])
assert build['RTL17']==c['rtl']
source_recipe=read(ROOT/'recipe.json');inputs=[DEST/'rtl'/Path(x).name for x in source_recipe['simulation']['argv'] if '/simulation/inputs/rtl/' in x]
inputs += [ROOT/x.split('{RELEASE}/')[1] for x in source_recipe['simulation']['argv'] if '/simulation/inputs/sim/' in x]
inputs += [Path(x) for x in model['simulation_model_sources']]
digest=hashlib.sha256()
for p in inputs:digest.update(p.name.encode());digest.update(p.read_bytes())
digest.update(b'1');assert digest.hexdigest()==build['identity']
assert (HERE/'ROLLBACK.sh').stat().st_mode&stat.S_IXUSR
proofs={n:ref(HERE/n) for n in ('MODEL_ADAPTATION.json','MODEL_SUPPORT.json','PRODUCTION_GUARD.json','READ_CONE_VERIFICATION.json','CORE_VERIFICATION.json','ROLLBACK_RESULT.json','EXTENDED_RECIPE.json','EXTENDED_MODEL_BUILD.json','MODEL_PROCESS.json')}
verification=dict(status='FUNCTIONAL_READY_EXPLICIT32_COMPARE_LUT6D',changed_field=c['changed_field'],baseline_sha256=c['baseline_sha256'],modified_sha256=c['modified_sha256'],INIT='ff55aa00d8d8d8d8',macros=32,source_inverse_exact=True,source17=c['rtl'],physical18=c['physical_rtl'],full_proof_records=proofs,model_contract='Two unsupported UDP definitions are deterministically translated from installed truth rows; all4160 possible four-state inputs match actual official UDP; truth-row mutation fails. Two enclosing official modules add12instance names only and byte-invert exactly; GTP_LUT6D remains byte-original. Full1024five-input four-state tuples and32binary tuples match complete official model.',production_contract='Actual source extraction proves196outputs for arbitrary1024bit registers and all controls via SAT. Each of32production pair guards covers all1024four-state tuples (65536output-bit checks); original ternary handles every nonbinary tuple. No storage, reset, ISA, latency, counters or other source expressions change.',production_SAT=dict(command=cone['SAT']['command'],input_directory=cone['SAT']['input_directory'],literal_result='SAT proof finished - no model found: SUCCESS!',exit_status=0),production_negative=dict(command=cone['negative_wrong_INIT']['command'],literal_result='ERROR: Called with -verify and proof did fail!',exit_status=1),production_fourstate=cone['fourstate'],BMR=[{k:t[k] for k in ('label','compile_command','compile_exit_status','command','input','exit_status')}|dict(literal_output_tail=t['literal_output'].strip().splitlines()[-1],full_literal_output_sha256=hashlib.sha256(t['literal_output'].encode()).hexdigest()) for t in core['tests']],rollback=rb,extended_model=dict(identity=build['identity'],executable=build['executable'],executable_sha256=build['executable_sha256'],load_bubble=1,threads=1,native_exit=0),protected_parent_files=len(c['protected_parents']),firmware_changes=0,benchmarks_launched=0,PDS_launched_by_this_task=0,physical_timing='ROOT_OWNED_PENDING')
write(HERE/'VERIFICATION.txt',verification)
summary=['SG51 regfile compare mux LUT6D','',
         'Core '+c['modified_sha256']+'; parent SG30 core '+c['baseline_sha256']+'. Only two normal-ID result keep attributes and the compare_next selection block change. Thirty-two adjacent-bit LUT6D macros retain32bit operands, all sequential statements, latency and ISA behavior.',
         'Official UDP versus derived SV:4160complete four-state inputs; complete LUT6D versus adapted hierarchy:1024four-state tuples/32binary tuples; wrong truth-row negative:exit1; actual Verilator lint:exit0. Only12anonymous instances gain names; all other enclosing model bytes invert exactly and GTP_LUT6D is original.',
         'Production196-output arbitrary-state SAT, wrong-INIT negative,8192read-cone four-state cases, all1024input tuples for each32production pair,23core scenarios/591ARCH across BASELINE/MODIFIED/ROLLBACK, and real PowerShell rollback all pass.',
         'Extended standard native model actual compilation exits0 with threads1/load_bubble1, unchanged driver/observer/tool flags and an exact digest that includes all five proved model dependencies. Identity '+build['identity']+'; executable SHA256 '+build['executable_sha256']+'.',
         'All17simulation/18physical RTL snapshots and105protected parent source files remain exact. No firmware or CoreMark benchmark is generated/run by this task. Physical implementation and timing acceptance belong to root-owned runs.','']
(HERE/'SUMMARY.md').write_text('\n'.join(summary),encoding='utf-8')
write(HERE/'STATUS.json',dict(status='FUNCTIONAL_READY',core_sha256=c['modified_sha256'],macros=32,SAT_outputs=196,production_fourstate_pairs=32,model_UDP_fourstate_cases=4160,core_BMR23_ARCH591=True,real_rollback=True,standard_extended_model_actual_compile_exit=0,model_identity=build['identity'],physical_timing='ROOT_OWNED_PENDING'))
artifacts={n:ref(HERE/n) for n in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')}
final=dict(status='FUNCTIONAL_READY',source_sha256=c['modified_sha256'],four_artifacts=artifacts,summary=ref(HERE/'SUMMARY.md'),STATUS=ref(HERE/'STATUS.json'),proof_records=proofs,source17=c['rtl'],physical18=c['physical_rtl'],protected_parent_files=len(c['protected_parents']),model_identity=build['identity'],standard_extended_model_executable_sha256=build['executable_sha256'],negative_controls={'UDP_truth_row':1,'production_INIT':1},firmware_changes=0,benchmarks_launched=0)
write(HERE/'FINAL_RECHECK.json',final)
assert read(HERE/'FINAL_RECHECK.json')==final
for row in list(artifacts.values())+list(proofs.values())+[final['summary'],final['STATUS']]:assert sha(Path(row['path']))==row['sha256']
print('SG51_FUNCTIONAL_READY core='+c['modified_sha256']+' macros=32 SAT_outputs=196 production_XZ=8192+1024perPair UDP_XZ=4160 BMR=23_ARCH591 rollback=PASS native_compile=exit0 all_artifacts=reopened')

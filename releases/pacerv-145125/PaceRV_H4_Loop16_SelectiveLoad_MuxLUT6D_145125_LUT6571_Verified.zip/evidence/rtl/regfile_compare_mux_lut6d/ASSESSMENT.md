SG51 vendor primitive assessment

The installed official GTP_LUT6D model implements Z5 from the low 32 INIT bits and Z from the I5-selected half. For I0=ex_ready, I1=normal0, I2=forward0, I3=normal1, I4=forward1 and I5=1, the correct INIT is 64'hff55aa00d8d8d8d8.
Actual iverilog compilation and all 32 binary truth cases pass. The real vendor model has four-state differences from a ternary for some X/Z data; the reduction-case/default-original-ternary guard passes all 1024 four-state combinations.
The standard installed Verilator 5.032 rejects both actual vendor UDP tables (INT_LUTMUX2_UDP and INT_LUTMUX4_UDP) with exit 1. Merely adding the five official dependency files to experiment.py does not create a working standard simulation model.
The model files are preserved byte-for-byte with installed-source hashes. The two installed PDS releases have the same GTP_LUT6D model. No pseudo model, ignored black box, changed tool flags or source-selection ifdef is used.
This assessment creates no production candidate and changes no original recipe or SG30 source. It launches no PDS, CoreMark benchmark, firmware generation or long simulation.

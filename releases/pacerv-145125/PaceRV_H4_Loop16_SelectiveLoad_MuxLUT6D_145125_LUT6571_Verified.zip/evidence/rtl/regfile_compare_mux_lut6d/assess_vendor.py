"""Inspect and exercise the actual installed Pango dual-output primitive."""
from pathlib import Path
import hashlib,json,shutil,subprocess
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
VENDOR=Path('/mnt/d/PDS_2022.2-SP6.4/arch/vendor/pango/verilog/simulation')
VERILATOR=Path('/tmp/ccfa-native-snapshot-verilator-v5.032-5a262564b1/verilator-5.032/bin/verilator')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
deps=['GTP_LUT6D.v','GTP_LUT5.v','GTP_MUX2LUT6.v','INT_LUTMUX2_UDP.v','INT_LUTMUX4_UDP.v']
(HERE/'vendor').mkdir(exist_ok=True)
records=[]
for name in deps:
    src=VENDOR/name;dst=HERE/'vendor'/name
    if dst.exists():assert dst.read_bytes()==src.read_bytes()
    else:shutil.copy2(src,dst)
    records.append(dict(name=name,installed_source=str(src),snapshot=str(dst),sha256=sha(dst)))
low=sum(((i>>1&1) if (i&1) else (i>>2&1))<<i for i in range(32))
high=sum(((i>>3&1) if (i&1) else (i>>4&1))<<i for i in range(32))
init=high<<32|low
assert init==0xff55aa00d8d8d8d8
text='module vendor_mux_tb; reg[4:0]x; wire z,z5; integer i; GTP_LUT6D #(.INIT(64\'h'+f'{init:016x}'+')) dut(.I0(x[0]),.I1(x[1]),.I2(x[2]),.I3(x[3]),.I4(x[4]),.I5(1\'b1),.Z(z),.Z5(z5)); initial begin for(i=0;i<32;i=i+1)begin x=i;#1;if(z5 !== (x[0]?x[1]:x[2]) || z !== (x[0]?x[3]:x[4]))$fatal(1,"vendor truth mismatch");end $display("VENDOR_LUT6D_TRUTH_PASS binary_cases=32 INIT=ff55aa00d8d8d8d8 Z5=low Z=high I5=1");$finish;end endmodule\n'
(HERE/'vendor_mux_tb.sv').write_text(text)
commands=[['iverilog','-g2012','-s','vendor_mux_tb','-o',str(HERE/'vendor-mux.vvp'),str(HERE/'vendor_mux_tb.sv'),*[str(HERE/'vendor'/n) for n in deps]],['vvp',str(HERE/'vendor-mux.vvp')],[str(VERILATOR),'--lint-only','--timing','-Wno-fatal','--top-module','vendor_mux_tb',str(HERE/'vendor_mux_tb.sv'),*[str(HERE/'vendor'/n) for n in deps]]]
tests=[]
for label,cmd in zip(['iverilog_compile','actual_model_truth','verilator_lint'],commands):
    p=subprocess.run(cmd,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout)
    tests.append(dict(label=label,command=cmd,literal_output=p.stdout,exit_status=p.returncode))
    print(label+' exit='+str(p.returncode)+' '+p.stdout[-1200:],flush=True)
    assert p.returncode==0,p.stdout
result=dict(status='ACTUAL_VENDOR_MODEL_SUPPORTED',vendor_sources=records,INIT=f'{init:016x}',port_contract='Z5=INIT_low[I4:I0]; Z=I5?INIT_high[I4:I0]:INIT_low[I4:I0]; I0 is least significant truth-table bit.',tests=tests)
(HERE/'VENDOR_ASSESSMENT.json').write_text(json.dumps(result,indent=2)+'\n')
print('SG51_VENDOR_READY real_files=5 binary_cases=32 iverilog=PASS verilator=PASS')

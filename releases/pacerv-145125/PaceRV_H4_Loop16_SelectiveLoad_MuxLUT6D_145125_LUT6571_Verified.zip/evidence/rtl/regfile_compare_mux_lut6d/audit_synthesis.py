"""Audit saved SG30/SG49 vendor netlists without modifying frozen evidence."""
from pathlib import Path
from collections import Counter, defaultdict
import bisect
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ref = lambda p: dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size)
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
atoms = lambda s: set(re.findall(r'[A-Za-z_$][A-Za-z0-9_$]*(?:\[\d+\])*', s))
outports = ('Z', 'Z5', 'COUT', 'CO', 'Q', 'DO')
def read_build(name):
    build = ROOT/'work'/name
    vm = build/'synthesis/synthesize/pds_soc_top_syn.vm'
    full = vm.read_text(encoding='utf-8-sig')
    nl = [i for i,c in enumerate(full) if c == '\n']
    modules = {}
    for mm in re.finditer(r'^module\s+(\S+)', full, re.M):
        end = full.index('endmodule', mm.end())
        text = full[mm.start():end]
        cells = []
        for m in re.finditer(r'\b(GTP_[A-Z0-9_]+)\s*(?:/\*\s*(.*?)\s*\*/\s*)?(?:#\s*\((.*?)\)\s*)?([^\s(]+)\s*\(', text, re.S):
            body = text[m.end():text.index(';',m.end())]
            ports = {k: re.sub(r'\s+', '', v).replace('\\', '') for k,v in re.findall(r'(?<![\w\\])\.(\w+)\s*\((.*?)\)', body, re.S)}
            parameters = {k: re.sub(r'\s+', '', v) for k,v in re.findall(r'\.(\w+)\s*\((.*?)\)', m[3] or '', re.S)}
            cells.append(dict(type=m[1], name=(m[2] or m[4]).strip().lstrip('\\'), ports=ports, parameters=parameters, line=bisect.bisect_left(nl,mm.start()+m.start())+1))
        modules[mm[1]] = cells
    core = modules['rv32_core']
    data_ram = [c for c in core if c['type'].startswith('GTP_RAM') and c['name'].startswith('registers_')]
    zero_ram = [c for c in core if c['type'].startswith('GTP_RAM') and c['name'].startswith('register_zero')]
    valid_ff = [c for c in core if c['type'].startswith('GTP_DFF') and re.fullmatch(r'register_valid\[\d+\]', c['name'])]
    ramout = set().union(*(atoms(c['ports']['DO']) for c in data_ram))
    direct = defaultdict(list)
    output_groups = defaultdict(list)
    for c in core:
        if not c['type'].startswith('GTP_LUT'): continue
        used = set().union(*(atoms(v) for k,v in c['ports'].items() if k not in outports)) & ramout
        outs = [c['ports'].get(k,'') for k in ('Z','Z5')]
        labels = []
        for label, prefixes in [('normal_ID_read', ('id_operand_a[','id_operand_b[')), ('compare_next', ('compare_next_a[','compare_next_b[','compare_mux_lut_a[','compare_mux_lut_b['))]:
            if any(s.startswith(prefixes) for s in outs):
                output_groups[label].append(c)
                labels.append(label)
        if used:
            for label in labels or ['muldiv_prefetch']: direct[label].append(c)
    compare_drivers = []
    for port in ('a','b'):
        for bit in range(32):
            net=f'compare_mux_lut_{port}[{bit}]' if name.startswith('sg51-') else f'compare_next_{port}[{bit}]'
            found=[c for c in core if any(c['ports'].get(k)==net for k in outports)]
            assert len(found)==1
            c=found[0]
            inputs={k:v for k,v in c['ports'].items() if re.fullmatch(r'I[0-5]',k)}
            compare_drivers.append(dict(net=net,cell=c,own_id_operand_present=f'id_operand_{port}[{bit}]' in inputs.values(),inputs=inputs))
    paired = [c for c in output_groups['compare_next'] if c['type']=='GTP_LUT6D' and all(c['ports'].get(k,'').startswith(('compare_next_a[','compare_next_b[','compare_mux_lut_a[','compare_mux_lut_b[')) for k in ('Z','Z5'))]
    mixed = [c for c in output_groups['compare_next'] if c['type']=='GTP_LUT6D' and c not in paired]
    totals = {m:dict(Counter(c['type'] for c in cs)) for m,cs in modules.items()}
    log=build/'synthesis/run.log'; logtext=log.read_text(encoding='utf-8-sig')
    resource=dict(LUT=int(re.search(r'Total LUTs:\s+(\d+)',logtext)[1]), FF=int(re.search(r'Total Registers:\s+(\d+)',logtext)[1]), dram_LUT=int(re.search(r'LUTs as dram:\s+(\d+)',logtext)[1]))
    return dict(name=name,resources=resource,netlist=ref(vm),log=ref(log),build_result=ref(build/'BUILD_RESULT.json'),module_cell_counts=totals,all_core_cells=core,regfile=dict(data_RAM=data_ram,zero_RAM=zero_ram,valid_FF=valid_ff,direct_RAM_read_consumers=dict(direct),output_groups=dict(output_groups),all64_compare_drivers=compare_drivers,compare_pair_LUT6D=paired,compare_mixed_LUT6D=mixed))


frozen=load(HERE/'FINAL_RECHECK.json')
for row in frozen['four_artifacts'].values():assert sha(Path(row['path']))==row['sha256']
parent=read_build('sg30-ram-memory-range-synth')
candidate=read_build('sg51-regfile-compare-mux-lut6d-synth')
macros=[c for c in candidate['all_core_cells'] if c['name'].startswith('g_compare_pair[')]
assert len(macros)==32 and all(c['type']=='GTP_LUT6D' for c in macros)
for c in macros:
    match=re.fullmatch(r'g_compare_pair\[(\d+)\]\.compare_mux_([ab])',c['name']);assert match,c
    pair=int(match[1]);port=match[2];b=2*pair
    assert int(c['parameters']['INIT'].split("'b")[1],2)==0xff55aa00d8d8d8d8
    expected={'I0':'ex_ready','I1':f'id_operand_{port}[{b}]','I2':f'forwarded_{port}[{b}]','I3':f'id_operand_{port}[{b+1}]','I4':f'forwarded_{port}[{b+1}]','I5':"1'b1",'Z5':f'compare_mux_lut_{port}[{b}]','Z':f'compare_mux_lut_{port}[{b+1}]'}
    assert c['ports']==expected,c
consumers=[]
for port in ('a','b'):
    for b in range(32):
        found=[c for c in candidate['all_core_cells'] if c['ports'].get('D')==f'compare_mux_lut_{port}[{b}]' and c['ports'].get('Q')==f'ex_operand_{port}[{b}]']
        assert len(found)==1 and found[0]['type'].startswith('GTP_DFF'),found
        consumers+=found
bindings=[]
actualbuild=ROOT/'work/sg51-regfile-compare-mux-lut6d-synth'
hashes=load(actualbuild/'INPUT_HASHES.json');byrelative={x['RelativePath']:x['SHA256'].lower() for x in hashes}
for folder,count in [('rtl',17),('physical_rtl',18)]:
    srcs=list((ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d'/folder).glob('*.sv'));assert len(srcs)==count
    for src in srcs:
        actual=actualbuild/'inputs/rtl'/src.name
        assert sha(src)==sha(actual)==byrelative['rtl/'+src.name]
        bindings.append(dict(folder=folder,source=ref(src),actual_input=ref(actual)))
changes={}
for name in sorted(parent['module_cell_counts'].keys()|candidate['module_cell_counts'].keys()):
    a=Counter(parent['module_cell_counts'].get(name,{}));b=Counter(candidate['module_cell_counts'].get(name,{}))
    d={k:b[k]-a[k] for k in sorted(a.keys()|b.keys()) if a[k]!=b[k]}
    if d:changes[name]=d
lut_delta={m:sum(v for k,v in cs.items() if k.startswith('GTP_LUT')) for m,cs in changes.items()}
assert sum(lut_delta.values())==candidate['resources']['LUT']-parent['resources']['LUT']==-21
assert candidate['resources']==dict(LUT=6121,FF=2561,dram_LUT=471)
assert len(candidate['regfile']['data_RAM'])==32 and len(candidate['regfile']['zero_RAM'])==2 and len(candidate['regfile']['valid_FF'])==32
result=dict(status='SG51_ACTUAL_32_MACROS_MAPPED',resources=candidate['resources'],delta_LUT=-21,parent=parent,candidate=candidate,exact_macro_instances=macros,all64_operand_FF_direct_consumers=consumers,macro_pins_and_INIT_exact=True,no_binary_Xfallback_logic_between_macro_and_operand_FF=True,module_cell_type_deltas=changes,module_LUT_instance_deltas=lut_delta,source17_physical18_binding=bindings,functional_record=ref(HERE/'FINAL_RECHECK.json'),frozen_four_unchanged=True)
(HERE/'SYNTHESIS_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for k in ('all_core_cells',):candidate.pop(k,None);parent.pop(k,None)
lines=['SG51 actual vendor mapping','',
       'Actual synthesis: SG30 parent6142 LUT/2561 FF/471 dramLUT; SG51 6121/2561/471, LUT change -21.',
       'Exactly32 explicit GTP_LUT6D instances survive (16 adjacent-bit pairs on each operand port). All32 INIT values are ff55aa00d8d8d8d8 and every I0..I5/Z/Z5 connection matches production source exactly.',
       'All64 macro outputs directly drive the corresponding original ex_operand_a/b flip-flop D pins. The four-state fallback adds no binary hardware between macro and operand FF.',
       'Register data32RAM, zero metadata2RAM and register_valid32FF remain unchanged. Comparison mux output cells change from64LUT6 to32LUT6D. Other local mapping explains the difference between gross32mux cells saved and net21LUT reduction.',
       'Module LUT deltas: '+json.dumps(lut_delta,sort_keys=True)+'. Full primitive-type changes are in SYNTHESIS_AUDIT.json.',
       'All17 simulation/18physical files match actual synthesis inputs and INPUT_HASHES. Frozen functional four artifacts, core75d136 and all proved model dependencies remain unchanged.',
       'This audit reads existing raw logs and VM only. PDS route and benchmark qualification remain root-owned.','']
(HERE/'SYNTHESIS_AUDIT.md').write_text('\n'.join(lines),encoding='utf-8')
z=dict(status='SG51_ACTUAL_MAPPING_READY',resources=candidate['resources'],delta_LUT=-21,macro_instances32=True,macro_pins_INIT_exact=True,all64_operand_FF_direct=True,source17_physical18=35,audit=ref(HERE/'SYNTHESIS_AUDIT.json'),summary=ref(HERE/'SYNTHESIS_AUDIT.md'),script=ref(Path(__file__)),functional_record=ref(HERE/'FINAL_RECHECK.json'),four_artifacts=frozen['four_artifacts'])
(HERE/'SYNTHESIS_RECHECK.json').write_text(json.dumps(z,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'SYNTHESIS_RECHECK.json')==z
for row in [z[k] for k in ('audit','summary','script','functional_record')]+list(z['four_artifacts'].values()):assert sha(Path(row['path']))==row['sha256']
for row in (candidate['netlist'],candidate['log'],parent['netlist'],parent['log']):assert sha(Path(row['path']))==row['sha256']
print('SG51_MAPPING_READY macros=32 all_pins_INIT=exact FF_direct=64 LUT=6121 FF=2561 dramLUT=471 deltaLUT=-21 module_delta='+json.dumps(lut_delta,sort_keys=True)+' all_artifacts=reopened')

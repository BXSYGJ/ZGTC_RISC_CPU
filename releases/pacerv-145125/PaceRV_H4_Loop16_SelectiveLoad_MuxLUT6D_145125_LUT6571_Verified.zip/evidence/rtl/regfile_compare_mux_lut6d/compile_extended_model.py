"""One actual standard Verilator build with the proved equivalent vendor model set."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
recipe=json.loads((HERE/'EXTENDED_RECIPE.json').read_text())
for key in ('original','derived','recipe'):assert sha(Path(recipe[key]['path']))==recipe[key]['sha256']
spec=importlib.util.spec_from_file_location('sg51_experiment',HERE/'experiment_extended.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
real_run=e.subprocess.run
calls=[]
def tracked(command,**kwargs):
    started=time.time();p=subprocess.Popen(command,**kwargs)
    proc=dict(status='RUNNING',command=command,worker_pid=os.getpid(),native_pid=p.pid,started_epoch=started,load_bubble=1,threads=1,RTL_directory=str(ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d/rtl'))
    (HERE/'MODEL_PROCESS.json').write_text(json.dumps(proc,indent=2)+'\n')
    code=p.wait();proc.update(status='COMPLETE',native_exit_status=code,finished_epoch=time.time())
    (HERE/'MODEL_PROCESS.json').write_text(json.dumps(proc,indent=2)+'\n');calls.append(proc)
    return subprocess.CompletedProcess(command,code)
e.subprocess.run=tracked
exe,identity=e.simulator(ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d/rtl',load_bubble=1,threads=1)
build=exe.parent/'BUILD.json';record=json.loads(build.read_text())
assert record['source_sha256']==identity
out=dict(status='ACTUAL_STANDARD_EXTENDED_MODEL_COMPILED',identity=identity,executable=str(exe),executable_sha256=sha(exe),BUILD=dict(path=str(build),sha256=sha(build)),compile_log=dict(path=str(exe.parent/'compile.log'),sha256=sha(exe.parent/'compile.log')),load_bubble=1,threads=1,command=record['command'],native_processes=calls,recipe=recipe,RTL17={p.name:sha(p) for p in sorted((ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d/rtl').glob('*.sv'))},extra_model_sha256={Path(p).name:sha(Path(p)) for p in recipe['extra_models']})
(HERE/'EXTENDED_MODEL_BUILD.json').write_text(json.dumps(out,indent=2)+'\n')
print('SG51_STANDARD_EXTENDED_MODEL_COMPILED identity='+identity+' executable_sha256='+sha(exe)+' load_bubble=1 threads=1 actual_compile_exit=0')

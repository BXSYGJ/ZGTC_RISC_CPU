module actual_production_mux(input ex_ready,input[31:0]id_operand_a,id_operand_b,forwarded_a,forwarded_b,output[63:0]observed);reg[31:0]compare_next_a,compare_next_b;
    wire [31:0] compare_mux_lut_a,compare_mux_lut_b;
    genvar compare_pair_bit;
    generate for(compare_pair_bit=0;compare_pair_bit<16;compare_pair_bit=compare_pair_bit+1) begin: g_compare_pair
        GTP_LUT6D #(.INIT(64'hff55aa00d8d8d8d8)) compare_mux_a(
            .I0(ex_ready),.I1(id_operand_a[2*compare_pair_bit]),.I2(forwarded_a[2*compare_pair_bit]),
            .I3(id_operand_a[2*compare_pair_bit+1]),.I4(forwarded_a[2*compare_pair_bit+1]),.I5(1'b1),
            .Z5(compare_mux_lut_a[2*compare_pair_bit]),.Z(compare_mux_lut_a[2*compare_pair_bit+1]));
        always @* begin
            case(^{ex_ready,id_operand_a[2*compare_pair_bit+:2],forwarded_a[2*compare_pair_bit+:2]})
                1'b0,1'b1: compare_next_a[2*compare_pair_bit+:2]=compare_mux_lut_a[2*compare_pair_bit+:2];
                default: compare_next_a[2*compare_pair_bit+:2]=ex_ready ? id_operand_a[2*compare_pair_bit+:2] : forwarded_a[2*compare_pair_bit+:2];
            endcase
        end
        GTP_LUT6D #(.INIT(64'hff55aa00d8d8d8d8)) compare_mux_b(
            .I0(ex_ready),.I1(id_operand_b[2*compare_pair_bit]),.I2(forwarded_b[2*compare_pair_bit]),
            .I3(id_operand_b[2*compare_pair_bit+1]),.I4(forwarded_b[2*compare_pair_bit+1]),.I5(1'b1),
            .Z5(compare_mux_lut_b[2*compare_pair_bit]),.Z(compare_mux_lut_b[2*compare_pair_bit+1]));
        always @* begin
            case(^{ex_ready,id_operand_b[2*compare_pair_bit+:2],forwarded_b[2*compare_pair_bit+:2]})
                1'b0,1'b1: compare_next_b[2*compare_pair_bit+:2]=compare_mux_lut_b[2*compare_pair_bit+:2];
                default: compare_next_b[2*compare_pair_bit+:2]=ex_ready ? id_operand_b[2*compare_pair_bit+:2] : forwarded_b[2*compare_pair_bit+:2];
            endcase
        end
    end endgenerate
assign observed={compare_next_a,compare_next_b};endmodule

"""Derive unsupported combinational UDPs from installed rows, prove every 4-state input."""
from pathlib import Path
import hashlib,json,re,subprocess
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
DERIVED=HERE/'derived_vendor';DERIVED.mkdir(exist_ok=True)
VERILATOR=Path('/tmp/ccfa-native-snapshot-verilator-v5.032-5a262564b1/verilator-5.032/bin/verilator')
records=[];official=[];derived=[];testbenches=[]
for size,count in [(2,3),(4,6)]:
    name=f'INT_LUTMUX{size}_UDP';src=HERE/'vendor'/(name+'.v');text=src.read_text()
    ports=[x.strip() for x in re.search(r'primitive\s+'+name+r'\s*\((.*?)\)',text,re.S)[1].split(',')]
    output=ports[0];inputs=ports[1:];assert len(inputs)==count
    rows=[]
    table=text.split('    table',1)[1].split('    endtable',1)[0]
    for line in table.splitlines():
        line=line.split('//',1)[0].strip()
        if not line:continue
        left,right=line.rstrip(';').split(':');tokens=left.split();out=right.strip()
        assert len(tokens)==count and set(tokens)<=set('01x?') and out in ('0','1')
        rows.append((tokens,out))
    body=['`timescale 1ns/1ps','// Deterministic translation of installed UDP table rows. UDP inputs Z match X.','module '+name+'('+','.join(ports)+');','output reg '+output+';','input '+','.join(inputs)+';','always @* begin','    '+output+"=1'bx;"]
    for tokens,out in rows:
        terms=[]
        for signal,tok in zip(inputs,tokens):
            if tok=='?':continue
            terms.append('('+signal+"!==1'b0 && "+signal+"!==1'b1)" if tok=='x' else '('+signal+"===1'b"+tok+')')
        body.append('    if ('+' && '.join(terms)+') '+output+"=1'b"+out+';')
    body+=['end','endmodule',''];model='\n'.join(body)
    dst=DERIVED/(name+'.sv');dst.write_text(model,encoding='utf-8')
    osnap=HERE/(name+'_official_test.v');osnap.write_text(text.replace('primitive '+name,'primitive '+name+'_OFFICIAL',1),encoding='utf-8')
    dsnap=HERE/(name+'_derived_test.sv');dsnap.write_text(model.replace('module '+name,'module '+name+'_DERIVED',1),encoding='utf-8')
    official.append(osnap);derived.append(dsnap)
    records.append(dict(name=name,official_source=str(src),official_sha256=sha(src),derived_source=str(dst),derived_sha256=sha(dst),input_count=count,full_fourstate_cases=4**count,table_rows=len(rows),row_translation='0/1 use case equality; x matches x and z; ? matches all four states; unmatched output x.',ports=ports,official_test_source=str(osnap),official_test_sha256=sha(osnap),derived_test_source=str(dsnap),derived_test_sha256=sha(dsnap)))
    testbenches += ['reg['+str(count-1)+':0]x'+str(size)+';wire off'+str(size)+',der'+str(size)+';',name+'_OFFICIAL o'+str(size)+'(off'+str(size)+','+','.join('x'+str(size)+'['+str(count-1-i)+']' for i in range(count))+');',name+'_DERIVED d'+str(size)+'(der'+str(size)+','+','.join('x'+str(size)+'['+str(count-1-i)+']' for i in range(count))+');']
tb=['`timescale 1ns/1ps','module udp_equivalence_tb;',*testbenches,'integer i,j,t,checks;initial begin checks=0;']
for size,count in [(2,3),(4,6)]:
    tb += ['for(i=0;i<'+str(4**count)+';i=i+1)begin t=i;for(j=0;j<'+str(count)+';j=j+1)begin case(t%4)0:x'+str(size)+'[j]=0;1:x'+str(size)+"[j]=1;2:x"+str(size)+"[j]=1'bx;3:x"+str(size)+"[j]=1'bz;endcase t=t/4;end #1;if(off"+str(size)+' !== der'+str(size)+')$fatal(1,"UDP_DERIVATION_MISMATCH primitive='+str(size)+' case=%0d",i);checks=checks+1;end']
tb += ['$display("UDP_FULL_FOURSTATE_EQUIVALENCE_PASS mux2_cases=64 mux4_cases=4096 checks=%0d",checks);$finish;end endmodule','']
(HERE/'udp_equivalence_tb.sv').write_text('\n'.join(tb),encoding='utf-8')
def run(cmd,label,expected=0):
    p=subprocess.run(cmd,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout,encoding='utf-8')
    if expected is not None:assert p.returncode==expected,p.stdout[-5000:]
    return dict(command=cmd,literal_output=p.stdout,exit_status=p.returncode)
compile=run(['iverilog','-g2012','-s','udp_equivalence_tb','-o','udp-equivalence.vvp','udp_equivalence_tb.sv',*[str(x) for x in official+derived]],'udp-equivalence-compile')
positive=run(['vvp','udp-equivalence.vvp'],'udp-equivalence')
assert 'checks=4160' in positive['literal_output']
wrong=(derived[0].read_text()).replace("dout=1'b0;","dout=1'b1;",1)
assert wrong!=derived[0].read_text()
(HERE/'negative_udp_row.sv').write_text(wrong,encoding='utf-8')
negative_compile=run(['iverilog','-g2012','-s','udp_equivalence_tb','-o','negative-udp.vvp','udp_equivalence_tb.sv',*[str(x) for x in official],str(HERE/'negative_udp_row.sv'),str(derived[1])],'negative-udp-compile')
negative=run(['vvp','negative-udp.vvp'],'negative-udp',1)
assert 'UDP_DERIVATION_MISMATCH primitive=2' in negative['literal_output']
sources=[str(HERE/'vendor'/n) for n in ('GTP_LUT6D.v','GTP_LUT5.v','GTP_MUX2LUT6.v')]+[str(DERIVED/(x['name']+'.sv')) for x in records]
lint=run([str(VERILATOR),'--lint-only','--timing','-Wno-fatal','--top-module','vendor_mux_tb',str(HERE/'vendor_mux_tb.sv'),*sources],'adapted-verilator-lint',None)
result=dict(status='OFFICIAL_UDP_FULL_FOURSTATE_EQUIVALENT_'+('VERILATOR_SUPPORTED' if lint['exit_status']==0 else 'ANONYMOUS_INSTANCE_NORMALIZATION_REQUIRED'),source_records=records,generator=dict(path=str(Path(__file__)),sha256=sha(Path(__file__))),fourstate_compile=compile,full_fourstate=positive,negative_compile=negative_compile,negative_wrong_truth_row=negative,adapted_verilator_lint=lint,unchanged_official_GTP_models={n:sha(HERE/'vendor'/n) for n in ('GTP_LUT6D.v','GTP_LUT5.v','GTP_MUX2LUT6.v')},simulation_model_sources=sources,INIT='ff55aa00d8d8d8d8',original_failed_lint_preserved=str(HERE/'verilator_lint.log'))
(HERE/'MODEL_ADAPTATION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert json.loads((HERE/'MODEL_ADAPTATION.json').read_text())==result
for row in records:assert sha(Path(row['official_source']))==row['official_sha256'] and sha(Path(row['derived_source']))==row['derived_sha256']
print(positive['literal_output'],end='')
print('SG51_MODEL_ADAPTATION_UDP_PASS official_UDP_cases=4160 negative=exit1 Verilator_lint_exit='+str(lint['exit_status'])+' real_GTP_models=3 derived_UDP=2 all_evidence=reopened')

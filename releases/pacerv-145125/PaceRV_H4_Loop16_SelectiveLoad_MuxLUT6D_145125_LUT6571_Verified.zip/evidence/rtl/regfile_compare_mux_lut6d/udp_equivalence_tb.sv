`timescale 1ns/1ps
module udp_equivalence_tb;
reg[2:0]x2;wire off2,der2;
INT_LUTMUX2_UDP_OFFICIAL o2(off2,x2[2],x2[1],x2[0]);
INT_LUTMUX2_UDP_DERIVED d2(der2,x2[2],x2[1],x2[0]);
reg[5:0]x4;wire off4,der4;
INT_LUTMUX4_UDP_OFFICIAL o4(off4,x4[5],x4[4],x4[3],x4[2],x4[1],x4[0]);
INT_LUTMUX4_UDP_DERIVED d4(der4,x4[5],x4[4],x4[3],x4[2],x4[1],x4[0]);
integer i,j,t,checks;initial begin checks=0;
for(i=0;i<64;i=i+1)begin t=i;for(j=0;j<3;j=j+1)begin case(t%4)0:x2[j]=0;1:x2[j]=1;2:x2[j]=1'bx;3:x2[j]=1'bz;endcase t=t/4;end #1;if(off2 !== der2)$fatal(1,"UDP_DERIVATION_MISMATCH primitive=2 case=%0d",i);checks=checks+1;end
for(i=0;i<4096;i=i+1)begin t=i;for(j=0;j<6;j=j+1)begin case(t%4)0:x4[j]=0;1:x4[j]=1;2:x4[j]=1'bx;3:x4[j]=1'bz;endcase t=t/4;end #1;if(off4 !== der4)$fatal(1,"UDP_DERIVATION_MISMATCH primitive=4 case=%0d",i);checks=checks+1;end
$display("UDP_FULL_FOURSTATE_EQUIVALENCE_PASS mux2_cases=64 mux4_cases=4096 checks=%0d",checks);$finish;end endmodule

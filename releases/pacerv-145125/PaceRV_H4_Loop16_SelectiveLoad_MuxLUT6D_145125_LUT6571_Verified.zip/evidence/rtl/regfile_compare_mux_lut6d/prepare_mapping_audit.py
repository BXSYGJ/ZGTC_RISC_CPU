"""Reuse the already audited primitive parser; inspect only saved SG51 synthesis evidence."""
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
donor=(ROOT/'rtl_proposals/loop16_h4_regfile_id_operand_keep/audit_synthesis.py').read_text()
header=donor[:donor.index("frozen = load(HERE/'FINAL_RECHECK.json')")]
function=donor[donor.index('def read_build(name):'):donor.index("parent=read_build('sg30-ram-memory-range-synth')")]
function=function.replace("('compare_next_a[','compare_next_b[')","('compare_next_a[','compare_next_b[','compare_mux_lut_a[','compare_mux_lut_b[')")
function=function.replace("net=f'compare_next_{port}[{bit}]'","net=f'compare_mux_lut_{port}[{bit}]' if name.startswith('sg51-') else f'compare_next_{port}[{bit}]'")
function=function.replace("module_cell_counts=totals,regfile=", "module_cell_counts=totals,all_core_cells=core,regfile=")
tail='''
frozen=load(HERE/'FINAL_RECHECK.json')
for row in frozen['four_artifacts'].values():assert sha(Path(row['path']))==row['sha256']
parent=read_build('sg30-ram-memory-range-synth')
candidate=read_build('sg51-regfile-compare-mux-lut6d-synth')
macros=[c for c in candidate['all_core_cells'] if c['name'].startswith('g_compare_pair[')]
assert len(macros)==32 and all(c['type']=='GTP_LUT6D' for c in macros)
for c in macros:
    match=re.fullmatch(r'g_compare_pair\\[(\\d+)\\]\\.compare_mux_([ab])',c['name']);assert match,c
    pair=int(match[1]);port=match[2];b=2*pair
    assert int(c['parameters']['INIT'].split("'b")[1],2)==0xff55aa00d8d8d8d8
    expected={'I0':'ex_ready','I1':f'id_operand_{port}[{b}]','I2':f'forwarded_{port}[{b}]','I3':f'id_operand_{port}[{b+1}]','I4':f'forwarded_{port}[{b+1}]','I5':"1'b1",'Z5':f'compare_mux_lut_{port}[{b}]','Z':f'compare_mux_lut_{port}[{b+1}]'}
    assert c['ports']==expected,c
consumers=[]
for port in ('a','b'):
    for b in range(32):
        found=[c for c in candidate['all_core_cells'] if c['ports'].get('D')==f'compare_mux_lut_{port}[{b}]' and c['ports'].get('Q')==f'ex_operand_{port}[{b}]']
        assert len(found)==1 and found[0]['type'].startswith('GTP_DFF'),found
        consumers+=found
bindings=[]
actualbuild=ROOT/'work/sg51-regfile-compare-mux-lut6d-synth'
hashes=load(actualbuild/'INPUT_HASHES.json');byrelative={x['RelativePath']:x['SHA256'].lower() for x in hashes}
for folder,count in [('rtl',17),('physical_rtl',18)]:
    srcs=list((ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d'/folder).glob('*.sv'));assert len(srcs)==count
    for src in srcs:
        actual=actualbuild/'inputs/rtl'/src.name
        assert sha(src)==sha(actual)==byrelative['rtl/'+src.name]
        bindings.append(dict(folder=folder,source=ref(src),actual_input=ref(actual)))
changes={}
for name in sorted(parent['module_cell_counts'].keys()|candidate['module_cell_counts'].keys()):
    a=Counter(parent['module_cell_counts'].get(name,{}));b=Counter(candidate['module_cell_counts'].get(name,{}))
    d={k:b[k]-a[k] for k in sorted(a.keys()|b.keys()) if a[k]!=b[k]}
    if d:changes[name]=d
lut_delta={m:sum(v for k,v in cs.items() if k.startswith('GTP_LUT')) for m,cs in changes.items()}
assert sum(lut_delta.values())==candidate['resources']['LUT']-parent['resources']['LUT']==-21
assert candidate['resources']==dict(LUT=6121,FF=2561,dram_LUT=471)
assert len(candidate['regfile']['data_RAM'])==32 and len(candidate['regfile']['zero_RAM'])==2 and len(candidate['regfile']['valid_FF'])==32
result=dict(status='SG51_ACTUAL_32_MACROS_MAPPED',resources=candidate['resources'],delta_LUT=-21,parent=parent,candidate=candidate,exact_macro_instances=macros,all64_operand_FF_direct_consumers=consumers,macro_pins_and_INIT_exact=True,no_binary_Xfallback_logic_between_macro_and_operand_FF=True,module_cell_type_deltas=changes,module_LUT_instance_deltas=lut_delta,source17_physical18_binding=bindings,functional_record=ref(HERE/'FINAL_RECHECK.json'),frozen_four_unchanged=True)
(HERE/'SYNTHESIS_AUDIT.json').write_text(json.dumps(result,indent=2)+'\\n',encoding='utf-8')
for k in ('all_core_cells',):candidate.pop(k,None);parent.pop(k,None)
lines=['SG51 actual vendor mapping','',
       'Actual synthesis: SG30 parent6142 LUT/2561 FF/471 dramLUT; SG51 6121/2561/471, LUT change -21.',
       'Exactly32 explicit GTP_LUT6D instances survive (16 adjacent-bit pairs on each operand port). All32 INIT values are ff55aa00d8d8d8d8 and every I0..I5/Z/Z5 connection matches production source exactly.',
       'All64 macro outputs directly drive the corresponding original ex_operand_a/b flip-flop D pins. The four-state fallback adds no binary hardware between macro and operand FF.',
       'Register data32RAM, zero metadata2RAM and register_valid32FF remain unchanged. Comparison mux output cells change from64LUT6 to32LUT6D. Other local mapping explains the difference between gross32mux cells saved and net21LUT reduction.',
       'Module LUT deltas: '+json.dumps(lut_delta,sort_keys=True)+'. Full primitive-type changes are in SYNTHESIS_AUDIT.json.',
       'All17 simulation/18physical files match actual synthesis inputs and INPUT_HASHES. Frozen functional four artifacts, core75d136 and all proved model dependencies remain unchanged.',
       'This audit reads existing raw logs and VM only. PDS route and benchmark qualification remain root-owned.','']
(HERE/'SYNTHESIS_AUDIT.md').write_text('\\n'.join(lines),encoding='utf-8')
z=dict(status='SG51_ACTUAL_MAPPING_READY',resources=candidate['resources'],delta_LUT=-21,macro_instances32=True,macro_pins_INIT_exact=True,all64_operand_FF_direct=True,source17_physical18=35,audit=ref(HERE/'SYNTHESIS_AUDIT.json'),summary=ref(HERE/'SYNTHESIS_AUDIT.md'),script=ref(Path(__file__)),functional_record=ref(HERE/'FINAL_RECHECK.json'),four_artifacts=frozen['four_artifacts'])
(HERE/'SYNTHESIS_RECHECK.json').write_text(json.dumps(z,indent=2)+'\\n',encoding='utf-8')
assert load(HERE/'SYNTHESIS_RECHECK.json')==z
for row in [z[k] for k in ('audit','summary','script','functional_record')]+list(z['four_artifacts'].values()):assert sha(Path(row['path']))==row['sha256']
for row in (candidate['netlist'],candidate['log'],parent['netlist'],parent['log']):assert sha(Path(row['path']))==row['sha256']
print('SG51_MAPPING_READY macros=32 all_pins_INIT=exact FF_direct=64 LUT=6121 FF=2561 dramLUT=471 deltaLUT=-21 module_delta='+json.dumps(lut_delta,sort_keys=True)+' all_artifacts=reopened')
'''
(HERE/'audit_synthesis.py').write_text(header+function+tail,encoding='utf-8')
print('SG51_READONLY_MAPPING_AUDIT_PREPARED')

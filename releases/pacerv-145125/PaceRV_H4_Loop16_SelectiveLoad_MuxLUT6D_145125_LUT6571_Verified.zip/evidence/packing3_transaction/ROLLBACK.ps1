﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $target = [System.IO.Path]::GetFullPath($TargetPath)
    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)
    if ($target -eq $baseline) { throw 'Use an independent target copy' }
    if ([System.IO.Path]::GetFileName($target) -ne 'rollback_copy.tcl' -or [System.IO.Path]::GetDirectoryName($target) -ne [System.IO.Path]::GetDirectoryName($baseline)) { throw 'Use the independent rollback_copy.tcl beside the baseline snapshot' }
    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '666EB25A9158F9D4CE610F2C4BEB668B6F1649D192CA873CB13A4901B7925764') { throw 'Baseline hash mismatch' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($hash -ne '666EB25A9158F9D4CE610F2C4BEB668B6F1649D192CA873CB13A4901B7925764') { throw 'Restore hash mismatch' }
    Write-Output ('SG51_PACKING3_ROLLBACK_TCL_PASS SHA256=' + $hash)
    exit 0
} catch { Write-Error $_; exit 1 }

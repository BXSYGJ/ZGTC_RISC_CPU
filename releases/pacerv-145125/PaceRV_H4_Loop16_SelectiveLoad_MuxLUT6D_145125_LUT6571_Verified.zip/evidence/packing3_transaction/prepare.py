"""Capture actual baseline/new implementation Tcl without touching either build."""
from pathlib import Path
import difflib
import hashlib
import json

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=ROOT/"work/sg51-regfile-compare-mux-lut6d-lut1-s1"
new=ROOT/"work/sg51-regfile-compare-mux-lut6d-lut3-s1"
assert not (AREA/"MODIFIED_FILE.tcl").exists(),"Preserve existing transaction"
oldpath=old/"implementation/build.tcl"
newpath=new/"implementation/build.tcl"
before=oldpath.read_bytes();after=newpath.read_bytes()
(AREA/"BASELINE_FILE.tcl").write_bytes(before)
(AREA/"MODIFIED_FILE.tcl").write_bytes(after)
(AREA/"rollback_copy.tcl").write_bytes(after)
(AREA/"DIFF_FILE.diff").write_text("".join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile=str(oldpath),tofile=str(newpath))),encoding="utf-8")
norm=lambda data,base:data.decode().replace(chr(92),"/").replace(base.as_posix()+"/","{BUILD}/")
assert norm(before,old).replace("-logic_optimize_lut6d_combing_strategy 1","-logic_optimize_lut6d_combing_strategy 3",1)==norm(after,new)
rollback="\n".join([
    "#!/usr/bin/env pwsh","[CmdletBinding()]",
    "param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)",
    "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8","$OutputEncoding = [System.Text.UTF8Encoding]::new($true)","$ErrorActionPreference = 'Stop'",
    "try {","    $target = [System.IO.Path]::GetFullPath($TargetPath)","    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)",
    "    if ($target -eq $baseline) { throw 'Use an independent target copy' }",
    "    if ([System.IO.Path]::GetFileName($target) -ne 'rollback_copy.tcl' -or [System.IO.Path]::GetDirectoryName($target) -ne [System.IO.Path]::GetDirectoryName($baseline)) { throw 'Use the independent rollback_copy.tcl beside the baseline snapshot' }",
    "    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '"+sha(oldpath).upper()+"') { throw 'Baseline hash mismatch' }",
    "    Copy-Item -LiteralPath $baseline -Destination $target -Force",
    "    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash",
    "    if ($hash -ne '"+sha(oldpath).upper()+"') { throw 'Restore hash mismatch' }",
    "    Write-Output ('SG51_PACKING3_ROLLBACK_TCL_PASS SHA256=' + $hash)","    exit 0","} catch { Write-Error $_; exit 1 }",""])
for n in ["ROLLBACK.sh","ROLLBACK.ps1"]:(AREA/n).write_text(rollback,encoding="utf-8-sig")
change=dict(changed_field="PnrOptions.logic_optimize_lut6d_combing_strategy:1->3; actual Tcl file paths follow their builddirectories. After normalizing only those paths, packing1->3 is the only difference. Same frozen SG51 netlist/ADF/inputbytes/seed1/frequency145125000/uncertainty.150; noRTLchange.",
    baseline_source=str(oldpath),modified_source=str(newpath),baseline_build=str(old),modified_build=str(new),
    baseline_sha256=sha(oldpath),modified_sha256=sha(newpath),normalized_baseline=norm(before,old),normalized_modified=norm(after,new),
    historical_PDS_invocations={label:json.loads((base/"implementation/INVOCATION.json").read_text(encoding="utf-8-sig")) for label,base in [("BASELINE",old),("MODIFIED",new)]},
    protected_build_files={str(p):sha(p) for base in [old,new] for p in [base/"implementation/build.tcl",base/"BUILD_RESULT.json",base/"INPUT_HASHES.json",base/"implementation/netlist.v",base/"implementation/source.adf"]})
(AREA/"CHANGE.json").write_text(json.dumps(change,indent=2)+"\n",encoding="utf-8-sig")
(AREA/"VERIFICATION.txt").write_text(json.dumps(dict(status="ACTUAL_TCL_COPIES_PREPARED_BMR_PENDING",change=change),indent=2)+"\n",encoding="utf-8-sig")
print("SG51_PACKING3_TRANSACTION_PREPARED baselineSHA256="+change["baseline_sha256"]+" modifiedSHA256="+change["modified_sha256"]+" exact_source_copies=PASS normalized_onlypacking1to3=PASS exit=0")

"""Isolated, reproducible compiler/RTL experiments against frozen PaceRV H3.

Run with Python in WSL; no shell is used to build or execute the tools.
CoreMark algorithms, seeds, memory size and measured interval remain unchanged.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
GCC = Path('/mnt/d/AAAFPGA/ZGTC_RISC_CPU/cpu_paper/tools/xpack-riscv-none-embed-gcc-10.2.0-1.2/bin/riscv-none-embed-gcc')
VERILATOR_ROOT = Path('/tmp/ccfa-native-snapshot-verilator-v5.032-5a262564b1/verilator-5.032')
PROFILES = {
    'baseline': [],
    'lto': ['-flto'],
    'lto-align4': ['-flto', '-falign-functions=4', '-falign-loops=4', '-falign-jumps=4', '-falign-labels=4'],
    'lto-align16': ['-flto', '-falign-functions=16', '-falign-loops=16'],
    'lto-unroll-all': ['-flto', '-funroll-all-loops'],
    'unroll-all': ['-funroll-all-loops'],
    'lto-noif': ['-flto', '-fno-if-conversion', '-fno-if-conversion2'],
    'lto-rename': ['-flto', '-frename-registers'],
    'lto-inline': ['-flto', '-finline-limit=1000'],
    'lto-align2': ['-flto', '-falign-functions=2', '-falign-loops=2', '-falign-jumps=2', '-falign-labels=2'],
    'align4': ['-falign-functions=4', '-falign-loops=4', '-falign-jumps=4', '-falign-labels=4'],
    'align2': ['-falign-functions=2', '-falign-loops=2', '-falign-jumps=2', '-falign-labels=2'],
    'no-unroll': ['-fno-unroll-loops'],
    'O2': ['-O2', '-fno-unroll-loops'],
    'tune3': ['-mtune=sifive-3-series'],
    'tune5': ['-mtune=sifive-5-series'],
    'noif': ['-fno-if-conversion', '-fno-if-conversion2'],
    'noif-align2': ['-fno-if-conversion', '-fno-if-conversion2', '-falign-functions=2', '-falign-loops=2', '-falign-jumps=2', '-falign-labels=2'],
    'noif-align4': ['-fno-if-conversion', '-fno-if-conversion2', '-falign-functions=4', '-falign-loops=4', '-falign-jumps=4', '-falign-labels=4'],
    'noif-align16': ['-fno-if-conversion', '-fno-if-conversion2', '-falign-functions=16', '-falign-loops=16'],
    'noif-rename': ['-fno-if-conversion', '-fno-if-conversion2', '-frename-registers'],
    'noif-nosched': ['-fno-if-conversion', '-fno-if-conversion2', '-fno-schedule-insns', '-fno-schedule-insns2'],
    'noif-branch1': ['-fno-if-conversion', '-fno-if-conversion2', '-mbranch-cost=1'],
    'noif-branch2': ['-fno-if-conversion', '-fno-if-conversion2', '-mbranch-cost=2'],
    'noif-inline': ['-fno-if-conversion', '-fno-if-conversion2', '-finline-limit=1000'],
    'noif-nocross': ['-fno-if-conversion', '-fno-if-conversion2', '-fno-crossjumping'],
    'noif-unroll16': ['-fno-if-conversion', '-fno-if-conversion2', '--param=max-unroll-times=16', '--param=max-unrolled-insns=400'],
    'noif-unroll4': ['-fno-if-conversion', '-fno-if-conversion2', '--param=max-unroll-times=4'],
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def firmware(profile, iterations, role, label=None):
    target = ROOT / 'work' / (label or f'{profile}-i{iterations}-{role}')
    target.mkdir(parents=True, exist_ok=True)
    inputs = ROOT / 'firmware' / role / 'inputs'
    recipe = json.loads((ROOT / 'recipe.json').read_text(encoding='utf-8-sig'))
    argv = []
    for token in recipe['roles'][role]['firmware_argv']:
        if token.startswith('-DITERATIONS='):
            token = f'-DITERATIONS={iterations}'
        if token.startswith('-DFLAGS_STR='):
            continue
        argv.append(token.replace('{RELEASE}', str(ROOT)).replace('{OUTPUT}', str(target)))
    # Keep the measured compiler flags in the UART report, including experiment options.
    extra = PROFILES[profile]
    at = argv.index('-I')
    argv[at:at] = extra
    options = [x for x in argv[:argv.index('-I')] if x.startswith('-')]
    argv.insert(0, '-DFLAGS_STR="' + ' '.join(options) + '"')
    command = [str(GCC), *argv]
    with (target / 'compiler.log').open('w') as log:
        result = subprocess.run(command, cwd=target, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError((target / 'compiler.log').read_text()[-5000:])
    objcopy = GCC.with_name('riscv-none-embed-objcopy')
    subprocess.run([str(objcopy), '-O', 'binary', 'firmware.elf', 'firmware.bin'], cwd=target, check=True)
    binary = (target / 'firmware.bin').read_bytes()
    if len(binary) > 49152:
        raise RuntimeError('Firmware overlaps the existing 16KiB stack reservation')
    binary = binary.ljust(65536, b'\0')
    (target / 'firmware.hex').write_text(''.join(f'{int.from_bytes(binary[i:i+4], "little"):08x}\n' for i in range(0, len(binary), 4)))
    with (target / 'firmware.dis').open('w') as out:
        subprocess.run([str(GCC.with_name('riscv-none-embed-objdump')), '-d', 'firmware.elf'], cwd=target, stdout=out, check=True)
    record = {'command': command, 'gcc_version': subprocess.check_output([str(GCC), '--version'], text=True),
              'source_hashes': {str(p.relative_to(inputs)): sha(p) for p in sorted(inputs.rglob('*')) if p.is_file()},
              'firmware_hex_sha256': sha(target / 'firmware.hex'), 'binary_bytes': len((target / 'firmware.bin').read_bytes()),
              'role': role, 'profile': profile, 'iterations': iterations}
    write_json(target / 'BUILD.json', record)
    return target


def simulator(rtl_directory=None, load_bubble=1, threads=4):
    recipe = json.loads((ROOT / 'recipe.json').read_text(encoding='utf-8-sig'))
    rtl = Path(rtl_directory) if rtl_directory else ROOT / 'simulation' / 'inputs' / 'rtl'
    argv = list(recipe['simulation']['argv'])
    inputs = [rtl / Path(x).name for x in argv if '/simulation/inputs/rtl/' in x]
    inputs += [ROOT / x.split('{RELEASE}/')[1] for x in argv if '/simulation/inputs/sim/' in x]
    digest = hashlib.sha256()
    for p in inputs:
        digest.update(p.name.encode())
        digest.update(p.read_bytes())
    digest.update(str(load_bubble).encode())
    identity = digest.hexdigest()
    obj = Path('/tmp') / f'pacerv_h3_{identity[:16]}'
    obj.mkdir(parents=True, exist_ok=True)
    command = [str(VERILATOR_ROOT / 'bin' / 'verilator')]
    for x in argv:
        if x == '{OUTPUT}/objects':
            x = str(obj)
        elif '/simulation/inputs/rtl/' in x:
            x = str(rtl / Path(x).name)
        else:
            x = x.replace('{RELEASE}', str(ROOT))
        if x == '-GLOAD_USE_BUBBLE=1':
            x = f'-GLOAD_USE_BUBBLE={load_bubble}'
        command.append(x)
    command[command.index('-j')+1] = str(threads)
    executable = obj / 'Vrv32_observed_soc'
    if not executable.exists():
        env = os.environ.copy()
        env['VERILATOR_ROOT'] = str(VERILATOR_ROOT)
        started = time.monotonic()
        with (obj / 'compile.log').open('w') as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, env=env)
        if result.returncode:
            raise RuntimeError((obj / 'compile.log').read_text()[-10000:])
        write_json(obj / 'BUILD.json', {'command': command, 'source_sha256': identity, 'seconds': time.monotonic()-started})
    return executable, identity


def run(target, executable, identity, max_cycles, load_bubble):
    started = time.monotonic()
    command = [str(executable), str(target / 'uart.log'), str(max_cycles)]
    with (target / 'simulation.log').open('w') as log:
        result = subprocess.run(command, cwd=target, stdout=log, stderr=subprocess.STDOUT)
    text = (target / 'simulation.log').read_text()
    uart = (target / 'uart.log').read_text() if (target / 'uart.log').exists() else ''
    metadata = json.loads((target / 'BUILD.json').read_text())
    cycles = re.search(r'OBSERVER cycles=(\d+) retired=(\d+) minimum_sp=(\d+)', text)
    uart_cycles = re.search(r'cycles_hex=([0-9a-fA-F]{16}) retired_hex=([0-9a-fA-F]{16})', uart)
    crcs = re.findall(r'\[0\](?:crc(?:list|matrix|state)|crcfinal)\s*:\s*(0x[0-9a-fA-F]+)', uart)
    # Short runs deliberately report the standard ten-second duration diagnostic.
    error_lines = [line for line in uart.splitlines() if 'ERROR' in line
                   and 'Must execute for at least 10 secs' not in line]
    expected = {'V0': ['0xe714', '0x1fd7', '0x8e3a'], 'V1': ['0xe3c1', '0x0747', '0x8d84']}
    short_duration = 'Must execute for at least 10 secs' in uart
    checks = {'rtl_exit_zero': result.returncode == 0, 'observer_present': bool(cycles),
              'counter_interval_matches_uart': bool(cycles and uart_cycles and int(cycles[1]) == int(uart_cycles[1],16) and int(cycles[2]) == int(uart_cycles[2],16)),
              'all_four_crc_fields': len(crcs) == 4,
              'three_standard_algorithm_crcs': crcs[:3] == expected[metadata['role']],
              'duration_diagnostic_consistent': 'Errors detected' not in uart or short_duration,
              'no_crc_or_runtime_error': not error_lines}
    record = {'command': command, 'working_directory': str(target), 'exit_status': result.returncode,
              'wall_seconds': time.monotonic()-started, 'rtl_sha256': identity,
              'load_use_bubble': load_bubble, 'firmware': metadata, 'checks': checks,
              'error_lines': error_lines, 'crc_fields': crcs, 'formal_ten_seconds': 'Correct operation validated.' in uart,
              'stdout': text}
    if cycles:
        record.update(timed_cycles=int(cycles[1]), retired=int(cycles[2]), minimum_sp=int(cycles[3]),
                      coremark_per_mhz=metadata['iterations']*1e6/int(cycles[1]),
                      duration_at_145125MHz_seconds=int(cycles[1])/145125000)
    write_json(target / 'RUN.json', record)
    print(text, end='')
    print('RESULT ' + json.dumps({k:v for k,v in record.items() if k not in ('stdout','firmware','command')}, sort_keys=True), flush=True)
    if not all(checks.values()):
        raise RuntimeError(f'Benchmark verification failed: {checks}; errors={error_lines}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=PROFILES, default='baseline')
    parser.add_argument('--label')
    parser.add_argument('--iterations', type=int, default=100)
    parser.add_argument('--role', choices=('V0', 'V1'), default='V0')
    parser.add_argument('--build-only', action='store_true')
    parser.add_argument('--compile-only', action='store_true')
    parser.add_argument('--rtl-directory')
    parser.add_argument('--load-bubble', type=int, choices=(0,1), default=1)
    parser.add_argument('--threads', type=int, default=4)
    parser.add_argument('--max-cycles', type=int, default=2400000000)
    args = parser.parse_args()
    if not 1 <= args.iterations <= 1000000:
        parser.error('iterations outside allowed range')
    if args.label and not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',args.label):
        parser.error('invalid label')
    if args.compile_only:
        exe, identity = simulator(args.rtl_directory, args.load_bubble, args.threads)
        print(f'SIMULATOR {exe} SHA256={identity}', flush=True)
        return
    target = firmware(args.profile, args.iterations, args.role, args.label)
    print(f'FIRMWARE {target}', flush=True)
    if not args.build_only:
        executable, identity = simulator(args.rtl_directory, args.load_bubble, args.threads)
        run(target, executable, identity, args.max_cycles, args.load_bubble)


if __name__ == '__main__':
    main()

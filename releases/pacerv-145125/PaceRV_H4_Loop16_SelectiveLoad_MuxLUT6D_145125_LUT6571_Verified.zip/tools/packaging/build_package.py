"""Package existing SG51 evidence only after its original two6000 jobs complete."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,shutil,sys,zipfile
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PROPOSAL=ROOT/'rtl_proposals/regfile_compare_mux_lut6d'
SHORT=ROOT/'rtl_proposals/regfile_compare_mux_lut6d_performance'
LONG=ROOT/'rtl_proposals/regfile_compare_mux_lut6d_longs'
PARENT=ROOT/'optimized_releases/PaceRV_H4_Loop16_SelectiveLoad_MemoryRange_145125_LUT6621_Verified.zip'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
allowed={'.sv','.v','.py','.ps1','.sh','.diff','.json','.txt','.log','.md','.tcl'}
spec=importlib.util.spec_from_file_location('sg51_verifier',HERE/'verify_package_sg51.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
WORK=ROOT/'work'/v.SELECTION['physical_work']
PACKING=ROOT/'evidence/selective_closure_20261118'/v.SELECTION['packing_transaction']

def collect():
    files={}
    def add(source,relative):
        source=Path(source);v.require(source.is_file(),'Missing package source '+str(source))
        relative=v.safe(str(relative).replace(chr(92),'/'));v.require(relative not in files,'Duplicate packaging target '+relative)
        files[relative]=source
    def tree(source,relative,filter=lambda p:True):
        v.require(source.is_dir(),'Missing source directory '+str(source))
        for p in sorted(source.rglob('*')):
            if p.is_file() and filter(p):add(p,Path(relative)/p.relative_to(source))
    add(PARENT,'parents/SG30_LUT6621_Verified.zip')
    add(HERE/'verify_package_sg51.py','verify_package_sg51.py')
    add(HERE/'build_package.py','tools/packaging/build_package.py')
    add(HERE/'prepare_framework.py','tools/packaging/prepare_framework.py')
    add(ROOT/'recipe.json','recipe.json')
    add(ROOT/'scripts/experiment.py','tools/experiment.py')
    add(PROPOSAL/'experiment_extended.py','tools/experiment_extended.py')
    add(WORK/'Build-PacePds.snapshot.ps1','tools/Build-PacePds.snapshot.ps1')
    add(HERE/'Rebuild-Physical.ps1','Rebuild-Physical.ps1')
    tree(WORK/'inputs','physical_inputs')
    candidate=ROOT/'candidates/loop16_h4_regfile_compare_mux_lut6d'
    tree(candidate/'rtl','simulation/rtl')
    for arg in load(ROOT/'recipe.json')['simulation']['argv']:
        if '/simulation/inputs/sim/' in arg:add(ROOT/arg.split('{RELEASE}/')[1],'simulation/sim/'+Path(arg).name)
    for folder in ['vendor','derived_vendor']:tree(PROPOSAL/folder,'simulation/models/'+folder)
    tree(HERE/'native_snapshot','simulation/native')
    for root,relative in [(PROPOSAL,'evidence/rtl/regfile_compare_mux_lut6d'),(SHORT,'evidence/shorts'),(LONG,'evidence/longs')]:
        tree(root,relative,lambda p:p.suffix.lower()in allowed and '__pycache__'not in p.parts and not any(t in p.parts for t in ['vendor','derived_vendor','native_model_receipts']))
    for p in sorted(WORK.iterdir()):
        if p.is_file():add(p,'evidence/physical/'+p.name)
    for p in sorted((WORK/'implementation').iterdir()):
        if p.is_file():add(p,'evidence/physical/implementation/'+p.name)
    for relative in ['report_timing/pds_soc_top.rtr','report_timing/build.tcl','report_timing/run.log','place_route/pds_soc_top.prr','place_route/build.tcl','place_route/run.log','generate_bitstream/run.log']:
        p=WORK/'implementation'/relative
        if p.exists():add(p,'evidence/physical/implementation/'+relative)
    ph=load(WORK/'BUILD_RESULT.json');add(Path(ph['Bitstream']['Path']),'bitstreams/V0.sbit')
    tree(PACKING,'evidence/packing3_transaction')
    for role in ['V0','V1']:
        long=ROOT/'work'/('sg51-regfile-compare-mux-lut6d-i6000-'+role)
        short=ROOT/'work'/('sg51-regfile-compare-mux-lut6d-i100-'+role)
        for p in sorted(long.iterdir()):
            if p.is_file():add(p,'firmware/'+role+'/'+p.name)
        tree(ROOT/'firmware'/role/'inputs','firmware/'+role+'/inputs')
        for p in sorted(short.iterdir()):
            if p.is_file():add(p,'short_runs/'+role+'/'+p.name)
    return files

def completed_longs():
    p=LONG/'LONG_FINAL_AUDIT.json'
    v.require(p.exists(),'PENDING_OR_MISSING_FORMAL6000')
    j=load(p)
    v.require(j['status']=='PASS_BOTH_ACTUAL6000_AND_MATCHING_6571_TIMING' and j['pending']==[] and len(j['completed'])==2,'PENDING_OR_MISSING_FORMAL6000')

def plan(files):
    read=lambda n:files[v.safe(n)].read_bytes()
    parent,legacy=v.parent_chain(read)
    c,support,vm=v.source_and_models(read,parent,legacy)
    v.simulation_model(read,support)
    v.launch_contract(read,c)
    ph,checks,resources=v.physical(read,parent,legacy)
    v.short_runs(read,parent)
    pending=[]
    for role in ['V0','V1']:
        if 'firmware/'+role+'/RUN.json'not in files:pending.append(role)
    result=dict(status='CODE_PLAN_READY_FORMAL6000_PENDING'if pending else 'CODE_PLAN_READY_FORMAL6000_PRESENT',
        package_name=v.NAME,files_present=len(files),parent_ZIP_sha256=sha(PARENT),resources=resources,
        timing_categories=len(checks),source17=c['rtl'],physical18=c['physical_rtl'],pair_VM_cases=vm,
        pending_actual6000_roles=pending,output_created=False,PDS_launched=0,benchmark_launched=0)
    (HERE/'PLAN_RECHECK.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('SG51_PACKAGE_PLAN_READY source17/18=35 parent536=verified macro32_VM1024=PASS physical'+str(resources['LUT'])+'_all10=PASS formal6000_pending='+','.join(pending)+' output_created=0',flush=True)
    return result

def build(files):
    completed_longs()
    OUT=ROOT/'optimized_releases'/v.NAME
    v.require(not OUT.exists() and not OUT.with_suffix('.zip').exists(),'Use a fresh SG51 package output')
    # Validate every semantic gate in memory before a Verified-named root exists.
    raw={n:p.read_bytes()for n,p in files.items()}
    raw['SELECTED_PHYSICAL.json']=(json.dumps(v.SELECTION,indent=2)+'\n').encode()
    s=v.SELECTION
    raw['README.md']=('\n'.join(['# PaceRV SG51 SelectiveLoad — '+str(s['resources']['LUT'])+' LUT','',
        '145.125 MHz / setup uncertainty 0.150ns / PG2L200H-6FBB676 / RV32IMC. Actual packing '+str(s['packing'])+' seed '+str(s['seed'])+': '+str(s['resources']['LUT'])+' LUT, '+str(s['resources']['FF'])+' FF, 25 DRM, 4 APM, 1 GPLL; all 10 timing categories pass; slow setup '+format(s['slow_setup_ns'],'+.3f')+'ns.',
        'The two original source-matched6000 RTL runs validate fourCRCs, UART/CSR/observer counts and formal intervals above10seconds; scores are recomputed by the verifier. No new board programming was performed in this packaging step.',
        'Original qualified 6621 parent ZIP remains byte-identical under parents/. Current '+str(s['resources']['LUT'])+' physical evidence, 32 compare LUT6D source/models/proofs, actual 100/6000 runs and packing 1→'+str(s['packing'])+' transaction have separate paths.',
        'Python3 standard library: python ./verify_package_sg51.py --root . ; the same verifier accepts --zip <archive>.',
        'PowerShell7 preparation: pwsh -NoProfile -File ./Rebuild-Physical.ps1 -WorkspaceRoot <new-directory>. It verifies this package before copying the exact checkpoint/inputs; default preparation launches no PDS. Explicit -RunPds invokes the packaged builder with seed '+str(s['seed'])+'/packing '+str(s['packing'])+'.',
        'simulation/native/ preserves the actual compiled Linux executable and compilation receipts. The standard simulation driver/observer and five proven vendor models are included. Firmware build flags, original sources, RUN/PROCESS/native exits and complete UART are preserved per role.',''])).encode('utf-8-sig')
    manifest=dict(schema='pacerv-sg51-qualified-release/v1',name=v.NAME,frequency_hz=145125000,setup_uncertainty_ns=0.15,
        resources=v.SELECTION['resources'],physical_build=WORK.name,
        qualification='actual6000_both_ge3.5_and_all10_physical_checks_pass',
        files=[dict(path=n,bytes=len(b),sha256=v.digest(b))for n,b in sorted(raw.items())])
    raw['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    result=v.verify_content(raw.__getitem__,list(raw))
    OUT.mkdir(parents=True)
    for n,b in raw.items():
        p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    # Reopen the actual root before archiving it, then verify archive separately.
    root_result=v.verify_content(lambda n:(OUT/n).read_bytes(),[p.relative_to(OUT).as_posix()for p in OUT.rglob('*')if p.is_file()])
    dest=OUT.with_suffix('.zip')
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
    with zipfile.ZipFile(dest)as z:
        v.require(z.testzip()is None,'Created ZIP CRC');zip_result=v.verify_content(z.read,z.namelist())
    record=dict(status='PACKAGED_VERIFIED',root=str(OUT),zip=str(dest),zip_sha256=sha(dest),zip_bytes=dest.stat().st_size,
        root_result=root_result,zip_result=zip_result,manifest_files=len(manifest['files']),PDS_launched=0,simulation_launched=0)
    (HERE/'PACKAGE_RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print('SG51_ARCHIVE_READY files='+str(len(manifest['files']))+' sha256='+sha(dest),flush=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--plan',action='store_true');args=ap.parse_args()
    if not args.plan:completed_longs()
    files=collect()
    if args.plan:plan(files)
    else:build(files)
if __name__=='__main__':main()

"""Prepare reversible verifier fixtures without creating a Verified release."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=ROOT/'scripts/closure-packaging-sg30/verify_package_sg30.py'
assert sha(baseline)=='ac17ff6f9fc08c5884fd77cf9e1a0674d4e12ffa1cea00c4c262bdabea5b3c35'
shutil.copyfile(baseline,HERE/'BASELINE_FILE.py')
shutil.copyfile(HERE/'verify_package_sg51.py',HERE/'MODIFIED_FILE.py')
(HERE/'DIFF_FILE.diff').write_text(''.join(difflib.unified_diff(baseline.read_text().splitlines(True),(HERE/'MODIFIED_FILE.py').read_text().splitlines(True),fromfile='SG30/verify_package_sg30.py',tofile='SG51/verify_package_sg51.py')),encoding='utf-8')
ps=['param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$DestinationPath)',
    '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8','$OutputEncoding = [System.Text.UTF8Encoding]::new($true)','$ErrorActionPreference = "Stop"','try {',
    '    $target = [System.IO.Path]::GetFullPath($DestinationPath)',
    '    foreach ($name in @("MODIFIED_FILE.py", "verify_package_sg51.py", "BASELINE_FILE.py")) {',
    '        if ($target -eq [System.IO.Path]::Combine($PSScriptRoot, $name)) { throw "Use an independent verifier copy." }','    }',
    '    $source = [System.IO.Path]::Combine($PSScriptRoot, "BASELINE_FILE.py")',
    '    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne "'+sha(HERE/'MODIFIED_FILE.py')+'") { throw "Unexpected modified verifier copy." }',
    '    [System.IO.File]::WriteAllBytes($target, [System.IO.File]::ReadAllBytes($source))',
    '    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()',
    '    if ($hash -ne "'+sha(baseline)+'") { throw "Rollback mismatch." }',
    '    Write-Output ("SG51_PACKAGING_ROLLBACK_PASS SHA256=" + $hash + " restored=SG30_strict_verifier")','    exit 0','} catch { Write-Error $_; exit 1 }']
for name in ['ROLLBACK.sh','ROLLBACK.ps1']:(HERE/name).write_text('\n'.join(ps)+'\n',encoding='utf-8-sig');(HERE/name).chmod(0o755)
rebuild=HERE/'Rebuild-Physical.ps1';rebuild.write_text(rebuild.read_text(encoding='utf-8-sig'),encoding='utf-8-sig')
parent=ROOT/'optimized_releases/PaceRV_H4_Loop16_SelectiveLoad_MemoryRange_145125_LUT6621_Verified.zip'
def run(command,label,expected=0):
    p=subprocess.run(command,cwd=HERE,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout,encoding='utf-8');assert p.returncode==expected,p.stdout[-3000:]
    return dict(command=command,literal_output=p.stdout,exit_status=p.returncode)
b=run([sys.executable,'-I',str(HERE/'BASELINE_FILE.py'),'--zip',str(parent)],'BASELINE')
package=HERE/'PACKAGE_RESULT.json'
if package.exists():
    result=json.loads(package.read_text(encoding='utf-8-sig'))
    m=run([sys.executable,'-I',str(HERE/'MODIFIED_FILE.py'),'--root',result['root']],'MODIFIED')
else:m=run([sys.executable,'-I',str(HERE/'check_prepared.py')],'MODIFIED')
target=HERE/'rollback_copy.py';shutil.copyfile(HERE/'MODIFIED_FILE.py',target)
r=run(['pwsh','-NoProfile','-File',str(HERE/'ROLLBACK.ps1'),'-DestinationPath',str(target)],'ROLLBACK_ACTION')
assert sha(target)==sha(baseline)
rb=run([sys.executable,'-I',str(target),'--zip',str(parent)],'ROLLBACK')
record=dict(status='BASELINE_MODIFIED_ROLLBACK_PASS' if package.exists() else 'BASELINE_MODIFIED_GATES_ROLLBACK_PASS_FORMAL6000_PENDING',changed_field='SG30 strict release verifier -> SG51 exact source/model/physical/formal6000 closure verifier',baseline=b,modified=m,rollback_action=r,rollback_test=rb,
    parent_ZIP_sha256=sha(parent),baseline_verifier_sha256=sha(baseline),modified_verifier_sha256=sha(HERE/'MODIFIED_FILE.py'),
    restored_verifier_sha256=sha(target),modified_left_changed=True,release_ZIP_created=package.exists(),PDS_launched=0,benchmark_launched=0,
    four_artifacts={name:str(HERE/name)for name in ['MODIFIED_FILE.py','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh']},
    restored_behavior='Original SG30 standalone verifier accepts the original 536-file parent archive; active SG51 verifier remains changed and enforces exact source/model/physical/actual6000 closure')
(HERE/'FRAMEWORK_BMR.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
(HERE/'VERIFICATION.txt').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
for name in ['MODIFIED_FILE.py','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh']:assert (HERE/name).read_bytes()
print('SG51_PACKAGING_FRAMEWORK_PASS parent536=verified baseline_exit0 rollback_action_exit0 rollback_test_exit0 modified_pending_formal6000=1 ZIP_created=0 four_artifacts=reopened')

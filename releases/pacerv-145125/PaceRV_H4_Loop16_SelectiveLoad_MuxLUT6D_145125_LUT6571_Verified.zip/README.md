﻿# PaceRV SG51 SelectiveLoad — 6571 LUT

145.125 MHz / setup uncertainty 0.150ns / PG2L200H-6FBB676 / RV32IMC. Actual packing 3 seed 1: 6571 LUT, 2557 FF, 25 DRM, 4 APM, 1 GPLL; all 10 timing categories pass; slow setup +0.099ns.
The two original source-matched6000 RTL runs validate fourCRCs, UART/CSR/observer counts and formal intervals above10seconds; scores are recomputed by the verifier. No new board programming was performed in this packaging step.
Original qualified 6621 parent ZIP remains byte-identical under parents/. Current 6571 physical evidence, 32 compare LUT6D source/models/proofs, actual 100/6000 runs and packing 1→3 transaction have separate paths.
Python3 standard library: python ./verify_package_sg51.py --root . ; the same verifier accepts --zip <archive>.
PowerShell7 preparation: pwsh -NoProfile -File ./Rebuild-Physical.ps1 -WorkspaceRoot <new-directory>. It verifies this package before copying the exact checkpoint/inputs; default preparation launches no PDS. Explicit -RunPds invokes the packaged builder with seed 1/packing 3.
simulation/native/ preserves the actual compiled Linux executable and compilation receipts. The standard simulation driver/observer and five proven vendor models are included. Firmware build flags, original sources, RUN/PROCESS/native exits and complete UART are preserved per role.

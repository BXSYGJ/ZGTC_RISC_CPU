﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $target=[System.IO.Path]::GetFullPath($TargetPath)
    $baseline=[System.IO.Path]::GetFullPath($BaselinePath)
    if ($target -eq $baseline) { throw 'Use an independent target copy' }
    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '8EAFB3330EAA57B7579AAA351ED851A1E34678255C0F3F2DD307DE9DC502232B') { throw 'Baseline hash mismatch' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $hash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($hash -ne '8EAFB3330EAA57B7579AAA351ED851A1E34678255C0F3F2DD307DE9DC502232B') { throw 'Restore hash mismatch' }
    Write-Output ('H4_PACKAGER_ROLLBACK_PASS SHA256='+$hash)
} catch { Write-Error $_; exit 1 }

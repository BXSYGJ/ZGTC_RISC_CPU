"""Package selected completed PaceRV runs with exact RTL and proof binding."""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import re
import sys

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
sys.path.insert(0, str(AREA))
sys.path.insert(0, str(ROOT / "scripts"))
from closure_proofs import collect_proofs, parse_timing_report
from audit_results import audit_simulation, audit_physical, read_json, require, sha

spec = importlib.util.spec_from_file_location("preserved_package", AREA / "PACKAGE_BASE.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT = ROOT
simulation_identity = base.simulation_identity
canonical_core = base.canonical_core
copy_file = base.copy_file
SUFFIXES = {".json", ".sv", ".v", ".ys", ".diff", ".txt", ".md", ".ps1", ".sh", ".py", ".log", ".tcl", ".rtr", ".prr"}


def cache_proof(area=None):
    area = area or ROOT / "rtl_proposals/timing_cache_hit_fanout"
    change = read_json(area / "CHANGE.json")
    before, after = area / "BASELINE_FILE.sv", area / "rv32_cache.sv"
    require(sha(before) == change["baseline_sha256"].lower() and sha(after) == change["modified_sha256"].lower(), "Cache proof source hashes")
    text = after.read_text(encoding="utf-8-sig")
    require(text.count(change["after"]) == 1 and text.replace(change["after"], change["before"]) == before.read_text(encoding="utf-8-sig"),
            "Cache exact inverse source transform")
    receipt = read_json(area / "VERIFICATION.txt")
    require(receipt["baseline_sha256"] == sha(before) and receipt["modified_sha256"] == sha(after), "Cache verification source binding")
    require(len(receipt["formal_tests"]) == len(receipt["four_state_tests"]) == 7, "Cache proof widths")
    for item in receipt["formal_tests"]:
        require(item["exit_status"] == 0 and "SAT proof finished - no model found: SUCCESS!" in item["literal_output"], "Cache SAT result")
    require(all(item["exit_status"] == 0 and "cases=20000" in item["literal_output"] for item in receipt["four_state_tests"]), "Cache four-state result")
    directed = read_json(area / "DIRECTED_EQUIVALENCE.json")
    require(directed["baseline_modified_rollback_equal"] and directed["core_scenarios"] == 23
            and directed["cache_configs_per_variant"] == 4 and directed["four_state_cases"] == 140000, "Cache directed equality")
    interface = read_json(area / "INTERFACE_EQUIVALENCE.json")
    a, b = interface["cached_baseline"], interface["modified"]
    require(a["exit_status"] == b["exit_status"] == interface["modified_build"]["exit_status"] == 0, "Cache interface status")
    for field in ("timed_cycles", "retired", "trace_sha256", "trace_bytes", "interface_sha256", "interface_bytes", "uart_sha256"):
        require(a[field] == b[field], "Cache interface equality: " + field)
    require(all(item["exit_status"] == 0 for item in interface["comparisons"].values()), "Cache comparison exits")
    require(interface["modified_build"]["input_sha256"]["rv32_cache.sv"] == sha(after)
            and interface["baseline_binding"]["source_inventory"]["rv32_cache.sv"] == sha(before), "Cache interface source binding")
    rollback = read_json(area / "ROLLBACK_RESULT.json")
    require(rollback["ExitStatus"] == 0 and rollback["RestoredSHA256"].lower() == sha(before), "Cache rollback result")
    return {"proposal": "timing_cache_hit_fanout", "baseline_sha256": sha(before), "modified_sha256": sha(after),
            "formal_widths": directed["formal_widths"], "four_state_cases": 140000, "interface_cycles": a["timed_cycles"],
            "trace_sha256": a["trace_sha256"], "interface_sha256": a["interface_sha256"]}


def simple_proof(core_hash):
    area = ROOT / "rtl_proposals/load_simple"
    change = read_json(area / "CHANGE.json")
    require(change["candidate_sha256"].lower() == core_hash == sha(area / "rv32_core.sv"), "Selective load source hash")
    directed = read_json(area / "DIRECTED_VERIFICATION.json")
    require(directed["architectural_match"] and directed["all_exit_zero"] and directed["formal_add_xor_all_inputs"]
            and directed["scenarios"] == 23 and directed["modified_sha256"].lower() == core_hash, "Selective load directed proof")
    decoder = read_json(area / "DECODER_CLASSIFICATION.json")
    require(decoder["exit_status"] == 0 and decoder["core_sha256"].lower() == core_hash
            and "SAT proof finished - no model found: SUCCESS!" in decoder["literal_output"], "Selective load decoder SAT")
    require(all(item["expected_failure_observed"] and item["exit_status"] != 0
                for item in read_json(area / "NEGATIVE_CONTROLS.json")), "Selective load negative controls")
    rollback = read_json(area / "ROLLBACK_SH_RESULT.json")
    require(rollback["exit_status"] == 0 and rollback["restored_sha256"].lower() == change["baseline_sha256"].lower(), "Selective load rollback")
    return {"proposal": "load_simple", "modified_sha256": core_hash, "scenarios": 23}


def core_proofs():
    area = ROOT / "rtl_proposals/timing_id_equal_lut4"
    proof = read_json(area / "FORMAL_EQUIVALENCE.json")
    require(proof["exit_status"] == 0 and proof["core_sha256"].lower() == sha(area / "rv32_core.sv"), "Core representation SAT binding")
    results = []
    for folder, name in (("timing_id_fanout8", "BENCHMARK_EQUIVALENCE.json"), ("timing_id_equal_lut4", "INTERFACE_EQUIVALENCE.json")):
        receipt = read_json(ROOT / "rtl_proposals" / folder / name)
        require(receipt["trace_comparison"]["exit_status"] == receipt["uart_comparison"]["exit_status"] == 0 and len(receipt["records"]) == 2, "Core comparison receipt")
        for field in ("timed_cycles", "retired", "trace_sha256", "uart_sha256"):
            require(receipt["records"][0][field] == receipt["records"][1][field], "Core representation equality: " + field)
        if "interface_comparison" in receipt:
            require(receipt["interface_comparison"]["exit_status"] == 0 and receipt["records"][0]["interface_sha256"]
                    == receipt["records"][1]["interface_sha256"], "Core interface equality")
        results.append({"proposal": folder, "receipt": name, "sha256": sha(ROOT / "rtl_proposals" / folder / name)})
    return results


def compare_rtl(simulation, actual):
    checks = []
    require(len(list(simulation.glob("*.sv"))) == 17, "Expected17simulationRTLfiles")
    for path in sorted(simulation.glob("*.sv")):
        other = actual / path.name
        require(other.is_file() and sha(path) == sha(other), "Exact17RTLbindingrequired: " + path.name)
        checks.append({"name": path.name, "simulation_sha256": sha(path), "physical_sha256": sha(other), "binding": "identical"})
    return checks, collect_proofs(ROOT, actual)


def bind_rtl(v0, v1, physical_path):
    require(v0["rtl_sha256"] == v1["rtl_sha256"], "V0/V1 simulator identity")
    record = read_json(ROOT / "work" / v0["name"] / "RUN.json")
    candidates = [ROOT / "simulation/inputs/rtl"] + sorted((ROOT / "candidates").glob("*/rtl")) + sorted((ROOT / "candidates").glob("*/rtl17"))
    matches = [p for p in candidates if simulation_identity(p, record["load_use_bubble"]) == v0["rtl_sha256"]]
    require(matches, "Simulation identity has no frozen source directory")
    actual = physical_path / "inputs/rtl"
    matches.sort(key=lambda d: (sum(not (actual / p.name).is_file() or sha(p) != sha(actual / p.name) for p in d.glob("*.sv")), str(d)))
    checks, proofs = compare_rtl(matches[0], actual)
    return {"simulation_directory": str(matches[0]), "simulation_identity": v0["rtl_sha256"], "load_use_bubble": record["load_use_bubble"],
            "identical_source_directories": [str(p) for p in matches], "common_files": len(checks), "checks": checks, "proofs": proofs}


def copy_small(source, destination):
    if not source.is_dir():
        return
    for item in sorted(source.iterdir()):
        if item.is_file() and item.suffix.lower() in SUFFIXES and item.stat().st_size <= 32 * 1024 * 1024:
            copy_file(item, destination / item.name)


def validate_selection(v0_name, v1_name, physical_name, archive_failed=False):
    a, b, p = [ROOT / "work" / name for name in (v0_name, v1_name, physical_name)]
    v0, v1, physical = audit_simulation(a), audit_simulation(b), audit_physical(p)
    require(v0["role"] == "V0" and v1["role"] == "V1", "Role binding")
    require(v0["formal_ten_seconds"] and v1["formal_ten_seconds"] and v0["iterations"] == v1["iterations"] == 6000, "Both full 6000-iteration runs must pass")
    require(physical["status"].startswith("completed_"), "Physical build incomplete")
    passed = physical["all_ten_timing_checks_pass"]
    require(v0["coremark_per_mhz"] > 3.5 and v1["coremark_per_mhz"] > 3.5, "Both6000CoreMark/MHzmustexceed3.5")
    require(not archive_failed and passed, "All10timingchecksmustpass;failedarchivesareexcluded")
    require(parse_timing_report((p / "implementation/report_timing/pds_soc_top.rtr").read_bytes()) == read_json(p / "BUILD_RESULT.json")["Timing"]["Checks"], "Actual10timingrowsmustmatchreceipt")
    require(v0["firmware_sha256"] == physical["firmware_sha256"], "V0/physical firmware mismatch")
    for role, folder in (("V0", a), ("V1", b)):
        for relative, expected in read_json(folder / "BUILD.json")["source_hashes"].items():
            require(sha(ROOT / "firmware" / role / "inputs" / relative) == expected.lower(), "Firmware source mismatch: " + relative)
    return v0, v1, physical, bind_rtl(v0, v1, p)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("v0", "v1", "physical", "output"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    for value in (args.v0, args.v1, args.physical, args.output):
        require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", value) is not None and value not in (".", ".."), "Expected a directory name")
    v0, v1, physical, binding = validate_selection(args.v0, args.v1, args.physical, False)
    if args.verify_only:
        print("CLOSURE_SELECTION_PASS actual6000=2 score_gt3_5=2 timing_checks=10 exact_rtl=17")
        return
    frozen = read_json(ROOT / "EXPERIMENT.json")["BaselineFiles"]
    for entry in frozen:
        require(sha(ROOT / entry["Path"]) == entry["SHA256"].lower(), "Frozen baseline changed: " + entry["Path"])
    base.bind_rtl = bind_rtl
    package_output = io.StringIO()
    with redirect_stdout(package_output):
        base.main()
    out = ROOT / "optimized_releases" / args.output
    copy_file(ROOT / "recipe.json", out / "evidence/SIMULATION_RECIPE.json")
    for proposal in sorted({"load_simple"} | {proof["proposal"] for proof in binding["proofs"]}):
        copy_small(ROOT / "rtl_proposals" / proposal, out / "evidence/rtl" / proposal)
    p = ROOT / "work" / args.physical
    for name in ("TIMING_SUMMARY.json", "Build-PacePds.snapshot.ps1"):
        copy_file(p / name, out / "evidence/physical" / name)
    copy_small(p / "synthesis", out / "evidence/physical/synthesis")
    for name in ("MODIFIED_FILE.py", "BASELINE_FILE.py", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh", "ROLLBACK.ps1", "verify_package.py", "create_zip.py", "PACKAGE_BASE.py", "closure_proofs.py"):
        copy_file(AREA / name, out / "reproduction/closure-packaging" / name)
    audit = {"V0": v0, "V1": v1, "physical": physical, "frozen_baseline_files_verified": len(frozen)}
    for name in ("SELECTED_AUDIT.json", "RESULTS_AUDIT.json"):
        (out / "evidence" / name).write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8-sig")
    manifest = read_json(out / "MANIFEST.json")
    manifest.update(schema="pacerv-optimized-release/v3-closure", closure_minimum_coremark_per_mhz_exclusive=3.5, name=args.output, timing_checks=read_json(p / "BUILD_RESULT.json")["Timing"]["Checks"],
                    frozen_baseline_files_verified=len(frozen), rtl_binding=binding,
                    standalone_verifier="python reproduction/closure-packaging/verify_package.py --folder PATH")
    manifest["files"] = [{"path": file.relative_to(out).as_posix(), "sha256": sha(file), "bytes": file.stat().st_size}
                         for file in sorted(out.rglob("*")) if file.is_file() and file.name != "MANIFEST.json"]
    (out / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8-sig")
    verify_spec = importlib.util.spec_from_file_location("standalone_package_verifier", AREA / "verify_package.py")
    verifier = importlib.util.module_from_spec(verify_spec)
    verify_spec.loader.exec_module(verifier)
    verifier.verify_folder(out)
    print(package_output.getvalue(), end="")
    print(f"CLOSURE_PACKAGE_PASS files={len(manifest['files'])} common_rtl={binding['common_files']} timing_pass={physical['all_ten_timing_checks_pass']}")


if __name__ == "__main__":
    main()

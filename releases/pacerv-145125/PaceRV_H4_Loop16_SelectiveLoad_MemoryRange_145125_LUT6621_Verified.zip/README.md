﻿# PaceRV H4 Loop16 SelectiveLoad MemoryRange — 6621 LUT

本包是新增的完整合格版本：145.125 MHz，setup uncertainty 0.150 ns，RV32IMC，PG2L200H-6FBB676。实际布局布线资源为 **6621 LUT / 2557 FF / 25 DRM36K / 4 APM / 1 GPLL**，全部十类内部时序检查通过，slow setup **+0.043 ns**。相较先前 H4 6812 LUT / 2813 FF，节省 191 LUT 与 256 FF。

| 实际 6000 次 RTL 运行 | Cycles | CoreMark/MHz | 145.125 MHz 计时 |
|---|---:|---:|---:|
| V0 | 1712559880 | 3.503527129223651 | 11.800584875 秒 |
| V1 | 1713586192 | 3.501428774351375 | 11.807656792 秒 |

两组 CRC、UART 计数与独立 observer 均通过，17 份公共 RTL 在仿真与物理构建中逐字节相同。保留完整 SelectiveLoad、H4 历史预测器和 16 项循环预测表；将循环 count/trip RAM 写口归并，并预计算完整地址范围后选择 memory redirect。物理配方为 seed=2、LUT combine strategy=1、dc_duplication=false。

`bitstreams/V0.sbit` 绑定包内 V0 固件；`firmware/V1/` 提供实际测试过的 V1 固件和运行证据。本包归档的成绩来自实际 RTL 仿真；本轮没有新增板上烧录或 UART 实测采样。

## 校验

在解压目录运行 Python 3（仅标准库）：

```powershell
python ./verify_package_sg30.py --root .
```

同一校验器支持 ZIP：`python ./verify_package_sg30.py --zip ./PaceRV_H4_Loop16_SelectiveLoad_MemoryRange_145125_LUT6621_Verified.zip`。它重新读取完整清单、实际长测、源身份、raw RTR/PRR、位流、约束和各级源变换/证明/回滚记录。

## 物理重建准备

包内提供原始 Build-PacePds 快照、完整 recipe.json、18 份物理 RTL、三份 FDC、PLL、V0 固件，以及原综合 netlist/ADF 检查点。以下入口在独立新目录准备相同 seed2/packing1 配方；默认只准备文件。Windows PowerShell 7：

```powershell
pwsh -NoProfile -File ./Rebuild-Physical.ps1 -WorkspaceRoot ([IO.Path]::Combine($env:TEMP, 'PaceRV-SG30-Rebuild'))
```

实际重建需本机安装 PDS 2022.2-SP6.4，使用一个新的 WorkspaceRoot，并显式添加 `-RunPds -PdsRoot <PDS安装目录>`。综合检查点与 RTL/FDC/固件均为此版本原始字节；布局布线的再运行结果应读取新报告验收。固件编译命令、工具版本与全部源码在 `firmware/V0`、`firmware/V1` 的 BUILD.json 和 inputs 中。仿真依赖的 vendor model、wrapper、observer 在 simulation/sim 中，原 recipe 和 PROCESS.json 保留实际调用。

## 证据导航

- `evidence/qualification/`：新 6621 选择及独立全资格审计。
- `evidence/physical/`：实际 PDS invocation、输入哈希、TCL、检查点、raw timing/PRR 与执行日志。
- `evidence/packing1_transaction/`：packing3→1 的单字段变更与独立副本回滚。
- `evidence/rtl/`：H6→H3 donor→H4→single-write BTB，以及 SelectiveLoad→target_keep→memory_range core 的真实 source/proof/BMR/负控/回滚链。
- 祖先报告中保留当时 `PHYSICAL_PENDING` 或旧 seed 失败状态；本包资格由后续 `sg30-ram-memory-range-lut1-s2` 的真实通过结果确定。

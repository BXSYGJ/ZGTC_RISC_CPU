"""Verify saved actual builds; rollback independently restores Tcl only, no PDS."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import subprocess
import sys

sys.dont_write_bytecode=True
AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
parser=argparse.ArgumentParser()
parser.add_argument("--stage",choices=["BASELINE","MODIFIED","ROLLBACK"],required=True)
stage=parser.parse_args().stage
change=read(AREA/"CHANGE.json")
spec=importlib.util.spec_from_file_location("packing1_existing_audit",ROOT/"scripts/audit_results.py")
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
old=Path(change["baseline_build"]);new=Path(change["modified_build"])
for p,h in change["protected_build_files"].items():assert sha(Path(p))==h
assert sha(AREA/"BASELINE_FILE.tcl")==change["baseline_sha256"]
assert sha(AREA/"MODIFIED_FILE.tcl")==change["modified_sha256"]
rollback=None
if stage=="ROLLBACK":
    target=AREA/"rollback_copy.tcl"
    target.write_bytes((AREA/"MODIFIED_FILE.tcl").read_bytes())
    action=("[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
        "$a=[System.IO.Path]::Combine('D:/AAAFPGA','ZGTC_RISC_CPU','pds_minimal_blink_200h','pacerv_h3_optimization','evidence','selective_closure_20261118','packing1_transaction'); "
        "& ([ScriptBlock]::Create((Get-Content -LiteralPath ([System.IO.Path]::Combine($a,'ROLLBACK.sh')) -Raw))) "
        "-TargetPath ([System.IO.Path]::Combine($a,'rollback_copy.tcl')) -BaselinePath ([System.IO.Path]::Combine($a,'BASELINE_FILE.tcl'))")
    command=["pwsh","-NoProfile","-NonInteractive","-Command",action]
    p=subprocess.run(command,capture_output=True,text=True,encoding="utf-8",timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    assert p.returncode==0,p.stdout+p.stderr
    assert sha(target)==change["baseline_sha256"]
    rollback=dict(command=command,input=dict(target=str(target),input_sha256=change["modified_sha256"],baseline=str(AREA/"BASELINE_FILE.tcl")),literal_output=p.stdout+p.stderr,exit_status=p.returncode,restored_sha256=sha(target))
    print(p.stdout.strip(),flush=True)
base=new if stage=="MODIFIED" else old
source=AREA/("MODIFIED_FILE.tcl" if stage=="MODIFIED" else "rollback_copy.tcl" if stage=="ROLLBACK" else "BASELINE_FILE.tcl")
assert source.read_bytes()==(base/"implementation/build.tcl").read_bytes()
result=audit.audit_physical(base)
manifest=read(base/"BUILD_RESULT.json")
expected_lut=6621 if stage=="MODIFIED" else 6611
expected_slack=0.043 if stage=="MODIFIED" else -0.005
assert result["resources"]["LUT"]==expected_lut and result["resources"]["FF"]==2557 and result["slow_setup_ns"]==expected_slack
assert result["all_ten_timing_checks_pass"]==(stage=="MODIFIED")
# Independently compare all ten raw RTR summary categories with the manifest.
report=base/"implementation/report_timing/pds_soc_top.rtr"
text=report.read_text(encoding="utf-8-sig")
checks={}
for corner in ["Slow","Fast"]:
    for kind in ["Setup","Hold","Recovery","Removal","Minimum Pulse Width"]:
        section=re.search(re.escape(kind+" Summary("+corner+" Corner):")+r"(.*?)(?=\r?\n=+)",text,re.S)
        assert section
        rows=re.findall(r"^\s*(.*?)\s+([+-]?\d+\.\d+)\s+([+-]?\d+\.\d+)\s+(\d+)\s+(\d+)\s*$",section[1],re.M)
        checks[kind+"_"+corner]=[dict(Clocks=c.strip(),WorstSlackNs=float(s),TotalNegativeSlackNs=float(t),FailingEndpoints=int(f),TotalEndpoints=int(n)) for c,s,t,f,n in rows]
assert len(checks)==10 and checks==manifest["Timing"]["Checks"]
prr=base/"implementation/place_route/pds_soc_top.prr"
prrtext=prr.read_text(encoding="utf-8-sig")
counts={k:sum(int(v) for v in re.findall(r"\|\s+"+k+r"\s+\|\s*(\d+)\s*\|",prrtext)) for k in ["LUT","FF"]}
assert counts==dict(LUT=expected_lut,FF=2557)
inputs=read(base/"INPUT_HASHES.json")
for entry in inputs:
    path=base/"inputs"/entry["RelativePath"]
    assert sha(path)==entry["SHA256"].lower() and path.stat().st_size==entry["Bytes"]
for p,h in change["protected_build_files"].items():assert sha(Path(p))==h
assert sha(AREA/"MODIFIED_FILE.tcl")==change["modified_sha256"]
line="PACKING1_"+stage+"_PASS input="+source.name+" SHA256="+sha(source)+" LUT="+str(expected_lut)+" FF=2557 slow="+format(expected_slack,"+.3f")+"ns rawtiming="+("10/10_PASS" if stage=="MODIFIED" else "9/10_FAIL_1ep")+" input_hashes="+str(len(inputs))+" verified PDS_restarted=0"
record=dict(stage=stage,command=[sys.executable,"verify.py","--stage",stage],working_directory=str(AREA),input=dict(Tcl=str(source),sha256=sha(source),actual_build=str(base)),
    audit_physical=result,raw_RTR_checks=checks,RTR_sha256=sha(report),PRR_sha256=sha(prr),INPUT_HASHES_sha256=sha(base/"INPUT_HASHES.json"),input_hashes_verified=len(inputs),
    literal_output=line+"\n",exit_status=0,rollback=rollback,rollback_scope="Independent Tcl copy only. Original baseline actual reports are reread after restoring its recipe. No new PDS/route execution is claimed.",modified_copy_remains_changed=True)
(AREA/(stage+"_RESULT.json")).write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8-sig")
print(line,flush=True)

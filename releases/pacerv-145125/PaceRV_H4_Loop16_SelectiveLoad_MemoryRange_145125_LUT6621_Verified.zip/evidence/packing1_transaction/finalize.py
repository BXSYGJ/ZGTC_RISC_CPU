"""Execute and freeze all three short real transaction verification commands."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

AREA=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
change=read(AREA/"CHANGE.json")
tests=[]
for stage in ["BASELINE","MODIFIED","ROLLBACK"]:
    command=[sys.executable,"verify.py","--stage",stage]
    p=subprocess.run(command,cwd=AREA,text=True,encoding="utf-8",stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    (AREA/(stage+".log")).write_text(p.stdout,encoding="utf-8")
    assert p.returncode==0,p.stdout
    result=read(AREA/(stage+"_RESULT.json"))
    tests.append(dict(stage=stage,command=command,working_directory=str(AREA),input=result["input"],literal_output=p.stdout,exit_status=p.returncode,full_result=result))
    print(p.stdout.strip(),flush=True)
assert sha(AREA/"rollback_copy.tcl")==change["baseline_sha256"]
assert sha(AREA/"MODIFIED_FILE.tcl")==change["modified_sha256"]
for entry in change["historical_PDS_invocations"].values():assert entry["ExitStatus"]==0
evidence=dict(status="PASS_REAL_BASELINE_MODIFIED_INDEPENDENT_TCL_ROLLBACK",changed_field=change["changed_field"],
    MODIFIED_FILE=str(AREA/"MODIFIED_FILE.tcl"),DIFF_FILE=str(AREA/"DIFF_FILE.diff"),VERIFICATION=str(AREA/"VERIFICATION.txt"),ROLLBACK=str(AREA/"ROLLBACK.sh"),
    original_hash_preserved=change["baseline_sha256"],modified_hash=change["modified_sha256"],change=change,tests=tests,
    historical_actual_PDS_commands=change["historical_PDS_invocations"],
    restored_behavior="Actual rollback restores independent Tcl copy to original SG30s2 bytes/packing3. Original actual RTR/PRR/INPUT_HASHES revalidated:6611LUT/2557FF,slow-.005ns,one failing endpoint. This is the restored original recipe and its saved actual status; rollback launches no PDS. Active modified copy and qualified actual lut1build remain unchanged atpacking1,6621LUT/2557FF,+.043ns,10checks pass.",
    actual_invocations_new_PDS=0,exit_status=0)
(AREA/"VERIFICATION.txt").write_text(json.dumps(evidence,indent=2)+"\n",encoding="utf-8-sig")
names=["BASELINE_FILE.tcl","MODIFIED_FILE.tcl","DIFF_FILE.diff","VERIFICATION.txt","ROLLBACK.sh","ROLLBACK.ps1","CHANGE.json","BASELINE_RESULT.json","MODIFIED_RESULT.json","ROLLBACK_RESULT.json","rollback_copy.tcl"]
artifacts={n:dict(sha256=sha(AREA/n),bytes=(AREA/n).stat().st_size) for n in names}
assert (AREA/"ROLLBACK.sh").read_bytes()==(AREA/"ROLLBACK.ps1").read_bytes()
for p,h in change["protected_build_files"].items():assert sha(Path(p))==h
final=dict(status=evidence["status"],changed_field=change["changed_field"],original_sha256=change["baseline_sha256"],modified_sha256=change["modified_sha256"],
    artifacts=artifacts,BMR_exit_statuses=[t["exit_status"] for t in tests],real_sh_rollback_tested=True,rollback_reexecutes_PDS=False,modified_remains_changed=True,exit_status=0)
(AREA/"FINAL_RECHECK.json").write_text(json.dumps(final,indent=2)+"\n",encoding="utf-8-sig")
assert read(AREA/"FINAL_RECHECK.json")==final
for n,item in artifacts.items():assert sha(AREA/n)==item["sha256"] and (AREA/n).read_bytes()
print("PACKING1_TRANSACTION_READY BMR=3xexit0 independent_actual_sh_rollback=PASS raw_RTR_PRR_INPUT_HASHES=both_verified baseline6611=-.005 modified6621=+.043 modified_still_packing1=PASS artifacts=reopened PDS_restarted=0 exit=0")

add_design {D:/AAAFPGA/ZGTC_RISC_CPU/pds_minimal_blink_200h/pacerv_h3_optimization/work/sg30-ram-memory-range-lut1-s2/implementation/netlist.v}
add_constraint {D:/AAAFPGA/ZGTC_RISC_CPU/pds_minimal_blink_200h/pacerv_h3_optimization/work/sg30-ram-memory-range-lut1-s2/inputs/constraints/board.fdc}
add_constraint {D:/AAAFPGA/ZGTC_RISC_CPU/pds_minimal_blink_200h/pacerv_h3_optimization/work/sg30-ram-memory-range-lut1-s2/inputs/constraints/uart_board.fdc}
set_arch -family Logos2 -device PG2L200H -speedgrade -6 -package FBB676
compile -system_verilog -top_module pds_soc_top
dev_map -input_db_file {D:/AAAFPGA/ZGTC_RISC_CPU/pds_minimal_blink_200h/pacerv_h3_optimization/work/sg30-ram-memory-range-lut1-s2/implementation/source.adf}
pnr -dc_duplication false -plc_decongestion 0 -gplace_seed 2 -logic_optimize_lut6d_combing_strategy 1
report_timing
gen_bit_stream

﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $target = [System.IO.Path]::GetFullPath($TargetPath)
    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)
    if ($target -eq $baseline) { throw 'Use an independent target copy' }
    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '59A6B16C1E10F6C911B444F1CA9951EB8E4CAF0E4092050D85643E534ECB8F0F') { throw 'Baseline hash mismatch' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($hash -ne '59A6B16C1E10F6C911B444F1CA9951EB8E4CAF0E4092050D85643E534ECB8F0F') { throw 'Restore hash mismatch' }
    Write-Output ('PACKING1_ROLLBACK_TCL_PASS SHA256=' + $hash)
    exit 0
} catch { Write-Error $_; exit 1 }

﻿[CmdletBinding()]
param(
    [string]$ReleaseRoot,
    [ValidateSet('V0','V1')][string]$Role = 'V0',
    [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$OutputDirectory,
    [string]$PdsRoot = $env:PDS_ROOT,
    [ValidateSet('LocalBoard','RemoteLab')][string]$UartPins = 'LocalBoard',
    [ValidateRange(1,999)][int]$Seed = 1,
    [ValidateSet(0,1)][int]$PlcDecongestion = 0,
    [ValidateRange(0,3)][int]$LutCombineStrategy = 3,
    [string]$FirmwareHex,
    [string]$CoreOverride,
    [string]$BtbOverride,
    [string]$RtlDirectory,
    [string]$ReuseSynthesisBuild,
    [switch]$PrepareOnly,
    [switch]$SynthesisOnly,
    [switch]$ResumeImplementation
)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Write-JsonFile {
    param([Parameter(Mandatory)]$Value,[Parameter(Mandatory)][string]$Path)
    [IO.File]::WriteAllText($Path,(ConvertTo-Json -InputObject $Value -Depth 30)+[Environment]::NewLine,[Text.UTF8Encoding]::new($true))
}

function ConvertTo-TclPath {
    param([Parameter(Mandatory)][string]$Path)
    if ($Path.IndexOfAny([char[]]@([char]123,[char]125,[char]10,[char]13)) -ge 0) { throw 'Tcl-incompatible path characters.' }
    return '{'+$Path.Replace([char]92,[char]47)+'}'
}

function Get-Inventory {
    param([Parameter(Mandatory)][string]$Root)
    return @(Get-ChildItem -LiteralPath $Root -File -Recurse | Sort-Object FullName | ForEach-Object {
        [ordered]@{RelativePath=[IO.Path]::GetRelativePath($Root,$_.FullName).Replace([char]92,[char]47);SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash;Bytes=$_.Length}
    })
}

function Assert-Inventory {
    param([Parameter(Mandatory)][string]$BuildRoot)
    $inventory=Get-Content -LiteralPath ([IO.Path]::Combine($BuildRoot,'INPUT_HASHES.json')) -Raw -Encoding utf8 | ConvertFrom-Json
    foreach ($item in $inventory) {
        $path=[IO.Path]::Combine($BuildRoot,'inputs',$item.RelativePath)
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $item.SHA256) { throw ('Frozen physical input changed: '+$item.RelativePath) }
    }
}

function Invoke-PdsStage {
    param([Parameter(Mandatory)][string]$StageDirectory,[Parameter(Mandatory)][string]$Name)
    $tcl=[IO.Path]::Combine($StageDirectory,'build.tcl')
    $argv=@('-file',$tcl,'-work_dir',$StageDirectory,'-project_name','pace145')
    $receipt=[ordered]@{Executable=$script:pdsShell;Argv=$argv;WorkingDirectory=$StageDirectory;StartedUtc=[DateTime]::UtcNow.ToString('o');Pid=$null;ExitStatus=$null;FinishedUtc=$null}
    $receiptPath=[IO.Path]::Combine($StageDirectory,'INVOCATION.json')
    Write-JsonFile $receipt $receiptPath
    $info=[Diagnostics.ProcessStartInfo]::new()
    $info.FileName=$script:pdsShell
    $info.WorkingDirectory=$StageDirectory
    $info.UseShellExecute=$false
    $info.CreateNoWindow=$true
    $info.RedirectStandardOutput=$true
    $info.RedirectStandardError=$true
    foreach ($argument in $argv) { [void]$info.ArgumentList.Add($argument) }
    $process=[Diagnostics.Process]::new()
    $process.StartInfo=$info
    if (-not $process.Start()) { throw ('PDS '+$Name+' did not start.') }
    $receipt.Pid=$process.Id
    Write-JsonFile $receipt $receiptPath
    $outTask=$process.StandardOutput.ReadToEndAsync()
    $errTask=$process.StandardError.ReadToEndAsync()
    Write-Output ('PDS '+$Name+' PID='+$process.Id+' directory='+$StageDirectory)
    $process.WaitForExit()
    $out=$outTask.GetAwaiter().GetResult()
    $err=$errTask.GetAwaiter().GetResult()
    [IO.File]::WriteAllText([IO.Path]::Combine($StageDirectory,'console.stdout.log'),$out,[Text.UTF8Encoding]::new($true))
    [IO.File]::WriteAllText([IO.Path]::Combine($StageDirectory,'console.stderr.log'),$err,[Text.UTF8Encoding]::new($true))
    $receipt.ExitStatus=$process.ExitCode
    $receipt.FinishedUtc=[DateTime]::UtcNow.ToString('o')
    Write-JsonFile $receipt $receiptPath
    $process.Dispose()
    if ($receipt.ExitStatus -ne 0 -or ($out+[Environment]::NewLine+$err) -match '(?m)^\s*(E:|Error:)') { throw ('PDS '+$Name+' failed; inspect '+$StageDirectory) }
}

function Read-TimingSummary {
    param([Parameter(Mandatory)][string]$Path)
    $text=[IO.File]::ReadAllText($Path)
    $checks=[ordered]@{}
    $passing=$text -match 'Design Summary\s*:\s*All Constraints Met\.'
    foreach ($corner in @('Slow','Fast')) {
        foreach ($kind in @('Setup','Hold','Recovery','Removal','Minimum Pulse Width')) {
            $pattern=[regex]::Escape($kind+' Summary('+$corner+' Corner):')+'(?<body>.*?)(?=\r?\n=+)'
            $section=[regex]::Match($text,$pattern,[Text.RegularExpressions.RegexOptions]::Singleline)
            if (-not $section.Success) { throw ('Missing timing section '+$kind+'/'+$corner) }
            $rows=[regex]::Matches($section.Groups['body'].Value,'(?m)^\s*(?<clocks>.*?)\s+(?<slack>[+-]?\d+\.\d+)\s+(?<total>[+-]?\d+\.\d+)\s+(?<failing>\d+)\s+(?<endpoints>\d+)\s*$')
            if ($rows.Count -eq 0) { throw ('No timing endpoints '+$kind+'/'+$corner) }
            $values=@()
            foreach ($row in $rows) {
                $slack=[double]::Parse($row.Groups['slack'].Value,[Globalization.CultureInfo]::InvariantCulture)
                $failing=[int]$row.Groups['failing'].Value
                if ($slack -lt 0 -or $failing -gt 0) { $passing=$false }
                $values += [ordered]@{Clocks=$row.Groups['clocks'].Value.Trim();WorstSlackNs=$slack;TotalNegativeSlackNs=[double]::Parse($row.Groups['total'].Value,[Globalization.CultureInfo]::InvariantCulture);FailingEndpoints=$failing;TotalEndpoints=[int]$row.Groups['endpoints'].Value}
            }
            $checks[$kind+'_'+$corner]=@($values)
        }
    }
    $uncertainties=@([regex]::Matches($text,'clock uncertainty\s+(-?\d+\.\d+)') | ForEach-Object { [double]::Parse($_.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture) })
    if (@($uncertainties | Where-Object {[Math]::Abs($_+0.150) -lt 0.00001}).Count -eq 0) { throw 'The required 0.150 ns setup uncertainty is absent.' }
    $clocks=@($text -split '\r?\n' | Where-Object {$_ -match 'CLKOUT0_Inferred\s+6\.8900|145\.1379 MHz'})
    if ($clocks.Count -lt 2) { throw 'The 145.125 MHz generated clock evidence is absent.' }
    return [ordered]@{AllReportedChecksPass=$passing;ConfiguredCpuClockHz=145125000;SetupUncertaintyNs=0.150;Checks=$checks;ClockEvidence=$clocks;ReportSHA256=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash;ConstraintScope='All reported internal/generated-clock checks. Asynchronous inputs and unspecified external UART/LED timing retain the baseline constraints.'}
}

function Complete-PhysicalResult {
    param([Parameter(Mandatory)][string]$BuildRoot,[Parameter(Mandatory)]$Manifest)
    Assert-Inventory $BuildRoot
    $implementation=[IO.Path]::Combine($BuildRoot,'implementation')
    $Manifest.Timing=Read-TimingSummary ([IO.Path]::Combine($implementation,'report_timing','pds_soc_top.rtr'))
    Write-JsonFile $Manifest.Timing ([IO.Path]::Combine($BuildRoot,'TIMING_SUMMARY.json'))
    $routeLog=[IO.File]::ReadAllText([IO.Path]::Combine($implementation,'place_route','run.log'))
    $resources=[ordered]@{LUT=0;FF=0;DRM36K=0;APM=0;GPLL=0;RawRows=@($routeLog -split '\r?\n' | Where-Object {$_ -match '^\|\s*(FF|LUT|Use of (APM|DRM|GPLL))\s*\|'})}
    foreach ($row in [regex]::Matches($routeLog,'(?m)^\|\s*(?<resource>FF|LUT|Use of APM|Use of DRM|Use of GPLL)\s*\|\s*(?<used>\d+)\s*\|')) {
        $key=switch ($row.Groups['resource'].Value) {'Use of APM' {'APM'} 'Use of DRM' {'DRM36K'} 'Use of GPLL' {'GPLL'} default {$row.Groups['resource'].Value}}
        $resources[$key]+=[int]$row.Groups['used'].Value
    }
    $Manifest.Resources=$resources
    $bitstream=[IO.Path]::Combine($implementation,'generate_bitstream','pds_soc_top.sbit')
    $Manifest.Bitstream=[ordered]@{Path=$bitstream;SHA256=(Get-FileHash -LiteralPath $bitstream -Algorithm SHA256).Hash;Bytes=(Get-Item -LiteralPath $bitstream).Length}
    $Manifest.Status=if ($Manifest.Timing.AllReportedChecksPass) {'completed_timing_pass'} else {'completed_timing_fail'}
    $Manifest.FinishedUtc=[DateTime]::UtcNow.ToString('o')
    Write-JsonFile $Manifest ([IO.Path]::Combine($BuildRoot,'BUILD_RESULT.json'))
    Write-Output ('PDS result: '+$Manifest.Status)
    Write-Output ('Bitstream: '+$bitstream)
    Write-Output ('SHA-256: '+$Manifest.Bitstream.SHA256)
    Write-Output ('Slow setup WNS ns: '+$Manifest.Timing.Checks.Setup_Slow[0].WorstSlackNs)
}

$manifest=$null
$manifestPath=$null
try {
    if ([string]::IsNullOrWhiteSpace($ReleaseRoot)) {$ReleaseRoot=[IO.Path]::Combine($PSScriptRoot,'..')}
    $releasePath=[IO.Path]::GetFullPath($ReleaseRoot)
    $buildRoot=[IO.Path]::GetFullPath($OutputDirectory)
    [void](ConvertTo-TclPath $buildRoot)
    if ($buildRoot -eq $releasePath) {throw 'Output directory must be separate from the release root.'}
    foreach ($protected in @('source','physical','firmware','simulation','evidence','bitstreams')) {
        $protectedPath=[IO.Path]::Combine($releasePath,$protected)
        if ($buildRoot -eq $protectedPath -or $buildRoot.StartsWith($protectedPath+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {throw ('Output directory overlaps frozen '+$protected)}
    }
    if ([string]::IsNullOrWhiteSpace($PdsRoot)) {$PdsRoot=[IO.Path]::Combine('D:/','PDS_2022.2-SP6.4')}
    $script:pdsShell=[IO.Path]::Combine([IO.Path]::GetFullPath($PdsRoot),'bin','pds_shell.exe')
    if (-not $PrepareOnly -and -not (Test-Path -LiteralPath $script:pdsShell -PathType Leaf)) {throw ('PDS shell missing: '+$script:pdsShell)}
    if ($ResumeImplementation) {
        $manifestPath=[IO.Path]::Combine($buildRoot,'BUILD_RESULT.json')
        $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
        if ($manifest.Status -ne 'synthesized') {throw 'ResumeImplementation requires exactly synthesized status.'}
        Assert-Inventory $buildRoot
    } else {
        if (Test-Path -LiteralPath $buildRoot) {throw 'Use a new output directory for each physical build.'}
        if (-not [string]::IsNullOrWhiteSpace($ReuseSynthesisBuild)) {
            if ($FirmwareHex -or $CoreOverride -or $BtbOverride -or $RtlDirectory) {throw 'Synthesis reuse accepts the exact frozen inputs only.'}
            $reuseRoot=[IO.Path]::GetFullPath($ReuseSynthesisBuild)
            Assert-Inventory $reuseRoot
            $manifest=Get-Content -LiteralPath ([IO.Path]::Combine($reuseRoot,'BUILD_RESULT.json')) -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
            if ($manifest.Status -notin @('synthesized','completed_timing_fail','completed_timing_pass')) {throw 'ReuseSynthesisBuild requires completed synthesis.'}
            if ($manifest.UartPins -ne $UartPins) {throw 'Synthesis reuse must keep the frozen UART pin mapping.'}
            [void](New-Item -ItemType Directory -Path $buildRoot)
            Copy-Item -LiteralPath ([IO.Path]::Combine($reuseRoot,'inputs')) -Destination ([IO.Path]::Combine($buildRoot,'inputs')) -Recurse
            Copy-Item -LiteralPath ([IO.Path]::Combine($reuseRoot,'INPUT_HASHES.json')) -Destination ([IO.Path]::Combine($buildRoot,'INPUT_HASHES.json'))
            $implementation=[IO.Path]::Combine($buildRoot,'implementation')
            [void](New-Item -ItemType Directory -Path $implementation)
            foreach ($leaf in @('netlist.v','source.adf')) {Copy-Item -LiteralPath ([IO.Path]::Combine($reuseRoot,'implementation',$leaf)) -Destination ([IO.Path]::Combine($implementation,$leaf))}
            $manifest.ReusedSynthesis=[ordered]@{BuildRoot=$reuseRoot;NetlistSHA256=(Get-FileHash -LiteralPath ([IO.Path]::Combine($implementation,'netlist.v')) -Algorithm SHA256).Hash;DatabaseSHA256=(Get-FileHash -LiteralPath ([IO.Path]::Combine($implementation,'source.adf')) -Algorithm SHA256).Hash}
            $manifest.Status='synthesized'
        } else {
            $recipePath=[IO.Path]::Combine($releasePath,'recipe.json')
            $recipe=Get-Content -LiteralPath $recipePath -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
            if ($recipe.clock_hz -ne 145125000) {throw 'This flow requires the 145.125 MHz recipe.'}
            $image=$recipe.roles[$Role]
            $frozenInputs=[IO.Path]::Combine($releasePath,$image.physical_inputs)
            $inputRoot=[IO.Path]::Combine($buildRoot,'inputs')
            [void](New-Item -ItemType Directory -Path $buildRoot)
            Copy-Item -LiteralPath $frozenInputs -Destination $inputRoot -Recurse
            $firmware=[IO.Path]::Combine($inputRoot,'firmware.hex')
            if ((Get-FileHash -LiteralPath $firmware -Algorithm SHA256).Hash.ToLowerInvariant() -ne $image.firmware_sha256.ToLowerInvariant()) {throw 'Frozen baseline firmware hash mismatch.'}
            if ($FirmwareHex) {
                $FirmwareHex=[IO.Path]::GetFullPath($FirmwareHex)
                $hexLines=@(Get-Content -LiteralPath $FirmwareHex -Encoding utf8)
                if ($hexLines.Count -ne 16384 -or @($hexLines | Where-Object {$_ -notmatch '^[0-9A-Fa-f]{8}$'}).Count -gt 0) {throw 'Firmware must contain exactly 16384 hexadecimal 32-bit words.'}
                Copy-Item -LiteralPath $FirmwareHex -Destination $firmware -Force
            }
            $rtl=[IO.Path]::Combine($inputRoot,'rtl')
            if ($RtlDirectory) {
                $RtlDirectory=[IO.Path]::GetFullPath($RtlDirectory)
                foreach ($baselineFile in @(Get-ChildItem -LiteralPath $rtl -File -Filter '*.sv')) {
                    $replacement=[IO.Path]::Combine($RtlDirectory,$baselineFile.Name)
                    if (-not (Test-Path -LiteralPath $replacement -PathType Leaf)) {throw ('Candidate RTL is incomplete: '+$baselineFile.Name)}
                    Copy-Item -LiteralPath $replacement -Destination $baselineFile.FullName -Force
                }
            }
            if ($CoreOverride) {
                $CoreOverride=[IO.Path]::GetFullPath($CoreOverride)
                if (-not (Test-Path -LiteralPath $CoreOverride -PathType Leaf)) {throw 'CoreOverride file missing.'}
                Copy-Item -LiteralPath $CoreOverride -Destination ([IO.Path]::Combine($rtl,'rv32_core.sv')) -Force
            }
            if ($BtbOverride) {
                $BtbOverride=[IO.Path]::GetFullPath($BtbOverride)
                if (-not (Test-Path -LiteralPath $BtbOverride -PathType Leaf)) {throw 'BtbOverride file missing.'}
                Copy-Item -LiteralPath $BtbOverride -Destination ([IO.Path]::Combine($rtl,'rv32_btb.sv')) -Force
            }
            $topPath=[IO.Path]::Combine($inputRoot,'pds_soc_top.v')
            $top=Get-Content -LiteralPath $topPath -Raw -Encoding utf8
            $bindings=[regex]::Matches($top,'\.INIT_FILE\("[^"]+"\)')
            if ($bindings.Count -ne 1) {throw 'Expected exactly one physical firmware binding.'}
            $top=$top.Replace($bindings[0].Value,'.INIT_FILE("'+$firmware.Replace([char]92,[char]47)+'")')
            [IO.File]::WriteAllText($topPath,$top,[Text.UTF8Encoding]::new($false))
            $synthesis=[IO.Path]::Combine($buildRoot,'synthesis')
            $implementation=[IO.Path]::Combine($buildRoot,'implementation')
            [void](New-Item -ItemType Directory -Path $synthesis,$implementation)
            $designs=@((Get-ChildItem -LiteralPath $rtl -Filter '*.sv' -File | Sort-Object Name).FullName)
            $designs+=@($topPath,[IO.Path]::Combine($inputRoot,'fpga','rv32_pll.sv'))
            $board=[IO.Path]::Combine($inputRoot,'constraints','board.fdc')
            $uartLeaf=if ($UartPins -eq 'LocalBoard') {'uart_board.fdc'} else {'uart_remotelab.fdc'}
            $uart=[IO.Path]::Combine($inputRoot,'constraints',$uartLeaf)
            $synLines=@($designs | ForEach-Object {'add_design '+(ConvertTo-TclPath $_)})
            $synLines+=@(('add_constraint '+(ConvertTo-TclPath $board)),('add_constraint '+(ConvertTo-TclPath $uart)),'set_arch -family Logos2 -device PG2L200H -speedgrade -6 -package FBB676','compile -system_verilog -top_module pds_soc_top','synthesize -ads -selected_syn_tool_opt 2')
            [IO.File]::WriteAllText([IO.Path]::Combine($synthesis,'build.tcl'),($synLines -join [Environment]::NewLine)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
            Write-JsonFile (Get-Inventory $inputRoot) ([IO.Path]::Combine($buildRoot,'INPUT_HASHES.json'))
            $manifest=[ordered]@{Schema='pacerv-h3-pds/v1';Status='prepared';ReleaseRoot=$releasePath;Role=$Role;BuildRoot=$buildRoot;Device='PG2L200H-6FBB676';ConfiguredCpuClockHz=145125000;ReferenceClockHz=27000000;SetupUncertaintyNs=0.150;UartPins=$UartPins;UartTxPin=if ($UartPins -eq 'LocalBoard') {'C24'} else {'AB26'};RecipeSHA256=(Get-FileHash -LiteralPath $recipePath -Algorithm SHA256).Hash;ParentFirmwareSHA256=$image.firmware_sha256;FirmwareSource=$FirmwareHex;FirmwareSHA256=(Get-FileHash -LiteralPath $firmware -Algorithm SHA256).Hash;CoreOverrideSource=$CoreOverride;BtbOverrideSource=$BtbOverride;RtlDirectorySource=$RtlDirectory;Seed=$Seed;PnrOptions=$null;StartedUtc=[DateTime]::UtcNow.ToString('o');FinishedUtc=$null;Timing=$null;Resources=$null;Bitstream=$null;Error=$null}
        }
        $manifest.BuildRoot=$buildRoot
        $manifest.Seed=$Seed
        $manifest.PnrOptions='-dc_duplication false -plc_decongestion '+$PlcDecongestion+' -gplace_seed '+$Seed+' -logic_optimize_lut6d_combing_strategy '+$LutCombineStrategy
        $manifest.Timing=$null
        $manifest.Resources=$null
        $manifest.Bitstream=$null
        $manifest.Error=$null
        $manifest.StartedUtc=[DateTime]::UtcNow.ToString('o')
        $manifest.FinishedUtc=$null
        $inputRoot=[IO.Path]::Combine($buildRoot,'inputs')
        $implementation=[IO.Path]::Combine($buildRoot,'implementation')
        $board=[IO.Path]::Combine($inputRoot,'constraints','board.fdc')
        $uartLeaf=if ($UartPins -eq 'LocalBoard') {'uart_board.fdc'} else {'uart_remotelab.fdc'}
        $uart=[IO.Path]::Combine($inputRoot,'constraints',$uartLeaf)
        $implLines=@(('add_design '+(ConvertTo-TclPath ([IO.Path]::Combine($implementation,'netlist.v')))),('add_constraint '+(ConvertTo-TclPath $board)),('add_constraint '+(ConvertTo-TclPath $uart)),'set_arch -family Logos2 -device PG2L200H -speedgrade -6 -package FBB676','compile -system_verilog -top_module pds_soc_top',('dev_map -input_db_file '+(ConvertTo-TclPath ([IO.Path]::Combine($implementation,'source.adf')))),('pnr '+$manifest.PnrOptions),'report_timing','gen_bit_stream')
        [IO.File]::WriteAllText([IO.Path]::Combine($implementation,'build.tcl'),($implLines -join [Environment]::NewLine)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
        Copy-Item -LiteralPath $PSCommandPath -Destination ([IO.Path]::Combine($buildRoot,'Build-PacePds.snapshot.ps1'))
        $manifestPath=[IO.Path]::Combine($buildRoot,'BUILD_RESULT.json')
        Write-JsonFile $manifest $manifestPath
        if ($PrepareOnly) {Write-Output ('Prepared '+$Role+' at '+$buildRoot); exit 0}
    }
    if ([string]::IsNullOrWhiteSpace($env:PANGO_LICENSE_FILE)) {$env:PANGO_LICENSE_FILE=[Environment]::GetEnvironmentVariable('PANGO_LICENSE_FILE','User')}
    if ([string]::IsNullOrWhiteSpace($env:PANGO_LICENSE_FILE)) {throw 'PANGO_LICENSE_FILE is not configured.'}
    if ($manifest.Status -eq 'prepared') {
        Assert-Inventory $buildRoot
        $manifest.Status='synthesis_running'
        Write-JsonFile $manifest $manifestPath
        Invoke-PdsStage ([IO.Path]::Combine($buildRoot,'synthesis')) 'synthesis'
        Copy-Item -LiteralPath ([IO.Path]::Combine($buildRoot,'synthesis','synthesize','pds_soc_top_syn.vm')) -Destination ([IO.Path]::Combine($buildRoot,'implementation','netlist.v'))
        Copy-Item -LiteralPath ([IO.Path]::Combine($buildRoot,'synthesis','synthesize','pds_soc_top_syn.adf')) -Destination ([IO.Path]::Combine($buildRoot,'implementation','source.adf'))
        $manifest.Status='synthesized'
        Write-JsonFile $manifest $manifestPath
    }
    if ($SynthesisOnly) {Write-Output ('Synthesis complete: '+$buildRoot); exit 0}
    Assert-Inventory $buildRoot
    $manifest.Status='implementation_running'
    Write-JsonFile $manifest $manifestPath
    Invoke-PdsStage ([IO.Path]::Combine($buildRoot,'implementation')) 'implementation'
    Complete-PhysicalResult $buildRoot $manifest
    exit 0
} catch {
    if ($null -ne $manifest -and $null -ne $manifestPath) {
        $manifest.Status='failed'
        $manifest.Error=$_.Exception.Message
        $manifest.FinishedUtc=[DateTime]::UtcNow.ToString('o')
        Write-JsonFile $manifest $manifestPath
    }
    Write-Error $_
    exit 1
}

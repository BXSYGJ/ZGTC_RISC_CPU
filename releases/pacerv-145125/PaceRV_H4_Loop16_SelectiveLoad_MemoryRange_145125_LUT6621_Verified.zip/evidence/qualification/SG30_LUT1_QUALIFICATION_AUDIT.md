﻿# SG30 packing1 independent qualification

PASS_FULL_QUALIFICATION_ACTUAL6000_AND_ALL10_PHYSICAL_CHECKS

Actual physical result: **6621LUT /2557FF /25DRM36K /4APM /1GPLL**,145.125MHz,.150ns setupuncertainty. All10rawRTRcategories pass; slowsetup **+.043ns**,TNS0,0failing endpoints.

All35source entries (17simulation+18physical) match the frozen sourcechain. Allphysical input bytes and the reused netlist/ADF match SG30s2; all3FDC files andPLL bytes match qualifiedH4. Afterpath normalization the only implementationTCL change is packing3to1.

| Actual6000 | Cycles | Retired | CoreMark/MHz | Duration s |
|---|---:|---:|---:|---:|
| V0 | 1712559880 | 1634152429 | 3.503527129223651 | 11.800584875108 |
| V1 | 1713586192 | 1634361529 | 3.501428774351375 | 11.807656792420 |

BothrawUARTCRCs/counters and independentobserver match RUNreceipts. Exactcycles/retired/scores equal qualifiedH4. FirmwareV0 matches941041...physical image; bothroles are actual6000 naturalexit0 and duration>10seconds.

BitstreamSHA256: `381a005b52f37eb7411bb46e98dc06b4ea1525ab4a2a21117f3fcde35836449b` (9188552bytes).

Saves191LUT and256FF versus H4; H4archive preserved. Newload_equal_bytes source is excluded from this qualification.

Root may create a new strictly qualified selection/archive for exact8af95f/13aa/C9/210b source and SG30-lut1-s2 physical build. cabd1c load_equal_bytes is an independent unqualified backup and is excluded.

"""Read-only independent full qualification of actual SG30 packing1 implementation."""
from pathlib import Path
from datetime import datetime,timezone
import ast
import hashlib
import json
import re

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
work=ROOT/"work/sg30-ram-memory-range-lut1-s2"
oldwork=ROOT/"work/sg30-ram-memory-range-s2"
h4work=ROOT/"work/sg21-loop16-h4-s2"
proposal=ROOT/"rtl_proposals/loop16_h4_ram_memory_range"
longs=ROOT/"rtl_proposals/loop16_h4_ram_memory_range_longs"
candidate=ROOT/"candidates/loop16_h4_ram_memory_range"
frozen={str(p):sha(p) for base in [proposal,longs] for n in ["MODIFIED_FILE.sv","DIFF_FILE.diff","VERIFICATION.txt","ROLLBACK.sh","FINAL_RECHECK.json","SOURCE_CHANGE.json","SOURCE_VERIFICATION.txt","SOURCE_FINAL_RECHECK.json","LONG_FINAL_AUDIT.json"] if (p:=base/n).exists()}
manifest=read(work/"BUILD_RESULT.json")
old=read(oldwork/"BUILD_RESULT.json")
h4=read(h4work/"BUILD_RESULT.json")
assert manifest["Status"]=="completed_timing_pass" and manifest["Error"] is None
assert all(m["ConfiguredCpuClockHz"]==145125000 and m["SetupUncertaintyNs"]==0.15 and m["Device"]=="PG2L200H-6FBB676" for m in [manifest,old,h4])
assert manifest["Role"]=="V0" and manifest["Seed"]==2
# Parse every raw timing category; use only the existing pure parser functions.
parser=ROOT/"scripts/closure-packaging-loop16-h4/closure_proofs_h4.py"
tree=ast.parse(parser.read_text(encoding="utf-8-sig"))
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ["require","parse_timing_report"]]
assert len(functions)==2
exec(compile(ast.Module(body=functions,type_ignores=[]),str(parser),"exec"))
rtr=work/"implementation/report_timing/pds_soc_top.rtr"
raw=rtr.read_bytes()
checks=parse_timing_report(raw)
assert len(checks)==10 and checks==manifest["Timing"]["Checks"]
assert all(rows and all(r["WorstSlackNs"]>=0 and r["TotalNegativeSlackNs"]==0 and r["FailingEndpoints"]==0 and r["TotalEndpoints"]>0 for r in rows) for rows in checks.values())
assert manifest["Timing"]["AllReportedChecksPass"] and sha(rtr)==manifest["Timing"]["ReportSHA256"].lower()
assert checks["Setup_Slow"][0]["WorstSlackNs"]==0.043
prr=work/"implementation/place_route/pds_soc_top.prr"
prrtext=prr.read_text(encoding="utf-8-sig")
counts={k:sum(int(v) for v in re.findall(r"\|\s+"+re.escape(k)+r"\s+\|\s*(\d+)\s*\|",prrtext)) for k in ["LUT","FF"]}
for label,key in [("DRM","DRM36K"),("APM","APM"),("GPLL","GPLL")]:counts[key]=int(re.search(r"\| Use of "+label+r"\s+\|\s*(\d+)",prrtext)[1])
assert counts=={k:manifest["Resources"][k] for k in ["LUT","FF","DRM36K","APM","GPLL"]}==dict(LUT=6621,FF=2557,DRM36K=25,APM=4,GPLL=1)
# Every input byte matches the original SG30-s2, including its full constraints and firmware.
input_hashes={p.relative_to(work/"inputs").as_posix():sha(p) for p in sorted((work/"inputs").rglob("*")) if p.is_file()}
old_input_hashes={p.relative_to(oldwork/"inputs").as_posix():sha(p) for p in sorted((oldwork/"inputs").rglob("*")) if p.is_file()}
assert input_hashes==old_input_hashes
constraints={}
for p in sorted((work/"inputs/constraints").glob("*.fdc")):
    assert p.read_bytes()==(oldwork/"inputs/constraints"/p.name).read_bytes()==(h4work/"inputs/constraints"/p.name).read_bytes()
    constraints[p.name]=dict(sha256=sha(p),bytes=p.stat().st_size,exact_match_SG30s2=True,exact_match_qualifiedH4=True)
assert len(constraints)==3
assert (work/"inputs/fpga/rv32_pll.sv").read_bytes()==(h4work/"inputs/fpga/rv32_pll.sv").read_bytes()
wrapper=(work/"inputs/pds_soc_top.v").read_text()
assert ".CLOCK_HZ(145125000)" in wrapper and ".LOAD_USE_BUBBLE(1)" in wrapper and ".ENABLE_PREDICTOR(1)" in wrapper
assert sha(work/"implementation/netlist.v")==sha(oldwork/"implementation/netlist.v")==manifest["ReusedSynthesis"]["NetlistSHA256"].lower()
assert sha(work/"implementation/source.adf")==sha(oldwork/"implementation/source.adf")==manifest["ReusedSynthesis"]["DatabaseSHA256"].lower()
def normalized_tcl(base):return (base/"implementation/build.tcl").read_text().replace(chr(92),"/").replace(base.as_posix()+"/","{BUILD}/")
old_tcl=normalized_tcl(oldwork)
new_tcl=normalized_tcl(work)
assert old_tcl.count("-logic_optimize_lut6d_combing_strategy 3")==1
assert old_tcl.replace("-logic_optimize_lut6d_combing_strategy 3","-logic_optimize_lut6d_combing_strategy 1",1)==new_tcl
assert manifest["PnrOptions"]==old["PnrOptions"].replace("-logic_optimize_lut6d_combing_strategy 3","-logic_optimize_lut6d_combing_strategy 1")
change=read(proposal/"CHANGE.json")
launch=read(longs/"SOURCE_CHANGE.json")
final=read(proposal/"FINAL_RECHECK.json")
assert final["core_BMR23_full_equal"] and final["architecture_lines"]==591 and final["production_source_SAT"] and final["negative_controls_rejected"]==2
source_inventory={}
for mode,n in [("rtl",17),("physical_rtl",18)]:
    files={p.name:sha(p) for p in sorted((candidate/mode).glob("*.sv"))}
    assert len(files)==n and files==change[mode]==launch[mode]
    source_inventory[mode]=files
actual_physical={p.name:sha(p) for p in sorted((work/"inputs/rtl").glob("*.sv"))}
assert actual_physical==source_inventory["physical_rtl"]
for n,h in source_inventory["rtl"].items():assert actual_physical[n]==h
assert actual_physical["rv32_core.sv"]=="8af95f92009be4979e23fa0bee77eff3bc6858357173470a0bdf7db75326c416"
assert actual_physical["rv32_btb.sv"]=="13aa9b1196adc482149b3414f62d752e787ded7a9b0bf06438b28e9be8a563c8"
# Reconstruct the exact simulator-source identity, including vendor/testbench inputs and mode.
recipe=read(ROOT/"recipe.json")["simulation"]["argv"]
files=[candidate/"rtl"/Path(x).name for x in recipe if "/simulation/inputs/rtl/" in x]
files += [ROOT/x.split("{RELEASE}/")[1] for x in recipe if "/simulation/inputs/sim/" in x]
identity_hash=hashlib.sha256()
for p in files:identity_hash.update(p.name.encode());identity_hash.update(p.read_bytes())
identity_hash.update(b"1")
identity=identity_hash.hexdigest()
assert identity=="5bfd35fb3ce5591c17d5b0f5a020662b3d4a7152b83cff437c7010a5f3be1778"
audit=read(longs/"LONG_FINAL_AUDIT.json")
assert audit["status"]=="PASS_BOTH_ACTUAL6000_GT3P5" and audit["pending"]==[]
long_results=[]
for role in ["V0","V1"]:
    base=ROOT/"work"/("sg30-ram-memory-range-i6000-"+role)
    record=read(longs/("LONG_"+role+"_RESULT.json"))
    run=read(base/"RUN.json")
    build=read(base/"BUILD.json")
    process=read(base/"PROCESS.json")
    uart=(base/"uart.log").read_text(encoding="utf-8-sig")
    stdout=(base/"simulation.log").read_text(encoding="utf-8-sig")
    assert record["run"]==run and run["firmware"]==build and run["stdout"]==stdout
    assert process["status"]=="COMPLETED" and process["native_exit_status"]==run["exit_status"]==0
    assert all(run["checks"].values()) and run["error_lines"]==[] and run["formal_ten_seconds"]
    assert run["rtl_sha256"]==identity and run["load_use_bubble"]==1
    assert build["role"]==role and build["iterations"]==6000
    assert "-DCPU_CLOCK_HZ=145125000u" in build["command"] and "-DITERATIONS=6000" in build["command"]
    firmware_hash=sha(base/"firmware.hex")
    assert firmware_hash==build["firmware_hex_sha256"]
    if role=="V0":assert firmware_hash==manifest["FirmwareSHA256"].lower()==sha(work/"inputs/firmware.hex")=="941041b71bd0b8a3075bd3470fdd566605492f3ceb21ba8faea677dd230bc0cf"
    for relative,h in build["source_hashes"].items():assert sha(ROOT/"firmware"/role/"inputs"/relative)==h
    counters=re.search(r"cycles_hex=([0-9a-fA-F]{16}) retired_hex=([0-9a-fA-F]{16}) clock_hz=(\d+)",uart)
    assert counters and int(counters[1],16)==run["timed_cycles"] and int(counters[2],16)==run["retired"] and int(counters[3])==145125000
    observer=re.search(r"OBSERVER cycles=(\d+) retired=(\d+) minimum_sp=(\d+)",stdout)
    assert observer and int(observer[1])==run["timed_cycles"] and int(observer[2])==run["retired"] and int(observer[3])==run["minimum_sp"] and 49152<=run["minimum_sp"]<=65536
    expected={"V0":["0xe714","0x1fd7","0x8e3a","0xa14c"],"V1":["0xe3c1","0x0747","0x8d84","0x18e1"]}[role]
    crcs=re.findall(r"\[0\](?:crc(?:list|matrix|state)|crcfinal)\s*:\s*(0x[0-9a-fA-F]+)",uart)
    assert crcs==expected==run["crc_fields"] and "ZGTC COREMARK FINISHED" in uart
    score=6000000000/run["timed_cycles"]
    duration=run["timed_cycles"]/145125000
    assert score>3.5 and abs(score-run["coremark_per_mhz"])<1e-12 and duration>=10
    reference=read(ROOT/"rtl_proposals/load_simple_loop16_h4"/("LONG_"+role+"_RESULT.json"))["run"]
    assert all(run[k]==reference[k] for k in ["timed_cycles","retired","coremark_per_mhz"])
    long_results.append(dict(role=role,iterations=6000,cycles=run["timed_cycles"],retired=run["retired"],score=score,duration_seconds=duration,
        CRCs=crcs,raw_observer_matches_UART=True,exact_cycles_retired_score_equal_H4=True,firmware_sha256=firmware_hash,
        artifact_sha256={n:sha(base/n) for n in ["RUN.json","BUILD.json","PROCESS.json","uart.log","simulation.log","firmware.hex"]},exit_status=0))
bit=Path(manifest["Bitstream"]["Path"])
assert bit.exists() and sha(bit)==manifest["Bitstream"]["SHA256"].lower() and bit.stat().st_size==manifest["Bitstream"]["Bytes"]==9188552
for p,h in frozen.items():assert sha(Path(p))==h
result=dict(status="PASS_FULL_QUALIFICATION_ACTUAL6000_AND_ALL10_PHYSICAL_CHECKS",checked_utc=datetime.now(timezone.utc).isoformat(),
    build=str(work),manifest_sha256=sha(work/"BUILD_RESULT.json"),resources_from_raw_PRR=counts,PRR=str(prr),PRR_sha256=sha(prr),
    raw_timing_checks=checks,RTR=str(rtr),RTR_sha256=sha(rtr),timing_summary="All10rawcategories nonnegativeWNS,0TNS,0failingendpoints; slowsetup+.043ns.",
    frequency_hz=145125000,setup_uncertainty_ns=0.15,constraints_exact_identity=constraints,PLL_exact_H4=True,
    all_input_files_exact_SG30s2=input_hashes,only_physical_option_changed="logic_optimize_lut6d_combing_strategy3->1; seed2/dcdupfalse/clock/constraints/checkpoint/source/firmware unchanged",
    reused_netlist_sha256=sha(work/"implementation/netlist.v"),reused_ADF_sha256=sha(work/"implementation/source.adf"),
    source_inventory_35=source_inventory,simulation_physical_common17_exact=True,simulation_identity=identity,
    simulation_identity_files={str(p):sha(p) for p in files},actual_long_results=long_results,bitstream=dict(path=str(bit),sha256=sha(bit),bytes=bit.stat().st_size),
    improvement_vs_H4=dict(LUT_saved=6812-counts["LUT"],FF_saved=2813-counts["FF"],LUT_reduction_percent=(6812-counts["LUT"])*100/6812),
    frozen_proof_hashes_unchanged=frozen,source_edits=0,PDS_launches=0,benchmarks_launched=0,package_created=False,
    next="Root may create a new strictly qualified selection/archive for exact8af95f/13aa/C9/210b source and SG30-lut1-s2 physical build. cabd1c load_equal_bytes is an independent unqualified backup and is excluded.",exit_status=0)
(AREA/"SG30_LUT1_QUALIFICATION_AUDIT.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8-sig")
lines=["# SG30 packing1 independent qualification","",result["status"],"",
    "Actual physical result: **6621LUT /2557FF /25DRM36K /4APM /1GPLL**,145.125MHz,.150ns setupuncertainty. All10rawRTRcategories pass; slowsetup **+.043ns**,TNS0,0failing endpoints.","",
    "All35source entries (17simulation+18physical) match the frozen sourcechain. Allphysical input bytes and the reused netlist/ADF match SG30s2; all3FDC files andPLL bytes match qualifiedH4. Afterpath normalization the only implementationTCL change is packing3to1.","",
    "| Actual6000 | Cycles | Retired | CoreMark/MHz | Duration s |","|---|---:|---:|---:|---:|"]
for row in long_results:lines.append(f"| {row['role']} | {row['cycles']} | {row['retired']} | {row['score']:.15f} | {row['duration_seconds']:.12f} |")
lines += ["","BothrawUARTCRCs/counters and independentobserver match RUNreceipts. Exactcycles/retired/scores equal qualifiedH4. FirmwareV0 matches941041...physical image; bothroles are actual6000 naturalexit0 and duration>10seconds.","",
    "BitstreamSHA256: `"+sha(bit)+"` (9188552bytes).","",
    "Saves191LUT and256FF versus H4; H4archive preserved. Newload_equal_bytes source is excluded from this qualification.","",result["next"],""]
(AREA/"SG30_LUT1_QUALIFICATION_AUDIT.md").write_text("\n".join(lines),encoding="utf-8-sig")
assert read(AREA/"SG30_LUT1_QUALIFICATION_AUDIT.json")==result and (AREA/"SG30_LUT1_QUALIFICATION_AUDIT.md").read_bytes()
print("SG30_LUT1_INDEPENDENT_QUALIFICATION_PASS LUT=6621 FF=2557 rawtiming=10/10 slow=+.043ns constraints=exact35source=exact source="+identity+" actual6000=V0/V1>3.5 firmware=941041 bit="+sha(bit)+" savedLUT=191 proofs_unchanged="+str(len(frozen))+" artifacts=reopened exit=0")

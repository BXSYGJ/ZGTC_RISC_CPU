`timescale 1ns/1ps
module range_fourstate_tb;
reg[31:0] trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough;
reg mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken;
wire[1:0] reference_control[0:33],modified_control[0:33];
integer checks=0,i,j,k,b,t,seed=32'h68a32d45;
generate for(genvar B=0;B<34;B=B+1)begin:configs
range_parameter_reference#(B)r(trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken,reference_control[B]);
range_parameter_modified#(B)m(trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken,modified_control[B]);end endgenerate
function automatic four(input integer value);case(value&3)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase endfunction
task step;begin #1;for(b=0;b<34;b=b+1)begin checks=checks+1;if(reference_control[b]!==modified_control[b])begin $display("RANGE_MISMATCH B=%0d fault=%b trap=%h next=%h old=%b new=%b",b,mem_fault,trap_target,mem_next_pc,reference_control[b],modified_control[b]);$fatal(1,"Production range differs");end end end endtask
initial begin mem_flush=1;ex_redirect_candidate=0;early_taken=0;id_zero_taken=0;early_target=0;early_fallthrough=0;id_zero_target=0;id_zero_fallthrough=0;
for(i=0;i<34;i=i+1)begin for(j=0;j<8;j=j+1)begin case(j)0:trap_target=0;1:trap_target=32'hffffffff;2:trap_target=32'h1<<i;3:trap_target=(32'h1<<i)-1;4:trap_target=(32'h1<<i)+1;5:trap_target=32'h80000000;6:trap_target=32'h0001ffff;7:trap_target=32'h00020000;endcase
for(k=0;k<8;k=k+1)begin case(k)0:mem_next_pc=0;1:mem_next_pc=32'hffffffff;2:mem_next_pc=32'h1<<i;3:mem_next_pc=(32'h1<<i)-1;4:mem_next_pc=(32'h1<<i)+1;5:mem_next_pc=32'h80000000;6:mem_next_pc=32'h0001ffff;7:mem_next_pc=32'h00020000;endcase for(t=0;t<4;t=t+1)begin mem_fault=four(t);step;end end end end
for(i=0;i<32;i=i+1)begin for(j=0;j<4;j=j+1)begin for(k=0;k<4;k=k+1)begin trap_target=0;mem_next_pc=0;trap_target[i]=four(j);mem_next_pc[i]=four(k);for(t=0;t<4;t=t+1)begin mem_fault=four(t);step;end end end end
for(i=0;i<10004;i=i+1)begin for(k=0;k<32;k=k+1)begin trap_target[k]=four($random(seed));mem_next_pc[k]=four($random(seed));early_target[k]=four($random(seed));early_fallthrough[k]=four($random(seed));id_zero_target[k]=four($random(seed));id_zero_fallthrough[k]=four($random(seed));end mem_fault=four($random(seed));mem_flush=four($random(seed));ex_redirect_candidate=four($random(seed));early_taken=four($random(seed));id_zero_taken=four($random(seed));step;end
$display("RANGE_FOURSTATE_PASS checks=%0d configurations=34 widths=0..33 production_width=16 complete32bit_inputs fault=0/1/X/Z random=10004",checks);$finish;end
endmodule

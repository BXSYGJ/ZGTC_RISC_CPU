﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $target = [System.IO.Path]::GetFullPath($TargetPath)
    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)
    if ($target -eq $baseline) { throw 'Use an independent target copy' }
    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '9896D2D8177CD69ADDA9A4399839023DAC5A37D2343E5E0E74D117DDF152A411') { throw 'Baseline hash mismatch' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($hash -ne '9896D2D8177CD69ADDA9A4399839023DAC5A37D2343E5E0E74D117DDF152A411') { throw 'Restore hash mismatch' }
    Write-Output ('RAM_MEMORY_RANGE_ROLLBACK_PASS SHA256=' + $hash)
    exit 0
} catch { Write-Error $_; exit 1 }

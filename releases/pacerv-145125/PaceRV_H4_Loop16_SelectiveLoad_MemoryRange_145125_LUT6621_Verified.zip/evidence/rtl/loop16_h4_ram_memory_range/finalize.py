"""Reopen proofs, source overlays, frozen parents, and all four artifacts."""
from pathlib import Path
import hashlib
import json
import re

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
change = read(AREA / "CHANGE.json")
core = read(AREA / "CORE_VERIFICATION.json")
proof = read(AREA / "RANGE_VERIFICATION.json")
rollback = read(AREA / "ROLLBACK_RESULT.json")
assert core["status"] == proof["status"] == "PASS"
assert core["all_three_full_literal_outputs_equal"] and core["architecture_lines"] == 591
assert proof["production_source_extraction"]
assert proof["formal"]["exit_status"] == 0
assert proof["negative_wrong_fault_branch"]["exit_status"] == 1
assert proof["negative_missing_xz_fallback"]["exit_status"] == 1
assert rollback["exit_status"] == 0
assert sha(AREA / "rollback_test.sv") == rollback["restored_sha256"] == change["baseline_sha256"]
assert sha(AREA / "MODIFIED_FILE.sv") == sha(AREA / "rv32_core.sv") == change["modified_sha256"]
original = (AREA / "BASELINE_FILE.sv").read_bytes()
modified = (AREA / "MODIFIED_FILE.sv").read_bytes()
assert modified.replace(change["insertion_after"].encode(), change["insertion_before"].encode(), 1).replace(
    change["branch_after"].encode(), change["branch_before"].encode(), 1) == original
dest = ROOT / "candidates/loop16_h4_ram_memory_range"
for mode, count in [("rtl", 17), ("physical_rtl", 18)]:
    paths = list((dest / mode).glob("*.sv"))
    assert len(paths) == count
    for path in paths:
        assert sha(path) == change[mode][path.name]
        if path.name != "rv32_core.sv":
            assert path.read_bytes() == (ROOT / "candidates/loop16_h4_ram_target_keep" / mode / path.name).read_bytes()
for path in (dest / "rtl").glob("*.sv"):
    assert path.read_bytes() == (dest / "physical_rtl" / path.name).read_bytes()
for relative, expected in change["protected_parents"].items():
    assert sha(ROOT / relative) == expected
frozen = read(ROOT / "EXPERIMENT.json")["BaselineFiles"]
for item in frozen:
    assert sha(ROOT / item["Path"]) == item["SHA256"].lower()
report = ROOT / "work/sg26-ram-target-keep-s2/implementation/report_timing/pds_soc_top.rtr"
paths = []
for block in re.split(r"(?=Startpoint  :)", report.read_text(encoding="utf-8")):
    if "Path Type   : max (slow corner)" not in block:
        continue
    paths.append(block.split("====================================================================================================")[0])
    if len(paths) == 3:
        break
assert len(paths) == 3 and "mem_fault" in paths[0] and "-0.444" in paths[0]
mechanism = dict(report=str(report), report_sha256=sha(report), actual_slow_setup_top3=paths,
    observation="Dcache request_address6 -> tag/hit1 -> memory N27 -> mem_fault fanout23 -> three range-reduction levels -> frontend N256/N332 -> Icache companion address CE; first path9logic levels, logic2.128ns, route4.674ns, total6.802ns, slack-0.444ns",
    change="Move complete source-address range reductions before mem_fault. Keep both scalar results. A known mem_fault selects one bit; X/Z uses exact original full-address ternary/range expression. Full addresses, mem_flush, other redirect branches, state and cycle protocol are byte-identical after inverse.",
    limitations="Top3 public setup paths describe one mechanism, not the entire215 failing endpoint population. Synplify pruning of X/Z fallback and actual kept-scalar mapping require root synthesis inspection; no new timing or LUT result claimed.")
(AREA / "PATH_ANALYSIS.json").write_text(json.dumps(mechanism, indent=2)+"\n", encoding="utf-8-sig")
evidence = dict(status="READY_SOURCE_BOUND_PROOFS_PASS_PHYSICAL_PENDING", changed_field=change["changed_field"],
    MODIFIED_FILE=str(AREA / "MODIFIED_FILE.sv"), DIFF_FILE=str(AREA / "DIFF_FILE.diff"),
    VERIFICATION=str(AREA / "VERIFICATION.txt"), ROLLBACK=str(AREA / "ROLLBACK.sh"),
    baseline_sha256=change["baseline_sha256"], modified_sha256=change["modified_sha256"],
    parent_btb_sha256=change["parent_btb_sha256"], core_tests=core["tests"],
    core_scope="Unchanged23scenario harness, LOAD_ALU_MODE2, ENABLE_PREDICTOR0, all full literal outputs including591ARCH and cycles identical; not a new whole-CPU formal proof",
    range_proof=proof, real_rollback=rollback, exact_source_inverse=True, source_binding=change,
    restored_behavior="Independent copy restores exact9896 target_keep core bytes;13aa single-write count/trip RAM retained; all23scenario complete output/cycle/591ARCH traces match BASELINE and active modified copy. MODIFIED_FILE remains8AF95F.",
    exact_simulation_physical_common_files=17, physical_files=18,
    protected_parent_files=len(change["protected_parents"]), frozen_baseline_files_verified=len(frozen),
    actual_parent_path_analysis=mechanism,
    production_equivalence_scope="SAT uses source-extracted full redirect range cone, six arbitrary complete32bit address inputs, all five Boolean controls, arbitrary32bit right-shift count. Directed fourstate tests cover34 widths0..33 including actual16 and default32,705704 comparisons; original X/Z fallback remains.",
    physical_status="Pending root actual synthesis/route; fixed145.125MHz/0.150ns constraints untouched; no PDS or6000 launched by this agent", exit_status=0)
(AREA / "VERIFICATION.txt").write_text(json.dumps(evidence, indent=2)+"\n", encoding="utf-8-sig")
names = ["MODIFIED_FILE.sv", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh", "CHANGE.json",
         "RANGE_VERIFICATION.json", "CORE_VERIFICATION.json", "ROLLBACK_RESULT.json", "PATH_ANALYSIS.json"]
artifacts = {name: dict(sha256=sha(AREA / name), bytes=(AREA / name).stat().st_size) for name in names}
assert all(item["bytes"] > 0 for item in artifacts.values())
final = dict(status=evidence["status"], core_sha256=change["modified_sha256"], parent_core_sha256=change["baseline_sha256"],
    parent_btb_sha256=change["parent_btb_sha256"], rtl=change["rtl"], physical_rtl=change["physical_rtl"],
    artifacts=artifacts, production_source_SAT=True, fourstate_comparisons=705704,
    negative_controls_rejected=2, core_BMR23_full_equal=True, architecture_lines=591,
    exact_source_inverse=True, actual_rollback_restored_parent=True,
    protected_parent_files=len(change["protected_parents"]), frozen_baseline_files_verified=len(frozen),
    PDS_launched=False, benchmark6000_launched=False)
(AREA / "FINAL_RECHECK.json").write_text(json.dumps(final, indent=2)+"\n", encoding="utf-8-sig")
assert read(AREA / "FINAL_RECHECK.json") == final
print("RAM_MEMORY_RANGE_READY coreSHA256="+change["modified_sha256"]+" parent=9896 BTB=13aa rtl=17 physical=18 SAT=source_bound fourstate=705704 negatives=2_REJECTED BMR23=full_equal ARCH=591 rollback=9896 protected="+str(len(change["protected_parents"]))+" original_frozen="+str(len(frozen))+" artifacts=reopened exit=0")

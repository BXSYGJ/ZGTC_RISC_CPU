﻿# SG30 memory range actual synthesis mapping

Actual ADS keeps both full-source upper-bit reductions, then late mem_fault drives exactly one LUT3 1bit mux; the previous three-level fault-dependent reduction becomes one level. No sequential state or address interface changed.

Actual FETCH_ADDRESS_BITS=16, companion retained width17. Initial proof display used17 as production label; proof always covered widths0..33 and arbitrary32bit shift, so actual16 was covered. Metadata corrected and proof rerun; no source changed.

| Actual ADS synthesis | LUT | FF | LUTRAM | Logic LUT |
|---|---:|---:|---:|---:|
| sg26-ram-target-keep-synth | 6143 | 2561 | 471 | 5672 |
| sg30-ram-memory-range-synth | 6142 | 2561 | 471 | 5671 |

Both new scalar declarations retain PAP_KEEP in the actual mapped netlist. Their cones contain only source bits16..31; mem_fault enters the following LUT3. Actual synthesis saves1LUT with unchangedFF/LUTRAM. Root physical route remains pending.

```verilog
GTP_LUT3 /* N256_16 */ #(
            .INIT(8'b11100100))
        N256_16 (
            .Z (_N3947),
            .I0 (\board/soc/core/mem_fault ),
            .I1 (\board/soc/core/memory_next_in_range ),
            .I2 (\board/soc/core/memory_trap_in_range ));
```

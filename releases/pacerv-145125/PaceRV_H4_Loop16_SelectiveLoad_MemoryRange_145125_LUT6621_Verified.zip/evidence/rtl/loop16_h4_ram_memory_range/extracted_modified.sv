module range_modified(input [31:0] FETCH_ADDRESS_BITS,input [31:0] trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,input mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken,output [1:0] control);
    wire [31:0] memory_redirect_pc=mem_fault ? trap_target : mem_next_pc;
    // Reduce each complete source address before the late memory-fault select.
    (* syn_keep=1 *) wire memory_trap_in_range=(trap_target >> FETCH_ADDRESS_BITS)==0;
    (* syn_keep=1 *) wire memory_next_in_range=(mem_next_pc >> FETCH_ADDRESS_BITS)==0;
    reg memory_redirect_in_range;
    always @* begin
        case(mem_fault)
            1'b0: memory_redirect_in_range=memory_next_in_range;
            1'b1: memory_redirect_in_range=memory_trap_in_range;
            default: memory_redirect_in_range=(memory_redirect_pc >> FETCH_ADDRESS_BITS)==0;
        endcase
    end
    wire redirect_fetch_valid=mem_flush ? memory_redirect_in_range :
        ex_redirect_candidate ? (early_taken ? (early_target >> FETCH_ADDRESS_BITS)==0 : (early_fallthrough >> FETCH_ADDRESS_BITS)==0) :
        id_zero_taken ? (id_zero_target >> FETCH_ADDRESS_BITS)==0 : (id_zero_fallthrough >> FETCH_ADDRESS_BITS)==0;
assign control={redirect_fetch_valid,memory_redirect_in_range};
endmodule

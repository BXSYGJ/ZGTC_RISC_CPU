"""Use the real PowerShell rollback on an independent changed-core copy."""
from pathlib import Path
import hashlib
import json
import subprocess

area = Path(__file__).resolve().parent
root = area.parents[1]
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
change = read(area / "CHANGE.json")
assert sha(area / "rollback_test.sv") == change["modified_sha256"]
action = ("[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
          "$a=[System.IO.Path]::Combine('D:/AAAFPGA','ZGTC_RISC_CPU','pds_minimal_blink_200h',"
          "'pacerv_h3_optimization','rtl_proposals','loop16_h4_ram_memory_range'); "
          "& ([ScriptBlock]::Create((Get-Content -LiteralPath ([System.IO.Path]::Combine($a,'ROLLBACK.sh')) -Raw))) "
          "-TargetPath ([System.IO.Path]::Combine($a,'rollback_test.sv')) "
          "-BaselinePath ([System.IO.Path]::Combine($a,'BASELINE_FILE.sv'))")
command = ["pwsh", "-NoProfile", "-NonInteractive", "-Command", action]
proc = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", timeout=30,
                      creationflags=subprocess.CREATE_NO_WINDOW)
literal = (proc.stdout + proc.stderr).strip()
assert proc.returncode == 0, literal
assert sha(area / "rollback_test.sv") == change["baseline_sha256"]
assert sha(area / "MODIFIED_FILE.sv") == change["modified_sha256"]
for relative, h in change["protected_parents"].items():
    assert sha(root / relative) == h
result = dict(command=command, input="Independent modified rollback_test.sv; original13aa BTB retained",
              input_sha256=change["modified_sha256"], literal_output=literal, exit_status=proc.returncode,
              restored_sha256=sha(area / "rollback_test.sv"), active_modified_sha256=sha(area / "MODIFIED_FILE.sv"),
              parent_btb_sha256=change["parent_btb_sha256"], preserved_parent_files=len(change["protected_parents"]))
(area / "ROLLBACK_RESULT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8-sig")
print(literal)

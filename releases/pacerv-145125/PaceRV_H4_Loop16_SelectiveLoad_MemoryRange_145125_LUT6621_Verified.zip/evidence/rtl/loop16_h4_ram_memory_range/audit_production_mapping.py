"""Inspect root-created SG30 ADS outputs without modifying any input/artifact."""
from pathlib import Path
import hashlib
import json
import re

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
change = read(AREA / "CHANGE.json")
freeze = {name:sha(AREA / name) for name in ["MODIFIED_FILE.sv", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh", "FINAL_RECHECK.json"]}

def module(text, name):
    start = re.search(r"(?m)^module " + name + r"\b", text).start()
    return text[start:text.index("endmodule", start)], start

def cells(text, base_offset=0, full=""):
    result=[]
    pattern=r"(GTP_\w+)\s*(?:/\*\s*([^*]+?)\s*\*/\s*)?(?:#\(.*?\)\s*)?(\\?[^\s(]+)\s*\([^;]*?;"
    for match in re.finditer(pattern,text,re.S):
        ports={k:v.strip() for k,v in re.findall(r"\.(\w+)\s*\((.*?)\)",match.group(),re.S)}
        result.append(dict(name=(match[2] or match[3]).strip().lstrip(chr(92)),primitive=match[1],ports=ports,
                           literal=match.group(),netlist_line=full[:base_offset+match.start()].count("\n")+1))
    return result

snapshots=[]
for name in ["sg26-ram-target-keep-synth", "sg30-ram-memory-range-synth"]:
    base=ROOT/"work"/name
    netpath=base/"implementation/netlist.v"
    logpath=base/"synthesis/console.stdout.log"
    text=netpath.read_text(encoding="utf-8-sig")
    ct,offset=module(text,"rv32_core")
    corecells=cells(ct,offset,text)
    drivers={value:cell for cell in corecells for key,value in cell["ports"].items() if key in ["Z","Z5","COUT"] and value}
    def cone(net,active=()):
        if net in active:
            return set(),0
        if net not in drivers:
            return {net},0
        cell=drivers[net]
        children=[value for key,value in cell["ports"].items() if (key.startswith("I") or key=="CIN") and value and "'" not in value]
        leaves=set()
        depth=0
        for child in children:
            sub,levels=cone(child,active+(net,))
            leaves|=sub
            depth=max(depth,levels)
        return leaves,depth+1
    log=logpath.read_text(encoding="utf-8-sig")
    resource={key:int(re.findall(pattern,log)[-1]) for key,pattern in dict(
        LUT=r"Total LUTs:\s*(\d+)",FF=r"Total Registers:\s*(\d+)",
        LUTRAM=r"LUTs as dram:\s*(\d+)",logic_LUT=r"LUTs as logic:\s*(\d+)").items()}
    src={p.name:sha(p) for p in sorted((base/"inputs/rtl").glob("*.sv"))}
    assert len(src)==18 and src["rv32_btb.sv"]==change["parent_btb_sha256"]
    entry=dict(build=name,netlist=str(netpath),netlist_sha256=sha(netpath),log=str(logpath),log_sha256=sha(logpath),
               source_hashes=src,resources=resource)
    if name.startswith("sg26"):
        selected=[c for c in corecells if c["name"] in ["N58[23]","N1728_11","N1728_16"]]
        assert len(selected)==3
        leaves,depth=cone("N1728")
        assert "mem_fault" not in leaves  # It has its own driver; inspect direct cell pins below.
        assert any(c["ports"].get("I0")=="mem_fault" for c in selected)
        entry.update(old_range_cells=selected,old_range_all_upstream_logic_depth=depth,
                     fault_reduction_path="N58[23].Z5 -> N1728_11 -> N1728_16; actual SG26 RTR confirms three levels after mem_fault")
    else:
        cofactors={}
        for signal,address in [("memory_trap_in_range","trap_target"),("memory_next_in_range","mem_next_pc")]:
            leaves,depth=cone(signal)
            expected={address+"["+str(bit)+"]" for bit in range(16,32)}
            assert leaves==expected,(signal,leaves)
            assert re.search(r'\(\* PAP_KEEP="TRUE" \*\)\s+wire '+signal+r";",ct)
            cofactors[signal]=dict(driver=drivers[signal],leaves=sorted(leaves),logic_depth_before_fault=depth,
                                   exact_upper_bits="16..31",fault_in_cone=False,PAP_KEEP_retained=True)
        ft,foffset=module(text,"rv32_rvc_frontend")
        fcells=cells(ft,foffset,text)
        mux=[c for c in fcells if c["name"]=="N256_16"]
        assert len(mux)==1 and mux[0]["primitive"]=="GTP_LUT3"
        assert mux[0]["ports"]["I0"].endswith("/mem_fault")
        assert mux[0]["ports"]["I1"].endswith("/memory_next_in_range")
        assert mux[0]["ports"]["I2"].endswith("/memory_trap_in_range")
        actual_attr=[dict(line=i+1,literal=line) for i,line in enumerate(log.splitlines())
                     if "rv32_core.sv(line number: 118)" in line or "rv32_core.sv(line number: 119)" in line]
        assert len(actual_attr)==2 and all("syn_keep to PAP_KEEP" in x["literal"] for x in actual_attr)
        soc=(base/"inputs/rtl/rv32_soc.sv").read_text()
        assert "parameter integer MEMORY_ADDRESS_BITS=14" in soc
        assert ".FETCH_ADDRESS_BITS(MEMORY_ADDRESS_BITS+2)" in soc
        board=(base/"inputs/rtl/rv32_board_top.sv").read_text()
        assert ".MEMORY_ADDRESS_BITS(" not in board
        entry.update(cofactors=cofactors,late_fault_one_bit_mux=mux[0],attribute_recognition=actual_attr,
            effective_FETCH_ADDRESS_BITS=16,actual_parameter_chain="rv32_soc MEMORY_ADDRESS_BITS default14; board has no override; core FETCH_ADDRESS_BITS=14+2=16. Captured companion width17 includes the extra overflow bit.")
    snapshots.append(entry)
old,new=snapshots
assert old["source_hashes"]["rv32_core.sv"]==change["baseline_sha256"]
assert new["source_hashes"]["rv32_core.sv"]==change["modified_sha256"]
assert [n for n in old["source_hashes"] if old["source_hashes"][n]!=new["source_hashes"][n]]==["rv32_core.sv"]
assert new["resources"]==dict(LUT=6142,FF=2561,LUTRAM=471,logic_LUT=5671)
for name,h in freeze.items():assert sha(AREA/name)==h
for relative,h in change["protected_parents"].items():assert sha(ROOT/relative)==h
result=dict(status="PASS_ACTUAL_FAULT_RANGE_DEPTH_REDUCED",snapshots=snapshots,
    delta={k:new["resources"][k]-old["resources"][k] for k in old["resources"]},
    mechanism="Actual ADS keeps both full-source upper-bit reductions, then late mem_fault drives exactly one LUT3 1bit mux; the previous three-level fault-dependent reduction becomes one level. No sequential state or address interface changed.",
    parameter_note="Actual FETCH_ADDRESS_BITS=16, companion retained width17. Initial proof display used17 as production label; proof always covered widths0..33 and arbitrary32bit shift, so actual16 was covered. Metadata corrected and proof rerun; no source changed.",
    physical_status="Root actual SG30 s2 route running; no timing improvement claimed before completion",
    artifact_freeze=freeze,protected_files=len(change["protected_parents"]),PDS_launches=0,production_changes=0)
(AREA/"PRODUCTION_MAPPING.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8-sig")
lines=["# SG30 memory range actual synthesis mapping","",result["mechanism"],"",result["parameter_note"],"",
       "| Actual ADS synthesis | LUT | FF | LUTRAM | Logic LUT |","|---|---:|---:|---:|---:|"]
for s in snapshots:
    r=s["resources"]
    lines.append(f"| {s['build']} | {r['LUT']} | {r['FF']} | {r['LUTRAM']} | {r['logic_LUT']} |")
lines += ["","Both new scalar declarations retain PAP_KEEP in the actual mapped netlist. Their cones contain only source bits16..31; mem_fault enters the following LUT3. Actual synthesis saves1LUT with unchangedFF/LUTRAM. Root physical route remains pending.","",
          "```verilog",new["late_fault_one_bit_mux"]["literal"],"```",""]
(AREA/"PRODUCTION_MAPPING.md").write_text("\n".join(lines),encoding="utf-8-sig")
assert read(AREA/"PRODUCTION_MAPPING.json")==result and (AREA/"PRODUCTION_MAPPING.md").read_bytes()
print("RAM_MEMORY_RANGE_MAPPING_PASS late_fault_range_levels=3->1 kept_scalars=2 actual_fetch_width=16 companion_width=17 LUT=6142 delta=-1 FF=2561 LUTRAM=471 source=8AF95F artifacts_unchanged=5 protected=105 PDS=0 exit=0")

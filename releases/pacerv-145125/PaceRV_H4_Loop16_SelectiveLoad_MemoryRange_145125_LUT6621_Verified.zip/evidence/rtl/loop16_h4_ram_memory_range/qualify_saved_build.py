"""Qualify actual PDS timing and matched-source completed 6000-iteration runs."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LONGS = ROOT / 'rtl_proposals' / 'loop16_h4_ram_memory_range_longs'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
parser = argparse.ArgumentParser()
parser.add_argument('--physical', required=True)
args = parser.parse_args()
assert re.fullmatch(r'sg30-ram-memory-range-[A-Za-z0-9_-]+', args.physical)
physical = ROOT / 'work' / args.physical
change = load(HERE / 'CHANGE.json')
longs = load(LONGS / 'LONG_FINAL_AUDIT.json')
assert longs['status'] == 'PASS_BOTH_ACTUAL6000_GT3P5' and not longs['pending']
spec = importlib.util.spec_from_file_location('readonly_physical_audit', ROOT / 'scripts' / 'audit_results.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
spec = importlib.util.spec_from_file_location('readonly_timing_proof', ROOT / 'scripts' / 'closure-packaging-quarter' / 'closure_proofs_quarter.py')
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
observed = audit.audit_physical(physical)
assert observed['status'] == 'completed_timing_pass' and observed['all_ten_timing_checks_pass']
assert observed['frequency_mhz'] == 145.125 and observed['setup_uncertainty_ns'] == 0.15
manifest = load(physical / 'BUILD_RESULT.json')
timing = proof.parse_timing_report((physical / 'implementation' / 'report_timing' / 'pds_soc_top.rtr').read_bytes())
assert timing == manifest['Timing']['Checks'] and len(timing) == 10
assert all(row['WorstSlackNs'] >= 0 and row['TotalNegativeSlackNs'] == 0 and row['FailingEndpoints'] == 0 for rows in timing.values() for row in rows)
parent = ROOT / 'work' / 'sg30-ram-memory-range-s2'
constraint_bindings = {}
for path in sorted((physical / 'inputs' / 'constraints').glob('*')):
    if path.is_file():
        assert path.read_bytes() == (parent / 'inputs' / 'constraints' / path.name).read_bytes()
        constraint_bindings[path.name] = sha(path)
bindings = []
for folder, total in [('rtl', 17), ('physical_rtl', 18)]:
    source = ROOT / 'candidates' / 'loop16_h4_ram_memory_range' / folder
    actual = {p.name: sha(p) for p in source.glob('*.sv')}
    assert len(actual) == total and actual == change[folder]
    if folder == 'physical_rtl':
        assert {p.name: sha(p) for p in (physical / 'inputs' / 'rtl').glob('*.sv')} == actual
    else:
        for name, value in actual.items():
            assert sha(physical / 'inputs' / 'rtl' / name) == value
            bindings.append(dict(name=name, simulation_sha256=value, physical_sha256=value))
assert len(bindings) == 17
formal = []
for role in ['V0', 'V1']:
    target = ROOT / 'work' / ('sg30-ram-memory-range-i6000-' + role)
    record = next(entry for entry in longs['records'] if entry['role'] == role)
    row = audit.audit_simulation(target)
    assert row == record['audit']
    assert row['formal_ten_seconds'] and row['iterations'] == 6000 and row['coremark_per_mhz'] > 3.5
    assert record['process']['native_exit_status'] == 0
    assert record['source_binding']['rtl_17_sha256'] == change['rtl']
    assert record['source_binding']['physical_rtl_18_sha256'] == change['physical_rtl']
    assert record['source_binding']['rtl_sha256'] == row['rtl_sha256']
    assert row['coremark_per_mhz'] == 6000000000 / row['cycles']
    if role == 'V0':
        assert row['firmware_sha256'] == observed['firmware_sha256']
    formal.append(row)
old = load(ROOT / 'rtl_proposals' / 'load_simple_loop16_h4' / 'QUALIFICATION-sg21-loop16-h4-s2.json')
assert observed['resources']['LUT'] < old['physical']['resources']['LUT']
result = dict(status='QUALIFIED_SAVED_PHYSICAL_AND_ACTUAL6000', updated_utc=datetime.now(timezone.utc).isoformat(),
    physical=observed, timing_checks=timing, actual6000=formal, RTL17_bindings=bindings,
    RTL18_manifest=change['physical_rtl'], retained_source_chain=change,
    constraint_bytes_equal_previous_sg30=True, constraint_sha256=constraint_bindings,
    raw_timing_report_sha256=sha(physical / 'implementation' / 'report_timing' / 'pds_soc_top.rtr'),
    physical_manifest_sha256=sha(physical / 'BUILD_RESULT.json'), long_final_audit_sha256=sha(LONGS / 'LONG_FINAL_AUDIT.json'),
    improvement_from_H4=dict(LUT_saved=old['physical']['resources']['LUT'] - observed['resources']['LUT'],
        FF_saved=old['physical']['resources']['FF'] - observed['resources']['FF']),
    score_formula='6000 * 1000000 / raw_UART_CSR_observer_cycles',
    qualification_does_not_create_package=True, production_RTL_changed=False, work_launched=False)
output = HERE / ('QUALIFICATION-' + args.physical + '.json')
output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8-sig')
assert load(output) == result
print('SG30_SAVED_BUILD_QUALIFIED ' + args.physical + ' actual6000=2 both_gt3p5=True timing=10/10 exactRTL=17/18 LUT=' + str(observed['resources']['LUT']) + ' FF=' + str(observed['resources']['FF']) + ' WNS=' + str(observed['slow_setup_ns']) + ' reopened=1')

"""Prove the extracted production cone and exercise X/Z at address boundaries."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import time

AREA = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
change = read(AREA / "CHANGE.json")
baseline = (AREA / "BASELINE_FILE.sv").read_text()
modified = (AREA / "MODIFIED_FILE.sv").read_text()
assert sha(AREA / "BASELINE_FILE.sv") == change["baseline_sha256"]
assert sha(AREA / "MODIFIED_FILE.sv") == change["modified_sha256"]
assert modified.replace(change["insertion_after"], change["insertion_before"], 1).replace(
    change["branch_after"], change["branch_before"], 1) == baseline

def run(command, label, expected=0):
    started = time.monotonic()
    proc = subprocess.run(command, cwd=AREA, text=True, encoding="utf-8", errors="replace",
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    log = AREA / (label + ".log")
    log.write_text(proc.stdout, encoding="utf-8")
    assert proc.returncode == expected, label + " " + proc.stdout[-3500:]
    return dict(command=command, input_directory=str(AREA), literal_output=proc.stdout,
                exit_status=proc.returncode, expected_exit_status=expected,
                seconds=time.monotonic()-started, full_log_sha256=sha(log))

def extract(text, name, dynamic=True):
    original_line = re.search(r"    wire \[31:0\] memory_redirect_pc=.*?;", text).group()
    new_block = ""
    if "    reg memory_redirect_in_range;" in text:
        start = text.index("    // Reduce each complete source address")
        stop = text.index("    wire [31:0] redirect_pc=", start)
        new_block = text[start:stop]
        memory_output = "memory_redirect_in_range"
    else:
        memory_output = "(memory_redirect_pc >> FETCH_ADDRESS_BITS)==0"
    fetch_line = re.search(r"    wire redirect_fetch_valid=.*?;", text, re.S).group()
    header = "module " + name + ("(" if dynamic else "#(parameter integer FETCH_ADDRESS_BITS=17)(")
    if dynamic:
        header += "input [31:0] FETCH_ADDRESS_BITS,"
    header += ("input [31:0] trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,"
               "input mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken,output [1:0] control);\n")
    return header + original_line + "\n" + new_block + fetch_line + "\nassign control={redirect_fetch_valid," + memory_output + "};\nendmodule\n"

ports = "FETCH_ADDRESS_BITS,trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken"
wrapper = ("module range_miter(input [31:0] FETCH_ADDRESS_BITS,trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,"
           "input mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken,output same);\n"
           "wire [1:0] reference_control,modified_control;range_reference reference_unit(" + ports + ",reference_control);\n"
           "range_modified modified_unit(" + ports + ",modified_control);assign same=reference_control==modified_control;endmodule\n")
reference = extract(baseline, "range_reference")
actual = extract(modified, "range_modified")
(AREA / "extracted_reference.sv").write_text(reference, encoding="utf-8")
(AREA / "extracted_modified.sv").write_text(actual, encoding="utf-8")
(AREA / "actual_range_miter.sv").write_text(reference+actual+wrapper, encoding="utf-8")
formal = run(["yosys", "-p", "read_verilog -sv actual_range_miter.sv; prep -top range_miter -flatten; sat -verify -prove same 1 -show-inputs"], "formal-range")
assert "SAT proof finished - no model found: SUCCESS!" in formal["literal_output"]
bad_old = "1'b1: memory_redirect_in_range=memory_trap_in_range;"
bad_new = "1'b1: memory_redirect_in_range=memory_next_in_range;"
assert modified.count(bad_old) == 1
mutant = modified.replace(bad_old, bad_new, 1)
(AREA / "negative_wrong_fault_core.sv").write_text(mutant, encoding="utf-8")
(AREA / "negative_range_miter.sv").write_text(reference+extract(mutant, "range_modified")+wrapper, encoding="utf-8")
negative = run(["yosys", "-p", "read_verilog -sv negative_range_miter.sv; prep -top range_miter -flatten; sat -verify -prove same 1 -show-inputs"], "negative-wrong-fault", 1)
assert "proof did fail" in negative["literal_output"]
print("RAM_MEMORY_RANGE_SAT_PASS production_extraction=2 address_bits=32 arbitrary_shift_bits=32 arbitrary_fault=1 full_redirect_output=2 wrong_fault_branch=REJECTED exit=0", flush=True)

parameter_reference = extract(baseline, "range_parameter_reference", False)
parameter_modified = extract(modified, "range_parameter_modified", False)
(AREA / "parameter_range_cones.sv").write_text(parameter_reference+parameter_modified, encoding="utf-8")
fourstate = "\n".join([
    "`timescale 1ns/1ps", "module range_fourstate_tb;",
    "reg[31:0] trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough;",
    "reg mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken;",
    "wire[1:0] reference_control[0:33],modified_control[0:33];",
    "integer checks=0,i,j,k,b,t,seed=32'h68a32d45;",
    "generate for(genvar B=0;B<34;B=B+1)begin:configs",
    "range_parameter_reference#(B)r(trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken,reference_control[B]);",
    "range_parameter_modified#(B)m(trap_target,mem_next_pc,early_target,early_fallthrough,id_zero_target,id_zero_fallthrough,mem_fault,mem_flush,ex_redirect_candidate,early_taken,id_zero_taken,modified_control[B]);end endgenerate",
    "function automatic four(input integer value);case(value&3)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase endfunction",
    "task step;begin #1;for(b=0;b<34;b=b+1)begin checks=checks+1;if(reference_control[b]!==modified_control[b])begin $display(\"RANGE_MISMATCH B=%0d fault=%b trap=%h next=%h old=%b new=%b\",b,mem_fault,trap_target,mem_next_pc,reference_control[b],modified_control[b]);$fatal(1,\"Production range differs\");end end end endtask",
    "initial begin mem_flush=1;ex_redirect_candidate=0;early_taken=0;id_zero_taken=0;early_target=0;early_fallthrough=0;id_zero_target=0;id_zero_fallthrough=0;",
    "for(i=0;i<34;i=i+1)begin for(j=0;j<8;j=j+1)begin case(j)0:trap_target=0;1:trap_target=32'hffffffff;2:trap_target=32'h1<<i;3:trap_target=(32'h1<<i)-1;4:trap_target=(32'h1<<i)+1;5:trap_target=32'h80000000;6:trap_target=32'h0001ffff;7:trap_target=32'h00020000;endcase",
    "for(k=0;k<8;k=k+1)begin case(k)0:mem_next_pc=0;1:mem_next_pc=32'hffffffff;2:mem_next_pc=32'h1<<i;3:mem_next_pc=(32'h1<<i)-1;4:mem_next_pc=(32'h1<<i)+1;5:mem_next_pc=32'h80000000;6:mem_next_pc=32'h0001ffff;7:mem_next_pc=32'h00020000;endcase for(t=0;t<4;t=t+1)begin mem_fault=four(t);step;end end end end",
    "for(i=0;i<32;i=i+1)begin for(j=0;j<4;j=j+1)begin for(k=0;k<4;k=k+1)begin trap_target=0;mem_next_pc=0;trap_target[i]=four(j);mem_next_pc[i]=four(k);for(t=0;t<4;t=t+1)begin mem_fault=four(t);step;end end end end",
    "for(i=0;i<10004;i=i+1)begin for(k=0;k<32;k=k+1)begin trap_target[k]=four($random(seed));mem_next_pc[k]=four($random(seed));early_target[k]=four($random(seed));early_fallthrough[k]=four($random(seed));id_zero_target[k]=four($random(seed));id_zero_fallthrough[k]=four($random(seed));end mem_fault=four($random(seed));mem_flush=four($random(seed));ex_redirect_candidate=four($random(seed));early_taken=four($random(seed));id_zero_taken=four($random(seed));step;end",
    "$display(\"RANGE_FOURSTATE_PASS checks=%0d configurations=34 widths=0..33 production_width=16 complete32bit_inputs fault=0/1/X/Z random=10004\",checks);$finish;end", "endmodule", ""])
(AREA / "range_fourstate_tb.sv").write_text(fourstate, encoding="utf-8")
four_compile = run(["iverilog", "-g2012", "-s", "range_fourstate_tb", "-o", "range-fourstate.vvp", "range_fourstate_tb.sv", "parameter_range_cones.sv"], "fourstate-compile")
four_run = run(["vvp", "range-fourstate.vvp"], "fourstate")
assert "RANGE_FOURSTATE_PASS checks=705704" in four_run["literal_output"], four_run["literal_output"]
no_fallback = modified.replace("default: memory_redirect_in_range=(memory_redirect_pc >> FETCH_ADDRESS_BITS)==0;",
                               "default: memory_redirect_in_range=1'b0;")
assert no_fallback != modified
(AREA / "negative_missing_xz_fallback_core.sv").write_text(no_fallback, encoding="utf-8")
(AREA / "negative_parameter_range_cones.sv").write_text(parameter_reference+extract(no_fallback, "range_parameter_modified", False), encoding="utf-8")
bad_compile = run(["iverilog", "-g2012", "-s", "range_fourstate_tb", "-o", "negative-fourstate.vvp", "range_fourstate_tb.sv", "negative_parameter_range_cones.sv"], "negative-fourstate-compile")
bad_four = run(["vvp", "negative-fourstate.vvp"], "negative-fourstate", 1)
assert "Production range differs" in bad_four["literal_output"]
result = dict(status="PASS", baseline_sha256=change["baseline_sha256"], modified_sha256=change["modified_sha256"],
              production_source_extraction=True, binary_inputs="six arbitrary32bit addresses, arbitrary32bit unsigned right-shift count, all five control bits; no range restrictions on addresses",
              formal=formal, negative_wrong_fault_branch=negative, fourstate_compile=four_compile,
              fourstate=four_run, negative_missing_xz_fallback_compile=bad_compile, negative_missing_xz_fallback=bad_four,
              fourstate_checks=705336, actual_parameter17=True, parameter_widths=list(range(34)),
              source_bindings={name: sha(AREA / name) for name in ["BASELINE_FILE.sv", "MODIFIED_FILE.sv", "extracted_reference.sv", "extracted_modified.sv", "actual_range_miter.sv", "range_fourstate_tb.sv", "negative_wrong_fault_core.sv", "negative_missing_xz_fallback_core.sv"]},
              exact_source_inverse=True, full_address_mem_flush_other_redirect_branches_unchanged=True)
(AREA / "RANGE_VERIFICATION.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8-sig")
print(four_run["literal_output"].strip(), flush=True)
print("RAM_MEMORY_RANGE_PROOF_READY actual_source_SAT=PASS fourstate=705704 negatives=2_REJECTED exit=0", flush=True)

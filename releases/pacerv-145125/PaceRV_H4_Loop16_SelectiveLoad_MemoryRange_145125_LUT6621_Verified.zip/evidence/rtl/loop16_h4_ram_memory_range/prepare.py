"""Freeze memory redirect range cofactors over the exact target_keep parent."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
PARENT_NAME = "loop16_h4_ram_target_keep"
NAME = "loop16_h4_ram_memory_range"
PARENT = ROOT / "candidates" / PARENT_NAME
DEST = ROOT / "candidates" / NAME
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
assert not DEST.exists(), "Preserve existing candidate"
baseline_hash = "9896d2d8177cd69adda9a4399839023dac5a37d2343e5e0e74d117ddf152a411"
btb_hash = "13aa9b1196adc482149b3414f62d752e787ded7a9b0bf06438b28e9be8a563c8"
parent_receipt = read(ROOT / "rtl_proposals" / PARENT_NAME / "CHANGE.json")
original = (PARENT / "rtl/rv32_core.sv").read_bytes()
assert sha(PARENT / "rtl/rv32_core.sv") == baseline_hash
before = b"    wire [31:0] memory_redirect_pc=mem_fault ? trap_target : mem_next_pc;"
addition = "\n".join([
    "    // Reduce each complete source address before the late memory-fault select.",
    "    (* syn_keep=1 *) wire memory_trap_in_range=(trap_target >> FETCH_ADDRESS_BITS)==0;",
    "    (* syn_keep=1 *) wire memory_next_in_range=(mem_next_pc >> FETCH_ADDRESS_BITS)==0;",
    "    reg memory_redirect_in_range;",
    "    always @* begin",
    "        case(mem_fault)",
    "            1'b0: memory_redirect_in_range=memory_next_in_range;",
    "            1'b1: memory_redirect_in_range=memory_trap_in_range;",
    "            default: memory_redirect_in_range=(memory_redirect_pc >> FETCH_ADDRESS_BITS)==0;",
    "        endcase",
    "    end",
]).encode()
after = before + b"\n" + addition
old_branch = b"    wire redirect_fetch_valid=mem_flush ? (memory_redirect_pc >> FETCH_ADDRESS_BITS)==0 :"
new_branch = b"    wire redirect_fetch_valid=mem_flush ? memory_redirect_in_range :"
assert original.count(before) == 1 and original.count(old_branch) == 1
modified = original.replace(before, after, 1).replace(old_branch, new_branch, 1)
assert modified.replace(after, before, 1).replace(new_branch, old_branch, 1) == original
for name, data in [("BASELINE_FILE.sv", original), ("MODIFIED_FILE.sv", modified),
                   ("rv32_core.sv", modified), ("rollback_test.sv", modified)]:
    (AREA / name).write_bytes(data)
protected = {}
for base_name in [PARENT_NAME, "loop16_h4_single_write", "load_simple_loop16_h4"]:
    for mode, count in [("rtl", 17), ("physical_rtl", 18)]:
        paths = list((ROOT / "candidates" / base_name / mode).glob("*.sv"))
        assert len(paths) == count
        for path in paths:
            protected[path.relative_to(ROOT).as_posix()] = sha(path)
for mode, count in [("rtl", 17), ("physical_rtl", 18)]:
    assert sha(PARENT / mode / "rv32_btb.sv") == btb_hash
    shutil.copytree(PARENT / mode, DEST / mode)
    for name, expected in parent_receipt[mode].items():
        assert sha(DEST / mode / name) == expected
    (DEST / mode / "rv32_core.sv").write_bytes(modified)
    assert len(list((DEST / mode).glob("*.sv"))) == count
shutil.copy2(ROOT / "rtl_proposals" / PARENT_NAME / "core_token_tb.sv", AREA / "core_token_tb.sv")
template = (ROOT / "rtl_proposals" / PARENT_NAME / "ROLLBACK.sh").read_text(encoding="utf-8-sig")
rollback = template.replace("RAM_TARGET_KEEP_ROLLBACK_PASS", "RAM_MEMORY_RANGE_ROLLBACK_PASS").replace(
    "5E81F9C56246E502B43C6A48C14342DBB16AC437788AC01D00A482D9A06CA84B", baseline_hash.upper())
for name in ["ROLLBACK.sh", "ROLLBACK.ps1"]:
    (AREA / name).write_text(rollback, encoding="utf-8-sig")
(AREA / "DIFF_FILE.diff").write_text("".join(difflib.unified_diff(
    original.decode().splitlines(True), modified.decode().splitlines(True),
    fromfile="BASELINE_FILE.sv", tofile="MODIFIED_FILE.sv")), encoding="utf-8")
for script in ["run_rollback.py", "verify_core.py"]:
    text = (ROOT / "rtl_proposals" / PARENT_NAME / script).read_text(encoding="utf-8-sig")
    text = text.replace("loop16_h4_ram_target_keep", NAME).replace("RAM_TARGET_KEEP", "RAM_MEMORY_RANGE")
    text = text.replace('"candidates/loop16_h4_single_write/rtl"', '"candidates/loop16_h4_ram_target_keep/rtl"')
    (AREA / script).write_text(text, encoding="utf-8")
change = dict(changed_field="Precompute complete32bit trap_target and mem_next_pc range with FETCH_ADDRESS_BITS, keep each scalar, select by known mem_fault; original full-width comparison on X/Z; only memory branch of redirect_fetch_valid changed",
              parent_candidate=str(PARENT), baseline_sha256=baseline_hash,
              modified_sha256=sha(AREA / "MODIFIED_FILE.sv"), parent_btb_sha256=btb_hash,
              insertion_before=before.decode(), insertion_after=after.decode(),
              branch_before=old_branch.decode(), branch_after=new_branch.decode(),
              protected_parents=protected,
              parent_change_sha256=sha(ROOT / "rtl_proposals" / PARENT_NAME / "CHANGE.json"),
              rtl={p.name: sha(p) for p in sorted((DEST / "rtl").glob("*.sv"))},
              physical_rtl={p.name: sha(p) for p in sorted((DEST / "physical_rtl").glob("*.sv"))})
(AREA / "CHANGE.json").write_text(json.dumps(change, indent=2) + "\n", encoding="utf-8-sig")
(AREA / "VERIFICATION.txt").write_text(json.dumps(dict(status="SOURCE_FROZEN_PROOF_PENDING", change=change), indent=2) + "\n", encoding="utf-8-sig")
for name in ["MODIFIED_FILE.sv", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh"]:
    assert (AREA / name).read_bytes()
print("RAM_MEMORY_RANGE_FROZEN coreSHA256=" + change["modified_sha256"] + " parent=9896 BTB=13aa rtl=17 physical=18 inverse=PASS proofs=PENDING", flush=True)

﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string] $TargetPath, [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string] $BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
try {
    $resolvedTarget = [System.IO.Path]::GetFullPath($TargetPath)
    $resolvedBaseline = [System.IO.Path]::GetFullPath($BaselinePath)
    if (-not (Test-Path -LiteralPath $resolvedTarget -PathType Leaf)) { throw 'Target missing.' }
    Copy-Item -LiteralPath $resolvedBaseline -Destination $resolvedTarget -Force
    $restoredHash = (Get-FileHash -LiteralPath $resolvedTarget -Algorithm SHA256).Hash
    if ($restoredHash -ne (Get-FileHash -LiteralPath $resolvedBaseline -Algorithm SHA256).Hash) { throw 'Restored hash mismatch.' }
    Write-Output ('RESTORED SHA256=' + $restoredHash)
    exit 0
} catch {
    Write-Error $_
    exit 1
}

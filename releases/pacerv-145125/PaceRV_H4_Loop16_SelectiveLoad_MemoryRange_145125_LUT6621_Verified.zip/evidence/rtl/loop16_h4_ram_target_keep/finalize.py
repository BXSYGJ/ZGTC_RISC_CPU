"""Freeze attribute-only evidence, exact overlays, original parents and artifacts."""
from pathlib import Path
import hashlib
import json

area = Path(__file__).resolve().parent
root = area.parents[1]
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
change = read(area / "CHANGE.json")
core = read(area / "CORE_VERIFICATION.json")
identity = read(area / "SOURCE_IDENTITY_PROOF.json")
rollback = read(area / "ROLLBACK_RESULT.json")
assert core["status"] == "PASS" and core["all_three_full_literal_outputs_equal"] and core["architecture_lines"] == 591
assert identity["byte_inverse_equal"] and identity["all_parameters_and_four_state_semantics_unchanged"]
assert rollback["exit_status"] == 0 and rollback["restored_sha256"] == change["baseline_sha256"]
assert sha(area / "MODIFIED_FILE.sv") == sha(area / "rv32_core.sv") == change["modified_sha256"]
assert sha(area / "rollback_test.sv") == change["baseline_sha256"]
dest = root / "candidates/loop16_h4_ram_target_keep"
for mode, count in [("rtl", 17), ("physical_rtl", 18)]:
    assert len(list((dest / mode).glob("*.sv"))) == count
    for name, h in change[mode].items():
        assert sha(dest / mode / name) == h
        if name != "rv32_core.sv":
            assert sha(dest / mode / name) == sha(root / "candidates/loop16_h4_single_write" / mode / name)
for path in (dest / "rtl").glob("*.sv"):
    assert path.read_bytes() == (dest / "physical_rtl" / path.name).read_bytes()
for relative, h in change["protected_parents"].items():
    assert sha(root / relative) == h
frozen = read(root / "EXPERIMENT.json")["BaselineFiles"]
for entry in frozen:
    assert sha(root / entry["Path"]) == entry["SHA256"].lower()
evidence = dict(status="READY_SOURCE_FROZEN_ATTRIBUTE_ONLY_BMR_PASS", changed_field=change["changed_field"],
    MODIFIED_FILE=str(area / "MODIFIED_FILE.sv"), DIFF_FILE=str(area / "DIFF_FILE.diff"),
    VERIFICATION=str(area / "VERIFICATION.txt"), ROLLBACK=str(area / "ROLLBACK.sh"),
    baseline_sha256=change["baseline_sha256"], modified_sha256=change["modified_sha256"],
    parent_btb_sha256=change["parent_btb_sha256"], source_identity=identity, tests=core["tests"],
    source_identity_scope="Entire byte-exact core inverse after removing exactly one synthesis attribute; all expressions, parameters, state, four-state simulation and cycles are identical to parent by source identity",
    core_scope="Existing23scenario full core harness, LOAD_ALU_MODE2, complete literal trace and591ARCH match; ENABLE_PREDICTOR0 in this harness. Attribute-only whole-source identity covers predictor-enabled expressions without a new predictor functional change.",
    real_rollback=rollback, restored_behavior="Independent core restores exact5E81 parent bytes with13aa single-write BTB retained; full23scenario output and591ARCH return identical. Active modified copy remains changed.",
    exact_simulation_physical_common_files=17, physical_files=18, protected_parent_files=len(change["protected_parents"]),
    frozen_baseline_files_verified=len(frozen), physical_mapping="PENDING actual synthesis; do not claim mux/adder separation until mapped netlist inspection",
    performance="No new6000 run launched; expression-identical attribute candidate preserves parent functionality but no new physical result claimed",
    exit_status=0)
(area / "VERIFICATION.txt").write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8-sig")
names = ["MODIFIED_FILE.sv", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh", "CHANGE.json",
         "SOURCE_IDENTITY_PROOF.json", "CORE_VERIFICATION.json", "ROLLBACK_RESULT.json", "NEGATIVE_CONTROLS.json"]
artifacts = {name: dict(sha256=sha(area / name), bytes=(area / name).stat().st_size) for name in names}
assert all(row["bytes"] > 0 for row in artifacts.values())
(area / "FINAL_RECHECK.json").write_text(json.dumps(dict(status=evidence["status"], core_sha256=change["modified_sha256"],
    parent_btb_sha256=change["parent_btb_sha256"], rtl=change["rtl"], physical_rtl=change["physical_rtl"],
    artifacts=artifacts, core_BMR23="PASS_FULL_LITERAL_AND591ARCH_EQUAL", exact_attribute_inverse=True,
    negative_control="FUNCTIONAL_MUTATION_REJECTED", parent_files_preserved=70,
    frozen_baseline_files_verified=len(frozen), PDS_launched=False, benchmark6000_launched=False), indent=2) + "\n", encoding="utf-8-sig")
assert (area / "FINAL_RECHECK.json").read_bytes()
print("RAM_TARGET_KEEP_READY coreSHA256=" + change["modified_sha256"] + " BTB=13aa rtl=17 physical=18 inverse=byte_exact BMR23=full_equal ARCH=591 rollback=5E81 protected_parent_files=70 frozen_baseline_files=" + str(len(frozen)) + " artifacts=reopened exit=0")

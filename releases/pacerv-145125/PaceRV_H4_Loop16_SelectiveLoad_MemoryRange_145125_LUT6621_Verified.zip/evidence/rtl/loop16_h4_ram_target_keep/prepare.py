"""Freeze only the direct-target result attribute over the original13aa parent."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
PARENT = ROOT / "candidates/loop16_h4_single_write"
DEST = ROOT / "candidates/loop16_h4_ram_target_keep"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
assert not DEST.exists(), "Preserve existing candidate"
baseline_hash = "5e81f9c56246e502b43c6a48c14342dbb16ac437788ac01d00a482d9a06ca84b"
btb_hash = "13aa9b1196adc482149b3414f62d752e787ded7a9b0bf06438b28e9be8a563c8"
before = b"    wire [31:0] frontend_direct_target=frontend_pc+frontend_direct_offset;"
after = b"    (* syn_keep=1 *) wire [31:0] frontend_direct_target=frontend_pc+frontend_direct_offset;"
parent_source = PARENT / "rtl/rv32_core.sv"
assert sha(parent_source) == baseline_hash
original = parent_source.read_bytes()
assert original.count(before) == 1 and after not in original
modified = original.replace(before, after, 1)
assert modified.count(after) == 1 and modified.replace(after, before, 1) == original
(AREA / "BASELINE_FILE.sv").write_bytes(original)
for name in ["MODIFIED_FILE.sv", "rv32_core.sv", "rollback_test.sv"]:
    (AREA / name).write_bytes(modified)
parent_receipt = read(ROOT / "rtl_proposals/loop16_h4_single_write/CHANGE.json")
protected = {}
for base in [PARENT, ROOT / "candidates/load_simple_loop16_h4"]:
    for mode, count in [("rtl", 17), ("physical_rtl", 18)]:
        paths = list((base / mode).glob("*.sv"))
        assert len(paths) == count
        for path in paths:
            protected[str(path.relative_to(ROOT)).replace(chr(92), "/")] = sha(path)
for mode, count in [("rtl", 17), ("physical_rtl", 18)]:
    assert sha(PARENT / mode / "rv32_btb.sv") == btb_hash
    shutil.copytree(PARENT / mode, DEST / mode)
    for name, expected in parent_receipt[mode].items():
        assert sha(DEST / mode / name) == expected
    (DEST / mode / "rv32_core.sv").write_bytes(modified)
    assert len(list((DEST / mode).glob("*.sv"))) == count
shutil.copy2(ROOT / "rtl_proposals/loop16_h4_single_write/core_token_tb.sv", AREA / "core_token_tb.sv")
template = (ROOT / "rtl_proposals/timing_response_flush_split/ROLLBACK.sh").read_text(encoding="utf-8-sig")
rollback = template.replace("RESPONSE_FLUSH_SPLIT_ROLLBACK_PASS", "RAM_TARGET_KEEP_ROLLBACK_PASS")
assert rollback != template
for name in ["ROLLBACK.sh", "ROLLBACK.ps1"]:
    (AREA / name).write_text(rollback, encoding="utf-8-sig")
(AREA / "DIFF_FILE.diff").write_text("".join(difflib.unified_diff(
    original.decode().splitlines(True), modified.decode().splitlines(True),
    fromfile="BASELINE_FILE.sv", tofile="MODIFIED_FILE.sv")), encoding="utf-8")
negative = modified.replace(b"frontend_pc+frontend_direct_offset", b"frontend_pc-frontend_direct_offset", 1)
(AREA / "negative_functional_core.sv").write_bytes(negative)
def inverse(data):
    assert data.count(after) == 1, "Exact single target keep required"
    assert data.replace(after, before, 1) == original, "Non-attribute source change rejected"
inverse(modified)
try:
    inverse(negative)
except AssertionError as error:
    negative_result = dict(source_sha256=sha(AREA / "negative_functional_core.sv"),
                           literal_output=str(error), expected_rejection=True,
                           result="REJECTED", exit_status=1)
else:
    raise AssertionError("Functional mutation accepted")
(AREA / "NEGATIVE_CONTROLS.json").write_text(json.dumps([negative_result], indent=2) + "\n", encoding="utf-8-sig")
change = dict(changed_field="Only add syn_keep=1 to the complete32bit frontend_direct_target wire; preserve direct-target expression, all cycle semantics and13aa count/trip RAM parent",
              parent_candidate=str(PARENT), baseline_sha256=baseline_hash,
              modified_sha256=sha(AREA / "MODIFIED_FILE.sv"), parent_btb_sha256=btb_hash,
              before=before.decode(), after=after.decode(), protected_parents=protected,
              parent_change_sha256=sha(ROOT / "rtl_proposals/loop16_h4_single_write/CHANGE.json"),
              source_identity_proof="Removing only the one exact added attribute restores the entire baseline file byte-for-byte",
              rtl={p.name: sha(p) for p in sorted((DEST / "rtl").glob("*.sv"))},
              physical_rtl={p.name: sha(p) for p in sorted((DEST / "physical_rtl").glob("*.sv"))})
(AREA / "CHANGE.json").write_text(json.dumps(change, indent=2) + "\n", encoding="utf-8-sig")
(AREA / "SOURCE_IDENTITY_PROOF.json").write_text(json.dumps(dict(status="PASS_EXACT_ATTRIBUTE_ONLY_INVERSE",
    baseline_sha256=baseline_hash, modified_sha256=change["modified_sha256"],
    byte_inverse_equal=True, expression_unchanged=True, all_parameters_and_four_state_semantics_unchanged=True,
    exact_single_added_attribute=True, parent_btb_sha256=btb_hash, negative_control=negative_result,
    preserved_parent_files=len(protected)), indent=2) + "\n", encoding="utf-8-sig")
(AREA / "VERIFICATION.txt").write_text(json.dumps(dict(status="SOURCE_FROZEN_BMR_PENDING", change=change), indent=2) + "\n", encoding="utf-8-sig")
assert all((AREA / name).read_bytes() for name in ["MODIFIED_FILE.sv", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh"])
print("RAM_TARGET_KEEP_FROZEN coreSHA256=" + change["modified_sha256"] + " BTB=13aa rtl=17 physical=18 exact_attribute_inverse=PASS negative=REJECTED BMR=PENDING")

"""Read-only comparison of root-created SG26 actual ADS mapping against SG25."""
from pathlib import Path
import hashlib
import json
import re

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
change = read(AREA / "CHANGE.json")
artifacts_before = {name: sha(AREA / name) for name in ["MODIFIED_FILE.sv", "DIFF_FILE.diff", "VERIFICATION.txt", "ROLLBACK.sh", "FINAL_RECHECK.json"]}


def core(text):
    start = re.search(r"(?m)^module rv32_core\b", text).start()
    return text[start:text.index("endmodule", start)], start


def cells(text):
    result = []
    for match in re.finditer(r"(GTP_\w+)\s*/\*\s*([^*]+?)\s*\*/[^;]*;", text, re.S):
        primitive, name = match[1], match[2].strip().lstrip(chr(92))
        ports = {key: value.strip() for key, value in re.findall(r"\.(\w+)\s*\((.*?)\)", match.group(), re.S)}
        result.append(dict(name=name, primitive=primitive, ports=ports, literal=match.group(), offset=match.start()))
    return result


snapshots = []
for name in ["sg25-loop-single-write-synth", "sg26-ram-target-keep-synth"]:
    folder = ROOT / "work" / name
    netlist_path = folder / "implementation/netlist.v"
    log_path = folder / "synthesis/console.stdout.log"
    netlist = netlist_path.read_text(encoding="utf-8-sig")
    text, offset = core(netlist)
    items = cells(text)
    carry = [item for item in items if item["primitive"] == "GTP_LUT6CARRY"]
    direct = [item for item in carry if re.fullmatch(r"frontend_direct_target\[\d+\]", item["ports"].get("Z", ""))]
    merged = [item for item in carry if re.fullmatch(r"N1140\[\d+\]", item["ports"].get("Z", ""))]
    bits = lambda group: sorted(int(re.search(r"\[(\d+)\]", item["ports"]["Z"])[1]) for item in group)
    chosen = []
    for group in [direct, merged]:
        for item in group:
            if item["ports"]["Z"].endswith(("[22]", "[23]", "[24]")):
                copy = dict(item)
                copy["netlist_line"] = netlist[:offset + item["offset"]].count("\n") + 1
                chosen.append(copy)
    post_mux = [item for item in items if item["primitive"] == "GTP_LUT6"
                and item["ports"].get("Z") == "N1140[2]"]
    log = log_path.read_text(encoding="utf-8-sig")
    resource_patterns = dict(LUT=r"Total LUTs:\s*(\d+)", FF=r"Total Registers:\s*(\d+)",
                             LUTRAM=r"LUTs as dram:\s*(\d+)", logic_LUT=r"LUTs as logic:\s*(\d+)")
    resource = {key: int(re.findall(pattern, log)[-1]) for key, pattern in resource_patterns.items()}
    btb_start = re.search(r"(?m)^module rv32_btb\b", netlist).start()
    btb = netlist[btb_start:netlist.index("endmodule", btb_start)]
    loop_rams = re.findall(r"GTP_RAM32X2SP\s*/\*\s*(loop_(?:count|trip)_\d+)\s*\*/", btb)
    assert len(loop_rams) == 8
    source_hashes = {p.name: sha(p) for p in sorted((folder / "inputs/rtl").glob("*.sv"))}
    assert len(source_hashes) == 18 and source_hashes["rv32_btb.sv"] == change["parent_btb_sha256"]
    snapshots.append(dict(build=name, netlist=str(netlist_path), netlist_sha256=sha(netlist_path),
                          synthesis_log=str(log_path), log_sha256=sha(log_path),
                          source_core_sha256=source_hashes["rv32_core.sv"], all18source_hashes=source_hashes,
                          resources=resource, direct_target_adder_bits=bits(direct),
                          merged_target_selection_carry_bits=bits(merged), selected_cells=chosen,
                          post_sum_mux_example=post_mux, loop_count_trip_RAM_primitives=loop_rams,
                          target_attribute_recognition=[dict(line=index + 1, literal=line)
                              for index, line in enumerate(log.splitlines())
                              if "rv32_core.sv(line number: 521)" in line and "Convert attribute name from syn_keep to PAP_KEEP" in line],
                          netlist_target_has_explicit_PAP_KEEP_comment=bool(re.search(r"PAP_KEEP[^\n]*frontend_direct_target", text))))

old, new = snapshots
assert old["source_core_sha256"] == change["baseline_sha256"]
assert new["source_core_sha256"] == change["modified_sha256"]
assert old["direct_target_adder_bits"] == list(range(1, 21))
assert old["merged_target_selection_carry_bits"] == list(range(21, 32))
assert new["direct_target_adder_bits"] == list(range(1, 32))
assert new["merged_target_selection_carry_bits"] == []
assert len(new["target_attribute_recognition"]) == 1
assert not old["target_attribute_recognition"]
assert new["resources"] == dict(LUT=6143, FF=2561, LUTRAM=471, logic_LUT=5672)
assert old["resources"] == dict(LUT=6134, FF=2561, LUTRAM=471, logic_LUT=5663)
assert [name for name in old["all18source_hashes"] if old["all18source_hashes"][name] != new["all18source_hashes"][name]] == ["rv32_core.sv"]
for item in new["selected_cells"]:
    inputs = " ".join(value for key, value in item["ports"].items() if key.startswith("I") or key == "CIN")
    assert "frontend_return" not in inputs and "frontend_ras_target" not in inputs and "frontend_direct_jal" not in inputs
assert len(new["post_sum_mux_example"]) == 1
mux = new["post_sum_mux_example"][0]
assert mux["ports"]["I0"] == "frontend_direct_jal" and mux["ports"]["I1"] == "frontend_return"
assert mux["ports"]["I2"] == "frontend_direct_target[2]" and mux["ports"]["I3"] == "frontend_ras_target[2]"
for name, expected in artifacts_before.items():
    assert sha(AREA / name) == expected
for relative, expected in change["protected_parents"].items():
    assert sha(ROOT / relative) == expected
result = dict(status="PASS_ACTUAL_TARGET_ADDER_BOUNDARY_CHANGED", snapshots=snapshots,
    delta={key: new["resources"][key] - old["resources"][key] for key in old["resources"]},
    full_width="All31 nontrivial sum bits are independent mapped carry outputs; bit0 is the unchanged aligned offset0/PC0 alias",
    attribute="Actual ADS analyze log line151 recognizes source line521 syn_keep as PAP_KEEP. Final netlist has no explicit target PAP_KEEP annotation; claim recognition plus observed structural effect, not preserved output annotation.",
    mechanism="Old late return selection fed merged carry at bits21..31. New separate direct-target adder reaches bit31 before later LUT muxes combine direct/RAS/BTB targets; the identified carry fusion is removed.",
    area="Actual synthesis +9logic LUT, unchanged2561FF/471LUTRAM and all8 count/trip RAM cells. H4 synthesis6332 -> new6143 saves189LUT; routed footprint/timing remain pending. The old routed6581..6619 is not a prediction of new routed resources.",
    physical_route_result="PENDING; no new route is launched by this audit",
    artifact_freeze_preserved=artifacts_before, protected_parent_files=70,
    production_files_modified=0, new_PDS_or_simulation_started=0)
(AREA / "PRODUCTION_MAPPING.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8-sig")
lines = ["# Actual SG26 direct-target boundary mapping", "", result["mechanism"], "", result["attribute"], "",
         "| ADS synthesis | LUT | FF | LUTRAM | Logic LUT |", "|---|---:|---:|---:|---:|"]
for item in snapshots:
    r = item["resources"]
    lines.append(f"| {item['build']} | {r['LUT']} | {r['FF']} | {r['LUTRAM']} | {r['logic_LUT']} |")
lines += ["", result["area"], "", "Source: `" + new["source_core_sha256"] + "`; BTB remains `" + change["parent_btb_sha256"] + "`.", "",
          "Old independent target adder outputs: bits1..20. Old merged carry/target outputs: bits21..31. New independent target adder outputs: bits1..31. No N1140 carry outputs remain. The mapped post-sum N1140_16[2] LUT explicitly takes direct_target[2] and RAS[2], selected by direct_jal/frontend_return.", ""]
for item in snapshots:
    lines += ["## " + item["build"], "", "Netlist SHA256: `" + item["netlist_sha256"] + "`", ""]
    for cell in item["selected_cells"]:
        lines += ["Cell `" + cell["name"] + "`, netlist line" + str(cell["netlist_line"]), "", "```verilog", cell["literal"], "```", ""]
lines += ["Four original artifacts and FINAL_RECHECK remain byte-identical. Both parent candidate sets remain unchanged. This audit reads actual synthesis; physical timing and routed resources require the root's separate jobs.", ""]
(AREA / "PRODUCTION_MAPPING.md").write_text("\n".join(lines), encoding="utf-8-sig")
assert read(AREA / "PRODUCTION_MAPPING.json")["status"] == result["status"]
assert (AREA / "PRODUCTION_MAPPING.md").read_bytes()
print("RAM_TARGET_KEEP_PRODUCTION_MAPPING_PASS old_independent_bits=1..20 old_merged_bits=21..31 new_independent_bits=1..31 new_merged_carry=0 ADS_attribute_recognized=1 LUT_delta=+9 FF_delta=0 LUTRAM_delta=0 parent_frozen=70 artifacts_unchanged=5 exit=0")

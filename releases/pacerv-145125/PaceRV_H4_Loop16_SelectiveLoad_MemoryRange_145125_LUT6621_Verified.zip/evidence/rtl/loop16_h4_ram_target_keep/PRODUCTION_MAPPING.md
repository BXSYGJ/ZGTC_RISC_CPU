﻿# Actual SG26 direct-target boundary mapping

Old late return selection fed merged carry at bits21..31. New separate direct-target adder reaches bit31 before later LUT muxes combine direct/RAS/BTB targets; the identified carry fusion is removed.

Actual ADS analyze log line151 recognizes source line521 syn_keep as PAP_KEEP. Final netlist has no explicit target PAP_KEEP annotation; claim recognition plus observed structural effect, not preserved output annotation.

| ADS synthesis | LUT | FF | LUTRAM | Logic LUT |
|---|---:|---:|---:|---:|
| sg25-loop-single-write-synth | 6134 | 2561 | 471 | 5663 |
| sg26-ram-target-keep-synth | 6143 | 2561 | 471 | 5672 |

Actual synthesis +9logic LUT, unchanged2561FF/471LUTRAM and all8 count/trip RAM cells. H4 synthesis6332 -> new6143 saves189LUT; routed footprint/timing remain pending. The old routed6581..6619 is not a prediction of new routed resources.

Source: `9896d2d8177cd69adda9a4399839023dac5a37d2343e5e0e74d117ddf152a411`; BTB remains `13aa9b1196adc482149b3414f62d752e787ded7a9b0bf06438b28e9be8a563c8`.

Old independent target adder outputs: bits1..20. Old merged carry/target outputs: bits21..31. New independent target adder outputs: bits1..31. No N1140 carry outputs remain. The mapped post-sum N1140_16[2] LUT explicitly takes direct_target[2] and RAS[2], selected by direct_jal/frontend_return.

## sg25-loop-single-write-synth

Netlist SHA256: `5fe04eadbd1a2469b80da0b06b221f3b8b290cc70f49f63bc380d06ba87bc7b3`

Cell `N1076_0_22`, netlist line62779

```verilog
GTP_LUT6CARRY /* N1076_0_22 */ #(
            .INIT(64'b1101011110000010110101111000001001111101001010000111110100101000), 
            .I5_TO_CARRY("TRUE"), 
            .I5_TO_LUT("FALSE"))
        N1076_0_22 (
            .COUT (_N1238),
            .Z (N1140[22]),
            .CIN (_N1237),
            .I0 (frontend_direct_jal),
            .I1 (frontend_pc[22]),
            .I2 (frontend_direct_offset[20]),
            .I3 (_N7698),
            .I4 (),
            .I5 (frontend_direct_offset[20]));
```

Cell `N1076_0_23`, netlist line62797

```verilog
GTP_LUT6CARRY /* N1076_0_23 */ #(
            .INIT(64'b1101011110000010110101111000001001111101001010000111110100101000), 
            .I5_TO_CARRY("TRUE"), 
            .I5_TO_LUT("FALSE"))
        N1076_0_23 (
            .COUT (_N1239),
            .Z (N1140[23]),
            .CIN (_N1238),
            .I0 (frontend_direct_jal),
            .I1 (frontend_pc[23]),
            .I2 (frontend_direct_offset[20]),
            .I3 (_N7699),
            .I4 (),
            .I5 (frontend_direct_offset[20]));
```

Cell `N1076_0_24`, netlist line62815

```verilog
GTP_LUT6CARRY /* N1076_0_24 */ #(
            .INIT(64'b1101011110000010110101111000001001111101001010000111110100101000), 
            .I5_TO_CARRY("TRUE"), 
            .I5_TO_LUT("FALSE"))
        N1076_0_24 (
            .COUT (_N1240),
            .Z (N1140[24]),
            .CIN (_N1239),
            .I0 (frontend_direct_jal),
            .I1 (frontend_pc[24]),
            .I2 (frontend_direct_offset[20]),
            .I3 (_N7700),
            .I4 (),
            .I5 (frontend_direct_offset[20]));
```

## sg26-ram-target-keep-synth

Netlist SHA256: `f6797781f0acada42fbd682632fb584fb6b7b1363c9e9e1ddbc02baa257750c1`

Cell `N1076_0_22`, netlist line62681

```verilog
GTP_LUT6CARRY /* N1076_0_22 */ #(
            .INIT(64'b1001001111000110100100111001001101101100001110010110110001101100), 
            .I5_TO_CARRY("TRUE"), 
            .I5_TO_LUT("FALSE"))
        N1076_0_22 (
            .COUT (_N1238),
            .Z (frontend_direct_target[22]),
            .CIN (_N1237),
            .I0 (frontend_direct_c),
            .I1 (frontend_pc[22]),
            .I2 (frontend_buffered_instruction[12]),
            .I3 (frontend_buffered_length[1]),
            .I4 (_N3925),
            .I5 (frontend_pc[22]));
```

Cell `N1076_0_23`, netlist line62699

```verilog
GTP_LUT6CARRY /* N1076_0_23 */ #(
            .INIT(64'b1001001111000110100100111001001101101100001110010110110001101100), 
            .I5_TO_CARRY("TRUE"), 
            .I5_TO_LUT("FALSE"))
        N1076_0_23 (
            .COUT (_N1239),
            .Z (frontend_direct_target[23]),
            .CIN (_N1238),
            .I0 (frontend_direct_c),
            .I1 (frontend_pc[23]),
            .I2 (frontend_buffered_instruction[12]),
            .I3 (frontend_buffered_length[1]),
            .I4 (_N3925),
            .I5 (frontend_pc[23]));
```

Cell `N1076_0_24`, netlist line62717

```verilog
GTP_LUT6CARRY /* N1076_0_24 */ #(
            .INIT(64'b1001001111000110100100111001001101101100001110010110110001101100), 
            .I5_TO_CARRY("TRUE"), 
            .I5_TO_LUT("FALSE"))
        N1076_0_24 (
            .COUT (_N1240),
            .Z (frontend_direct_target[24]),
            .CIN (_N1239),
            .I0 (frontend_direct_c),
            .I1 (frontend_pc[24]),
            .I2 (frontend_buffered_instruction[12]),
            .I3 (frontend_buffered_length[1]),
            .I4 (_N3925),
            .I5 (frontend_pc[24]));
```

Four original artifacts and FINAL_RECHECK remain byte-identical. Both parent candidate sets remain unchanged. This audit reads actual synthesis; physical timing and routed resources require the root's separate jobs.

﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $target = [System.IO.Path]::GetFullPath($TargetPath)
    $baseline = [System.IO.Path]::GetFullPath($BaselinePath)
    if ($target -eq $baseline) { throw 'Use an independent target copy' }
    if ((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '5E81F9C56246E502B43C6A48C14342DBB16AC437788AC01D00A482D9A06CA84B') { throw 'Baseline hash mismatch' }
    Copy-Item -LiteralPath $baseline -Destination $target -Force
    $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($hash -ne '5E81F9C56246E502B43C6A48C14342DBB16AC437788AC01D00A482D9A06CA84B') { throw 'Restore hash mismatch' }
    Write-Output ('RAM_TARGET_KEEP_ROLLBACK_PASS SHA256=' + $hash)
    exit 0
} catch { Write-Error $_; exit 1 }

﻿[CmdletBinding()]
param()
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $area = $PSScriptRoot
    $target = [System.IO.Path]::Combine($area, 'rollback_extension_test.sv')
    $baseline = [System.IO.Path]::Combine($area, 'BASELINE_FILE.sv')
    $modified = [System.IO.Path]::Combine($area, 'rv32_core.sv')
    $rollback = [System.IO.Path]::Combine($area, 'ROLLBACK.sh')
    $originalHash = (Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash
    $candidateHash = (Get-FileHash -LiteralPath $modified -Algorithm SHA256).Hash
    Copy-Item -LiteralPath $modified -Destination $target -Force
    $command = '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; $ErrorActionPreference = ''Stop''; try { $area = (Get-Location).Path; $script = [System.IO.Path]::Combine($area, ''ROLLBACK.sh''); $target = [System.IO.Path]::Combine($area, ''rollback_extension_test.sv''); $baseline = [System.IO.Path]::Combine($area, ''BASELINE_FILE.sv''); & ([ScriptBlock]::Create((Get-Content -LiteralPath $script -Raw -Encoding utf8))) -TargetPath $target -BaselinePath $baseline } catch { Write-Error $_; exit 1 }'
    $start = [System.Diagnostics.ProcessStartInfo]::new()
    $start.FileName = (Get-Process -Id $PID).Path
    $start.WorkingDirectory = $area
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $start.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    foreach ($argument in @('-NoProfile', '-NonInteractive', '-Command', $command)) {
        [void]$start.ArgumentList.Add($argument)
    }
    $process = [System.Diagnostics.Process]::Start($start)
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    $restoredHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($process.ExitCode -ne 0) { throw ('Rollback exit ' + $process.ExitCode + ': ' + $stderr) }
    if ($restoredHash -ne $originalHash) { throw 'Rollback did not restore original bytes.' }
    if ((Get-FileHash -LiteralPath $modified -Algorithm SHA256).Hash -ne $candidateHash) {
        throw 'Active modified source hash changed.'
    }
    $result = [ordered]@{
        command = @($start.FileName, '-NoProfile', '-NonInteractive', '-Command', $command)
        working_directory = $area
        input = $target
        input_sha256 = $candidateHash
        rollback_script = $rollback
        rollback_sha256 = (Get-FileHash -LiteralPath $rollback -Algorithm SHA256).Hash
        literal_output = $stdout
        stderr = $stderr
        exit_status = $process.ExitCode
        restored_sha256 = $restoredHash
        active_modified_sha256 = $candidateHash
        restored_behavior = 'Original core bytes and load interlocks restored on independent copy; modified source retained.'
    }
    $file = [System.IO.Path]::Combine($area, 'ROLLBACK_SH_RESULT.json')
    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $file -Encoding utf8BOM
    $reopened = Get-Content -LiteralPath $file -Raw -Encoding utf8 | ConvertFrom-Json
    if ($reopened.restored_sha256 -ne $originalHash) { throw 'Reopened receipt differs.' }
    Write-Output ('ROLLBACK_SH_VERIFIED exit=0 restored=' + $restoredHash + ' active_modified=' + $candidateHash)
    exit 0
} catch {
    Write-Error $_
    exit 1
}

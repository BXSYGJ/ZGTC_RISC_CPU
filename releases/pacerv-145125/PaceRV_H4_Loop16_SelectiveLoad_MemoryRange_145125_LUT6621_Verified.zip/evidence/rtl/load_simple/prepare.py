"""Prepare a pinned ADD/XOR-only load consumer without changing existing inputs."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
SOURCE=ROOT/'candidates'/'id_equal_history6'/'rtl'
baseline=(SOURCE/'rv32_core.sv').read_bytes()
text=baseline.decode('utf-8')
old='    wire load_use_wait=LOAD_USE_BUBBLE!=0 && !equality_branch && !load_address_bypass && mem_valid'
new='''    // Only ADD/ADDI and XOR/XORI consume a load response in this path.
    // Other integer operations retain the original one-cycle load interlock.
    wire load_simple_class=(ex_instruction[6:0]==7'h13 ||
        (ex_instruction[6:0]==7'h33 && ex_instruction[31:25]!=1)) &&
        !ex_decode.illegal && (ex_decode.alu_op==0 || ex_decode.alu_op==5);
    wire load_use_wait=LOAD_USE_BUBBLE!=0 && !equality_branch && !load_address_bypass && !load_simple_class && mem_valid'''
assert text.count(old)==1
text=text.replace(old,new)
old='    reg branch_taken;'
new='''    wire [31:0] load_simple_b=ex_decode.alu_immediate ? ex_decode.immediate : branch_operand_b;
    wire use_load_simple=LOAD_USE_BUBBLE!=0 && load_simple_class && early_load_dependency;
    // Eight-bit carry-select groups keep the response adder bounded. The
    // dedicated path contains addition and XOR only, with no shift/compare mux.
    wire [8:0] load_simple_byte0={1'b0,branch_operand_a[7:0]}+{1'b0,load_simple_b[7:0]};
    (* syn_keep=1 *) wire [8:0] load_simple_byte1_zero={1'b0,branch_operand_a[15:8]}+{1'b0,load_simple_b[15:8]};
    (* syn_keep=1 *) wire [7:0] load_simple_byte1_one=branch_operand_a[15:8]+load_simple_b[15:8]+8'd1;
    (* syn_keep=1 *) wire [8:0] load_simple_byte2_zero={1'b0,branch_operand_a[23:16]}+{1'b0,load_simple_b[23:16]};
    (* syn_keep=1 *) wire [7:0] load_simple_byte2_one=branch_operand_a[23:16]+load_simple_b[23:16]+8'd1;
    (* syn_keep=1 *) wire [7:0] load_simple_byte3_zero=branch_operand_a[31:24]+load_simple_b[31:24];
    (* syn_keep=1 *) wire [7:0] load_simple_byte3_one=branch_operand_a[31:24]+load_simple_b[31:24]+8'd1;
    wire load_simple_propagate1=&(branch_operand_a[15:8]^load_simple_b[15:8]);
    wire load_simple_propagate2=&(branch_operand_a[23:16]^load_simple_b[23:16]);
    wire load_simple_carry16=load_simple_byte1_zero[8] || (load_simple_propagate1 && load_simple_byte0[8]);
    wire load_simple_carry24=load_simple_byte2_zero[8] || (load_simple_propagate2 && load_simple_byte1_zero[8]) ||
        (load_simple_propagate2 && load_simple_propagate1 && load_simple_byte0[8]);
    wire [31:0] load_simple_sum={load_simple_carry24 ? load_simple_byte3_one : load_simple_byte3_zero,
        load_simple_carry16 ? load_simple_byte2_one : load_simple_byte2_zero[7:0],
        load_simple_byte0[8] ? load_simple_byte1_one : load_simple_byte1_zero[7:0],load_simple_byte0[7:0]};
    wire [31:0] load_simple_result=ex_decode.alu_op==5 ? branch_operand_a^load_simple_b : load_simple_sum;
    reg branch_taken;'''
assert text.count(old)==1
text=text.replace(old,new)
assert text.count('        execute_result=alu_result;')==1
text=text.replace('        execute_result=alu_result;','        execute_result=use_load_simple ? load_simple_result : alu_result;')
candidate=text.encode('utf-8')
(AREA/'BASELINE_FILE.sv').write_bytes(baseline)
(AREA/'rv32_core.sv').write_bytes(candidate)
(AREA/'DIFF_FILE.diff').write_text(''.join(difflib.unified_diff(baseline.decode().splitlines(True),text.splitlines(True),fromfile='BASELINE_FILE.sv',tofile='rv32_core.sv')),encoding='utf-8')
target=ROOT/'candidates'/'load_simple'/'rtl'
target.mkdir(parents=True,exist_ok=True)
for p in SOURCE.glob('*.sv'):
    shutil.copy2(p,target/p.name)
(target/'rv32_core.sv').write_bytes(candidate)
physical=ROOT/'candidates'/'load_simple'/'physical_rtl'
physical.mkdir(parents=True,exist_ok=True)
for p in (ROOT/'work'/'physical-noif-nocross-loadalu-history6-local-s1'/'inputs'/'rtl').glob('*.sv'):
    shutil.copy2(p,physical/p.name)
(physical/'rv32_core.sv').write_bytes(candidate)
tb=(AREA.parent/'id_equal_load_alu'/'core_token_tb.sv').read_text()
tb=tb.replace('integer alu_load_pairs=0,alu_same_cycle=0,alu_waits=0;','integer alu_load_pairs=0,alu_same_cycle=0,alu_waits=0;\n    integer simple_pairs=0,simple_same_cycle=0,other_waits=0;\n    wire independent_simple=(dut.ex_instruction[14:12]==0 &&\n        (dut.ex_instruction[6:0]==7\'h13 || !dut.ex_instruction[30])) || dut.ex_instruction[14:12]==4;')
tb=tb.replace('if(LOAD_ALU_MODE!=0 && !dut.ex_fire) $fatal(1,"Eligible ALU did not complete with valid load response");','''if(LOAD_ALU_MODE==1 && !dut.ex_fire) $fatal(1,"Eligible ALU did not complete with valid load response");
                    if(LOAD_ALU_MODE==2 && independent_simple && !dut.ex_fire) $fatal(1,"Eligible ADD/XOR did not consume valid load response");
                    if(LOAD_ALU_MODE==2 && !independent_simple && dut.ex_fire) $fatal(1,"Unsupported operation lost its load-use bubble");
                    if(independent_simple) begin
                        simple_pairs=simple_pairs+1;
                        if(dut.ex_fire) simple_same_cycle=simple_same_cycle+1;
                    end else if(!dut.ex_fire) other_waits=other_waits+1;''')
tb=tb.replace('alu_waits=0;\n            traps=0;','alu_waits=0;simple_pairs=0;simple_same_cycle=0;other_waits=0;\n            traps=0;')
tb=tb.replace('if(LOAD_ALU_MODE==0 && alu_waits==0)', '''if(LOAD_ALU_MODE==2 && simple_same_cycle==0) $fatal(1,"No ADD/XOR load completion observed");
                if(LOAD_ALU_MODE==2 && which!=21 && other_waits==0) $fatal(1,"No preserved unsupported-op wait observed");
                $display("LOAD_SIMPLE_COVER scenario=%0d simple=%0d same_cycle=%0d other_waits=%0d",which,simple_pairs,simple_same_cycle,other_waits);
                if(LOAD_ALU_MODE==0 && alu_waits==0)''')
(AREA/'core_token_tb.sv').write_text(tb,encoding='utf-8')
sha=lambda b:hashlib.sha256(b).hexdigest()
record=dict(baseline=str(SOURCE/'rv32_core.sv'),baseline_sha256=sha(baseline),candidate_sha256=sha(candidate),changed_field='load_use_wait ADD/ADDI/XOR/XORI class exception; dedicated grouped addition/XOR result selected on load dependency',test_sha256=sha(tb.encode()),candidate_rtl=str(target),physical_rtl=str(physical),physical_files=len(list(physical.glob('*.sv'))))
(AREA/'CHANGE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('LOAD_SIMPLE_PREPARED baseline='+record['baseline_sha256']+' modified='+record['candidate_sha256']+' physical_files='+str(record['physical_files']))

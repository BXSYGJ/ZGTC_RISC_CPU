"""Confirm the bypass and preserved-interlock monitors reject opposite errors."""
from pathlib import Path
import json
import subprocess

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
SOURCE = ROOT / 'candidates' / 'id_equal_history6' / 'rtl'
common = [str(p) for p in sorted(SOURCE.glob('*.sv')) if p.name != 'rv32_core.sv']
records = []
for label, path, expected in (
    ('removed_bypass', AREA / 'BASELINE_FILE.sv', 'Eligible ADD/XOR did not consume valid load response'),
    ('overbypass', AREA.parent / 'id_equal_load_alu' / 'rv32_core.sv', 'Unsupported operation lost its load-use bubble'),
):
    binary = AREA / ('negative_' + label + '.vvp')
    compile_command = ['iverilog', '-g2012', '-s', 'core_token_tb',
                       '-Pcore_token_tb.LOAD_ALU_MODE=2', '-o', str(binary),
                       str(AREA / 'core_token_tb.sv'), str(path), *common]
    compiled = subprocess.run(compile_command, cwd=AREA, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True, timeout=180)
    (AREA / ('negative_' + label + '-compile.log')).write_text(compiled.stdout, encoding='utf-8')
    assert compiled.returncode == 0, compiled.stdout
    command = ['vvp', str(binary)]
    run = subprocess.run(command, cwd=AREA, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True, timeout=180)
    (AREA / ('negative_' + label + '.log')).write_text(run.stdout, encoding='utf-8')
    assert run.returncode != 0 and expected in run.stdout, run.stdout[-5000:]
    records.append(dict(label=label, input=str(path), compile_command=compile_command,
                        compile_exit_status=compiled.returncode, command=command,
                        literal_output=run.stdout, exit_status=run.returncode,
                        expected_failure=expected, expected_failure_observed=True))
    print('LOAD_SIMPLE_NEGATIVE_PASS label=' + label + ' expected_exit=' +
          str(run.returncode) + ' expected_message=' + expected)
(AREA / 'NEGATIVE_CONTROLS.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')

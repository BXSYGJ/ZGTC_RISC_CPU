"""Prove actual bypass classification equals the four legal ISA operations."""
from pathlib import Path
import hashlib
import json
import subprocess

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
core = (AREA / 'rv32_core.sv').read_text()
start = core.index('    wire load_simple_class=')
end = core.index('    wire load_use_wait=', start)
classification = core[start:end].replace('ex_instruction', 'instruction')
classification = classification.replace('ex_decode.illegal', 'illegal')
classification = classification.replace('ex_decode.alu_op', 'alu_op')
decode = ROOT / 'candidates' / 'load_simple' / 'rtl' / 'rv32_decode.sv'
miter = '\n'.join([
    'module decode_class_miter(input [31:0] instruction, output same);',
    'wire illegal; wire [3:0] alu_op;',
    'rv32_decode #(.ENABLE_M(1)) decode(.instruction(instruction),',
    '    .illegal(illegal), .alu_op(alu_op));',
    classification,
    "wire op_add_xor=(instruction[6:0]==7'h33 && instruction[31:25]==7'h00 &&",
    "    (instruction[14:12]==3'b000 || instruction[14:12]==3'b100));",
    "wire immediate_add_xor=(instruction[6:0]==7'h13 &&",
    "    (instruction[14:12]==3'b000 || instruction[14:12]==3'b100));",
    'assign same=load_simple_class==(op_add_xor || immediate_add_xor);',
    'endmodule',
    '',
])
(AREA / 'decode_class_miter.sv').write_text(miter, encoding='utf-8')
command = ['yosys', '-p', 'read_verilog -sv ' + str(decode) +
           '; read_verilog -sv decode_class_miter.sv; prep -top decode_class_miter -flatten; '
           'sat -verify -prove same 1 -show-inputs']
run = subprocess.run(command, cwd=AREA, stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True, timeout=180)
(AREA / 'formal-decode-class.log').write_text(run.stdout, encoding='utf-8')
assert run.returncode == 0 and 'SAT proof finished - no model found: SUCCESS!' in run.stdout, run.stdout
result = dict(command=command, working_directory=str(AREA),
              input_instruction='unconstrained 32-bit binary instruction',
              production_classification=classification,
              decode_sha256=hashlib.sha256(decode.read_bytes()).hexdigest(),
              core_sha256=hashlib.sha256((AREA / 'rv32_core.sv').read_bytes()).hexdigest(),
              literal_output=run.stdout, exit_status=run.returncode,
              result='Exactly legal ADD, ADDI, XOR, XORI selected for all 2^32 instruction words; SUB and M excluded.')
(AREA / 'DECODER_CLASSIFICATION.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('LOAD_SIMPLE_DECODE_SAT_PASS instructions=all_2^32 legal_operations=ADD,ADDI,XOR,XORI SUB_M=excluded exit=0')

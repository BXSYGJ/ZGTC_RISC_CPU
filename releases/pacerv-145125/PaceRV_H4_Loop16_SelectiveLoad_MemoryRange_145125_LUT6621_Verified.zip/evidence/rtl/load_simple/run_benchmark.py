"""Run the selective load core using the pinned compiler and original C inputs."""
from pathlib import Path
import argparse
import importlib.util
import json
import re
import shutil

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
spec=importlib.util.spec_from_file_location('experiment',ROOT/'scripts'/'experiment.py')
e=importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--label',required=True)
    p.add_argument('--role',choices=('V0','V1'),default='V0')
    p.add_argument('--iterations',type=int,default=100)
    p.add_argument('--reuse-firmware')
    action=p.add_mutually_exclusive_group()
    action.add_argument('--build-only',action='store_true')
    action.add_argument('--run-existing',action='store_true')
    a=p.parse_args()
    if not re.fullmatch(r'cf4-[A-Za-z0-9_-]+',a.label):
        p.error('Use a cf4-* token label')
    target=ROOT/'work'/a.label
    if a.run_existing:
        meta=json.loads((target/'BUILD.json').read_text())
        assert meta['iterations']==a.iterations and meta['role']==a.role
        assert e.sha(target/'firmware.hex')==meta['firmware_hex_sha256']
        if (target/'RUN.json').exists():
            raise RuntimeError('Existing measured results remain preserved')
    elif target.exists():
        raise RuntimeError('Use a fresh output directory')
    elif a.reuse_firmware:
        source=ROOT/'work'/a.reuse_firmware
        meta=json.loads((source/'BUILD.json').read_text())
        assert meta['iterations']==a.iterations and meta['role']==a.role
        assert e.sha(source/'firmware.hex')==meta['firmware_hex_sha256']
        target.mkdir()
        for n in ('firmware.hex','firmware.elf','firmware.bin','firmware.dis','BUILD.json'):
            shutil.copy2(source/n,target/n)
        e.write_json(target/'REUSE.json',dict(source=str(source),sha256=e.sha(source/'firmware.hex')))
    else:
        e.PROFILES['selective-tune5']=['-fno-if-conversion','-fno-if-conversion2','-fno-crossjumping','-mtune=sifive-5-series']
        target=e.firmware('selective-tune5',a.iterations,a.role,a.label)
    print('SELECTIVE_FIRMWARE '+str(target)+' sha256='+e.sha(target/'firmware.hex'),flush=True)
    if a.build_only:
        return
    executable,identity=e.simulator(ROOT/'candidates'/'load_simple'/'rtl',1,2)
    print('SELECTIVE_SIMULATOR '+str(executable)+' identity='+identity,flush=True)
    e.run(target,executable,identity,2400000000,1)

if __name__=='__main__':
    main()

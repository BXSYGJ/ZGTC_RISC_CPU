﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string] $TargetPath,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string] $BaselinePath)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $resolvedTarget = [System.IO.Path]::GetFullPath($TargetPath)
    $resolvedBaseline = [System.IO.Path]::GetFullPath($BaselinePath)
    if (-not (Test-Path -LiteralPath $resolvedTarget -PathType Leaf)) { throw 'Target missing.' }
    if ($resolvedTarget -eq $resolvedBaseline) { throw 'Use a separate target copy.' }
    Copy-Item -LiteralPath $resolvedBaseline -Destination $resolvedTarget -Force
    $hash = (Get-FileHash -LiteralPath $resolvedTarget -Algorithm SHA256).Hash
    if ($hash -ne (Get-FileHash -LiteralPath $resolvedBaseline -Algorithm SHA256).Hash) { throw 'Restored hash differs.' }
    Write-Output ('LOAD_SIMPLE_ROLLBACK_PASS SHA256=' + $hash)
    exit 0
} catch { Write-Error $_; exit 1 }
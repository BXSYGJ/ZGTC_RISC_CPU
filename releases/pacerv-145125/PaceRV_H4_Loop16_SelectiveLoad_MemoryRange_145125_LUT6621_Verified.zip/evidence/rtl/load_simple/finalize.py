"""Collect immutable directed, compiler, rollback and actual CoreMark evidence."""
from pathlib import Path
import hashlib
import json

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    change = read(AREA / 'CHANGE.json')
    evidence = read(AREA / 'VERIFICATION.txt')
    frozen = read(AREA / 'FIRMWARE_READY.json')
    assert sha(AREA / 'BASELINE_FILE.sv') == change['baseline_sha256']
    assert sha(AREA / 'rv32_core.sv') == change['candidate_sha256']
    assert sha(AREA / 'rollback_test.sv') == change['baseline_sha256']
    assert sha(ROOT / 'candidates' / 'id_equal_history6' / 'rtl' / 'rv32_core.sv') == change['baseline_sha256']
    for directory in ('rtl', 'physical_rtl'):
        assert sha(ROOT / 'candidates' / 'load_simple' / directory / 'rv32_core.sv') == change['candidate_sha256']
    for item in frozen['physical_inventory']:
        assert sha(ROOT / 'candidates' / 'load_simple' / 'physical_rtl' / item['name']) == item['sha256']

    expected = {
        (100, 'V0'): ['0xe714', '0x1fd7', '0x8e3a', '0x988c'],
        (100, 'V1'): ['0xe3c1', '0x0747', '0x8d84', '0x844d'],
        (6000, 'V0'): ['0xe714', '0x1fd7', '0x8e3a', '0xa14c'],
        (6000, 'V1'): ['0xe3c1', '0x0747', '0x8d84', '0x18e1'],
    }
    runs = []
    pending = []
    for iterations in (100, 6000):
        for role in ('V0', 'V1'):
            target = ROOT / 'work' / f'cf4-loadsimple-tune5-i{iterations}-{role}'
            path = target / 'RUN.json'
            if not path.exists():
                pending.append(str(path))
                continue
            run = read(path)
            build = read(target / 'BUILD.json')
            assert run['firmware'] == build
            assert build['iterations'] == iterations and build['role'] == role
            assert sha(target / 'firmware.hex') == build['firmware_hex_sha256']
            assert run['exit_status'] == 0 and all(run['checks'].values())
            assert run['crc_fields'] == expected[iterations, role]
            assert run['stdout'] == (target / 'simulation.log').read_text()
            assert run['timed_cycles'] > 0 and run['retired'] > 0
            assert run['coremark_per_mhz'] == iterations * 1e6 / run['timed_cycles']
            assert 'GCC 10.2.0' in run['stdout']
            for flag in ('-fno-if-conversion', '-fno-if-conversion2', '-fno-crossjumping', '-mtune=sifive-5-series'):
                assert flag in build['command']
            inputs = ROOT / 'firmware' / role / 'inputs'
            for name, original_sha in build['source_hashes'].items():
                assert sha(inputs / name) == original_sha
            if iterations == 6000:
                assert run['formal_ten_seconds']
                assert run['duration_at_145125MHz_seconds'] >= 10
                assert 'Correct operation validated.' in run['stdout']
                assert 'Errors detected' not in run['stdout']
                assert not run['error_lines']
                frozen_role = next(x for x in frozen['firmware'] if x['role'] == role)
                assert sha(target / 'firmware.hex') == frozen_role['sha256']
            runs.append(dict(label=target.name, run_json=str(path),
                             run_json_sha256=sha(path), command=run['command'],
                             input=build, working_directory=run['working_directory'],
                             literal_output=run['stdout'], exit_status=run['exit_status'],
                             cycles=run['timed_cycles'], retired=run['retired'],
                             coremark_per_mhz=run['coremark_per_mhz'],
                             duration_seconds=run['duration_at_145125MHz_seconds'],
                             formal_ten_seconds=run['formal_ten_seconds'],
                             crc_fields=run['crc_fields'], rtl_sha256=run['rtl_sha256']))

    assert len({x['rtl_sha256'] for x in runs}) <= 1
    v0 = next(x for x in runs if x['label'].endswith('i100-V0'))
    baseline_target = ROOT / 'work' / 'cf2-h6-noload-tune5-i100-V0'
    baseline = read(baseline_target / 'RUN.json')
    assert sha(baseline_target / 'firmware.hex') == v0['input']['firmware_hex_sha256']
    assert baseline['retired'] == v0['retired']
    assert baseline['crc_fields'] == v0['crc_fields']
    comparison = dict(baseline_cycles=baseline['timed_cycles'],
                      modified_cycles=v0['cycles'],
                      cycles_saved=baseline['timed_cycles'] - v0['cycles'],
                      same_firmware_sha256=v0['input']['firmware_hex_sha256'],
                      identical_retired=v0['retired'],
                      baseline_coremark_per_mhz=baseline['coremark_per_mhz'],
                      modified_coremark_per_mhz=v0['coremark_per_mhz'])
    result = dict(status='COMPLETE' if not pending else 'LONG_MEASUREMENTS_ACTIVE',
                  changed_field=change['changed_field'],
                  baseline_sha256=change['baseline_sha256'],
                  modified_sha256=change['candidate_sha256'],
                  comparison=comparison, runs=runs, pending=pending,
                  physical_overlay=frozen['physical_rtl'],
                  physical_files=len(frozen['physical_inventory']))
    (AREA / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    evidence['benchmark_status'] = result['status']
    evidence['benchmark_comparison'] = comparison
    evidence['benchmarks'] = runs
    evidence['pending_long_measurements'] = pending
    evidence['physical_inventory'] = frozen['physical_inventory']
    for name in ('ROLLBACK_SH_RESULT.json', 'NEGATIVE_CONTROLS.json',
                 'DECODER_CLASSIFICATION.json', 'PHYSICAL_OVERLAY_VERIFICATION.json'):
        if (AREA / name).exists():
            evidence[name.removesuffix('.json')] = read(AREA / name)
    (AREA / 'VERIFICATION.txt').write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
    for name in ('rv32_core.sv', 'DIFF_FILE.diff', 'VERIFICATION.txt', 'ROLLBACK.sh', 'RESULTS.json'):
        assert (AREA / name).read_bytes()
    print('LOAD_SIMPLE_EVIDENCE_PASS status=' + result['status'] +
          ' verified_runs=' + str(len(runs)) + ' pending=' + str(len(pending)) +
          ' cycles_saved=' + str(comparison['cycles_saved']))
    for item in runs:
        print(item['label'] + ' cycles=' + str(item['cycles']) +
              ' CoreMark/MHz=' + str(item['coremark_per_mhz']) +
              ' duration=' + str(item['duration_seconds']) +
              ' formal=' + str(item['formal_ten_seconds']) + ' exit=0')


if __name__ == '__main__':
    main()

module simple_alu_miter(input [31:0] a,b,input is_xor,output same);
    wire [8:0] byte0={1'b0,a[7:0]}+{1'b0,b[7:0]};
    (* syn_keep=1 *) wire [8:0] byte1_zero={1'b0,a[15:8]}+{1'b0,b[15:8]};
    (* syn_keep=1 *) wire [7:0] byte1_one=a[15:8]+b[15:8]+8'd1;
    (* syn_keep=1 *) wire [8:0] byte2_zero={1'b0,a[23:16]}+{1'b0,b[23:16]};
    (* syn_keep=1 *) wire [7:0] byte2_one=a[23:16]+b[23:16]+8'd1;
    (* syn_keep=1 *) wire [7:0] byte3_zero=a[31:24]+b[31:24];
    (* syn_keep=1 *) wire [7:0] byte3_one=a[31:24]+b[31:24]+8'd1;
    wire load_simple_propagate1=&(a[15:8]^b[15:8]);
    wire load_simple_propagate2=&(a[23:16]^b[23:16]);
    wire load_simple_carry16=byte1_zero[8] || (load_simple_propagate1 && byte0[8]);
    wire load_simple_carry24=byte2_zero[8] || (load_simple_propagate2 && byte1_zero[8]) ||
        (load_simple_propagate2 && load_simple_propagate1 && byte0[8]);
    wire [31:0] load_simple_sum={load_simple_carry24 ? byte3_one : byte3_zero,
        load_simple_carry16 ? byte2_one : byte2_zero[7:0],
        byte0[8] ? byte1_one : byte1_zero[7:0],byte0[7:0]};
    wire [31:0] load_simple_result=is_xor ? a^b : load_simple_sum;

wire [31:0] expected=is_xor ? a^b : a+b;
assign same=expected==load_simple_result;
endmodule

module decode_class_miter(input [31:0] instruction, output same);
wire illegal; wire [3:0] alu_op;
rv32_decode #(.ENABLE_M(1)) decode(.instruction(instruction),
    .illegal(illegal), .alu_op(alu_op));
    wire load_simple_class=(instruction[6:0]==7'h13 ||
        (instruction[6:0]==7'h33 && instruction[31:25]!=1)) &&
        !illegal && (alu_op==0 || alu_op==5);

wire op_add_xor=(instruction[6:0]==7'h33 && instruction[31:25]==7'h00 &&
    (instruction[14:12]==3'b000 || instruction[14:12]==3'b100));
wire immediate_add_xor=(instruction[6:0]==7'h13 &&
    (instruction[14:12]==3'b000 || instruction[14:12]==3'b100));
assign same=load_simple_class==(op_add_xor || immediate_add_xor);
endmodule

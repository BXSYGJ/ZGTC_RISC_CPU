﻿# Selective load consumer follow-up

Updated 2026-11-17T04:13:02.1286860+08:00

Status: COMPLETE_LONG_MEASUREMENTS_VERIFIED
Core SHA256 5E81F9C56246E502B43C6A48C14342DBB16AC437788AC01D00A482D9A06CA84B
Original H6 core SHA256 0E59ABBAA86A691F60317D51E9B07535A3CFCAA69685FC98FC3AE69CFADF2883

ADD/ADDI and XOR/XORI use the dedicated byte carry-select adder/XOR load-response path. Other dependencies retain original load bubbles. No new source features will be added.

Directed BASELINE/MODIFIED/ROLLBACK: 23 scenarios pass; 595 retirement/trap trace lines identical. Modified supported same-cycle completions 8+13+1; unsupported-operation waits31+13 remain.
Production arithmetic SAT: all65 binary inputs prove sum/XOR equivalence.
Decoder SAT: all2^32 instruction words prove bypass selects exactly legal ADD,ADDI,XOR,XORI; SUB and M excluded.
Negative controls: removing selective bypass and extending to fullALU each trigger intended independent monitor with exit1.
PowerShell7 executes ROLLBACK.sh content on an independent copy, exit0 restores original hash; active modified copy unchanged.

Same100 V0 exact firmware SHA25639504B698A04826E0584891B9CD321B73C1F3990FD3AF6FE8DE66268F8801355:
Baseline H6 tune5 cycles28551502 /3.5024427086182714 CoreMark/MHz.
Selective load cycles28486907 /3.5103846128328358 CoreMark/MHz; saved64595cycles; same27236534retired, allCRC e714/1fd7/8e3a/988c.
V1 short cycles28495942 /3.5092716008475873 CoreMark/MHz; allCRC e3c1/0747/8d84/844d.
Both short tests exit0 and UART/observer counts match. Their measured intervals are less than10seconds.

6000 V0 and V1 simulations completed with frozen identity35A9F550E8B55E746FFCD40AB78AAF6B0D6064ADF5F210CDBF2C9AFD0C7D85C5.
GCC10.2 originalCoreMark inputs, noif/nocross/tune5,145125000Hz; FIRMWARE_READY.json stores exact paths/commands/hashes.
V0 firmware SHA256941041B71BD0B8A3075BD3470FDD566605492F3CEB21BA8FAEA677DD230BC0CF.
V1 firmware SHA2569F97816A605E829D4A9345A3C739CD25603A60C99D6555533A3876DCCDE655DB.

Physical overlay has18files; only rv32_core.sv differs from original highscore physical inputs. Overlay hashes verified in PHYSICAL_OVERLAY_VERIFICATION.json.
Root-owned first actual physical result cf4-physical-loadsimple-tune5-local-s1: slow setup-0.234ns/TNS-5.470ns/71endpoints; allnineothercategoriespass; LUT7131 FF2541. No PDS launched by this worker.

Four review artifacts: rv32_core.sv, DIFF_FILE.diff, VERIFICATION.txt, ROLLBACK.sh. Exact directed commands, input, literal output and exit status are in VERIFICATION.txt.
RESULTS.json records all four actual short/long measurements; pending list is empty. finalize.py reopens and verifies every completed result, unchanged sourcehash and frozen overlay.

FINAL 2026-11-17T04:35:24.6815842+08:00
Both actual6000 runs completed exit0 with Correct operation validated, matching atomic UART/observer counts and all four expected CRCs.
V0 timed_cycles1708737607 retired1634152429 /3.5113641646443847 CoreMark/MHz /11.774247076658053seconds /CRC e714,1fd7,8e3a,a14c.
V1 timed_cycles1709422750 retired1634361529 /3.509956796819277 CoreMark/MHz /11.77896813092162seconds /CRC e3c1,0747,8d84,18e1.
V0 exceeds3.51; V1 is0.000043203180723below3.51 and exceeds the maxcyclethreshold by21041cycles. Both functional/formal-duration checks pass.
Source hashes, originalCoreMarkinputhashes, frozen6000firmwarehashes, all18physicalfiles, and independentrollbackverified.
No benchmark/native simulator remains; no PDS launched by this worker.
Review artifacts reopened: rv32_core.sv,DIFF_FILE.diff,VERIFICATION.txt,ROLLBACK.sh,RESULTS.json,FIRMWARE_READY.json.

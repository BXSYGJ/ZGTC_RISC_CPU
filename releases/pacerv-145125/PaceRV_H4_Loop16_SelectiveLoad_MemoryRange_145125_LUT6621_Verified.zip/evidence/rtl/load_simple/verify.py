"""Verify selective load bypass, preserved bubbles, formal sum, and rollback."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import time

AREA=Path(__file__).resolve().parent
ROOT=AREA.parents[1]
SOURCE=ROOT/'candidates'/'id_equal_history6'/'rtl'
change=json.loads((AREA/'CHANGE.json').read_text(encoding='utf-8-sig'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run(argv,label,timeout=180):
    start=time.monotonic()
    r=subprocess.run(argv,cwd=AREA,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    (AREA/(label+'.log')).write_text(r.stdout,encoding='utf-8')
    record=dict(command=argv,input_directory=str(AREA),literal_output=r.stdout,exit_status=r.returncode,seconds=time.monotonic()-start)
    if r.returncode:
        raise RuntimeError(label+': '+r.stdout[-5000:])
    return record

core=[]
common=[str(p) for p in sorted(SOURCE.glob('*.sv')) if p.name!='rv32_core.sv']
for name,path,mode in [('BASELINE','BASELINE_FILE.sv',0),('MODIFIED','rv32_core.sv',2),('ROLLBACK','rollback_test.sv',0)]:
    binary=name.lower()+'.vvp'
    compile_record=run(['iverilog','-g2012','-s','core_token_tb','-Pcore_token_tb.LOAD_ALU_MODE='+str(mode),'-o',binary,'core_token_tb.sv',path,*common],name.lower()+'-compile')
    result=run(['vvp',binary],name.lower())
    assert 'CORE_TOKEN_PASS early=1 mode=1 scenarios=23' in result['literal_output']
    architectural=[x for x in result['literal_output'].splitlines() if x.startswith(('ARCH ','TRAP '))]
    if core:
        assert architectural==core[0]['architectural_trace'],name+' architecture mismatch'
    cover=[x for x in result['literal_output'].splitlines() if x.startswith(('LOAD_SIMPLE_COVER ','LOAD_ALU_COVER ','CORE_CASE_PASS '))]
    core.append(dict(name=name,source=path,source_sha256=sha(AREA/path),compile=compile_record,run=result,architectural_trace=architectural,coverage=cover))
    print(name+' CORE_TOKEN_PASS early=1 mode=1 scenarios=23 exit=0',flush=True)

# Extract the actual production arithmetic text so SAT covers its grouping,
# selected carries and XOR path over all 2^65 binary input combinations.
production=(AREA/'rv32_core.sv').read_text()
start=production.index('    wire [8:0] load_simple_byte0=')
end=production.index('    reg branch_taken;',start)
cone=production[start:end].replace('branch_operand_a','a').replace('load_simple_b','b').replace('ex_decode.alu_op==5','is_xor')
formal='module simple_alu_miter(input [31:0] a,b,input is_xor,output same);\n'+cone+'\nwire [31:0] expected=is_xor ? a^b : a+b;\nassign same=expected==load_simple_result;\nendmodule\n'
(AREA/'simple_alu_miter.sv').write_text(formal,encoding='utf-8')
proof=run(['yosys','-p','read_verilog -sv simple_alu_miter.sv; prep -top simple_alu_miter -flatten; sat -verify -prove same 1 -show-inputs'],'formal-simple-alu')
assert 'SAT proof finished - no model found: SUCCESS!' in proof['literal_output']
print('LOAD_SIMPLE_ALU_SAT_PASS operands=unconstrained select=unconstrained add_xor=proven exit=0',flush=True)
for role,path,expected in [('baseline','BASELINE_FILE.sv',change['baseline_sha256']),('modified','rv32_core.sv',change['candidate_sha256']),('rollback','rollback_test.sv',change['baseline_sha256'])]:
    assert sha(AREA/path)==expected,role
assert sha(SOURCE/'rv32_core.sv')==change['baseline_sha256']
for entry in core:
    entry['architectural_lines']=len(entry.pop('architectural_trace'))
evidence=dict(changed_field=change['changed_field'],MODIFIED_FILE=str(AREA/'rv32_core.sv'),DIFF_FILE=str(AREA/'DIFF_FILE.diff'),VERIFICATION=str(AREA/'VERIFICATION.txt'),ROLLBACK=str(AREA/'ROLLBACK.sh'),baseline_sha256=change['baseline_sha256'],modified_sha256=change['candidate_sha256'],core_tests=core,formal=proof,rollback=json.loads((AREA/'ROLLBACK_RESULT.json').read_text(encoding='utf-8-sig')),restored_behavior='Independent rollback copy restores all original source bytes and original load interlocks; active modified copy preserves ADD/XOR-only bypass. All23 architectural traces match the baseline.')
(AREA/'VERIFICATION.txt').write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
summary=dict(architectural_match=True,scenarios=23,baseline_sha256=change['baseline_sha256'],modified_sha256=change['candidate_sha256'],all_exit_zero=True,formal_add_xor_all_inputs=True,core_coverage={x['name']:x['coverage'] for x in core})
(AREA/'DIRECTED_VERIFICATION.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for n in ('rv32_core.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh'):
    assert (AREA/n).read_bytes()
print('LOAD_SIMPLE_DIRECTED_PASS scenarios=23 architectural_trace=identical unsupported_bubbles=preserved BASELINE/MODIFIED/ROLLBACK exit=0',flush=True)

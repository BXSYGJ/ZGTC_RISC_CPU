﻿[CmdletBinding()]
param()
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
$OutputEncoding=[System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference='Stop'
try {
    $target=[System.IO.Path]::Combine($PSScriptRoot,'rollback_sources')
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    $source=[System.IO.Path]::Combine($PSScriptRoot,'MODIFIED_FILE.sv')
    $destination=[System.IO.Path]::Combine($target,'rv32_btb.sv')
    Copy-Item -LiteralPath $source -Destination $destination -Force
    $before=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    $payload=[ScriptBlock]::Create([System.IO.File]::ReadAllText([System.IO.Path]::Combine($PSScriptRoot,'ROLLBACK.sh')))
    $literal=(& $payload -TargetDirectory $target -BaselineFile ([System.IO.Path]::Combine($PSScriptRoot,'BASELINE_FILE.sv')) | Out-String).Trim()
    $restored=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
    if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $before){throw 'Active modified source changed'}
    $receipt=[ordered]@{Command='pwsh -NoProfile -File Test-Rollback.ps1';Input=$target;InputModifiedSHA256=$before;LiteralOutput=$literal;ExitStatus=0;RestoredSHA256=$restored;ActiveModifiedSHA256=$before}
    [System.IO.File]::WriteAllText([System.IO.Path]::Combine($PSScriptRoot,'ROLLBACK_RESULT.json'),($receipt | ConvertTo-Json -Depth 6),[System.Text.UTF8Encoding]::new($true))
    Write-Output $literal
} catch {Write-Error $_;exit 1}
﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetDirectory,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselineFile)
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
$OutputEncoding=[System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference='Stop'
try {
    $target=[System.IO.Path]::GetFullPath($TargetDirectory)
    $baseline=[System.IO.Path]::GetFullPath($BaselineFile)
    $destination=[System.IO.Path]::Combine($target,'rv32_btb.sv')
    if($destination -eq $baseline){throw 'Use an independent target directory'}
    if(-not(Test-Path -LiteralPath $target -PathType Container)){throw 'Target directory missing'}
    if((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '47573AE5B351A71C6BC453901822CA8910E7696C170BCA71ECD77FB8EB5B0993'){throw 'Baseline hash mismatch'}
    Copy-Item -LiteralPath $baseline -Destination $destination -Force
    if((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne '47573AE5B351A71C6BC453901822CA8910E7696C170BCA71ECD77FB8EB5B0993'){throw 'Restore hash mismatch'}
    Write-Output 'SL_LOOP16_ROLLBACK_PASS SHA256=47573AE5B351A71C6BC453901822CA8910E7696C170BCA71ECD77FB8EB5B0993'
} catch {Write-Error $_;exit 1}

from pathlib import Path
import hashlib
import json
import subprocess
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
BASE=ROOT/'candidates/load_simple'
DEST=ROOT/'candidates/load_simple_loop16'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
change=load(HERE/'CHANGE.json')
rollback=load(HERE/'ROLLBACK_RESULT.json')
assert sha(HERE/'rollback_sources/rv32_btb.sv')==change['baseline_btb_sha256']
assert sha(HERE/'rv32_btb.sv')==sha(HERE/'MODIFIED_FILE.sv')==change['modified_btb_sha256']
assert sha(BASE/'rtl/rv32_core.sv')==change['retained_core_sha256']
common=[str(p) for p in sorted((BASE/'rtl').glob('*.sv')) if p.name!='rv32_btb.sv']
receipts=[]
for label,btb in (('BASELINE',HERE/'BASELINE_FILE.sv'),('MODIFIED',HERE/'MODIFIED_FILE.sv'),('ROLLBACK',HERE/'rollback_sources/rv32_btb.sv')):
    output=HERE/(label.lower()+'-core.vvp')
    command=['iverilog','-g2012','-s','core_token_tb','-Pcore_token_tb.LOAD_ALU_MODE=2','-o',str(output),str(HERE/'core_token_tb.sv'),str(btb),*common]
    build=subprocess.run(command,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label.lower()+'-compile.log')).write_text(build.stdout,encoding='utf-8')
    assert build.returncode==0,build.stdout[-3000:]
    run_command=['vvp',str(output)]
    run=subprocess.run(run_command,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label.lower()+'-core.log')).write_text(run.stdout,encoding='utf-8')
    assert run.returncode==0 and 'CORE_TOKEN_PASS early=1 mode=1 scenarios=23' in run.stdout,run.stdout[-3000:]
    receipts.append(dict(label=label,compile_command=command,compile_exit_status=build.returncode,command=run_command,input=dict(BTB=str(btb),sha256=sha(btb),core=change['retained_core_sha256'],mode=2),literal_output=run.stdout,exit_status=run.returncode))
    print(label+' SL_LOOP16_CORE_PASS scenarios=23 exit=0',flush=True)
assert receipts[0]['literal_output']==receipts[2]['literal_output']
arch=lambda text:[line for line in text.splitlines() if line.startswith('ARCH ')]
assert arch(receipts[0]['literal_output'])==arch(receipts[1]['literal_output'])
result=dict(status='PASS',changed_field=change['changed_field'],core=receipts,rollback=rollback,
            baseline_rollback_full_cycle_equal=True,modified_full_cycle_equal=receipts[0]['literal_output']==receipts[1]['literal_output'],architecture_lines=len(arch(receipts[0]['literal_output'])))
(HERE/'CORE_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('SL_LOOP16_CORE_FINAL_PASS scenarios=23 BMR_architecture=equal baseline_rollback_cycles=equal modified_cycles_equal='+str(result['modified_full_cycle_equal']),flush=True)

from pathlib import Path
import importlib.util
import json
import shutil
import argparse

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
spec=importlib.util.spec_from_file_location('loop16_experiment',ROOT/'scripts/experiment.py')
ex=importlib.util.module_from_spec(spec)
spec.loader.exec_module(ex)
parser=argparse.ArgumentParser()
parser.add_argument('--role',choices=('V0','V1'),required=True)
parser.add_argument('--baseline',action='store_true')
args=parser.parse_args()
role=args.role
name='sg-loop16-sl-h6-baseline-i100-'+role if args.baseline else 'sg-loop16-sl-i100-'+role
target=ROOT/'work'/name
if target.exists():
    raise RuntimeError('Use a new output directory: '+str(target))
ex.PROFILES['loop16-sl-tune5']=['-fno-if-conversion','-fno-if-conversion2','-fno-crossjumping','-mtune=sifive-5-series']
target=ex.firmware('loop16-sl-tune5',100,role,name)
expected={'V0':'39504b698a04826e0584891b9cd321b73c1f3990fd3af6fe8de66268f8801355'}
if role in expected:
    assert ex.sha(target/'firmware.hex')==expected[role]
rtl=ROOT/'candidates'/('load_simple' if args.baseline else 'load_simple_loop16')/'rtl'
executable,identity=ex.simulator(rtl,1,2)
print('SL_LOOP16_SCREEN_START '+role+' baseline='+str(args.baseline)+' FW='+ex.sha(target/'firmware.hex')+' RTL='+identity,flush=True)
ex.run(target,executable,identity,60000000,1)
result=json.loads((target/'RUN.json').read_text())
shutil.copy2(target/'RUN.json',HERE/('SCREEN-'+('BASELINE-' if args.baseline else 'MODIFIED-')+role+'.json'))
print('SL_LOOP16_SCREEN_PASS '+role+' baseline='+str(args.baseline)+' score='+str(result['coremark_per_mhz'])+' cycles='+str(result['timed_cycles']),flush=True)

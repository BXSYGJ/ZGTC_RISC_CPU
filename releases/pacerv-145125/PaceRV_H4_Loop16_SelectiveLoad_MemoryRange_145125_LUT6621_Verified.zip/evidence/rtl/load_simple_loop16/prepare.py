from pathlib import Path
import difflib
import hashlib
import json
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
BASE=ROOT/'candidates/load_simple'
LOOP=ROOT/'candidates/id_equal_loop16'
DEST=ROOT/'candidates/load_simple_loop16'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

assert sha(BASE/'rtl/rv32_core.sv')=='5e81f9c56246e502b43c6a48c14342dbb16ac437788ac01d00a482d9a06ca84b'
assert sha(BASE/'rtl/rv32_btb.sv')=='47573ae5b351a71c6bc453901822ca8910e7696c170bca71ecd77fb8eb5b0993'
assert sha(LOOP/'rtl/rv32_btb.sv')=='222223a16f58695fa149a0b709acaebfa2bab479b0acea916dfef76c9e8581ba'
assert 'load_simple_class' not in (LOOP/'rtl/rv32_core.sv').read_text()
for p in (BASE/'rtl').glob('*.sv'):
    if p.name not in ('rv32_core.sv','rv32_btb.sv'):
        assert p.read_bytes()==(LOOP/'rtl'/p.name).read_bytes(),p.name
shutil.copy2(BASE/'rtl/rv32_btb.sv',HERE/'BASELINE_FILE.sv')
shutil.copy2(LOOP/'rtl/rv32_btb.sv',HERE/'MODIFIED_FILE.sv')
shutil.copy2(HERE/'MODIFIED_FILE.sv',HERE/'rv32_btb.sv')
old=(HERE/'BASELINE_FILE.sv').read_text()
new=(HERE/'MODIFIED_FILE.sv').read_text()
(HERE/'DIFF_FILE.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='SelectiveLoad-H6/rv32_btb.sv',tofile='SelectiveLoad-Loop16/rv32_btb.sv')),encoding='utf-8')
change=dict(changed_field='Replace only SelectiveLoad H6 BTB by proven H3+16-entry loop predictor; retain full ADD/XOR selective load bypass and all other 16/17 RTL files exactly.',
            baseline_btb_sha256=sha(HERE/'BASELINE_FILE.sv'),modified_btb_sha256=sha(HERE/'MODIFIED_FILE.sv'),
            retained_core_sha256=sha(BASE/'rtl/rv32_core.sv'),loop_original_core_sha256=sha(LOOP/'rtl/rv32_core.sv'),
            loop_original_has_selective_load=False,source_chain={'base':str(BASE),'predictor_donor':str(LOOP)})
for folder,total in (('rtl',17),('physical_rtl',18)):
    directory=DEST/folder
    directory.mkdir(parents=True,exist_ok=True)
    for p in (BASE/folder).glob('*.sv'):
        shutil.copy2(HERE/'MODIFIED_FILE.sv' if p.name=='rv32_btb.sv' else p,directory/p.name)
    assert len(list(directory.glob('*.sv')))==total
    change[folder]={p.name:sha(p) for p in sorted(directory.glob('*.sv'))}
    assert all(p.name=='rv32_btb.sv' or p.read_bytes()==(BASE/folder/p.name).read_bytes() for p in directory.glob('*.sv'))
shutil.copy2(ROOT/'rtl_proposals/load_simple/core_token_tb.sv',HERE/'core_token_tb.sv')
(HERE/'CHANGE.json').write_text(json.dumps(change,indent=2)+'\n',encoding='utf-8-sig')
rollback=['#!/usr/bin/env pwsh','[CmdletBinding()]',"param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetDirectory,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselineFile)",
          '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8',"$OutputEncoding=[System.Text.UTF8Encoding]::new($true)","$ErrorActionPreference='Stop'",'try {',
          '    $target=[System.IO.Path]::GetFullPath($TargetDirectory)','    $baseline=[System.IO.Path]::GetFullPath($BaselineFile)',
          "    $destination=[System.IO.Path]::Combine($target,'rv32_btb.sv')",
          "    if($destination -eq $baseline){throw 'Use an independent target directory'}",
          "    if(-not(Test-Path -LiteralPath $target -PathType Container)){throw 'Target directory missing'}",
          "    if((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '"+change['baseline_btb_sha256'].upper()+"'){throw 'Baseline hash mismatch'}",
          '    Copy-Item -LiteralPath $baseline -Destination $destination -Force',
          "    if((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne '"+change['baseline_btb_sha256'].upper()+"'){throw 'Restore hash mismatch'}",
          "    Write-Output 'SL_LOOP16_ROLLBACK_PASS SHA256="+change['baseline_btb_sha256'].upper()+"'",'} catch {Write-Error $_;exit 1}']
for name in ('ROLLBACK.sh','ROLLBACK.ps1'):
    (HERE/name).write_text('\n'.join(rollback)+'\n',encoding='utf-8-sig')
print('SL_LOOP16_PREPARED core='+change['retained_core_sha256']+' BTB='+change['modified_btb_sha256']+' frozen=17/18',flush=True)

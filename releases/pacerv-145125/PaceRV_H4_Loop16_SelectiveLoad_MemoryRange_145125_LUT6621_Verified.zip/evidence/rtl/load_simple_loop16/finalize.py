from pathlib import Path
import hashlib
import json
import math

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
change=load(HERE/'CHANGE.json')
core=load(HERE/'CORE_VERIFICATION.json')
assert core['architecture_lines']==591 and core['modified_full_cycle_equal']
screens=[]
for role in ('V0','V1'):
    old=load(ROOT/('work/cf4-loadsimple-tune5-i100-'+role+'/RUN.json'))
    new=load(HERE/('SCREEN-MODIFIED-'+role+'.json'))
    assert new['firmware']['firmware_hex_sha256']==old['firmware']['firmware_hex_sha256']
    assert all(new['checks'].values()) and all(old['checks'].values())
    screens.append(dict(role=role,baseline=old,modified=new,
                        cycle_delta=new['timed_cycles']-old['timed_cycles'],
                        saving_required_to_exceed_3p5=new['timed_cycles']-math.ceil(100e6/3.5)+1))
for folder in ('rtl','physical_rtl'):
    for name,expected in change[folder].items():
        assert sha(ROOT/'candidates/load_simple_loop16'/folder/name)==expected
        if name!='rv32_btb.sv':
            assert sha(ROOT/'candidates/load_simple'/folder/name)==expected
summary=dict(status='FUNCTIONAL_PASS_SHORT_SCORE_BELOW_3P5',changed_field=change['changed_field'],
             source_chain=change,core=core,screens=screens,
             full_ten_second_run_launched=False,PDS_launched=False,
             modified_btb_left_changed=sha(HERE/'MODIFIED_FILE.sv')==change['modified_btb_sha256'],
             restored_behavior='Actual rollback restores original H6 BTB; all 23 core scenarios and complete 591 ARCH lines match baseline and modified outputs.',
             artifacts={name:str(HERE/name) for name in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')})
(HERE/'VERIFICATION.txt').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
artifacts={name:dict(path=str(HERE/name),sha256=sha(HERE/name),bytes=len((HERE/name).read_bytes())) for name in summary['artifacts']}
assert load(HERE/'VERIFICATION.txt')==summary
(HERE/'FINAL_RECHECK.json').write_text(json.dumps(dict(status='PASS',artifacts=artifacts,short_scores={r['role']:r['modified']['coremark_per_mhz'] for r in screens}),indent=2)+'\n',encoding='utf-8')
print('SL_LOOP16_FINAL_PASS BMR_core23=equal ARCH=591 RTL=17/18 artifacts=reopened V0='+str(screens[0]['modified']['coremark_per_mhz'])+' V1='+str(screens[1]['modified']['coremark_per_mhz'])+' short_both_gt3p5=False')

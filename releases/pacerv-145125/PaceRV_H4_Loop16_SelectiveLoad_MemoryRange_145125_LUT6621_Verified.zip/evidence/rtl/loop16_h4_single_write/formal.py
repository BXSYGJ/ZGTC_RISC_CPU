"""Extract actual production loop blocks and prove every binary state transition."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
change=load(HERE/'CHANGE.json')
before=(HERE/'BASELINE_FILE.sv').read_text()
after=(HERE/'MODIFIED_FILE.sv').read_text()
assert change['before']==before and change['after']==after
assert sha(HERE/'BASELINE_FILE.sv')==change['baseline_sha256'] and sha(HERE/'MODIFIED_FILE.sv')==change['modified_sha256']
def production_blocks(text):
    start=text.index('\n',text.index('    wire loop_prediction='))+1
    section=text[start:text.index('    assign predicted_taken=')]
    matches=re.findall(r'^    always (@\(([^)]+)\)|@\*) begin\n(.*?)^    end\n',section,flags=re.M|re.S)
    blocks=[(event or '*',body) for syntax,event,body in matches]
    assert len(blocks) in (1,4)
    return blocks

def model(name,text,address):
    arrays=[('loop_tag',address-1),('loop_count',8),('loop_trip',8),('loop_confidence',2),('loop_overflow',1),('loop_direction',1),('loop_ahead',1)]
    total=16+sum(16*width for _,width in arrays)
    lines=['module '+name+'(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input['+str(total-1)+':0]state,output['+str(total-1)+':0]next_state);',
           'localparam ADDRESS_BITS='+str(address)+'; localparam LOOP_COUNT_BITS=8;',
           'wire[15:0]loop_valid=state[15:0]; reg[15:0]n_loop_valid;',
           'assign next_state[15:0]=n_loop_valid;']
    if 'loop_count_write_data' in text:
        lines+=['reg [7:0]loop_count_write_data,loop_trip_write_data;reg loop_count_write_enable,loop_trip_write_enable;']
    at=16
    for array,width in arrays:
        lines+=['wire['+str(width-1)+':0]'+array+'[0:15];reg['+str(width-1)+':0]n_'+array+'[0:15];']
        for index in range(16):
            lines+=['assign '+array+'['+str(index)+']=state['+str(at)+'+:'+str(width)+'];',
                    'assign next_state['+str(at)+'+:'+str(width)+']=n_'+array+'['+str(index)+'];']
            at+=width
    assert at==total
    lines+=['wire loop_update_match=loop_valid[loop_update_index] && loop_tag[loop_update_index]==update_pc[ADDRESS_BITS-1:1];',
            'integer j;always @* begin n_loop_valid=loop_valid;for(j=0;j<16;j=j+1)begin']
    for array,width in arrays:
        lines+=['n_'+array+'[j]='+array+'[j];']
    lines+=['end']
    for event,body in production_blocks(text):
        body=re.sub(r'\b(loop_(?:valid|tag|count|trip|confidence|overflow|direction|ahead))(\[[^\]]+\])?\s*<=',lambda m:'n_'+m[1]+(m[2] or '')+'=',body)
        if event=='*':
            lines+=[body]
        else:
            gate='clk_event || reset_fall' if 'negedge rst_n' in event else 'clk_event'
            lines+=['if('+gate+')begin',body,'end']
    lines+=['end endmodule']
    return '\n'.join(lines)+'\n',total

receipts=[]
def run(command,label,expected=0):
    p=subprocess.run(command,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout,encoding='utf-8')
    result=dict(command=command,input_directory=str(HERE),literal_output=p.stdout,exit_status=p.returncode)
    assert p.returncode==expected,p.stdout[-3000:]
    return result
for address in (8,16,32):
    a,total=model('baseline_loop',before,address)
    b,total2=model('modified_loop',after,address)
    assert total==total2
    port='input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc'
    signals='.clk_event(clk_event),.reset_fall(reset_fall),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc)'
    miter='module loop_transition_miter('+port+',input['+str(total-1)+':0]state,output same);wire['+str(total-1)+':0]a,b;baseline_loop aa('+signals+',.state(state),.next_state(a));modified_loop bb('+signals+',.state(state),.next_state(b));assign same=(reset_fall && rst_n) || a==b;endmodule\n'
    seqsignals=signals.replace('.reset_fall(reset_fall)','.reset_fall(reset_fall && !rst_n)')
    seq='module loop_sequence_miter(input clk,'+port+',output same);reg['+str(total-1)+':0]qa,qb;wire['+str(total-1)+':0]a,b;baseline_loop aa('+seqsignals+',.state(qa),.next_state(a));modified_loop bb('+seqsignals+',.state(qb),.next_state(b));always @(posedge clk)begin qa<=a;qb<=b;end assign same=qa==qb;endmodule\n'
    path=HERE/('loop_transition_'+str(address)+'.sv')
    path.write_text(a+b+miter+seq,encoding='utf-8')
    proof=run(['yosys','-p','read_verilog -sv '+path.name+'; prep -top loop_transition_miter -flatten; memory_map; opt; sat -verify -prove same 1 -show-inputs'],'transition-'+str(address))
    assert 'SAT proof finished - no model found: SUCCESS!' in proof['literal_output']
    sequence=run(['yosys','-p','read_verilog -sv '+path.name+'; prep -top loop_sequence_miter -flatten; memory_map; opt; sat -seq 3 -tempinduct -set-init-zero -verify -prove same 1'],'sequence-'+str(address))
    assert 'Induction step proven: SUCCESS!' in sequence['literal_output']
    receipts.append(dict(address_bits=address,state_bits=total,transition=proof,sequence=sequence))
    print('LOOP_SINGLE_WRITE_SAT_PASS address='+str(address)+' all_current_states=True all_next_bits='+str(total)+' legal_async_reset=True induction=unbounded',flush=True)
negative=after.replace("loop_trip_write_data=8'd0;","loop_trip_write_data=8'd1;",1)
assert negative!=after
negative_model,total=model('modified_loop',negative,16)
original,total2=model('baseline_loop',before,16)
positive=(HERE/'loop_transition_16.sv').read_text()
miter=positive[positive.index('module loop_transition_miter'):positive.index('module loop_sequence_miter')]
(HERE/'negative_transition.sv').write_text(original+negative_model+miter,encoding='utf-8')
rejected=run(['yosys','-p','read_verilog -sv negative_transition.sv; prep -top loop_transition_miter -flatten; memory_map; opt; sat -verify -prove same 1 -show-inputs'],'transition-negative',1)
assert 'proof did fail' in rejected['literal_output']
result=dict(status='PASS',actual_production_sources={name:sha(HERE/name) for name in ('BASELINE_FILE.sv','MODIFIED_FILE.sv')},source_text_bound=True,
            all_binary_current_states=True,all_next_state_bits_compared=True,legal_asynchronous_reset_events=True,
            sequential_induction_unbounded=True,configurations=receipts,negative_control=rejected)
(HERE/'FORMAL_EQUIVALENCE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('LOOP_SINGLE_WRITE_FORMAL_FINAL_PASS configs=3 transitions=all_binary induction=unbounded negative_control=rejected',flush=True)

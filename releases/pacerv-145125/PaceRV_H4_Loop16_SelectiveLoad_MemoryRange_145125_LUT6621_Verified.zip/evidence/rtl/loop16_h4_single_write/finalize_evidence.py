"""Bind saved SG25 long runs and four actual physical failures, without new work."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ref(path):
    return dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    assert load(path)==value

short_path=HERE/'SHORT_VERIFICATION_FROZEN.txt'
old_recheck_path=HERE/'SHORT_FINAL_RECHECK_FROZEN.json'
if not short_path.exists():
    old=load(HERE/'FINAL_RECHECK.json')
    assert sha(HERE/'VERIFICATION.txt')==old['artifacts']['VERIFICATION.txt']['sha256']
    shutil.copy2(HERE/'VERIFICATION.txt',short_path)
    shutil.copy2(HERE/'FINAL_RECHECK.json',old_recheck_path)
short=load(short_path)
old_recheck=load(old_recheck_path)
assert sha(short_path)==old_recheck['artifacts']['VERIFICATION.txt']['sha256']
audit_run=subprocess.run([sys.executable,'-I',str(HERE/'finalize_longs.py')],capture_output=True,text=True)
assert audit_run.returncode==0,audit_run.stdout+audit_run.stderr
longs=load(HERE/'LONG_FINAL_AUDIT.json')
assert longs['status']=='PASS_BOTH_ACTUAL6000_GT3P5' and not longs['pending']
assert not longs['production_RTL_changed'] and not longs['processes_launched_or_restarted']
change=load(HERE/'CHANGE.json')
for folder,total in (('rtl',17),('physical_rtl',18)):
    actual={p.name:sha(p) for p in (ROOT/'candidates/loop16_h4_single_write'/folder).glob('*.sv')}
    assert len(actual)==total and actual==change[folder]
assert sha(HERE/'MODIFIED_FILE.sv')==sha(HERE/'rv32_btb.sv')==change['modified_sha256']
assert sha(HERE/'BASELINE_FILE.sv')==change['baseline_sha256']
core=load(HERE/'CORE_VERIFICATION.json')
assert core['status']=='PASS' and core['architecture_lines']==591
assert core['modified_full_cycle_equal'] and core['baseline_rollback_full_cycle_equal']
assert core==short['core_BMR']
assert core['rollback']==short['rollback']
bmr=[]
for row in core['core']:
    assert row['exit_status']==row['compile_exit_status']==0
    bmr.append(dict(label=row['label'],compile_command=row['compile_command'],compile_exit_status=0,
                    command=row['command'],input=row['input'],literal_result=row['literal_output'].strip().splitlines()[-1],
                    full_literal_output_sha256=hashlib.sha256(row['literal_output'].encode()).hexdigest(),exit_status=0))
proof_names=('CORE_VERIFICATION.json','PREDICTOR_CHECKS.json','FORMAL_EQUIVALENCE.json','FOUR_STATE_EQUIVALENCE.json','FULL100_INTERFACE_EQUIVALENCE.json','ROLLBACK_RESULT.json')
proofs={name:ref(HERE/name) for name in proof_names}
formal=load(HERE/'FORMAL_EQUIVALENCE.json')
assert formal['status']=='PASS' and formal['sequential_induction_unbounded']
assert formal['negative_control']['exit_status']==1
full100=load(HERE/'FULL100_INTERFACE_EQUIVALENCE.json')
assert full100['status']=='PASS_BOTH_ROLES_ACTUAL_FULL100' and not full100['pending']
physical=[]
for seed in range(1,5):
    target=ROOT/'work'/('sg25-loop-single-write-s'+str(seed))
    build=load(target/'BUILD_RESULT.json')
    timing=load(target/'TIMING_SUMMARY.json')
    assert build['Status']=='completed_timing_fail' and build['Timing']==timing
    assert build['ConfiguredCpuClockHz']==timing['ConfiguredCpuClockHz']==145125000
    assert build['SetupUncertaintyNs']==timing['SetupUncertaintyNs']==0.150
    assert not timing['AllReportedChecksPass'] and len(timing['Checks'])==10
    assert {p.name:sha(p) for p in (target/'inputs/rtl').glob('*.sv')}==change['physical_rtl']
    inputs=load(target/'INPUT_HASHES.json')
    for row in inputs:
        actual=target/'inputs'/row['RelativePath']
        assert sha(actual)==row['SHA256'].lower()
    rtr=target/'implementation/report_timing/pds_soc_top.rtr'
    assert sha(rtr)==timing['ReportSHA256'].lower()
    bit=target/'implementation/generate_bitstream/pds_soc_top.sbit'
    assert sha(bit)==build['Bitstream']['SHA256'].lower()
    slow=timing['Checks']['Setup_Slow'][0]
    assert slow['WorstSlackNs']<0 and slow['FailingEndpoints']>0
    physical.append(dict(build=target.name,seed=seed,status=build['Status'],configured_clock_hz=145125000,
                         setup_uncertainty_ns=0.150,LUT=build['Resources']['LUT'],FF=build['Resources']['FF'],
                         resources={k:v for k,v in build['Resources'].items() if k!='RawRows'},
                         worst_setup_slack_ns=slow['WorstSlackNs'],total_negative_setup_slack_ns=slow['TotalNegativeSlackNs'],
                         failing_setup_endpoints=slow['FailingEndpoints'],all_10_timing_checks_pass=False,
                         timing_checks=timing['Checks'],build_receipt=ref(target/'BUILD_RESULT.json'),
                         timing_receipt=ref(target/'TIMING_SUMMARY.json'),input_hashes=ref(target/'INPUT_HASHES.json'),
                         raw_timing_report=ref(rtr),bitstream=ref(bit),all_18_physical_RTL_match=True))
assert [x['worst_setup_slack_ns'] for x in physical]==[-.392,-.168,-.133,-.166]
actual6000=[]
for row in longs['records']:
    role=row['role']
    binding=row['source_binding']
    assert binding['short_verification_sha256']==sha(short_path)
    run=load(HERE/('LONG_'+role+'_RESULT.json'))['run']
    assert row['audit']['coremark_per_mhz']>3.5 and row['audit']['formal_ten_seconds']
    assert row['qualified_H4_long_cycles_and_retired_equal']
    target=ROOT/'work'/('sg25-loop-single-write-i6000-'+role)
    actual6000.append(dict(role=role,work_directory=str(target),audit=row['audit'],process=row['process'],
                           native_command=row['process'].get('native_command'),
                           saved_uart=ref(target/'uart.log'),saved_stdout=ref(target/'simulation.log'),
                           run_receipt=ref(target/'RUN.json'),firmware_reuse=ref(target/'FIRMWARE_REUSE.json'),
                           worker_result=ref(HERE/('LONG_'+role+'_RESULT.json')),
                           all_four_CRC_fields_valid=True,observer_CSR_UART_interval_equal=True,
                           exact_cf4_firmware_and_build=True,qualified_H4_cycles_and_retired_equal=True,
                           timed_seconds=run['duration_at_145125MHz_seconds'],exit_status=0))
summary=dict(status='ACTUAL6000_PERFORMANCE_PASS_PHYSICAL_S1_S4_TIMING_FAIL',
             finalized_utc=datetime.now(timezone.utc).isoformat(),changed_field=change['changed_field'],
             source_chain=dict(receipt=ref(HERE/'CHANGE.json'),baseline_sha256=change['baseline_sha256'],modified_sha256=change['modified_sha256'],
                               retained_core_sha256=change['retained_core_sha256'],retained_cache_sha256=change['retained_cache_sha256'],
                               rtl_17=change['rtl'],physical_rtl_18=change['physical_rtl']),
             launch_time_short_verification=ref(short_path),original_recheck=ref(old_recheck_path),
             baseline_modified_rollback=dict(records=bmr,full_literal_outputs=ref(HERE/'CORE_VERIFICATION.json'),architecture_lines=591,
                                             all_complete_outputs_equal=True,actual_rollback=core['rollback'],restored_behavior=short['restored_behavior']),
             proof_receipts=proofs,
             proof_results=dict(production_full_state_widths=[8,16,32],state_bits=[464,592,848],unbounded_induction=True,
                                negative_control_rejected=True,production_four_state_checks=42343,unknown_reset_posedge_writes=8,
                                core_BMR_scenarios=23,core_architecture_lines=591,loop_model_BMR=True,three_parameter_random_configs=True,
                                full100_both_roles_byte_identical_retirement_interfaces_UART=True),
             vendor_synthesis=short['vendor_synthesis'],actual6000=dict(status=longs['status'],audit_receipt=ref(HERE/'LONG_FINAL_AUDIT.json'),records=actual6000),
             actual_physical=physical,completion_state=dict(functional_and_performance_pass=True,qualified_physical_builds=0,
                                                         timing_fail_builds=4,release_status='EXPERIMENTAL_AREA_CANDIDATE_TIMING_FAIL',
                                                         original_qualified_H4_release_preserved=True,production_sources_changed=False,
                                                         new_benchmark_runs_or_builds_launched=False),
             all_loop_capacities_unchanged=True,modified_file_left_changed=True,
             original_BMR_records_preserved=True,
             artifacts={name:str(HERE/name) for name in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')})
save(HERE/'VERIFICATION.txt',summary)
artifacts={name:ref(HERE/name) for name in summary['artifacts']}
final=dict(status='PASS',artifacts=artifacts,source_sha256=change['modified_sha256'],result=summary['status'],source_snapshot=change['physical_rtl'],
           historical_short_snapshot=ref(short_path),original_BMR_records_preserved=True,
           actual6000_scores={x['role']:x['audit']['coremark_per_mhz'] for x in longs['records']},
           physical_all_timing_fail=True,physical_seeds=[1,2,3,4],physical_worst_slack_ns=[x['worst_setup_slack_ns'] for x in physical],
           production_RTL_changed=False,new_tests_or_builds=False)
save(HERE/'FINAL_RECHECK.json',final)
for name,item in artifacts.items():
    assert sha(HERE/name)==item['sha256']
literal='SG25_FINAL_EVIDENCE_PASS actual6000=2 both_gt3p5=True H4_cycles_retired=equal physical_s1_s4=timing_fail BMR=preserved source=unchanged new_runs=0 four_artifacts=reopened'
update=dict(status='PASS',command=[sys.executable,'-I',str(Path(__file__).resolve())],
            inputs=dict(launch_time_short=ref(short_path),long_audit=ref(HERE/'LONG_FINAL_AUDIT.json'),physical_builds=[x['build'] for x in physical]),
            verification_before_sha256=sha(short_path),verification_after_sha256=sha(HERE/'VERIFICATION.txt'),
            verification_before_bytes=short_path.stat().st_size,verification_after_bytes=(HERE/'VERIFICATION.txt').stat().st_size,
            original_BMR_content_identical=True,production_RTL_identical=True,
            read_only_long_audit_command=[sys.executable,'-I',str(HERE/'finalize_longs.py')],
            read_only_long_audit_literal=audit_run.stdout,read_only_long_audit_exit_status=audit_run.returncode,
            literal_output=literal,exit_status=0)
save(HERE/'FINAL_EVIDENCE_UPDATE.json',update)
print(literal)

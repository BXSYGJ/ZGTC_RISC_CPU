from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
source=(ROOT/'rtl_proposals/load_simple_loop16_h4/long_benchmark.py').read_text()
source=source.replace("SOURCE=ROOT/'candidates/load_simple_loop16_h4/rtl'","SOURCE=ROOT/'candidates/loop16_h4_single_write/rtl'")
source=source.replace("IDENTITY='c7ab29adf836d1f94a9b637d4e8489412774bef95f254fde386b63aa03e7f194'","IDENTITY=load(AREA/'FULL100_INTERFACE_EQUIVALENCE.json')['standard_simulation_rtl_identity']")
# load is defined below the old literal; move the new identity below helpers.
identity="IDENTITY=load(AREA/'FULL100_INTERFACE_EQUIVALENCE.json')['standard_simulation_rtl_identity']\n"
source=source.replace(identity,'',1)
source=source.replace("utc=lambda:datetime.now(timezone.utc).isoformat()\n","utc=lambda:datetime.now(timezone.utc).isoformat()\n"+identity,1)
start=source.index("assert load(AREA/'FINAL_RECHECK.json')['short_status']")
end=source.index('def verify_sources():',start)
source=source[:start]+'''assert load(AREA/'FINAL_RECHECK.json')['result']=='FUNCTIONAL_AND_FULL100_EQUIVALENCE_PASS'
full100=load(AREA/'FULL100_INTERFACE_EQUIVALENCE.json')
assert full100['status']=='PASS_BOTH_ROLES_ACTUAL_FULL100' and not full100['pending']
assert all(row['all_equal'] for row in full100['records'])
'''+source[end:]
source=source.replace("target=ROOT/'work'/('sg21-loop16-h4-i6000-'+role)","target=ROOT/'work'/('sg25-loop-single-write-i6000-'+role)")
source=source.replace("assert result['firmware']==metadata and result['rtl_sha256']==identity", "assert result['firmware']==metadata and result['rtl_sha256']==identity\nexpected=load(ROOT/('rtl_proposals/load_simple_loop16_h4/LONG_'+role+'_RESULT.json'))['run']\nassert result['timed_cycles']==expected['timed_cycles'] and result['retired']==expected['retired']")
source=source.replace('SL_LOOP16_H4_LONG','LOOP_SINGLE_WRITE_LONG')
(HERE/'long_benchmark.py').write_text(source,encoding='utf-8')
print('LOOP_SINGLE_WRITE_LONG_RUNNER_READY')

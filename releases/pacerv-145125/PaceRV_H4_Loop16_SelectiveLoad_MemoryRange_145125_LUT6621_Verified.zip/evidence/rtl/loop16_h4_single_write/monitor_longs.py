"""Read and bind running native handles; never starts or restarts a process."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sessions={'V0':49643,'V1':80420}
rows=[]
now=datetime.now(timezone.utc)
ticks=os.sysconf('SC_CLK_TCK')
for role in ('V0','V1'):
    target=ROOT/'work'/('sg25-loop-single-write-i6000-'+role)
    record=json.loads((target/'PROCESS.json').read_text(encoding='utf-8-sig'))
    pid=record['native_pid']
    proc=Path('/proc')/str(pid)
    row=dict(role=role,unified_session=sessions[role],native_pid=pid,worker_pid=record['worker_pid'],live=proc.exists(),process_status=record['status'],process_receipt=str(target/'PROCESS.json'),wall_elapsed_seconds=(now-datetime.fromisoformat(record['started_utc'])).total_seconds())
    if row['live']:
        fields=(proc/'stat').read_text().split()
        row.update(process_state=fields[2],cpu_seconds=sum(map(int,fields[13:15]))/ticks,command_line=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace').strip())
        assert row['command_line'].startswith(record['command'][0])
    if (target/'RUN.json').exists():
        run=json.loads((target/'RUN.json').read_text(encoding='utf-8-sig'))
        row['completed_run']={key:run[key] for key in ('exit_status','timed_cycles','retired','coremark_per_mhz','formal_ten_seconds')}
    row['validated_result_receipt_exists']=(HERE/('LONG_'+role+'_RESULT.json')).exists()
    rows.append(row)
ready=all(row['validated_result_receipt_exists'] for row in rows)
result=dict(status='COMPLETED_AWAITING_AUDIT' if ready else 'RUNNING_ACTUAL6000',updated_utc=now.isoformat(),records=rows,ready_for_finalizer=ready)
(HERE/'LONG_LIVE_STATE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert json.loads((HERE/'LONG_LIVE_STATE.json').read_text())==result
print(json.dumps(result,sort_keys=True))

module baseline_loop(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[463:0]state,output[463:0]next_state);
localparam ADDRESS_BITS=8; localparam LOOP_COUNT_BITS=8;
wire[15:0]loop_valid=state[15:0]; reg[15:0]n_loop_valid;
assign next_state[15:0]=n_loop_valid;
wire[6:0]loop_tag[0:15];reg[6:0]n_loop_tag[0:15];
assign loop_tag[0]=state[16+:7];
assign next_state[16+:7]=n_loop_tag[0];
assign loop_tag[1]=state[23+:7];
assign next_state[23+:7]=n_loop_tag[1];
assign loop_tag[2]=state[30+:7];
assign next_state[30+:7]=n_loop_tag[2];
assign loop_tag[3]=state[37+:7];
assign next_state[37+:7]=n_loop_tag[3];
assign loop_tag[4]=state[44+:7];
assign next_state[44+:7]=n_loop_tag[4];
assign loop_tag[5]=state[51+:7];
assign next_state[51+:7]=n_loop_tag[5];
assign loop_tag[6]=state[58+:7];
assign next_state[58+:7]=n_loop_tag[6];
assign loop_tag[7]=state[65+:7];
assign next_state[65+:7]=n_loop_tag[7];
assign loop_tag[8]=state[72+:7];
assign next_state[72+:7]=n_loop_tag[8];
assign loop_tag[9]=state[79+:7];
assign next_state[79+:7]=n_loop_tag[9];
assign loop_tag[10]=state[86+:7];
assign next_state[86+:7]=n_loop_tag[10];
assign loop_tag[11]=state[93+:7];
assign next_state[93+:7]=n_loop_tag[11];
assign loop_tag[12]=state[100+:7];
assign next_state[100+:7]=n_loop_tag[12];
assign loop_tag[13]=state[107+:7];
assign next_state[107+:7]=n_loop_tag[13];
assign loop_tag[14]=state[114+:7];
assign next_state[114+:7]=n_loop_tag[14];
assign loop_tag[15]=state[121+:7];
assign next_state[121+:7]=n_loop_tag[15];
wire[7:0]loop_count[0:15];reg[7:0]n_loop_count[0:15];
assign loop_count[0]=state[128+:8];
assign next_state[128+:8]=n_loop_count[0];
assign loop_count[1]=state[136+:8];
assign next_state[136+:8]=n_loop_count[1];
assign loop_count[2]=state[144+:8];
assign next_state[144+:8]=n_loop_count[2];
assign loop_count[3]=state[152+:8];
assign next_state[152+:8]=n_loop_count[3];
assign loop_count[4]=state[160+:8];
assign next_state[160+:8]=n_loop_count[4];
assign loop_count[5]=state[168+:8];
assign next_state[168+:8]=n_loop_count[5];
assign loop_count[6]=state[176+:8];
assign next_state[176+:8]=n_loop_count[6];
assign loop_count[7]=state[184+:8];
assign next_state[184+:8]=n_loop_count[7];
assign loop_count[8]=state[192+:8];
assign next_state[192+:8]=n_loop_count[8];
assign loop_count[9]=state[200+:8];
assign next_state[200+:8]=n_loop_count[9];
assign loop_count[10]=state[208+:8];
assign next_state[208+:8]=n_loop_count[10];
assign loop_count[11]=state[216+:8];
assign next_state[216+:8]=n_loop_count[11];
assign loop_count[12]=state[224+:8];
assign next_state[224+:8]=n_loop_count[12];
assign loop_count[13]=state[232+:8];
assign next_state[232+:8]=n_loop_count[13];
assign loop_count[14]=state[240+:8];
assign next_state[240+:8]=n_loop_count[14];
assign loop_count[15]=state[248+:8];
assign next_state[248+:8]=n_loop_count[15];
wire[7:0]loop_trip[0:15];reg[7:0]n_loop_trip[0:15];
assign loop_trip[0]=state[256+:8];
assign next_state[256+:8]=n_loop_trip[0];
assign loop_trip[1]=state[264+:8];
assign next_state[264+:8]=n_loop_trip[1];
assign loop_trip[2]=state[272+:8];
assign next_state[272+:8]=n_loop_trip[2];
assign loop_trip[3]=state[280+:8];
assign next_state[280+:8]=n_loop_trip[3];
assign loop_trip[4]=state[288+:8];
assign next_state[288+:8]=n_loop_trip[4];
assign loop_trip[5]=state[296+:8];
assign next_state[296+:8]=n_loop_trip[5];
assign loop_trip[6]=state[304+:8];
assign next_state[304+:8]=n_loop_trip[6];
assign loop_trip[7]=state[312+:8];
assign next_state[312+:8]=n_loop_trip[7];
assign loop_trip[8]=state[320+:8];
assign next_state[320+:8]=n_loop_trip[8];
assign loop_trip[9]=state[328+:8];
assign next_state[328+:8]=n_loop_trip[9];
assign loop_trip[10]=state[336+:8];
assign next_state[336+:8]=n_loop_trip[10];
assign loop_trip[11]=state[344+:8];
assign next_state[344+:8]=n_loop_trip[11];
assign loop_trip[12]=state[352+:8];
assign next_state[352+:8]=n_loop_trip[12];
assign loop_trip[13]=state[360+:8];
assign next_state[360+:8]=n_loop_trip[13];
assign loop_trip[14]=state[368+:8];
assign next_state[368+:8]=n_loop_trip[14];
assign loop_trip[15]=state[376+:8];
assign next_state[376+:8]=n_loop_trip[15];
wire[1:0]loop_confidence[0:15];reg[1:0]n_loop_confidence[0:15];
assign loop_confidence[0]=state[384+:2];
assign next_state[384+:2]=n_loop_confidence[0];
assign loop_confidence[1]=state[386+:2];
assign next_state[386+:2]=n_loop_confidence[1];
assign loop_confidence[2]=state[388+:2];
assign next_state[388+:2]=n_loop_confidence[2];
assign loop_confidence[3]=state[390+:2];
assign next_state[390+:2]=n_loop_confidence[3];
assign loop_confidence[4]=state[392+:2];
assign next_state[392+:2]=n_loop_confidence[4];
assign loop_confidence[5]=state[394+:2];
assign next_state[394+:2]=n_loop_confidence[5];
assign loop_confidence[6]=state[396+:2];
assign next_state[396+:2]=n_loop_confidence[6];
assign loop_confidence[7]=state[398+:2];
assign next_state[398+:2]=n_loop_confidence[7];
assign loop_confidence[8]=state[400+:2];
assign next_state[400+:2]=n_loop_confidence[8];
assign loop_confidence[9]=state[402+:2];
assign next_state[402+:2]=n_loop_confidence[9];
assign loop_confidence[10]=state[404+:2];
assign next_state[404+:2]=n_loop_confidence[10];
assign loop_confidence[11]=state[406+:2];
assign next_state[406+:2]=n_loop_confidence[11];
assign loop_confidence[12]=state[408+:2];
assign next_state[408+:2]=n_loop_confidence[12];
assign loop_confidence[13]=state[410+:2];
assign next_state[410+:2]=n_loop_confidence[13];
assign loop_confidence[14]=state[412+:2];
assign next_state[412+:2]=n_loop_confidence[14];
assign loop_confidence[15]=state[414+:2];
assign next_state[414+:2]=n_loop_confidence[15];
wire[0:0]loop_overflow[0:15];reg[0:0]n_loop_overflow[0:15];
assign loop_overflow[0]=state[416+:1];
assign next_state[416+:1]=n_loop_overflow[0];
assign loop_overflow[1]=state[417+:1];
assign next_state[417+:1]=n_loop_overflow[1];
assign loop_overflow[2]=state[418+:1];
assign next_state[418+:1]=n_loop_overflow[2];
assign loop_overflow[3]=state[419+:1];
assign next_state[419+:1]=n_loop_overflow[3];
assign loop_overflow[4]=state[420+:1];
assign next_state[420+:1]=n_loop_overflow[4];
assign loop_overflow[5]=state[421+:1];
assign next_state[421+:1]=n_loop_overflow[5];
assign loop_overflow[6]=state[422+:1];
assign next_state[422+:1]=n_loop_overflow[6];
assign loop_overflow[7]=state[423+:1];
assign next_state[423+:1]=n_loop_overflow[7];
assign loop_overflow[8]=state[424+:1];
assign next_state[424+:1]=n_loop_overflow[8];
assign loop_overflow[9]=state[425+:1];
assign next_state[425+:1]=n_loop_overflow[9];
assign loop_overflow[10]=state[426+:1];
assign next_state[426+:1]=n_loop_overflow[10];
assign loop_overflow[11]=state[427+:1];
assign next_state[427+:1]=n_loop_overflow[11];
assign loop_overflow[12]=state[428+:1];
assign next_state[428+:1]=n_loop_overflow[12];
assign loop_overflow[13]=state[429+:1];
assign next_state[429+:1]=n_loop_overflow[13];
assign loop_overflow[14]=state[430+:1];
assign next_state[430+:1]=n_loop_overflow[14];
assign loop_overflow[15]=state[431+:1];
assign next_state[431+:1]=n_loop_overflow[15];
wire[0:0]loop_direction[0:15];reg[0:0]n_loop_direction[0:15];
assign loop_direction[0]=state[432+:1];
assign next_state[432+:1]=n_loop_direction[0];
assign loop_direction[1]=state[433+:1];
assign next_state[433+:1]=n_loop_direction[1];
assign loop_direction[2]=state[434+:1];
assign next_state[434+:1]=n_loop_direction[2];
assign loop_direction[3]=state[435+:1];
assign next_state[435+:1]=n_loop_direction[3];
assign loop_direction[4]=state[436+:1];
assign next_state[436+:1]=n_loop_direction[4];
assign loop_direction[5]=state[437+:1];
assign next_state[437+:1]=n_loop_direction[5];
assign loop_direction[6]=state[438+:1];
assign next_state[438+:1]=n_loop_direction[6];
assign loop_direction[7]=state[439+:1];
assign next_state[439+:1]=n_loop_direction[7];
assign loop_direction[8]=state[440+:1];
assign next_state[440+:1]=n_loop_direction[8];
assign loop_direction[9]=state[441+:1];
assign next_state[441+:1]=n_loop_direction[9];
assign loop_direction[10]=state[442+:1];
assign next_state[442+:1]=n_loop_direction[10];
assign loop_direction[11]=state[443+:1];
assign next_state[443+:1]=n_loop_direction[11];
assign loop_direction[12]=state[444+:1];
assign next_state[444+:1]=n_loop_direction[12];
assign loop_direction[13]=state[445+:1];
assign next_state[445+:1]=n_loop_direction[13];
assign loop_direction[14]=state[446+:1];
assign next_state[446+:1]=n_loop_direction[14];
assign loop_direction[15]=state[447+:1];
assign next_state[447+:1]=n_loop_direction[15];
wire[0:0]loop_ahead[0:15];reg[0:0]n_loop_ahead[0:15];
assign loop_ahead[0]=state[448+:1];
assign next_state[448+:1]=n_loop_ahead[0];
assign loop_ahead[1]=state[449+:1];
assign next_state[449+:1]=n_loop_ahead[1];
assign loop_ahead[2]=state[450+:1];
assign next_state[450+:1]=n_loop_ahead[2];
assign loop_ahead[3]=state[451+:1];
assign next_state[451+:1]=n_loop_ahead[3];
assign loop_ahead[4]=state[452+:1];
assign next_state[452+:1]=n_loop_ahead[4];
assign loop_ahead[5]=state[453+:1];
assign next_state[453+:1]=n_loop_ahead[5];
assign loop_ahead[6]=state[454+:1];
assign next_state[454+:1]=n_loop_ahead[6];
assign loop_ahead[7]=state[455+:1];
assign next_state[455+:1]=n_loop_ahead[7];
assign loop_ahead[8]=state[456+:1];
assign next_state[456+:1]=n_loop_ahead[8];
assign loop_ahead[9]=state[457+:1];
assign next_state[457+:1]=n_loop_ahead[9];
assign loop_ahead[10]=state[458+:1];
assign next_state[458+:1]=n_loop_ahead[10];
assign loop_ahead[11]=state[459+:1];
assign next_state[459+:1]=n_loop_ahead[11];
assign loop_ahead[12]=state[460+:1];
assign next_state[460+:1]=n_loop_ahead[12];
assign loop_ahead[13]=state[461+:1];
assign next_state[461+:1]=n_loop_ahead[13];
assign loop_ahead[14]=state[462+:1];
assign next_state[462+:1]=n_loop_ahead[14];
assign loop_ahead[15]=state[463+:1];
assign next_state[463+:1]=n_loop_ahead[15];
wire loop_update_match=loop_valid[loop_update_index] && loop_tag[loop_update_index]==update_pc[ADDRESS_BITS-1:1];
integer j;always @* begin n_loop_valid=loop_valid;for(j=0;j<16;j=j+1)begin
n_loop_tag[j]=loop_tag[j];
n_loop_count[j]=loop_count[j];
n_loop_trip[j]=loop_trip[j];
n_loop_confidence[j]=loop_confidence[j];
n_loop_overflow[j]=loop_overflow[j];
n_loop_direction[j]=loop_direction[j];
n_loop_ahead[j]=loop_ahead[j];
end
if(clk_event || reset_fall)begin
        if(!rst_n) n_loop_valid=0;
        else if(invalidate) n_loop_valid=0;
        else if(train_update && loop_backward) begin
            n_loop_valid[loop_update_index]=1;
            n_loop_tag[loop_update_index]=update_pc[ADDRESS_BITS-1:1];
            if(!loop_update_match) begin
                n_loop_count[loop_update_index]=update_taken ? 1 : 0;
                n_loop_trip[loop_update_index]=0;
                n_loop_confidence[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                n_loop_direction[loop_update_index]=1;
                n_loop_ahead[loop_update_index]=1;
            end else if(update_taken) begin
                if(&loop_count[loop_update_index]) begin
                    n_loop_overflow[loop_update_index]=1;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_count[loop_update_index]=loop_count[loop_update_index]+1'b1;
                    n_loop_direction[loop_update_index]=(loop_count[loop_update_index]+1'b1)<loop_trip[loop_update_index];
                    n_loop_ahead[loop_update_index]=({1'b0,loop_count[loop_update_index]}+2)<{1'b0,loop_trip[loop_update_index]};
                end
            end else begin
                n_loop_count[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin
                    n_loop_trip[loop_update_index]=0;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_trip[loop_update_index]=loop_count[loop_update_index];
                    n_loop_direction[loop_update_index]=1;
                    n_loop_ahead[loop_update_index]=loop_count[loop_update_index]>1;
                    if(loop_trip[loop_update_index]==loop_count[loop_update_index]) begin
                        if(loop_confidence[loop_update_index]!=3)
                            n_loop_confidence[loop_update_index]=loop_confidence[loop_update_index]+1'b1;
                    end else n_loop_confidence[loop_update_index]=0;
                end
            end
        end

end
end endmodule
module modified_loop(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[463:0]state,output[463:0]next_state);
localparam ADDRESS_BITS=8; localparam LOOP_COUNT_BITS=8;
wire[15:0]loop_valid=state[15:0]; reg[15:0]n_loop_valid;
assign next_state[15:0]=n_loop_valid;
reg [7:0]loop_count_write_data,loop_trip_write_data;reg loop_count_write_enable,loop_trip_write_enable;
wire[6:0]loop_tag[0:15];reg[6:0]n_loop_tag[0:15];
assign loop_tag[0]=state[16+:7];
assign next_state[16+:7]=n_loop_tag[0];
assign loop_tag[1]=state[23+:7];
assign next_state[23+:7]=n_loop_tag[1];
assign loop_tag[2]=state[30+:7];
assign next_state[30+:7]=n_loop_tag[2];
assign loop_tag[3]=state[37+:7];
assign next_state[37+:7]=n_loop_tag[3];
assign loop_tag[4]=state[44+:7];
assign next_state[44+:7]=n_loop_tag[4];
assign loop_tag[5]=state[51+:7];
assign next_state[51+:7]=n_loop_tag[5];
assign loop_tag[6]=state[58+:7];
assign next_state[58+:7]=n_loop_tag[6];
assign loop_tag[7]=state[65+:7];
assign next_state[65+:7]=n_loop_tag[7];
assign loop_tag[8]=state[72+:7];
assign next_state[72+:7]=n_loop_tag[8];
assign loop_tag[9]=state[79+:7];
assign next_state[79+:7]=n_loop_tag[9];
assign loop_tag[10]=state[86+:7];
assign next_state[86+:7]=n_loop_tag[10];
assign loop_tag[11]=state[93+:7];
assign next_state[93+:7]=n_loop_tag[11];
assign loop_tag[12]=state[100+:7];
assign next_state[100+:7]=n_loop_tag[12];
assign loop_tag[13]=state[107+:7];
assign next_state[107+:7]=n_loop_tag[13];
assign loop_tag[14]=state[114+:7];
assign next_state[114+:7]=n_loop_tag[14];
assign loop_tag[15]=state[121+:7];
assign next_state[121+:7]=n_loop_tag[15];
wire[7:0]loop_count[0:15];reg[7:0]n_loop_count[0:15];
assign loop_count[0]=state[128+:8];
assign next_state[128+:8]=n_loop_count[0];
assign loop_count[1]=state[136+:8];
assign next_state[136+:8]=n_loop_count[1];
assign loop_count[2]=state[144+:8];
assign next_state[144+:8]=n_loop_count[2];
assign loop_count[3]=state[152+:8];
assign next_state[152+:8]=n_loop_count[3];
assign loop_count[4]=state[160+:8];
assign next_state[160+:8]=n_loop_count[4];
assign loop_count[5]=state[168+:8];
assign next_state[168+:8]=n_loop_count[5];
assign loop_count[6]=state[176+:8];
assign next_state[176+:8]=n_loop_count[6];
assign loop_count[7]=state[184+:8];
assign next_state[184+:8]=n_loop_count[7];
assign loop_count[8]=state[192+:8];
assign next_state[192+:8]=n_loop_count[8];
assign loop_count[9]=state[200+:8];
assign next_state[200+:8]=n_loop_count[9];
assign loop_count[10]=state[208+:8];
assign next_state[208+:8]=n_loop_count[10];
assign loop_count[11]=state[216+:8];
assign next_state[216+:8]=n_loop_count[11];
assign loop_count[12]=state[224+:8];
assign next_state[224+:8]=n_loop_count[12];
assign loop_count[13]=state[232+:8];
assign next_state[232+:8]=n_loop_count[13];
assign loop_count[14]=state[240+:8];
assign next_state[240+:8]=n_loop_count[14];
assign loop_count[15]=state[248+:8];
assign next_state[248+:8]=n_loop_count[15];
wire[7:0]loop_trip[0:15];reg[7:0]n_loop_trip[0:15];
assign loop_trip[0]=state[256+:8];
assign next_state[256+:8]=n_loop_trip[0];
assign loop_trip[1]=state[264+:8];
assign next_state[264+:8]=n_loop_trip[1];
assign loop_trip[2]=state[272+:8];
assign next_state[272+:8]=n_loop_trip[2];
assign loop_trip[3]=state[280+:8];
assign next_state[280+:8]=n_loop_trip[3];
assign loop_trip[4]=state[288+:8];
assign next_state[288+:8]=n_loop_trip[4];
assign loop_trip[5]=state[296+:8];
assign next_state[296+:8]=n_loop_trip[5];
assign loop_trip[6]=state[304+:8];
assign next_state[304+:8]=n_loop_trip[6];
assign loop_trip[7]=state[312+:8];
assign next_state[312+:8]=n_loop_trip[7];
assign loop_trip[8]=state[320+:8];
assign next_state[320+:8]=n_loop_trip[8];
assign loop_trip[9]=state[328+:8];
assign next_state[328+:8]=n_loop_trip[9];
assign loop_trip[10]=state[336+:8];
assign next_state[336+:8]=n_loop_trip[10];
assign loop_trip[11]=state[344+:8];
assign next_state[344+:8]=n_loop_trip[11];
assign loop_trip[12]=state[352+:8];
assign next_state[352+:8]=n_loop_trip[12];
assign loop_trip[13]=state[360+:8];
assign next_state[360+:8]=n_loop_trip[13];
assign loop_trip[14]=state[368+:8];
assign next_state[368+:8]=n_loop_trip[14];
assign loop_trip[15]=state[376+:8];
assign next_state[376+:8]=n_loop_trip[15];
wire[1:0]loop_confidence[0:15];reg[1:0]n_loop_confidence[0:15];
assign loop_confidence[0]=state[384+:2];
assign next_state[384+:2]=n_loop_confidence[0];
assign loop_confidence[1]=state[386+:2];
assign next_state[386+:2]=n_loop_confidence[1];
assign loop_confidence[2]=state[388+:2];
assign next_state[388+:2]=n_loop_confidence[2];
assign loop_confidence[3]=state[390+:2];
assign next_state[390+:2]=n_loop_confidence[3];
assign loop_confidence[4]=state[392+:2];
assign next_state[392+:2]=n_loop_confidence[4];
assign loop_confidence[5]=state[394+:2];
assign next_state[394+:2]=n_loop_confidence[5];
assign loop_confidence[6]=state[396+:2];
assign next_state[396+:2]=n_loop_confidence[6];
assign loop_confidence[7]=state[398+:2];
assign next_state[398+:2]=n_loop_confidence[7];
assign loop_confidence[8]=state[400+:2];
assign next_state[400+:2]=n_loop_confidence[8];
assign loop_confidence[9]=state[402+:2];
assign next_state[402+:2]=n_loop_confidence[9];
assign loop_confidence[10]=state[404+:2];
assign next_state[404+:2]=n_loop_confidence[10];
assign loop_confidence[11]=state[406+:2];
assign next_state[406+:2]=n_loop_confidence[11];
assign loop_confidence[12]=state[408+:2];
assign next_state[408+:2]=n_loop_confidence[12];
assign loop_confidence[13]=state[410+:2];
assign next_state[410+:2]=n_loop_confidence[13];
assign loop_confidence[14]=state[412+:2];
assign next_state[412+:2]=n_loop_confidence[14];
assign loop_confidence[15]=state[414+:2];
assign next_state[414+:2]=n_loop_confidence[15];
wire[0:0]loop_overflow[0:15];reg[0:0]n_loop_overflow[0:15];
assign loop_overflow[0]=state[416+:1];
assign next_state[416+:1]=n_loop_overflow[0];
assign loop_overflow[1]=state[417+:1];
assign next_state[417+:1]=n_loop_overflow[1];
assign loop_overflow[2]=state[418+:1];
assign next_state[418+:1]=n_loop_overflow[2];
assign loop_overflow[3]=state[419+:1];
assign next_state[419+:1]=n_loop_overflow[3];
assign loop_overflow[4]=state[420+:1];
assign next_state[420+:1]=n_loop_overflow[4];
assign loop_overflow[5]=state[421+:1];
assign next_state[421+:1]=n_loop_overflow[5];
assign loop_overflow[6]=state[422+:1];
assign next_state[422+:1]=n_loop_overflow[6];
assign loop_overflow[7]=state[423+:1];
assign next_state[423+:1]=n_loop_overflow[7];
assign loop_overflow[8]=state[424+:1];
assign next_state[424+:1]=n_loop_overflow[8];
assign loop_overflow[9]=state[425+:1];
assign next_state[425+:1]=n_loop_overflow[9];
assign loop_overflow[10]=state[426+:1];
assign next_state[426+:1]=n_loop_overflow[10];
assign loop_overflow[11]=state[427+:1];
assign next_state[427+:1]=n_loop_overflow[11];
assign loop_overflow[12]=state[428+:1];
assign next_state[428+:1]=n_loop_overflow[12];
assign loop_overflow[13]=state[429+:1];
assign next_state[429+:1]=n_loop_overflow[13];
assign loop_overflow[14]=state[430+:1];
assign next_state[430+:1]=n_loop_overflow[14];
assign loop_overflow[15]=state[431+:1];
assign next_state[431+:1]=n_loop_overflow[15];
wire[0:0]loop_direction[0:15];reg[0:0]n_loop_direction[0:15];
assign loop_direction[0]=state[432+:1];
assign next_state[432+:1]=n_loop_direction[0];
assign loop_direction[1]=state[433+:1];
assign next_state[433+:1]=n_loop_direction[1];
assign loop_direction[2]=state[434+:1];
assign next_state[434+:1]=n_loop_direction[2];
assign loop_direction[3]=state[435+:1];
assign next_state[435+:1]=n_loop_direction[3];
assign loop_direction[4]=state[436+:1];
assign next_state[436+:1]=n_loop_direction[4];
assign loop_direction[5]=state[437+:1];
assign next_state[437+:1]=n_loop_direction[5];
assign loop_direction[6]=state[438+:1];
assign next_state[438+:1]=n_loop_direction[6];
assign loop_direction[7]=state[439+:1];
assign next_state[439+:1]=n_loop_direction[7];
assign loop_direction[8]=state[440+:1];
assign next_state[440+:1]=n_loop_direction[8];
assign loop_direction[9]=state[441+:1];
assign next_state[441+:1]=n_loop_direction[9];
assign loop_direction[10]=state[442+:1];
assign next_state[442+:1]=n_loop_direction[10];
assign loop_direction[11]=state[443+:1];
assign next_state[443+:1]=n_loop_direction[11];
assign loop_direction[12]=state[444+:1];
assign next_state[444+:1]=n_loop_direction[12];
assign loop_direction[13]=state[445+:1];
assign next_state[445+:1]=n_loop_direction[13];
assign loop_direction[14]=state[446+:1];
assign next_state[446+:1]=n_loop_direction[14];
assign loop_direction[15]=state[447+:1];
assign next_state[447+:1]=n_loop_direction[15];
wire[0:0]loop_ahead[0:15];reg[0:0]n_loop_ahead[0:15];
assign loop_ahead[0]=state[448+:1];
assign next_state[448+:1]=n_loop_ahead[0];
assign loop_ahead[1]=state[449+:1];
assign next_state[449+:1]=n_loop_ahead[1];
assign loop_ahead[2]=state[450+:1];
assign next_state[450+:1]=n_loop_ahead[2];
assign loop_ahead[3]=state[451+:1];
assign next_state[451+:1]=n_loop_ahead[3];
assign loop_ahead[4]=state[452+:1];
assign next_state[452+:1]=n_loop_ahead[4];
assign loop_ahead[5]=state[453+:1];
assign next_state[453+:1]=n_loop_ahead[5];
assign loop_ahead[6]=state[454+:1];
assign next_state[454+:1]=n_loop_ahead[6];
assign loop_ahead[7]=state[455+:1];
assign next_state[455+:1]=n_loop_ahead[7];
assign loop_ahead[8]=state[456+:1];
assign next_state[456+:1]=n_loop_ahead[8];
assign loop_ahead[9]=state[457+:1];
assign next_state[457+:1]=n_loop_ahead[9];
assign loop_ahead[10]=state[458+:1];
assign next_state[458+:1]=n_loop_ahead[10];
assign loop_ahead[11]=state[459+:1];
assign next_state[459+:1]=n_loop_ahead[11];
assign loop_ahead[12]=state[460+:1];
assign next_state[460+:1]=n_loop_ahead[12];
assign loop_ahead[13]=state[461+:1];
assign next_state[461+:1]=n_loop_ahead[13];
assign loop_ahead[14]=state[462+:1];
assign next_state[462+:1]=n_loop_ahead[14];
assign loop_ahead[15]=state[463+:1];
assign next_state[463+:1]=n_loop_ahead[15];
wire loop_update_match=loop_valid[loop_update_index] && loop_tag[loop_update_index]==update_pc[ADDRESS_BITS-1:1];
integer j;always @* begin n_loop_valid=loop_valid;for(j=0;j<16;j=j+1)begin
n_loop_tag[j]=loop_tag[j];
n_loop_count[j]=loop_count[j];
n_loop_trip[j]=loop_trip[j];
n_loop_confidence[j]=loop_confidence[j];
n_loop_overflow[j]=loop_overflow[j];
n_loop_direction[j]=loop_direction[j];
n_loop_ahead[j]=loop_ahead[j];
end
        loop_count_write_data=8'd0;
        loop_trip_write_data=8'd0;
        loop_count_write_enable=1'b0;
        loop_trip_write_enable=1'b0;
        if(!loop_update_match) begin
            loop_count_write_enable=1'b1;
            loop_count_write_data=update_taken ? 8'd1 : 8'd0;
            loop_trip_write_enable=1'b1;
        end else if(update_taken) begin
            if(&loop_count[loop_update_index]) begin end
            else begin
                loop_count_write_enable=1'b1;
                loop_count_write_data=loop_count[loop_update_index]+1'b1;
            end
        end else begin
            loop_count_write_enable=1'b1;
            loop_trip_write_enable=1'b1;
            if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin end
            else loop_trip_write_data=loop_count[loop_update_index];
        end

if(clk_event || reset_fall)begin
        if(!rst_n) n_loop_valid=0;
        else if(invalidate) n_loop_valid=0;
        else if(train_update && loop_backward) n_loop_valid[loop_update_index]=1;

end
if(clk_event)begin
        if(!rst_n) begin end
        else if(invalidate) begin end
        else if(train_update && loop_backward) begin
            n_loop_tag[loop_update_index]=update_pc[ADDRESS_BITS-1:1];
            if(!loop_update_match) begin
                n_loop_confidence[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                n_loop_direction[loop_update_index]=1;
                n_loop_ahead[loop_update_index]=1;
            end else if(update_taken) begin
                if(&loop_count[loop_update_index]) begin
                    n_loop_overflow[loop_update_index]=1;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_direction[loop_update_index]=(loop_count[loop_update_index]+1'b1)<loop_trip[loop_update_index];
                    n_loop_ahead[loop_update_index]=({1'b0,loop_count[loop_update_index]}+2)<{1'b0,loop_trip[loop_update_index]};
                end
            end else begin
                n_loop_overflow[loop_update_index]=0;
                if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_direction[loop_update_index]=1;
                    n_loop_ahead[loop_update_index]=loop_count[loop_update_index]>1;
                    if(loop_trip[loop_update_index]==loop_count[loop_update_index]) begin
                        if(loop_confidence[loop_update_index]!=3)
                            n_loop_confidence[loop_update_index]=loop_confidence[loop_update_index]+1'b1;
                    end else n_loop_confidence[loop_update_index]=0;
                end
            end
        end

end
if(clk_event)begin
        if(!rst_n) begin end
        else if(invalidate) begin end
        else if(train_update && loop_backward) begin
            if(loop_count_write_enable) n_loop_count[loop_update_index]=loop_count_write_data;
            if(loop_trip_write_enable) n_loop_trip[loop_update_index]=loop_trip_write_data;
        end

end
end endmodule
module loop_transition_miter(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[463:0]state,output same);wire[463:0]a,b;baseline_loop aa(.clk_event(clk_event),.reset_fall(reset_fall),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(state),.next_state(a));modified_loop bb(.clk_event(clk_event),.reset_fall(reset_fall),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(state),.next_state(b));assign same=(reset_fall && rst_n) || a==b;endmodule
module loop_sequence_miter(input clk,input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,output same);reg[463:0]qa,qb;wire[463:0]a,b;baseline_loop aa(.clk_event(clk_event),.reset_fall(reset_fall && !rst_n),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(qa),.next_state(a));modified_loop bb(.clk_event(clk_event),.reset_fall(reset_fall && !rst_n),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(qb),.next_state(b));always @(posedge clk)begin qa<=a;qb<=b;end assign same=qa==qb;endmodule

from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
original=ROOT/'rtl_proposals/load_simple_loop16_h4'
monitor=(original/'monitor_longs.py').read_text()
monitor=monitor.replace("sessions={'V0':46351,'V1':39806}","sessions={'V0':49643,'V1':80420}").replace('sg21-loop16-h4-i6000-','sg25-loop-single-write-i6000-')
(HERE/'monitor_longs.py').write_text(monitor,encoding='utf-8')
finalizer=(original/'finalize_longs.py').read_text()
finalizer=finalizer.replace('candidates/load_simple_loop16_h4','candidates/loop16_h4_single_write').replace('sg21-loop16-h4-i6000-','sg25-loop-single-write-i6000-')
finalizer=finalizer.replace('c7ab29adf836d1f94a9b637d4e8489412774bef95f254fde386b63aa03e7f194','3acadd2d7307bf1a9afd7fd6e893801719cfd8ffab1b3b067b3b5e1e3bae4ded')
finalizer=finalizer.replace("short=load(HERE/('SCREEN-MODIFIED-'+role+'.json'))", "short=next(row['modified'] for row in load(HERE/'FULL100_INTERFACE_EQUIVALENCE.json')['records'] if row['role']==role)\n    prior=load(ROOT/('rtl_proposals/load_simple_loop16_h4/LONG_'+role+'_RESULT.json'))['run']\n    assert raw['cycles']==prior['timed_cycles'] and raw['retired']==prior['retired']")
finalizer=finalizer.replace("raw_UART_observer_CSR_counters_match=True", "raw_UART_observer_CSR_counters_match=True,qualified_H4_long_cycles_and_retired_equal=True")
finalizer=finalizer.replace('H4_LONG_FINAL_AUDIT','LOOP_SINGLE_WRITE_LONG_FINAL_AUDIT')
(HERE/'finalize_longs.py').write_text(finalizer,encoding='utf-8')
print('LOOP_SINGLE_WRITE_READONLY_LONG_AUDIT_RUNNERS_READY')

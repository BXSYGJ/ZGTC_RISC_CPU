from pathlib import Path
import difflib
import hashlib
import json
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
BASE=ROOT/'candidates/load_simple_loop16_h4'
DEST=ROOT/'candidates/loop16_h4_single_write'
V1=ROOT/'rtl_proposals/loop16_h4_data_lutram'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=(BASE/'rtl/rv32_btb.sv').read_text()
assert sha(BASE/'rtl/rv32_btb.sv')=='b362dea594ba68f5eba4274ee054a5ec4d09e57b2695c695f1b2bdf849e8eca0'
after=(V1/'MODIFIED_FILE.sv').read_text()
old_decl='    (* syn_ramstyle="lut_ram" *) reg [LOOP_COUNT_BITS-1:0] loop_count[0:LOOP_ENTRIES-1],loop_trip[0:LOOP_ENTRIES-1];'
new_decl='    (* syn_ramstyle="lut_ram" *) reg [LOOP_COUNT_BITS-1:0] loop_count[0:LOOP_ENTRIES-1];\n    (* syn_ramstyle="lut_ram" *) reg [LOOP_COUNT_BITS-1:0] loop_trip[0:LOOP_ENTRIES-1];'
assert after.count(old_decl)==1
after=after.replace(old_decl,new_decl,1)
removals={
    '                loop_count[loop_update_index]<=update_taken ? 1 : 0;\n':1,
    '                loop_trip[loop_update_index]<=0;\n':1,
    "                    loop_count[loop_update_index]<=loop_count[loop_update_index]+1'b1;\n":1,
    '                loop_count[loop_update_index]<=0;\n':1,
    '                    loop_trip[loop_update_index]<=0;\n':1,
    '                    loop_trip[loop_update_index]<=loop_count[loop_update_index];\n':1,
}
lines=after.splitlines(True)
for fragment,count in removals.items():
    assert lines.count(fragment)==count,fragment
lines=[line for line in lines if line not in removals]
after=''.join(lines)
anchor='    always @(posedge clk or negedge rst_n) begin\n        if(!rst_n) loop_valid<=0;'
comb='''    reg [LOOP_COUNT_BITS-1:0] loop_count_write_data,loop_trip_write_data;
    reg loop_count_write_enable,loop_trip_write_enable;
    // Give each data memory one explicit write port; branch decisions preserve
    // the original procedural if semantics for X/Z controls at clock edges.
    always @* begin
        loop_count_write_data=8'd0;
        loop_trip_write_data=8'd0;
        loop_count_write_enable=1'b0;
        loop_trip_write_enable=1'b0;
        if(!loop_update_match) begin
            loop_count_write_enable=1'b1;
            loop_count_write_data=update_taken ? 8'd1 : 8'd0;
            loop_trip_write_enable=1'b1;
        end else if(update_taken) begin
            if(&loop_count[loop_update_index]) begin end
            else begin
                loop_count_write_enable=1'b1;
                loop_count_write_data=loop_count[loop_update_index]+1'b1;
            end
        end else begin
            loop_count_write_enable=1'b1;
            loop_trip_write_enable=1'b1;
            if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin end
            else loop_trip_write_data=loop_count[loop_update_index];
        end
    end
'''
assert after.count(anchor)==1
after=after.replace(anchor,comb+anchor,1)
anchor2='    assign predicted_taken='
write='''    always @(posedge clk) begin
        if(!rst_n) begin end
        else if(invalidate) begin end
        else if(train_update && loop_backward) begin
            if(loop_count_write_enable) loop_count[loop_update_index]<=loop_count_write_data;
            if(loop_trip_write_enable) loop_trip[loop_update_index]<=loop_trip_write_data;
        end
    end
'''
assert after.count(anchor2)==1
after=after.replace(anchor2,write+anchor2,1)
assert after.count('loop_count[loop_update_index]<=')==after.count('loop_trip[loop_update_index]<=')==1
shutil.copy2(BASE/'rtl/rv32_btb.sv',HERE/'BASELINE_FILE.sv')
(HERE/'MODIFIED_FILE.sv').write_text(after,encoding='utf-8')
shutil.copy2(HERE/'MODIFIED_FILE.sv',HERE/'rv32_btb.sv')
(HERE/'DIFF_FILE.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='H4/rv32_btb.sv',tofile='H4-singlewrite/rv32_btb.sv')),encoding='utf-8')
change=dict(changed_field='Keep original H4/Loop16 semantics and capacity; one explicit synchronous write port each for loop_count/loop_trip, combinational next-data/enable from original procedural branches; async reset retained only on loop_valid.',
            baseline_sha256=sha(HERE/'BASELINE_FILE.sv'),modified_sha256=sha(HERE/'MODIFIED_FILE.sv'),
            retained_core_sha256=sha(BASE/'rtl/rv32_core.sv'),retained_cache_sha256=sha(BASE/'rtl/rv32_cache.sv'),
            source_chain=str(BASE),v1_sources_preserved=True,before=before,after=after,
            memory_capacity=dict(entries=16,loop_count_bits=8,loop_trip_bits=8,history_bits=4),
            rationale='sg21 and sg23 both map128 countFF+128 tripFF; sg23 consumes RAM attribute but retains multi-site conditional writes. V2 consolidates each array to one write statement without changing the values or cycles.',
            v1_synthesis_netlist_sha256=sha(ROOT/'work/sg23-loopram-synth/synthesis/synthesize/pds_soc_top_syn.vm'))
for folder,total in (('rtl',17),('physical_rtl',18)):
    directory=DEST/folder
    directory.mkdir(parents=True,exist_ok=True)
    for p in (BASE/folder).glob('*.sv'):
        shutil.copy2(HERE/'MODIFIED_FILE.sv' if p.name=='rv32_btb.sv' else p,directory/p.name)
    assert len(list(directory.glob('*.sv')))==total
    change[folder]={p.name:sha(p) for p in sorted(directory.glob('*.sv'))}
    assert all(p.name=='rv32_btb.sv' or p.read_bytes()==(BASE/folder/p.name).read_bytes() for p in directory.glob('*.sv'))
for name in ('core_token_tb.sv','loop_predictor_tb.sv','Test-Rollback.ps1','verify_core.py','predictor_checks.py','four_state.py'):
    shutil.copy2(V1/name,HERE/name)
verify=(HERE/'verify_core.py').read_text().replace('candidates/loop16_h4_data_lutram','candidates/loop16_h4_single_write')
(HERE/'verify_core.py').write_text(verify,encoding='utf-8')
rollback=(V1/'ROLLBACK.sh').read_text(encoding='utf-8-sig').replace('LOOP_DATA_LUTRAM_ROLLBACK_PASS','LOOP_SINGLE_WRITE_ROLLBACK_PASS')
for name in ('ROLLBACK.sh','ROLLBACK.ps1'):
    (HERE/name).write_text(rollback,encoding='utf-8-sig')
(HERE/'CHANGE.json').write_text(json.dumps(change,indent=2)+'\n',encoding='utf-8-sig')
print('LOOP_SINGLE_WRITE_PREPARED BTB='+change['modified_sha256']+' core='+change['retained_core_sha256']+' cache='+change['retained_cache_sha256']+' frozen=17/18',flush=True)

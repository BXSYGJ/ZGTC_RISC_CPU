"""Check actual production loop memories, unknown controls and async reset."""
from pathlib import Path
import json
import subprocess

HERE=Path(__file__).resolve().parent
source=(HERE/'history_default_tb.sv').read_text()
source=source.replace('integer checks=0,hits=0,ras_checks=0,invalidates=0,rejected=0,i,j;',
                      'integer checks=0,hits=0,ras_checks=0,invalidates=0,rejected=0,i,j,k,phase,a,b,c; integer unknown_reset_writes=0;reg[3:0]four_values=4\'bZX10;')
anchor='for(j=1;j<4;j=j+1) if({taken[j],hit[j],available[j],target[j],ras[j]} !== {taken[0],hit[0],available[0],target[0],ras[0]}) $fatal(1,"BTB_BASE_OUTPUT_CHANGED variant=%0d cycle=%0d",j,checks);'
assert source.count(anchor)==1
state='''
if(ref_dut.loop_valid !== mod_dut.loop_valid || ref_dut.loop_valid !== rollback_dut.loop_valid) $fatal(1,"LOOP_VALID_CHANGED");
for(k=0;k<16;k=k+1)begin
 if({ref_dut.loop_tag[k],ref_dut.loop_count[k],ref_dut.loop_trip[k],ref_dut.loop_confidence[k],ref_dut.loop_overflow[k],ref_dut.loop_direction[k],ref_dut.loop_ahead[k]} !==
    {mod_dut.loop_tag[k],mod_dut.loop_count[k],mod_dut.loop_trip[k],mod_dut.loop_confidence[k],mod_dut.loop_overflow[k],mod_dut.loop_direction[k],mod_dut.loop_ahead[k]})$fatal(1,"LOOP_ALL_STATE_CHANGED entry=%0d checks=%0d",k,checks);
 if({ref_dut.loop_tag[k],ref_dut.loop_count[k],ref_dut.loop_trip[k],ref_dut.loop_confidence[k],ref_dut.loop_overflow[k],ref_dut.loop_direction[k],ref_dut.loop_ahead[k]} !==
    {rollback_dut.loop_tag[k],rollback_dut.loop_count[k],rollback_dut.loop_trip[k],rollback_dut.loop_confidence[k],rollback_dut.loop_overflow[k],rollback_dut.loop_direction[k],rollback_dut.loop_ahead[k]})$fatal(1,"LOOP_ROLLBACK_STATE_CHANGED");
end
'''
source=source.replace(anchor,anchor+state)
anchor2='if(hits<10 || (RETURN_STACK_DEPTH>0 && ras_checks<10))$fatal(1,"Insufficient predictor coverage");'
assert source.count(anchor2)==1
directed='''
// A binary asynchronous reset must leave data memories untouched and clear
// validity immediately, even while a write was otherwise eligible.
update_pc=32'h400;update_target=32'h380;fetch_pc=update_pc;update_valid=1;update_conditional=1;update_taken=1;update_return=0;invalidate=0;stack_push=0;stack_pop=0;
#1;rst_n=0;#1;check;if(mod_dut.loop_valid!==0)$fatal(1,"ASYNC_LOOP_VALID_RESET_FAILED");
update_valid=0;rst_n=1;repeat((1<<INDEX_BITS)+2)tick;
// Stabilize X/Z reset before enabling writes, then exercise the original
// procedural if chain at the clock edge. This exposes the &&-gate X mismatch.
for(phase=0;phase<2;phase=phase+1)begin
 update_valid=0;rst_n=phase==0 ? 1'bx:1'bz;#1;check;
 for(a=0;a<4;a=a+1)for(b=0;b<4;b=b+1)for(c=0;c<4;c=c+1)begin
  invalidate=four_values[a];update_valid=four_values[b];update_taken=four_values[c];
  update_pc=32'h400;update_target=32'h380;fetch_pc=update_pc;tick;
  if(invalidate===0 && update_valid===1 && ref_dut.train_update===1)unknown_reset_writes=unknown_reset_writes+1;
 end
 update_valid=0;invalidate=0;rst_n=1;repeat((1<<INDEX_BITS)+2)tick;
end
if(unknown_reset_writes<8)$fatal(1,"UNKNOWN_RESET_POSEDGE_COVERAGE_MISSING %0d",unknown_reset_writes);
$display("LOOP_DATA_FOUR_STATE_PASS all_arrays=7 entries=16 unknown_reset_posedge_writes=%0d checks=%0d async_reset=covered",unknown_reset_writes,checks);
'''
source=source.replace(anchor2,directed+anchor2)
(HERE/'loop_four_state_tb.sv').write_text(source,encoding='utf-8')
def run(command,label):
    p=subprocess.run(command,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label+'.log')).write_text(p.stdout,encoding='utf-8')
    receipt=dict(command=command,input_directory=str(HERE),literal_output=p.stdout,exit_status=p.returncode)
    assert p.returncode==0,p.stdout[-3000:]
    return receipt
compile=run(['iverilog','-g2012','-s','history_default_tb','-Phistory_default_tb.INDEX_BITS=8','-Phistory_default_tb.ADDRESS_BITS=16','-Phistory_default_tb.RETURN_STACK_DEPTH=1','-o','four-state.vvp','loop_four_state_tb.sv','reference_btb.sv','MODIFIED_FILE.sv','rollback_btb.sv'],'four-state-compile')
actual=run(['vvp','four-state.vvp'],'four-state')
assert 'LOOP_DATA_FOUR_STATE_PASS' in actual['literal_output']
(HERE/'FOUR_STATE_EQUIVALENCE.json').write_text(json.dumps(dict(status='PASS',compile=compile,run=actual),indent=2)+'\n',encoding='utf-8')
print(actual['literal_output'],end='')

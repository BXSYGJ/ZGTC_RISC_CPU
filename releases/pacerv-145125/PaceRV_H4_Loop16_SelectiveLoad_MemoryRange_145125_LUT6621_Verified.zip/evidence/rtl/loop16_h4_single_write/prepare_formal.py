from pathlib import Path
HERE=Path(__file__).resolve().parent
source=(HERE.parent/'loop16_h4_data_lutram/formal.py').read_text()
source=source.replace("assert after.replace(change['new_declaration'],change['old_declaration'],1).replace(change['new_head'],change['old_head'],1)==before", "assert change['before']==before and change['after']==after")
start=source.index('def production_blocks(text):')
end=source.index('\ndef model(',start)
replacement='''def production_blocks(text):
    start=text.index('\\n',text.index('    wire loop_prediction='))+1
    section=text[start:text.index('    assign predicted_taken=')]
    matches=re.findall(r'^    always (@\\(([^)]+)\\)|@\\*) begin\\n(.*?)^    end\\n',section,flags=re.M|re.S)
    blocks=[(event or '*',body) for syntax,event,body in matches]
    assert len(blocks) in (1,4)
    return blocks
'''
source=source[:start]+replacement+source[end:]
source=source.replace("'localparam ADDRESS_BITS='+str(address)+';',", "'localparam ADDRESS_BITS='+str(address)+'; localparam LOOP_COUNT_BITS=8;',")
anchor="    at=16\n"
source=source.replace(anchor,"    if 'loop_count_write_data' in text:\n        lines+=['reg [7:0]loop_count_write_data,loop_trip_write_data;reg loop_count_write_enable,loop_trip_write_enable;']\n"+anchor,1)
old="        gate='clk_event || reset_fall' if 'negedge rst_n' in event else 'clk_event'\n        lines+=['if('+gate+')begin',body,'end']"
new="        if event=='*':\n            lines+=[body]\n        else:\n            gate='clk_event || reset_fall' if 'negedge rst_n' in event else 'clk_event'\n            lines+=['if('+gate+')begin',body,'end']"
assert old in source
source=source.replace(old,new,1)
source=source.replace("negative=after.replace('loop_trip[loop_update_index]<=0;','loop_trip[loop_update_index]<=1;',1)","negative=after.replace(\"loop_trip_write_data=8'd0;\",\"loop_trip_write_data=8'd1;\",1)\nassert negative!=after")
source=source.replace('LOOP_DATA_','LOOP_SINGLE_WRITE_').replace('exact_inverse=True,','source_text_bound=True,')
(HERE/'formal.py').write_text(source,encoding='utf-8')
print('SINGLE_WRITE_FORMAL_EXTRACTION_READY')

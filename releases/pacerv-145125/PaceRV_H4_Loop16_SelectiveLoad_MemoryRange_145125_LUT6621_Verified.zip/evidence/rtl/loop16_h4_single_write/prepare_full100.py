from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
source=(ROOT/'rtl_proposals/timing_packed_valid_quarters_v3/benchmark_equivalence_stream.py').read_text()
source=source[:source.index('\ndef main():')]
source=source.replace("SOURCE = ROOT / 'candidates/timing_packed_valid_quarters_v3/rtl'","SOURCE = ROOT / 'candidates/loop16_h4_single_write/rtl'")
source=source.replace("PRISTINE = ROOT / 'candidates/load_simple/rtl'","PRISTINE = ROOT / 'candidates/load_simple_loop16_h4/rtl'")
source=source.replace("WORK = Path('/tmp/pacerv_timing_packed_valid_quarters_v3_full100_r2')","WORK = Path('/tmp/pacerv_loop16_h4_single_write_full100')")
source=source.replace("CACHE_SHA = '1045feea53dfd57a29b916091f5f7dea9e14d0c499b64306ed665bef9136d450'","CACHE_SHA = 'c9d73d59e80a70399df214dfbbe3316083e6df0d33974e1564795a4ae875d6c1'")
source=source.replace("p = ROOT/'candidates/timing_packed_valid_quarters_v3'/folder","p = ROOT/'candidates/loop16_h4_single_write'/folder")
source=source.replace("expected = json.loads((original/'RUN.json').read_text(encoding='utf-8-sig'))","expected = json.loads((ROOT/'work'/('sg-loop16-sl-h4-i100-'+role)/'RUN.json').read_text(encoding='utf-8-sig'))")
source=source.replace('QUARTER_FULL100_NATIVE_PASS','LOOP_SINGLE_WRITE_FULL100_NATIVE_PASS')
source+='''

def compile_model(label,rtl):
    prior_build=json.loads((BASELINE/'BUILD.json').read_text())
    builddir=WORK/('COMPILED_'+label)
    inputs=builddir/'inputs'
    inputs.mkdir(parents=True)
    for path in (BASELINE/'inputs').iterdir():
        if path.is_file():shutil.copy2(path,inputs/path.name)
    for path in rtl.glob('*.sv'):
        shutil.copy2(path,inputs/path.name)
    input_hashes={p.name:digest(p) for p in inputs.iterdir() if p.is_file()}
    assert all(p.read_bytes()==(inputs/p.name).read_bytes() for p in rtl.glob('*.sv'))
    argv=[x.replace(str(BASELINE),str(builddir)) for x in prior_build['command']]
    argv[argv.index('-j')+1]='1'
    started=time.monotonic()
    with (builddir/'build.log').open('w') as log:
        code=subprocess.run(argv,cwd=builddir,stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
    assert code==0,(builddir/'build.log').read_text()[-6000:]
    executable=builddir/'objects/Vrv32_observed_soc'
    build=dict(command=argv,cwd=str(builddir),exit_status=code,seconds=time.monotonic()-started,input_sha256=input_hashes,executable_sha256=digest(executable),standard_simulation_rtl_identity=standard_rtl_identity(rtl))
    save(builddir/'BUILD.json',build)
    binding=dict(model_executable=str(executable),build_receipt=str(builddir/'BUILD.json'),**build)
    print('LOOP_SINGLE_WRITE_FULL100_COMPILED '+label+' RTL='+binding['standard_simulation_rtl_identity'],flush=True)
    return executable,binding

def main():
    assert not WORK.exists(),'Preserve existing evidence'
    WORK.mkdir()
    frozen=assert_sources()
    base_exe,base_binding=compile_model('BASELINE',PRISTINE)
    modified_exe,modified_binding=compile_model('MODIFIED',SOURCE)
    assert base_binding['standard_simulation_rtl_identity']=='c7ab29adf836d1f94a9b637d4e8489412774bef95f254fde386b63aa03e7f194'
    changed=[name for name in base_binding['input_sha256'] if base_binding['input_sha256'][name]!=modified_binding['input_sha256'][name]]
    assert changed==['rv32_btb.sv']
    evidence=dict(status='RUNNING_BOTH_ROLES_ACTUAL_FULL100',changed_field=CHANGE['changed_field'],only_changed_production_input='rv32_btb.sv',baseline_build=base_binding,modified_build=modified_binding,standard_simulation_rtl_identity=modified_binding['standard_simulation_rtl_identity'],records=[],pending=['V0','V1'],frozen_files=frozen)
    save(AREA/'FULL100_INTERFACE_EQUIVALENCE.json',evidence)
    keys=['trace_sha256','trace_bytes','interface_sha256','interface_bytes','uart_sha256','timed_cycles','retired']
    for role in ['V0','V1']:
        with ThreadPoolExecutor(max_workers=2) as pool:
            base_future=pool.submit(run_native,WORK/('BASELINE_'+role),base_exe,role,base_binding)
            mod_future=pool.submit(run_native,WORK/('MODIFIED_'+role),modified_exe,role,modified_binding)
            before,after=base_future.result(),mod_future.result()
        assert all(before[key]==after[key] for key in keys)
        evidence['records'].append(dict(role=role,baseline=before,modified=after,compared_fields=keys,all_equal=True))
        evidence['pending'].remove(role)
        evidence.update(updated_utc=utc(),status='PASS_BOTH_ROLES_ACTUAL_FULL100' if not evidence['pending'] else 'V0_VERIFIED_V1_PENDING')
        save(AREA/'FULL100_INTERFACE_EQUIVALENCE.json',evidence)
        print('LOOP_SINGLE_WRITE_FULL100_EQUAL '+role+' retirement=identical interface=identical uart=identical cycles='+str(after['timed_cycles']),flush=True)
    assert assert_sources()==frozen
    assert digest(base_exe)==base_binding['executable_sha256'] and digest(modified_exe)==modified_binding['executable_sha256']
    print('LOOP_SINGLE_WRITE_FULL100_FINAL_PASS roles=2 actual_retirement_interface_uart=all_identical exact_firmware=True source=17/18',flush=True)

if __name__=='__main__':
    main()
'''
(HERE/'benchmark_equivalence_stream.py').write_text(source,encoding='utf-8')
print('SINGLE_WRITE_FULL100_RUNNER_READY')

module baseline_loop(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[847:0]state,output[847:0]next_state);
localparam ADDRESS_BITS=32; localparam LOOP_COUNT_BITS=8;
wire[15:0]loop_valid=state[15:0]; reg[15:0]n_loop_valid;
assign next_state[15:0]=n_loop_valid;
wire[30:0]loop_tag[0:15];reg[30:0]n_loop_tag[0:15];
assign loop_tag[0]=state[16+:31];
assign next_state[16+:31]=n_loop_tag[0];
assign loop_tag[1]=state[47+:31];
assign next_state[47+:31]=n_loop_tag[1];
assign loop_tag[2]=state[78+:31];
assign next_state[78+:31]=n_loop_tag[2];
assign loop_tag[3]=state[109+:31];
assign next_state[109+:31]=n_loop_tag[3];
assign loop_tag[4]=state[140+:31];
assign next_state[140+:31]=n_loop_tag[4];
assign loop_tag[5]=state[171+:31];
assign next_state[171+:31]=n_loop_tag[5];
assign loop_tag[6]=state[202+:31];
assign next_state[202+:31]=n_loop_tag[6];
assign loop_tag[7]=state[233+:31];
assign next_state[233+:31]=n_loop_tag[7];
assign loop_tag[8]=state[264+:31];
assign next_state[264+:31]=n_loop_tag[8];
assign loop_tag[9]=state[295+:31];
assign next_state[295+:31]=n_loop_tag[9];
assign loop_tag[10]=state[326+:31];
assign next_state[326+:31]=n_loop_tag[10];
assign loop_tag[11]=state[357+:31];
assign next_state[357+:31]=n_loop_tag[11];
assign loop_tag[12]=state[388+:31];
assign next_state[388+:31]=n_loop_tag[12];
assign loop_tag[13]=state[419+:31];
assign next_state[419+:31]=n_loop_tag[13];
assign loop_tag[14]=state[450+:31];
assign next_state[450+:31]=n_loop_tag[14];
assign loop_tag[15]=state[481+:31];
assign next_state[481+:31]=n_loop_tag[15];
wire[7:0]loop_count[0:15];reg[7:0]n_loop_count[0:15];
assign loop_count[0]=state[512+:8];
assign next_state[512+:8]=n_loop_count[0];
assign loop_count[1]=state[520+:8];
assign next_state[520+:8]=n_loop_count[1];
assign loop_count[2]=state[528+:8];
assign next_state[528+:8]=n_loop_count[2];
assign loop_count[3]=state[536+:8];
assign next_state[536+:8]=n_loop_count[3];
assign loop_count[4]=state[544+:8];
assign next_state[544+:8]=n_loop_count[4];
assign loop_count[5]=state[552+:8];
assign next_state[552+:8]=n_loop_count[5];
assign loop_count[6]=state[560+:8];
assign next_state[560+:8]=n_loop_count[6];
assign loop_count[7]=state[568+:8];
assign next_state[568+:8]=n_loop_count[7];
assign loop_count[8]=state[576+:8];
assign next_state[576+:8]=n_loop_count[8];
assign loop_count[9]=state[584+:8];
assign next_state[584+:8]=n_loop_count[9];
assign loop_count[10]=state[592+:8];
assign next_state[592+:8]=n_loop_count[10];
assign loop_count[11]=state[600+:8];
assign next_state[600+:8]=n_loop_count[11];
assign loop_count[12]=state[608+:8];
assign next_state[608+:8]=n_loop_count[12];
assign loop_count[13]=state[616+:8];
assign next_state[616+:8]=n_loop_count[13];
assign loop_count[14]=state[624+:8];
assign next_state[624+:8]=n_loop_count[14];
assign loop_count[15]=state[632+:8];
assign next_state[632+:8]=n_loop_count[15];
wire[7:0]loop_trip[0:15];reg[7:0]n_loop_trip[0:15];
assign loop_trip[0]=state[640+:8];
assign next_state[640+:8]=n_loop_trip[0];
assign loop_trip[1]=state[648+:8];
assign next_state[648+:8]=n_loop_trip[1];
assign loop_trip[2]=state[656+:8];
assign next_state[656+:8]=n_loop_trip[2];
assign loop_trip[3]=state[664+:8];
assign next_state[664+:8]=n_loop_trip[3];
assign loop_trip[4]=state[672+:8];
assign next_state[672+:8]=n_loop_trip[4];
assign loop_trip[5]=state[680+:8];
assign next_state[680+:8]=n_loop_trip[5];
assign loop_trip[6]=state[688+:8];
assign next_state[688+:8]=n_loop_trip[6];
assign loop_trip[7]=state[696+:8];
assign next_state[696+:8]=n_loop_trip[7];
assign loop_trip[8]=state[704+:8];
assign next_state[704+:8]=n_loop_trip[8];
assign loop_trip[9]=state[712+:8];
assign next_state[712+:8]=n_loop_trip[9];
assign loop_trip[10]=state[720+:8];
assign next_state[720+:8]=n_loop_trip[10];
assign loop_trip[11]=state[728+:8];
assign next_state[728+:8]=n_loop_trip[11];
assign loop_trip[12]=state[736+:8];
assign next_state[736+:8]=n_loop_trip[12];
assign loop_trip[13]=state[744+:8];
assign next_state[744+:8]=n_loop_trip[13];
assign loop_trip[14]=state[752+:8];
assign next_state[752+:8]=n_loop_trip[14];
assign loop_trip[15]=state[760+:8];
assign next_state[760+:8]=n_loop_trip[15];
wire[1:0]loop_confidence[0:15];reg[1:0]n_loop_confidence[0:15];
assign loop_confidence[0]=state[768+:2];
assign next_state[768+:2]=n_loop_confidence[0];
assign loop_confidence[1]=state[770+:2];
assign next_state[770+:2]=n_loop_confidence[1];
assign loop_confidence[2]=state[772+:2];
assign next_state[772+:2]=n_loop_confidence[2];
assign loop_confidence[3]=state[774+:2];
assign next_state[774+:2]=n_loop_confidence[3];
assign loop_confidence[4]=state[776+:2];
assign next_state[776+:2]=n_loop_confidence[4];
assign loop_confidence[5]=state[778+:2];
assign next_state[778+:2]=n_loop_confidence[5];
assign loop_confidence[6]=state[780+:2];
assign next_state[780+:2]=n_loop_confidence[6];
assign loop_confidence[7]=state[782+:2];
assign next_state[782+:2]=n_loop_confidence[7];
assign loop_confidence[8]=state[784+:2];
assign next_state[784+:2]=n_loop_confidence[8];
assign loop_confidence[9]=state[786+:2];
assign next_state[786+:2]=n_loop_confidence[9];
assign loop_confidence[10]=state[788+:2];
assign next_state[788+:2]=n_loop_confidence[10];
assign loop_confidence[11]=state[790+:2];
assign next_state[790+:2]=n_loop_confidence[11];
assign loop_confidence[12]=state[792+:2];
assign next_state[792+:2]=n_loop_confidence[12];
assign loop_confidence[13]=state[794+:2];
assign next_state[794+:2]=n_loop_confidence[13];
assign loop_confidence[14]=state[796+:2];
assign next_state[796+:2]=n_loop_confidence[14];
assign loop_confidence[15]=state[798+:2];
assign next_state[798+:2]=n_loop_confidence[15];
wire[0:0]loop_overflow[0:15];reg[0:0]n_loop_overflow[0:15];
assign loop_overflow[0]=state[800+:1];
assign next_state[800+:1]=n_loop_overflow[0];
assign loop_overflow[1]=state[801+:1];
assign next_state[801+:1]=n_loop_overflow[1];
assign loop_overflow[2]=state[802+:1];
assign next_state[802+:1]=n_loop_overflow[2];
assign loop_overflow[3]=state[803+:1];
assign next_state[803+:1]=n_loop_overflow[3];
assign loop_overflow[4]=state[804+:1];
assign next_state[804+:1]=n_loop_overflow[4];
assign loop_overflow[5]=state[805+:1];
assign next_state[805+:1]=n_loop_overflow[5];
assign loop_overflow[6]=state[806+:1];
assign next_state[806+:1]=n_loop_overflow[6];
assign loop_overflow[7]=state[807+:1];
assign next_state[807+:1]=n_loop_overflow[7];
assign loop_overflow[8]=state[808+:1];
assign next_state[808+:1]=n_loop_overflow[8];
assign loop_overflow[9]=state[809+:1];
assign next_state[809+:1]=n_loop_overflow[9];
assign loop_overflow[10]=state[810+:1];
assign next_state[810+:1]=n_loop_overflow[10];
assign loop_overflow[11]=state[811+:1];
assign next_state[811+:1]=n_loop_overflow[11];
assign loop_overflow[12]=state[812+:1];
assign next_state[812+:1]=n_loop_overflow[12];
assign loop_overflow[13]=state[813+:1];
assign next_state[813+:1]=n_loop_overflow[13];
assign loop_overflow[14]=state[814+:1];
assign next_state[814+:1]=n_loop_overflow[14];
assign loop_overflow[15]=state[815+:1];
assign next_state[815+:1]=n_loop_overflow[15];
wire[0:0]loop_direction[0:15];reg[0:0]n_loop_direction[0:15];
assign loop_direction[0]=state[816+:1];
assign next_state[816+:1]=n_loop_direction[0];
assign loop_direction[1]=state[817+:1];
assign next_state[817+:1]=n_loop_direction[1];
assign loop_direction[2]=state[818+:1];
assign next_state[818+:1]=n_loop_direction[2];
assign loop_direction[3]=state[819+:1];
assign next_state[819+:1]=n_loop_direction[3];
assign loop_direction[4]=state[820+:1];
assign next_state[820+:1]=n_loop_direction[4];
assign loop_direction[5]=state[821+:1];
assign next_state[821+:1]=n_loop_direction[5];
assign loop_direction[6]=state[822+:1];
assign next_state[822+:1]=n_loop_direction[6];
assign loop_direction[7]=state[823+:1];
assign next_state[823+:1]=n_loop_direction[7];
assign loop_direction[8]=state[824+:1];
assign next_state[824+:1]=n_loop_direction[8];
assign loop_direction[9]=state[825+:1];
assign next_state[825+:1]=n_loop_direction[9];
assign loop_direction[10]=state[826+:1];
assign next_state[826+:1]=n_loop_direction[10];
assign loop_direction[11]=state[827+:1];
assign next_state[827+:1]=n_loop_direction[11];
assign loop_direction[12]=state[828+:1];
assign next_state[828+:1]=n_loop_direction[12];
assign loop_direction[13]=state[829+:1];
assign next_state[829+:1]=n_loop_direction[13];
assign loop_direction[14]=state[830+:1];
assign next_state[830+:1]=n_loop_direction[14];
assign loop_direction[15]=state[831+:1];
assign next_state[831+:1]=n_loop_direction[15];
wire[0:0]loop_ahead[0:15];reg[0:0]n_loop_ahead[0:15];
assign loop_ahead[0]=state[832+:1];
assign next_state[832+:1]=n_loop_ahead[0];
assign loop_ahead[1]=state[833+:1];
assign next_state[833+:1]=n_loop_ahead[1];
assign loop_ahead[2]=state[834+:1];
assign next_state[834+:1]=n_loop_ahead[2];
assign loop_ahead[3]=state[835+:1];
assign next_state[835+:1]=n_loop_ahead[3];
assign loop_ahead[4]=state[836+:1];
assign next_state[836+:1]=n_loop_ahead[4];
assign loop_ahead[5]=state[837+:1];
assign next_state[837+:1]=n_loop_ahead[5];
assign loop_ahead[6]=state[838+:1];
assign next_state[838+:1]=n_loop_ahead[6];
assign loop_ahead[7]=state[839+:1];
assign next_state[839+:1]=n_loop_ahead[7];
assign loop_ahead[8]=state[840+:1];
assign next_state[840+:1]=n_loop_ahead[8];
assign loop_ahead[9]=state[841+:1];
assign next_state[841+:1]=n_loop_ahead[9];
assign loop_ahead[10]=state[842+:1];
assign next_state[842+:1]=n_loop_ahead[10];
assign loop_ahead[11]=state[843+:1];
assign next_state[843+:1]=n_loop_ahead[11];
assign loop_ahead[12]=state[844+:1];
assign next_state[844+:1]=n_loop_ahead[12];
assign loop_ahead[13]=state[845+:1];
assign next_state[845+:1]=n_loop_ahead[13];
assign loop_ahead[14]=state[846+:1];
assign next_state[846+:1]=n_loop_ahead[14];
assign loop_ahead[15]=state[847+:1];
assign next_state[847+:1]=n_loop_ahead[15];
wire loop_update_match=loop_valid[loop_update_index] && loop_tag[loop_update_index]==update_pc[ADDRESS_BITS-1:1];
integer j;always @* begin n_loop_valid=loop_valid;for(j=0;j<16;j=j+1)begin
n_loop_tag[j]=loop_tag[j];
n_loop_count[j]=loop_count[j];
n_loop_trip[j]=loop_trip[j];
n_loop_confidence[j]=loop_confidence[j];
n_loop_overflow[j]=loop_overflow[j];
n_loop_direction[j]=loop_direction[j];
n_loop_ahead[j]=loop_ahead[j];
end
if(clk_event || reset_fall)begin
        if(!rst_n) n_loop_valid=0;
        else if(invalidate) n_loop_valid=0;
        else if(train_update && loop_backward) begin
            n_loop_valid[loop_update_index]=1;
            n_loop_tag[loop_update_index]=update_pc[ADDRESS_BITS-1:1];
            if(!loop_update_match) begin
                n_loop_count[loop_update_index]=update_taken ? 1 : 0;
                n_loop_trip[loop_update_index]=0;
                n_loop_confidence[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                n_loop_direction[loop_update_index]=1;
                n_loop_ahead[loop_update_index]=1;
            end else if(update_taken) begin
                if(&loop_count[loop_update_index]) begin
                    n_loop_overflow[loop_update_index]=1;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_count[loop_update_index]=loop_count[loop_update_index]+1'b1;
                    n_loop_direction[loop_update_index]=(loop_count[loop_update_index]+1'b1)<loop_trip[loop_update_index];
                    n_loop_ahead[loop_update_index]=({1'b0,loop_count[loop_update_index]}+2)<{1'b0,loop_trip[loop_update_index]};
                end
            end else begin
                n_loop_count[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin
                    n_loop_trip[loop_update_index]=0;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_trip[loop_update_index]=loop_count[loop_update_index];
                    n_loop_direction[loop_update_index]=1;
                    n_loop_ahead[loop_update_index]=loop_count[loop_update_index]>1;
                    if(loop_trip[loop_update_index]==loop_count[loop_update_index]) begin
                        if(loop_confidence[loop_update_index]!=3)
                            n_loop_confidence[loop_update_index]=loop_confidence[loop_update_index]+1'b1;
                    end else n_loop_confidence[loop_update_index]=0;
                end
            end
        end

end
end endmodule
module modified_loop(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[847:0]state,output[847:0]next_state);
localparam ADDRESS_BITS=32; localparam LOOP_COUNT_BITS=8;
wire[15:0]loop_valid=state[15:0]; reg[15:0]n_loop_valid;
assign next_state[15:0]=n_loop_valid;
reg [7:0]loop_count_write_data,loop_trip_write_data;reg loop_count_write_enable,loop_trip_write_enable;
wire[30:0]loop_tag[0:15];reg[30:0]n_loop_tag[0:15];
assign loop_tag[0]=state[16+:31];
assign next_state[16+:31]=n_loop_tag[0];
assign loop_tag[1]=state[47+:31];
assign next_state[47+:31]=n_loop_tag[1];
assign loop_tag[2]=state[78+:31];
assign next_state[78+:31]=n_loop_tag[2];
assign loop_tag[3]=state[109+:31];
assign next_state[109+:31]=n_loop_tag[3];
assign loop_tag[4]=state[140+:31];
assign next_state[140+:31]=n_loop_tag[4];
assign loop_tag[5]=state[171+:31];
assign next_state[171+:31]=n_loop_tag[5];
assign loop_tag[6]=state[202+:31];
assign next_state[202+:31]=n_loop_tag[6];
assign loop_tag[7]=state[233+:31];
assign next_state[233+:31]=n_loop_tag[7];
assign loop_tag[8]=state[264+:31];
assign next_state[264+:31]=n_loop_tag[8];
assign loop_tag[9]=state[295+:31];
assign next_state[295+:31]=n_loop_tag[9];
assign loop_tag[10]=state[326+:31];
assign next_state[326+:31]=n_loop_tag[10];
assign loop_tag[11]=state[357+:31];
assign next_state[357+:31]=n_loop_tag[11];
assign loop_tag[12]=state[388+:31];
assign next_state[388+:31]=n_loop_tag[12];
assign loop_tag[13]=state[419+:31];
assign next_state[419+:31]=n_loop_tag[13];
assign loop_tag[14]=state[450+:31];
assign next_state[450+:31]=n_loop_tag[14];
assign loop_tag[15]=state[481+:31];
assign next_state[481+:31]=n_loop_tag[15];
wire[7:0]loop_count[0:15];reg[7:0]n_loop_count[0:15];
assign loop_count[0]=state[512+:8];
assign next_state[512+:8]=n_loop_count[0];
assign loop_count[1]=state[520+:8];
assign next_state[520+:8]=n_loop_count[1];
assign loop_count[2]=state[528+:8];
assign next_state[528+:8]=n_loop_count[2];
assign loop_count[3]=state[536+:8];
assign next_state[536+:8]=n_loop_count[3];
assign loop_count[4]=state[544+:8];
assign next_state[544+:8]=n_loop_count[4];
assign loop_count[5]=state[552+:8];
assign next_state[552+:8]=n_loop_count[5];
assign loop_count[6]=state[560+:8];
assign next_state[560+:8]=n_loop_count[6];
assign loop_count[7]=state[568+:8];
assign next_state[568+:8]=n_loop_count[7];
assign loop_count[8]=state[576+:8];
assign next_state[576+:8]=n_loop_count[8];
assign loop_count[9]=state[584+:8];
assign next_state[584+:8]=n_loop_count[9];
assign loop_count[10]=state[592+:8];
assign next_state[592+:8]=n_loop_count[10];
assign loop_count[11]=state[600+:8];
assign next_state[600+:8]=n_loop_count[11];
assign loop_count[12]=state[608+:8];
assign next_state[608+:8]=n_loop_count[12];
assign loop_count[13]=state[616+:8];
assign next_state[616+:8]=n_loop_count[13];
assign loop_count[14]=state[624+:8];
assign next_state[624+:8]=n_loop_count[14];
assign loop_count[15]=state[632+:8];
assign next_state[632+:8]=n_loop_count[15];
wire[7:0]loop_trip[0:15];reg[7:0]n_loop_trip[0:15];
assign loop_trip[0]=state[640+:8];
assign next_state[640+:8]=n_loop_trip[0];
assign loop_trip[1]=state[648+:8];
assign next_state[648+:8]=n_loop_trip[1];
assign loop_trip[2]=state[656+:8];
assign next_state[656+:8]=n_loop_trip[2];
assign loop_trip[3]=state[664+:8];
assign next_state[664+:8]=n_loop_trip[3];
assign loop_trip[4]=state[672+:8];
assign next_state[672+:8]=n_loop_trip[4];
assign loop_trip[5]=state[680+:8];
assign next_state[680+:8]=n_loop_trip[5];
assign loop_trip[6]=state[688+:8];
assign next_state[688+:8]=n_loop_trip[6];
assign loop_trip[7]=state[696+:8];
assign next_state[696+:8]=n_loop_trip[7];
assign loop_trip[8]=state[704+:8];
assign next_state[704+:8]=n_loop_trip[8];
assign loop_trip[9]=state[712+:8];
assign next_state[712+:8]=n_loop_trip[9];
assign loop_trip[10]=state[720+:8];
assign next_state[720+:8]=n_loop_trip[10];
assign loop_trip[11]=state[728+:8];
assign next_state[728+:8]=n_loop_trip[11];
assign loop_trip[12]=state[736+:8];
assign next_state[736+:8]=n_loop_trip[12];
assign loop_trip[13]=state[744+:8];
assign next_state[744+:8]=n_loop_trip[13];
assign loop_trip[14]=state[752+:8];
assign next_state[752+:8]=n_loop_trip[14];
assign loop_trip[15]=state[760+:8];
assign next_state[760+:8]=n_loop_trip[15];
wire[1:0]loop_confidence[0:15];reg[1:0]n_loop_confidence[0:15];
assign loop_confidence[0]=state[768+:2];
assign next_state[768+:2]=n_loop_confidence[0];
assign loop_confidence[1]=state[770+:2];
assign next_state[770+:2]=n_loop_confidence[1];
assign loop_confidence[2]=state[772+:2];
assign next_state[772+:2]=n_loop_confidence[2];
assign loop_confidence[3]=state[774+:2];
assign next_state[774+:2]=n_loop_confidence[3];
assign loop_confidence[4]=state[776+:2];
assign next_state[776+:2]=n_loop_confidence[4];
assign loop_confidence[5]=state[778+:2];
assign next_state[778+:2]=n_loop_confidence[5];
assign loop_confidence[6]=state[780+:2];
assign next_state[780+:2]=n_loop_confidence[6];
assign loop_confidence[7]=state[782+:2];
assign next_state[782+:2]=n_loop_confidence[7];
assign loop_confidence[8]=state[784+:2];
assign next_state[784+:2]=n_loop_confidence[8];
assign loop_confidence[9]=state[786+:2];
assign next_state[786+:2]=n_loop_confidence[9];
assign loop_confidence[10]=state[788+:2];
assign next_state[788+:2]=n_loop_confidence[10];
assign loop_confidence[11]=state[790+:2];
assign next_state[790+:2]=n_loop_confidence[11];
assign loop_confidence[12]=state[792+:2];
assign next_state[792+:2]=n_loop_confidence[12];
assign loop_confidence[13]=state[794+:2];
assign next_state[794+:2]=n_loop_confidence[13];
assign loop_confidence[14]=state[796+:2];
assign next_state[796+:2]=n_loop_confidence[14];
assign loop_confidence[15]=state[798+:2];
assign next_state[798+:2]=n_loop_confidence[15];
wire[0:0]loop_overflow[0:15];reg[0:0]n_loop_overflow[0:15];
assign loop_overflow[0]=state[800+:1];
assign next_state[800+:1]=n_loop_overflow[0];
assign loop_overflow[1]=state[801+:1];
assign next_state[801+:1]=n_loop_overflow[1];
assign loop_overflow[2]=state[802+:1];
assign next_state[802+:1]=n_loop_overflow[2];
assign loop_overflow[3]=state[803+:1];
assign next_state[803+:1]=n_loop_overflow[3];
assign loop_overflow[4]=state[804+:1];
assign next_state[804+:1]=n_loop_overflow[4];
assign loop_overflow[5]=state[805+:1];
assign next_state[805+:1]=n_loop_overflow[5];
assign loop_overflow[6]=state[806+:1];
assign next_state[806+:1]=n_loop_overflow[6];
assign loop_overflow[7]=state[807+:1];
assign next_state[807+:1]=n_loop_overflow[7];
assign loop_overflow[8]=state[808+:1];
assign next_state[808+:1]=n_loop_overflow[8];
assign loop_overflow[9]=state[809+:1];
assign next_state[809+:1]=n_loop_overflow[9];
assign loop_overflow[10]=state[810+:1];
assign next_state[810+:1]=n_loop_overflow[10];
assign loop_overflow[11]=state[811+:1];
assign next_state[811+:1]=n_loop_overflow[11];
assign loop_overflow[12]=state[812+:1];
assign next_state[812+:1]=n_loop_overflow[12];
assign loop_overflow[13]=state[813+:1];
assign next_state[813+:1]=n_loop_overflow[13];
assign loop_overflow[14]=state[814+:1];
assign next_state[814+:1]=n_loop_overflow[14];
assign loop_overflow[15]=state[815+:1];
assign next_state[815+:1]=n_loop_overflow[15];
wire[0:0]loop_direction[0:15];reg[0:0]n_loop_direction[0:15];
assign loop_direction[0]=state[816+:1];
assign next_state[816+:1]=n_loop_direction[0];
assign loop_direction[1]=state[817+:1];
assign next_state[817+:1]=n_loop_direction[1];
assign loop_direction[2]=state[818+:1];
assign next_state[818+:1]=n_loop_direction[2];
assign loop_direction[3]=state[819+:1];
assign next_state[819+:1]=n_loop_direction[3];
assign loop_direction[4]=state[820+:1];
assign next_state[820+:1]=n_loop_direction[4];
assign loop_direction[5]=state[821+:1];
assign next_state[821+:1]=n_loop_direction[5];
assign loop_direction[6]=state[822+:1];
assign next_state[822+:1]=n_loop_direction[6];
assign loop_direction[7]=state[823+:1];
assign next_state[823+:1]=n_loop_direction[7];
assign loop_direction[8]=state[824+:1];
assign next_state[824+:1]=n_loop_direction[8];
assign loop_direction[9]=state[825+:1];
assign next_state[825+:1]=n_loop_direction[9];
assign loop_direction[10]=state[826+:1];
assign next_state[826+:1]=n_loop_direction[10];
assign loop_direction[11]=state[827+:1];
assign next_state[827+:1]=n_loop_direction[11];
assign loop_direction[12]=state[828+:1];
assign next_state[828+:1]=n_loop_direction[12];
assign loop_direction[13]=state[829+:1];
assign next_state[829+:1]=n_loop_direction[13];
assign loop_direction[14]=state[830+:1];
assign next_state[830+:1]=n_loop_direction[14];
assign loop_direction[15]=state[831+:1];
assign next_state[831+:1]=n_loop_direction[15];
wire[0:0]loop_ahead[0:15];reg[0:0]n_loop_ahead[0:15];
assign loop_ahead[0]=state[832+:1];
assign next_state[832+:1]=n_loop_ahead[0];
assign loop_ahead[1]=state[833+:1];
assign next_state[833+:1]=n_loop_ahead[1];
assign loop_ahead[2]=state[834+:1];
assign next_state[834+:1]=n_loop_ahead[2];
assign loop_ahead[3]=state[835+:1];
assign next_state[835+:1]=n_loop_ahead[3];
assign loop_ahead[4]=state[836+:1];
assign next_state[836+:1]=n_loop_ahead[4];
assign loop_ahead[5]=state[837+:1];
assign next_state[837+:1]=n_loop_ahead[5];
assign loop_ahead[6]=state[838+:1];
assign next_state[838+:1]=n_loop_ahead[6];
assign loop_ahead[7]=state[839+:1];
assign next_state[839+:1]=n_loop_ahead[7];
assign loop_ahead[8]=state[840+:1];
assign next_state[840+:1]=n_loop_ahead[8];
assign loop_ahead[9]=state[841+:1];
assign next_state[841+:1]=n_loop_ahead[9];
assign loop_ahead[10]=state[842+:1];
assign next_state[842+:1]=n_loop_ahead[10];
assign loop_ahead[11]=state[843+:1];
assign next_state[843+:1]=n_loop_ahead[11];
assign loop_ahead[12]=state[844+:1];
assign next_state[844+:1]=n_loop_ahead[12];
assign loop_ahead[13]=state[845+:1];
assign next_state[845+:1]=n_loop_ahead[13];
assign loop_ahead[14]=state[846+:1];
assign next_state[846+:1]=n_loop_ahead[14];
assign loop_ahead[15]=state[847+:1];
assign next_state[847+:1]=n_loop_ahead[15];
wire loop_update_match=loop_valid[loop_update_index] && loop_tag[loop_update_index]==update_pc[ADDRESS_BITS-1:1];
integer j;always @* begin n_loop_valid=loop_valid;for(j=0;j<16;j=j+1)begin
n_loop_tag[j]=loop_tag[j];
n_loop_count[j]=loop_count[j];
n_loop_trip[j]=loop_trip[j];
n_loop_confidence[j]=loop_confidence[j];
n_loop_overflow[j]=loop_overflow[j];
n_loop_direction[j]=loop_direction[j];
n_loop_ahead[j]=loop_ahead[j];
end
        loop_count_write_data=8'd0;
        loop_trip_write_data=8'd0;
        loop_count_write_enable=1'b0;
        loop_trip_write_enable=1'b0;
        if(!loop_update_match) begin
            loop_count_write_enable=1'b1;
            loop_count_write_data=update_taken ? 8'd1 : 8'd0;
            loop_trip_write_enable=1'b1;
        end else if(update_taken) begin
            if(&loop_count[loop_update_index]) begin end
            else begin
                loop_count_write_enable=1'b1;
                loop_count_write_data=loop_count[loop_update_index]+1'b1;
            end
        end else begin
            loop_count_write_enable=1'b1;
            loop_trip_write_enable=1'b1;
            if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin end
            else loop_trip_write_data=loop_count[loop_update_index];
        end

if(clk_event || reset_fall)begin
        if(!rst_n) n_loop_valid=0;
        else if(invalidate) n_loop_valid=0;
        else if(train_update && loop_backward) n_loop_valid[loop_update_index]=1;

end
if(clk_event)begin
        if(!rst_n) begin end
        else if(invalidate) begin end
        else if(train_update && loop_backward) begin
            n_loop_tag[loop_update_index]=update_pc[ADDRESS_BITS-1:1];
            if(!loop_update_match) begin
                n_loop_confidence[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                n_loop_direction[loop_update_index]=1;
                n_loop_ahead[loop_update_index]=1;
            end else if(update_taken) begin
                if(&loop_count[loop_update_index]) begin
                    n_loop_overflow[loop_update_index]=1;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_direction[loop_update_index]=(loop_count[loop_update_index]+1'b1)<loop_trip[loop_update_index];
                    n_loop_ahead[loop_update_index]=({1'b0,loop_count[loop_update_index]}+2)<{1'b0,loop_trip[loop_update_index]};
                end
            end else begin
                n_loop_overflow[loop_update_index]=0;
                if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_direction[loop_update_index]=1;
                    n_loop_ahead[loop_update_index]=loop_count[loop_update_index]>1;
                    if(loop_trip[loop_update_index]==loop_count[loop_update_index]) begin
                        if(loop_confidence[loop_update_index]!=3)
                            n_loop_confidence[loop_update_index]=loop_confidence[loop_update_index]+1'b1;
                    end else n_loop_confidence[loop_update_index]=0;
                end
            end
        end

end
if(clk_event)begin
        if(!rst_n) begin end
        else if(invalidate) begin end
        else if(train_update && loop_backward) begin
            if(loop_count_write_enable) n_loop_count[loop_update_index]=loop_count_write_data;
            if(loop_trip_write_enable) n_loop_trip[loop_update_index]=loop_trip_write_data;
        end

end
end endmodule
module loop_transition_miter(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[847:0]state,output same);wire[847:0]a,b;baseline_loop aa(.clk_event(clk_event),.reset_fall(reset_fall),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(state),.next_state(a));modified_loop bb(.clk_event(clk_event),.reset_fall(reset_fall),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(state),.next_state(b));assign same=(reset_fall && rst_n) || a==b;endmodule
module loop_sequence_miter(input clk,input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,output same);reg[847:0]qa,qb;wire[847:0]a,b;baseline_loop aa(.clk_event(clk_event),.reset_fall(reset_fall && !rst_n),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(qa),.next_state(a));modified_loop bb(.clk_event(clk_event),.reset_fall(reset_fall && !rst_n),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(qb),.next_state(b));always @(posedge clk)begin qa<=a;qb<=b;end assign same=qa==qb;endmodule

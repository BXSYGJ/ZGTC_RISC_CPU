module baseline_loop(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[591:0]state,output[591:0]next_state);
localparam ADDRESS_BITS=16; localparam LOOP_COUNT_BITS=8;
wire[15:0]loop_valid=state[15:0]; reg[15:0]n_loop_valid;
assign next_state[15:0]=n_loop_valid;
wire[14:0]loop_tag[0:15];reg[14:0]n_loop_tag[0:15];
assign loop_tag[0]=state[16+:15];
assign next_state[16+:15]=n_loop_tag[0];
assign loop_tag[1]=state[31+:15];
assign next_state[31+:15]=n_loop_tag[1];
assign loop_tag[2]=state[46+:15];
assign next_state[46+:15]=n_loop_tag[2];
assign loop_tag[3]=state[61+:15];
assign next_state[61+:15]=n_loop_tag[3];
assign loop_tag[4]=state[76+:15];
assign next_state[76+:15]=n_loop_tag[4];
assign loop_tag[5]=state[91+:15];
assign next_state[91+:15]=n_loop_tag[5];
assign loop_tag[6]=state[106+:15];
assign next_state[106+:15]=n_loop_tag[6];
assign loop_tag[7]=state[121+:15];
assign next_state[121+:15]=n_loop_tag[7];
assign loop_tag[8]=state[136+:15];
assign next_state[136+:15]=n_loop_tag[8];
assign loop_tag[9]=state[151+:15];
assign next_state[151+:15]=n_loop_tag[9];
assign loop_tag[10]=state[166+:15];
assign next_state[166+:15]=n_loop_tag[10];
assign loop_tag[11]=state[181+:15];
assign next_state[181+:15]=n_loop_tag[11];
assign loop_tag[12]=state[196+:15];
assign next_state[196+:15]=n_loop_tag[12];
assign loop_tag[13]=state[211+:15];
assign next_state[211+:15]=n_loop_tag[13];
assign loop_tag[14]=state[226+:15];
assign next_state[226+:15]=n_loop_tag[14];
assign loop_tag[15]=state[241+:15];
assign next_state[241+:15]=n_loop_tag[15];
wire[7:0]loop_count[0:15];reg[7:0]n_loop_count[0:15];
assign loop_count[0]=state[256+:8];
assign next_state[256+:8]=n_loop_count[0];
assign loop_count[1]=state[264+:8];
assign next_state[264+:8]=n_loop_count[1];
assign loop_count[2]=state[272+:8];
assign next_state[272+:8]=n_loop_count[2];
assign loop_count[3]=state[280+:8];
assign next_state[280+:8]=n_loop_count[3];
assign loop_count[4]=state[288+:8];
assign next_state[288+:8]=n_loop_count[4];
assign loop_count[5]=state[296+:8];
assign next_state[296+:8]=n_loop_count[5];
assign loop_count[6]=state[304+:8];
assign next_state[304+:8]=n_loop_count[6];
assign loop_count[7]=state[312+:8];
assign next_state[312+:8]=n_loop_count[7];
assign loop_count[8]=state[320+:8];
assign next_state[320+:8]=n_loop_count[8];
assign loop_count[9]=state[328+:8];
assign next_state[328+:8]=n_loop_count[9];
assign loop_count[10]=state[336+:8];
assign next_state[336+:8]=n_loop_count[10];
assign loop_count[11]=state[344+:8];
assign next_state[344+:8]=n_loop_count[11];
assign loop_count[12]=state[352+:8];
assign next_state[352+:8]=n_loop_count[12];
assign loop_count[13]=state[360+:8];
assign next_state[360+:8]=n_loop_count[13];
assign loop_count[14]=state[368+:8];
assign next_state[368+:8]=n_loop_count[14];
assign loop_count[15]=state[376+:8];
assign next_state[376+:8]=n_loop_count[15];
wire[7:0]loop_trip[0:15];reg[7:0]n_loop_trip[0:15];
assign loop_trip[0]=state[384+:8];
assign next_state[384+:8]=n_loop_trip[0];
assign loop_trip[1]=state[392+:8];
assign next_state[392+:8]=n_loop_trip[1];
assign loop_trip[2]=state[400+:8];
assign next_state[400+:8]=n_loop_trip[2];
assign loop_trip[3]=state[408+:8];
assign next_state[408+:8]=n_loop_trip[3];
assign loop_trip[4]=state[416+:8];
assign next_state[416+:8]=n_loop_trip[4];
assign loop_trip[5]=state[424+:8];
assign next_state[424+:8]=n_loop_trip[5];
assign loop_trip[6]=state[432+:8];
assign next_state[432+:8]=n_loop_trip[6];
assign loop_trip[7]=state[440+:8];
assign next_state[440+:8]=n_loop_trip[7];
assign loop_trip[8]=state[448+:8];
assign next_state[448+:8]=n_loop_trip[8];
assign loop_trip[9]=state[456+:8];
assign next_state[456+:8]=n_loop_trip[9];
assign loop_trip[10]=state[464+:8];
assign next_state[464+:8]=n_loop_trip[10];
assign loop_trip[11]=state[472+:8];
assign next_state[472+:8]=n_loop_trip[11];
assign loop_trip[12]=state[480+:8];
assign next_state[480+:8]=n_loop_trip[12];
assign loop_trip[13]=state[488+:8];
assign next_state[488+:8]=n_loop_trip[13];
assign loop_trip[14]=state[496+:8];
assign next_state[496+:8]=n_loop_trip[14];
assign loop_trip[15]=state[504+:8];
assign next_state[504+:8]=n_loop_trip[15];
wire[1:0]loop_confidence[0:15];reg[1:0]n_loop_confidence[0:15];
assign loop_confidence[0]=state[512+:2];
assign next_state[512+:2]=n_loop_confidence[0];
assign loop_confidence[1]=state[514+:2];
assign next_state[514+:2]=n_loop_confidence[1];
assign loop_confidence[2]=state[516+:2];
assign next_state[516+:2]=n_loop_confidence[2];
assign loop_confidence[3]=state[518+:2];
assign next_state[518+:2]=n_loop_confidence[3];
assign loop_confidence[4]=state[520+:2];
assign next_state[520+:2]=n_loop_confidence[4];
assign loop_confidence[5]=state[522+:2];
assign next_state[522+:2]=n_loop_confidence[5];
assign loop_confidence[6]=state[524+:2];
assign next_state[524+:2]=n_loop_confidence[6];
assign loop_confidence[7]=state[526+:2];
assign next_state[526+:2]=n_loop_confidence[7];
assign loop_confidence[8]=state[528+:2];
assign next_state[528+:2]=n_loop_confidence[8];
assign loop_confidence[9]=state[530+:2];
assign next_state[530+:2]=n_loop_confidence[9];
assign loop_confidence[10]=state[532+:2];
assign next_state[532+:2]=n_loop_confidence[10];
assign loop_confidence[11]=state[534+:2];
assign next_state[534+:2]=n_loop_confidence[11];
assign loop_confidence[12]=state[536+:2];
assign next_state[536+:2]=n_loop_confidence[12];
assign loop_confidence[13]=state[538+:2];
assign next_state[538+:2]=n_loop_confidence[13];
assign loop_confidence[14]=state[540+:2];
assign next_state[540+:2]=n_loop_confidence[14];
assign loop_confidence[15]=state[542+:2];
assign next_state[542+:2]=n_loop_confidence[15];
wire[0:0]loop_overflow[0:15];reg[0:0]n_loop_overflow[0:15];
assign loop_overflow[0]=state[544+:1];
assign next_state[544+:1]=n_loop_overflow[0];
assign loop_overflow[1]=state[545+:1];
assign next_state[545+:1]=n_loop_overflow[1];
assign loop_overflow[2]=state[546+:1];
assign next_state[546+:1]=n_loop_overflow[2];
assign loop_overflow[3]=state[547+:1];
assign next_state[547+:1]=n_loop_overflow[3];
assign loop_overflow[4]=state[548+:1];
assign next_state[548+:1]=n_loop_overflow[4];
assign loop_overflow[5]=state[549+:1];
assign next_state[549+:1]=n_loop_overflow[5];
assign loop_overflow[6]=state[550+:1];
assign next_state[550+:1]=n_loop_overflow[6];
assign loop_overflow[7]=state[551+:1];
assign next_state[551+:1]=n_loop_overflow[7];
assign loop_overflow[8]=state[552+:1];
assign next_state[552+:1]=n_loop_overflow[8];
assign loop_overflow[9]=state[553+:1];
assign next_state[553+:1]=n_loop_overflow[9];
assign loop_overflow[10]=state[554+:1];
assign next_state[554+:1]=n_loop_overflow[10];
assign loop_overflow[11]=state[555+:1];
assign next_state[555+:1]=n_loop_overflow[11];
assign loop_overflow[12]=state[556+:1];
assign next_state[556+:1]=n_loop_overflow[12];
assign loop_overflow[13]=state[557+:1];
assign next_state[557+:1]=n_loop_overflow[13];
assign loop_overflow[14]=state[558+:1];
assign next_state[558+:1]=n_loop_overflow[14];
assign loop_overflow[15]=state[559+:1];
assign next_state[559+:1]=n_loop_overflow[15];
wire[0:0]loop_direction[0:15];reg[0:0]n_loop_direction[0:15];
assign loop_direction[0]=state[560+:1];
assign next_state[560+:1]=n_loop_direction[0];
assign loop_direction[1]=state[561+:1];
assign next_state[561+:1]=n_loop_direction[1];
assign loop_direction[2]=state[562+:1];
assign next_state[562+:1]=n_loop_direction[2];
assign loop_direction[3]=state[563+:1];
assign next_state[563+:1]=n_loop_direction[3];
assign loop_direction[4]=state[564+:1];
assign next_state[564+:1]=n_loop_direction[4];
assign loop_direction[5]=state[565+:1];
assign next_state[565+:1]=n_loop_direction[5];
assign loop_direction[6]=state[566+:1];
assign next_state[566+:1]=n_loop_direction[6];
assign loop_direction[7]=state[567+:1];
assign next_state[567+:1]=n_loop_direction[7];
assign loop_direction[8]=state[568+:1];
assign next_state[568+:1]=n_loop_direction[8];
assign loop_direction[9]=state[569+:1];
assign next_state[569+:1]=n_loop_direction[9];
assign loop_direction[10]=state[570+:1];
assign next_state[570+:1]=n_loop_direction[10];
assign loop_direction[11]=state[571+:1];
assign next_state[571+:1]=n_loop_direction[11];
assign loop_direction[12]=state[572+:1];
assign next_state[572+:1]=n_loop_direction[12];
assign loop_direction[13]=state[573+:1];
assign next_state[573+:1]=n_loop_direction[13];
assign loop_direction[14]=state[574+:1];
assign next_state[574+:1]=n_loop_direction[14];
assign loop_direction[15]=state[575+:1];
assign next_state[575+:1]=n_loop_direction[15];
wire[0:0]loop_ahead[0:15];reg[0:0]n_loop_ahead[0:15];
assign loop_ahead[0]=state[576+:1];
assign next_state[576+:1]=n_loop_ahead[0];
assign loop_ahead[1]=state[577+:1];
assign next_state[577+:1]=n_loop_ahead[1];
assign loop_ahead[2]=state[578+:1];
assign next_state[578+:1]=n_loop_ahead[2];
assign loop_ahead[3]=state[579+:1];
assign next_state[579+:1]=n_loop_ahead[3];
assign loop_ahead[4]=state[580+:1];
assign next_state[580+:1]=n_loop_ahead[4];
assign loop_ahead[5]=state[581+:1];
assign next_state[581+:1]=n_loop_ahead[5];
assign loop_ahead[6]=state[582+:1];
assign next_state[582+:1]=n_loop_ahead[6];
assign loop_ahead[7]=state[583+:1];
assign next_state[583+:1]=n_loop_ahead[7];
assign loop_ahead[8]=state[584+:1];
assign next_state[584+:1]=n_loop_ahead[8];
assign loop_ahead[9]=state[585+:1];
assign next_state[585+:1]=n_loop_ahead[9];
assign loop_ahead[10]=state[586+:1];
assign next_state[586+:1]=n_loop_ahead[10];
assign loop_ahead[11]=state[587+:1];
assign next_state[587+:1]=n_loop_ahead[11];
assign loop_ahead[12]=state[588+:1];
assign next_state[588+:1]=n_loop_ahead[12];
assign loop_ahead[13]=state[589+:1];
assign next_state[589+:1]=n_loop_ahead[13];
assign loop_ahead[14]=state[590+:1];
assign next_state[590+:1]=n_loop_ahead[14];
assign loop_ahead[15]=state[591+:1];
assign next_state[591+:1]=n_loop_ahead[15];
wire loop_update_match=loop_valid[loop_update_index] && loop_tag[loop_update_index]==update_pc[ADDRESS_BITS-1:1];
integer j;always @* begin n_loop_valid=loop_valid;for(j=0;j<16;j=j+1)begin
n_loop_tag[j]=loop_tag[j];
n_loop_count[j]=loop_count[j];
n_loop_trip[j]=loop_trip[j];
n_loop_confidence[j]=loop_confidence[j];
n_loop_overflow[j]=loop_overflow[j];
n_loop_direction[j]=loop_direction[j];
n_loop_ahead[j]=loop_ahead[j];
end
if(clk_event || reset_fall)begin
        if(!rst_n) n_loop_valid=0;
        else if(invalidate) n_loop_valid=0;
        else if(train_update && loop_backward) begin
            n_loop_valid[loop_update_index]=1;
            n_loop_tag[loop_update_index]=update_pc[ADDRESS_BITS-1:1];
            if(!loop_update_match) begin
                n_loop_count[loop_update_index]=update_taken ? 1 : 0;
                n_loop_trip[loop_update_index]=0;
                n_loop_confidence[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                n_loop_direction[loop_update_index]=1;
                n_loop_ahead[loop_update_index]=1;
            end else if(update_taken) begin
                if(&loop_count[loop_update_index]) begin
                    n_loop_overflow[loop_update_index]=1;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_count[loop_update_index]=loop_count[loop_update_index]+1'b1;
                    n_loop_direction[loop_update_index]=(loop_count[loop_update_index]+1'b1)<loop_trip[loop_update_index];
                    n_loop_ahead[loop_update_index]=({1'b0,loop_count[loop_update_index]}+2)<{1'b0,loop_trip[loop_update_index]};
                end
            end else begin
                n_loop_count[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin
                    n_loop_trip[loop_update_index]=0;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_trip[loop_update_index]=loop_count[loop_update_index];
                    n_loop_direction[loop_update_index]=1;
                    n_loop_ahead[loop_update_index]=loop_count[loop_update_index]>1;
                    if(loop_trip[loop_update_index]==loop_count[loop_update_index]) begin
                        if(loop_confidence[loop_update_index]!=3)
                            n_loop_confidence[loop_update_index]=loop_confidence[loop_update_index]+1'b1;
                    end else n_loop_confidence[loop_update_index]=0;
                end
            end
        end

end
end endmodule
module modified_loop(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[591:0]state,output[591:0]next_state);
localparam ADDRESS_BITS=16; localparam LOOP_COUNT_BITS=8;
wire[15:0]loop_valid=state[15:0]; reg[15:0]n_loop_valid;
assign next_state[15:0]=n_loop_valid;
reg [7:0]loop_count_write_data,loop_trip_write_data;reg loop_count_write_enable,loop_trip_write_enable;
wire[14:0]loop_tag[0:15];reg[14:0]n_loop_tag[0:15];
assign loop_tag[0]=state[16+:15];
assign next_state[16+:15]=n_loop_tag[0];
assign loop_tag[1]=state[31+:15];
assign next_state[31+:15]=n_loop_tag[1];
assign loop_tag[2]=state[46+:15];
assign next_state[46+:15]=n_loop_tag[2];
assign loop_tag[3]=state[61+:15];
assign next_state[61+:15]=n_loop_tag[3];
assign loop_tag[4]=state[76+:15];
assign next_state[76+:15]=n_loop_tag[4];
assign loop_tag[5]=state[91+:15];
assign next_state[91+:15]=n_loop_tag[5];
assign loop_tag[6]=state[106+:15];
assign next_state[106+:15]=n_loop_tag[6];
assign loop_tag[7]=state[121+:15];
assign next_state[121+:15]=n_loop_tag[7];
assign loop_tag[8]=state[136+:15];
assign next_state[136+:15]=n_loop_tag[8];
assign loop_tag[9]=state[151+:15];
assign next_state[151+:15]=n_loop_tag[9];
assign loop_tag[10]=state[166+:15];
assign next_state[166+:15]=n_loop_tag[10];
assign loop_tag[11]=state[181+:15];
assign next_state[181+:15]=n_loop_tag[11];
assign loop_tag[12]=state[196+:15];
assign next_state[196+:15]=n_loop_tag[12];
assign loop_tag[13]=state[211+:15];
assign next_state[211+:15]=n_loop_tag[13];
assign loop_tag[14]=state[226+:15];
assign next_state[226+:15]=n_loop_tag[14];
assign loop_tag[15]=state[241+:15];
assign next_state[241+:15]=n_loop_tag[15];
wire[7:0]loop_count[0:15];reg[7:0]n_loop_count[0:15];
assign loop_count[0]=state[256+:8];
assign next_state[256+:8]=n_loop_count[0];
assign loop_count[1]=state[264+:8];
assign next_state[264+:8]=n_loop_count[1];
assign loop_count[2]=state[272+:8];
assign next_state[272+:8]=n_loop_count[2];
assign loop_count[3]=state[280+:8];
assign next_state[280+:8]=n_loop_count[3];
assign loop_count[4]=state[288+:8];
assign next_state[288+:8]=n_loop_count[4];
assign loop_count[5]=state[296+:8];
assign next_state[296+:8]=n_loop_count[5];
assign loop_count[6]=state[304+:8];
assign next_state[304+:8]=n_loop_count[6];
assign loop_count[7]=state[312+:8];
assign next_state[312+:8]=n_loop_count[7];
assign loop_count[8]=state[320+:8];
assign next_state[320+:8]=n_loop_count[8];
assign loop_count[9]=state[328+:8];
assign next_state[328+:8]=n_loop_count[9];
assign loop_count[10]=state[336+:8];
assign next_state[336+:8]=n_loop_count[10];
assign loop_count[11]=state[344+:8];
assign next_state[344+:8]=n_loop_count[11];
assign loop_count[12]=state[352+:8];
assign next_state[352+:8]=n_loop_count[12];
assign loop_count[13]=state[360+:8];
assign next_state[360+:8]=n_loop_count[13];
assign loop_count[14]=state[368+:8];
assign next_state[368+:8]=n_loop_count[14];
assign loop_count[15]=state[376+:8];
assign next_state[376+:8]=n_loop_count[15];
wire[7:0]loop_trip[0:15];reg[7:0]n_loop_trip[0:15];
assign loop_trip[0]=state[384+:8];
assign next_state[384+:8]=n_loop_trip[0];
assign loop_trip[1]=state[392+:8];
assign next_state[392+:8]=n_loop_trip[1];
assign loop_trip[2]=state[400+:8];
assign next_state[400+:8]=n_loop_trip[2];
assign loop_trip[3]=state[408+:8];
assign next_state[408+:8]=n_loop_trip[3];
assign loop_trip[4]=state[416+:8];
assign next_state[416+:8]=n_loop_trip[4];
assign loop_trip[5]=state[424+:8];
assign next_state[424+:8]=n_loop_trip[5];
assign loop_trip[6]=state[432+:8];
assign next_state[432+:8]=n_loop_trip[6];
assign loop_trip[7]=state[440+:8];
assign next_state[440+:8]=n_loop_trip[7];
assign loop_trip[8]=state[448+:8];
assign next_state[448+:8]=n_loop_trip[8];
assign loop_trip[9]=state[456+:8];
assign next_state[456+:8]=n_loop_trip[9];
assign loop_trip[10]=state[464+:8];
assign next_state[464+:8]=n_loop_trip[10];
assign loop_trip[11]=state[472+:8];
assign next_state[472+:8]=n_loop_trip[11];
assign loop_trip[12]=state[480+:8];
assign next_state[480+:8]=n_loop_trip[12];
assign loop_trip[13]=state[488+:8];
assign next_state[488+:8]=n_loop_trip[13];
assign loop_trip[14]=state[496+:8];
assign next_state[496+:8]=n_loop_trip[14];
assign loop_trip[15]=state[504+:8];
assign next_state[504+:8]=n_loop_trip[15];
wire[1:0]loop_confidence[0:15];reg[1:0]n_loop_confidence[0:15];
assign loop_confidence[0]=state[512+:2];
assign next_state[512+:2]=n_loop_confidence[0];
assign loop_confidence[1]=state[514+:2];
assign next_state[514+:2]=n_loop_confidence[1];
assign loop_confidence[2]=state[516+:2];
assign next_state[516+:2]=n_loop_confidence[2];
assign loop_confidence[3]=state[518+:2];
assign next_state[518+:2]=n_loop_confidence[3];
assign loop_confidence[4]=state[520+:2];
assign next_state[520+:2]=n_loop_confidence[4];
assign loop_confidence[5]=state[522+:2];
assign next_state[522+:2]=n_loop_confidence[5];
assign loop_confidence[6]=state[524+:2];
assign next_state[524+:2]=n_loop_confidence[6];
assign loop_confidence[7]=state[526+:2];
assign next_state[526+:2]=n_loop_confidence[7];
assign loop_confidence[8]=state[528+:2];
assign next_state[528+:2]=n_loop_confidence[8];
assign loop_confidence[9]=state[530+:2];
assign next_state[530+:2]=n_loop_confidence[9];
assign loop_confidence[10]=state[532+:2];
assign next_state[532+:2]=n_loop_confidence[10];
assign loop_confidence[11]=state[534+:2];
assign next_state[534+:2]=n_loop_confidence[11];
assign loop_confidence[12]=state[536+:2];
assign next_state[536+:2]=n_loop_confidence[12];
assign loop_confidence[13]=state[538+:2];
assign next_state[538+:2]=n_loop_confidence[13];
assign loop_confidence[14]=state[540+:2];
assign next_state[540+:2]=n_loop_confidence[14];
assign loop_confidence[15]=state[542+:2];
assign next_state[542+:2]=n_loop_confidence[15];
wire[0:0]loop_overflow[0:15];reg[0:0]n_loop_overflow[0:15];
assign loop_overflow[0]=state[544+:1];
assign next_state[544+:1]=n_loop_overflow[0];
assign loop_overflow[1]=state[545+:1];
assign next_state[545+:1]=n_loop_overflow[1];
assign loop_overflow[2]=state[546+:1];
assign next_state[546+:1]=n_loop_overflow[2];
assign loop_overflow[3]=state[547+:1];
assign next_state[547+:1]=n_loop_overflow[3];
assign loop_overflow[4]=state[548+:1];
assign next_state[548+:1]=n_loop_overflow[4];
assign loop_overflow[5]=state[549+:1];
assign next_state[549+:1]=n_loop_overflow[5];
assign loop_overflow[6]=state[550+:1];
assign next_state[550+:1]=n_loop_overflow[6];
assign loop_overflow[7]=state[551+:1];
assign next_state[551+:1]=n_loop_overflow[7];
assign loop_overflow[8]=state[552+:1];
assign next_state[552+:1]=n_loop_overflow[8];
assign loop_overflow[9]=state[553+:1];
assign next_state[553+:1]=n_loop_overflow[9];
assign loop_overflow[10]=state[554+:1];
assign next_state[554+:1]=n_loop_overflow[10];
assign loop_overflow[11]=state[555+:1];
assign next_state[555+:1]=n_loop_overflow[11];
assign loop_overflow[12]=state[556+:1];
assign next_state[556+:1]=n_loop_overflow[12];
assign loop_overflow[13]=state[557+:1];
assign next_state[557+:1]=n_loop_overflow[13];
assign loop_overflow[14]=state[558+:1];
assign next_state[558+:1]=n_loop_overflow[14];
assign loop_overflow[15]=state[559+:1];
assign next_state[559+:1]=n_loop_overflow[15];
wire[0:0]loop_direction[0:15];reg[0:0]n_loop_direction[0:15];
assign loop_direction[0]=state[560+:1];
assign next_state[560+:1]=n_loop_direction[0];
assign loop_direction[1]=state[561+:1];
assign next_state[561+:1]=n_loop_direction[1];
assign loop_direction[2]=state[562+:1];
assign next_state[562+:1]=n_loop_direction[2];
assign loop_direction[3]=state[563+:1];
assign next_state[563+:1]=n_loop_direction[3];
assign loop_direction[4]=state[564+:1];
assign next_state[564+:1]=n_loop_direction[4];
assign loop_direction[5]=state[565+:1];
assign next_state[565+:1]=n_loop_direction[5];
assign loop_direction[6]=state[566+:1];
assign next_state[566+:1]=n_loop_direction[6];
assign loop_direction[7]=state[567+:1];
assign next_state[567+:1]=n_loop_direction[7];
assign loop_direction[8]=state[568+:1];
assign next_state[568+:1]=n_loop_direction[8];
assign loop_direction[9]=state[569+:1];
assign next_state[569+:1]=n_loop_direction[9];
assign loop_direction[10]=state[570+:1];
assign next_state[570+:1]=n_loop_direction[10];
assign loop_direction[11]=state[571+:1];
assign next_state[571+:1]=n_loop_direction[11];
assign loop_direction[12]=state[572+:1];
assign next_state[572+:1]=n_loop_direction[12];
assign loop_direction[13]=state[573+:1];
assign next_state[573+:1]=n_loop_direction[13];
assign loop_direction[14]=state[574+:1];
assign next_state[574+:1]=n_loop_direction[14];
assign loop_direction[15]=state[575+:1];
assign next_state[575+:1]=n_loop_direction[15];
wire[0:0]loop_ahead[0:15];reg[0:0]n_loop_ahead[0:15];
assign loop_ahead[0]=state[576+:1];
assign next_state[576+:1]=n_loop_ahead[0];
assign loop_ahead[1]=state[577+:1];
assign next_state[577+:1]=n_loop_ahead[1];
assign loop_ahead[2]=state[578+:1];
assign next_state[578+:1]=n_loop_ahead[2];
assign loop_ahead[3]=state[579+:1];
assign next_state[579+:1]=n_loop_ahead[3];
assign loop_ahead[4]=state[580+:1];
assign next_state[580+:1]=n_loop_ahead[4];
assign loop_ahead[5]=state[581+:1];
assign next_state[581+:1]=n_loop_ahead[5];
assign loop_ahead[6]=state[582+:1];
assign next_state[582+:1]=n_loop_ahead[6];
assign loop_ahead[7]=state[583+:1];
assign next_state[583+:1]=n_loop_ahead[7];
assign loop_ahead[8]=state[584+:1];
assign next_state[584+:1]=n_loop_ahead[8];
assign loop_ahead[9]=state[585+:1];
assign next_state[585+:1]=n_loop_ahead[9];
assign loop_ahead[10]=state[586+:1];
assign next_state[586+:1]=n_loop_ahead[10];
assign loop_ahead[11]=state[587+:1];
assign next_state[587+:1]=n_loop_ahead[11];
assign loop_ahead[12]=state[588+:1];
assign next_state[588+:1]=n_loop_ahead[12];
assign loop_ahead[13]=state[589+:1];
assign next_state[589+:1]=n_loop_ahead[13];
assign loop_ahead[14]=state[590+:1];
assign next_state[590+:1]=n_loop_ahead[14];
assign loop_ahead[15]=state[591+:1];
assign next_state[591+:1]=n_loop_ahead[15];
wire loop_update_match=loop_valid[loop_update_index] && loop_tag[loop_update_index]==update_pc[ADDRESS_BITS-1:1];
integer j;always @* begin n_loop_valid=loop_valid;for(j=0;j<16;j=j+1)begin
n_loop_tag[j]=loop_tag[j];
n_loop_count[j]=loop_count[j];
n_loop_trip[j]=loop_trip[j];
n_loop_confidence[j]=loop_confidence[j];
n_loop_overflow[j]=loop_overflow[j];
n_loop_direction[j]=loop_direction[j];
n_loop_ahead[j]=loop_ahead[j];
end
        loop_count_write_data=8'd0;
        loop_trip_write_data=8'd0;
        loop_count_write_enable=1'b0;
        loop_trip_write_enable=1'b0;
        if(!loop_update_match) begin
            loop_count_write_enable=1'b1;
            loop_count_write_data=update_taken ? 8'd1 : 8'd0;
            loop_trip_write_enable=1'b1;
        end else if(update_taken) begin
            if(&loop_count[loop_update_index]) begin end
            else begin
                loop_count_write_enable=1'b1;
                loop_count_write_data=loop_count[loop_update_index]+1'b1;
            end
        end else begin
            loop_count_write_enable=1'b1;
            loop_trip_write_enable=1'b1;
            if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin end
            else loop_trip_write_data=loop_count[loop_update_index];
        end

if(clk_event || reset_fall)begin
        if(!rst_n) n_loop_valid=0;
        else if(invalidate) n_loop_valid=0;
        else if(train_update && loop_backward) n_loop_valid[loop_update_index]=1;

end
if(clk_event)begin
        if(!rst_n) begin end
        else if(invalidate) begin end
        else if(train_update && loop_backward) begin
            n_loop_tag[loop_update_index]=update_pc[ADDRESS_BITS-1:1];
            if(!loop_update_match) begin
                n_loop_confidence[loop_update_index]=0;
                n_loop_overflow[loop_update_index]=0;
                n_loop_direction[loop_update_index]=1;
                n_loop_ahead[loop_update_index]=1;
            end else if(update_taken) begin
                if(&loop_count[loop_update_index]) begin
                    n_loop_overflow[loop_update_index]=1;
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_direction[loop_update_index]=(loop_count[loop_update_index]+1'b1)<loop_trip[loop_update_index];
                    n_loop_ahead[loop_update_index]=({1'b0,loop_count[loop_update_index]}+2)<{1'b0,loop_trip[loop_update_index]};
                end
            end else begin
                n_loop_overflow[loop_update_index]=0;
                if(loop_overflow[loop_update_index] || loop_count[loop_update_index]==0) begin
                    n_loop_confidence[loop_update_index]=0;
                    n_loop_direction[loop_update_index]=0;
                    n_loop_ahead[loop_update_index]=0;
                end else begin
                    n_loop_direction[loop_update_index]=1;
                    n_loop_ahead[loop_update_index]=loop_count[loop_update_index]>1;
                    if(loop_trip[loop_update_index]==loop_count[loop_update_index]) begin
                        if(loop_confidence[loop_update_index]!=3)
                            n_loop_confidence[loop_update_index]=loop_confidence[loop_update_index]+1'b1;
                    end else n_loop_confidence[loop_update_index]=0;
                end
            end
        end

end
if(clk_event)begin
        if(!rst_n) begin end
        else if(invalidate) begin end
        else if(train_update && loop_backward) begin
            if(loop_count_write_enable) n_loop_count[loop_update_index]=loop_count_write_data;
            if(loop_trip_write_enable) n_loop_trip[loop_update_index]=loop_trip_write_data;
        end

end
end endmodule
module loop_transition_miter(input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,input[591:0]state,output same);wire[591:0]a,b;baseline_loop aa(.clk_event(clk_event),.reset_fall(reset_fall),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(state),.next_state(a));modified_loop bb(.clk_event(clk_event),.reset_fall(reset_fall),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(state),.next_state(b));assign same=(reset_fall && rst_n) || a==b;endmodule
module loop_sequence_miter(input clk,input clk_event,reset_fall,rst_n,invalidate,train_update,loop_backward,update_taken,input[3:0]loop_update_index,input[31:0]update_pc,output same);reg[591:0]qa,qb;wire[591:0]a,b;baseline_loop aa(.clk_event(clk_event),.reset_fall(reset_fall && !rst_n),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(qa),.next_state(a));modified_loop bb(.clk_event(clk_event),.reset_fall(reset_fall && !rst_n),.rst_n(rst_n),.invalidate(invalidate),.train_update(train_update),.loop_backward(loop_backward),.update_taken(update_taken),.loop_update_index(loop_update_index),.update_pc(update_pc),.state(qb),.next_state(b));always @(posedge clk)begin qa<=a;qb<=b;end assign same=qa==qb;endmodule

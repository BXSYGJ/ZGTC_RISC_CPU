"""Run exact original 100-iteration images; hash every trace byte through FIFOs."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import threading
import time

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[1]
SOURCE = ROOT / 'candidates/loop16_h4_single_write/rtl'
PRISTINE = ROOT / 'candidates/load_simple_loop16_h4/rtl'
BASELINE = Path('/tmp/pacerv_timing_frontend_range_interface_equivalence/BASELINE')
WORK = Path('/tmp/pacerv_loop16_h4_single_write_full100')
CHANGE = json.loads((AREA / 'CHANGE.json').read_text(encoding='utf-8-sig'))
CORE_SHA = '5e81f9c56246e502b43c6a48c14342dbb16ac437788ac01d00a482d9a06ca84b'
CACHE_SHA = 'c9d73d59e80a70399df214dfbbe3316083e6df0d33974e1564795a4ae875d6c1'
FIRMWARE_SHA = {'V0':'39504b698a04826e0584891b9cd321b73c1f3990fd3af6fe8de66268f8801355', 'V1':'02a9c2dd04deee83269acbc97a7556c3dd6a2bbd522feb20f4a3307d0e997f2d'}
utc = lambda: datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8-sig')


def standard_rtl_identity(source):
    recipe = json.loads((ROOT/'recipe.json').read_text(encoding='utf-8-sig'))
    argv = recipe['simulation']['argv']
    inputs = [source/Path(x).name for x in argv if '/simulation/inputs/rtl/' in x]
    inputs += [ROOT/x.split('{RELEASE}/')[1] for x in argv if '/simulation/inputs/sim/' in x]
    h = hashlib.sha256()
    for p in inputs:
        h.update(p.name.encode())
        h.update(p.read_bytes())
    h.update(b'1')
    return h.hexdigest()


def assert_sources():
    for folder, n in [('rtl',17),('physical_rtl',18)]:
        p = ROOT/'candidates/loop16_h4_single_write'/folder
        files = sorted(p.glob('*.sv'))
        assert len(files)==n
        assert {f.name:digest(f) for f in files}==CHANGE[folder]
    assert digest(SOURCE/'rv32_core.sv')==CORE_SHA
    assert digest(SOURCE/'rv32_cache.sv')==CACHE_SHA
    frozen = json.loads((ROOT/'EXPERIMENT.json').read_text(encoding='utf-8-sig'))['BaselineFiles']
    for e in frozen:
        assert digest(ROOT/e['Path'])==e['SHA256'].lower()
    return len(frozen)


def run_native(directory, executable, role, binding):
    directory.mkdir(parents=True, exist_ok=False)
    original = ROOT/'work'/('cf4-loadsimple-tune5-i100-'+role)
    expected = json.loads((ROOT/'work'/('sg-loop16-sl-h4-i100-'+role)/'RUN.json').read_text(encoding='utf-8-sig'))
    assert expected['firmware']['iterations']==100
    assert digest(original/'firmware.hex')==FIRMWARE_SHA[role]
    for name in ['firmware.hex','BUILD.json']:
        shutil.copy2(original/name, directory/('ORIGINAL_'+name if name=='BUILD.json' else name))
    assert (directory/'ORIGINAL_BUILD.json').read_bytes()==(original/'BUILD.json').read_bytes()
    streams = {}
    errors = []

    def reader(name):
        try:
            h, count = hashlib.sha256(), 0
            with (directory/name).open('rb', buffering=1024*1024) as f:
                for data in iter(lambda:f.read(1024*1024), b''):
                    h.update(data)
                    count += len(data)
            streams[name] = {'sha256':h.hexdigest(), 'bytes':count}
        except BaseException as e:
            errors.append(repr(e))

    threads=[]
    for name in ['retirement.bin','interface.bin']:
        os.mkfifo(directory/name)
        assert stat.S_ISFIFO((directory/name).stat().st_mode)
        t=threading.Thread(target=reader,args=(name,),daemon=True)
        t.start()
        threads.append(t)
    argv=[str(executable),str(directory/'uart.log'),'40000000']
    start=time.monotonic()
    with (directory/'run.log').open('w') as log:
        proc=subprocess.Popen(argv,cwd=directory,stdout=log,stderr=subprocess.STDOUT)
        process=dict(status='RUNNING',role=role,native_pid=proc.pid,command=argv,cwd=str(directory),started_utc=utc(),firmware_sha256=FIRMWARE_SHA[role],source_binding=binding)
        save(directory/'PROCESS.json',process)
        code=proc.wait(timeout=900)
    process.update(status='COMPLETED',native_exit_status=code,finished_utc=utc())
    save(directory/'PROCESS.json',process)
    assert code==0,(directory/'run.log').read_text()[-6000:]
    for t in threads:
        t.join(timeout=30)
        assert not t.is_alive(),'FIFO reader did not finish'
    assert not errors,errors
    save(directory/'RAW_STREAM_HASHES.json',streams)
    text=(directory/'run.log').read_text()
    m=re.search(r'OBSERVER cycles=(\d+) retired=(\d+) minimum_sp=(\d+)',text)
    assert m,'Missing measured observer'
    cycles,retired,sp=map(int,m.groups())
    assert cycles==expected['timed_cycles'] and retired==expected['retired']
    for name,key,record_size in [('retirement.bin','FULL_RETIREMENT_TRACE',24),('interface.bin','FULL_INTERFACE_TRACE',40)]:
        m=re.search(key+r' records=(\d+) bytes=(\d+)',text)
        assert m,'Missing stream record accounting'
        records,bytes_=map(int,m.groups())
        assert bytes_==records*record_size==streams[name]['bytes']
        streams[name]['records']=records
    crc=re.findall(r'^\[0\]crc(?:list|matrix|state|final)\s*:\s*(0x[0-9a-f]+)',text,re.M)
    assert crc==expected['crc_fields']
    duration_diagnostic='ERROR! Must execute for at least 10 secs for a valid result!'
    assert duration_diagnostic in text
    assert 'PASS RTL CoreMark smoke' in text
    unexpected_errors=[line for line in text.splitlines() if ('ERROR' in line or 'error' in line) and line!=duration_diagnostic]
    assert not unexpected_errors,unexpected_errors
    uart_sha=digest(directory/'uart.log')
    record=dict(role=role,command=argv,directory=str(directory),exit_status=code,wall_seconds=time.monotonic()-start,timed_cycles=cycles,retired=retired,minimum_sp=sp,coremark_per_mhz=100_000_000/cycles,crc_fields=crc,short_duration_diagnostic_expected=True,formal_ten_seconds=False,trace_sha256=streams['retirement.bin']['sha256'],trace_bytes=streams['retirement.bin']['bytes'],interface_sha256=streams['interface.bin']['sha256'],interface_bytes=streams['interface.bin']['bytes'],uart_sha256=uart_sha,firmware_sha256=digest(directory/'firmware.hex'),firmware_and_build_receipts_byte_identical=True,trace_storage='POSIX FIFOs, every byte consumed by incremental SHA256; no regular trace files',streams=streams,process=process,stdout=text,source_binding=binding)
    save(directory/'RUN.json',record)
    print('LOOP_SINGLE_WRITE_FULL100_NATIVE_PASS '+role+' '+directory.name+' cycles='+str(cycles)+' retired='+str(retired)+' trace_bytes='+str(record['trace_bytes'])+' interface_bytes='+str(record['interface_bytes'])+' exit=0',flush=True)
    return record



def compile_model(label,rtl):
    prior_build=json.loads((BASELINE/'BUILD.json').read_text())
    builddir=WORK/('COMPILED_'+label)
    inputs=builddir/'inputs'
    inputs.mkdir(parents=True)
    for path in (BASELINE/'inputs').iterdir():
        if path.is_file():shutil.copy2(path,inputs/path.name)
    for path in rtl.glob('*.sv'):
        shutil.copy2(path,inputs/path.name)
    input_hashes={p.name:digest(p) for p in inputs.iterdir() if p.is_file()}
    assert all(p.read_bytes()==(inputs/p.name).read_bytes() for p in rtl.glob('*.sv'))
    argv=[x.replace(str(BASELINE),str(builddir)) for x in prior_build['command']]
    argv[argv.index('-j')+1]='1'
    started=time.monotonic()
    with (builddir/'build.log').open('w') as log:
        code=subprocess.run(argv,cwd=builddir,stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
    assert code==0,(builddir/'build.log').read_text()[-6000:]
    executable=builddir/'objects/Vrv32_observed_soc'
    build=dict(command=argv,cwd=str(builddir),exit_status=code,seconds=time.monotonic()-started,input_sha256=input_hashes,executable_sha256=digest(executable),standard_simulation_rtl_identity=standard_rtl_identity(rtl))
    save(builddir/'BUILD.json',build)
    binding=dict(model_executable=str(executable),build_receipt=str(builddir/'BUILD.json'),**build)
    print('LOOP_SINGLE_WRITE_FULL100_COMPILED '+label+' RTL='+binding['standard_simulation_rtl_identity'],flush=True)
    return executable,binding

def main():
    assert not WORK.exists(),'Preserve existing evidence'
    WORK.mkdir()
    frozen=assert_sources()
    base_exe,base_binding=compile_model('BASELINE',PRISTINE)
    modified_exe,modified_binding=compile_model('MODIFIED',SOURCE)
    assert base_binding['standard_simulation_rtl_identity']=='c7ab29adf836d1f94a9b637d4e8489412774bef95f254fde386b63aa03e7f194'
    changed=[name for name in base_binding['input_sha256'] if base_binding['input_sha256'][name]!=modified_binding['input_sha256'][name]]
    assert changed==['rv32_btb.sv']
    evidence=dict(status='RUNNING_BOTH_ROLES_ACTUAL_FULL100',changed_field=CHANGE['changed_field'],only_changed_production_input='rv32_btb.sv',baseline_build=base_binding,modified_build=modified_binding,standard_simulation_rtl_identity=modified_binding['standard_simulation_rtl_identity'],records=[],pending=['V0','V1'],frozen_files=frozen)
    save(AREA/'FULL100_INTERFACE_EQUIVALENCE.json',evidence)
    keys=['trace_sha256','trace_bytes','interface_sha256','interface_bytes','uart_sha256','timed_cycles','retired']
    for role in ['V0','V1']:
        with ThreadPoolExecutor(max_workers=2) as pool:
            base_future=pool.submit(run_native,WORK/('BASELINE_'+role),base_exe,role,base_binding)
            mod_future=pool.submit(run_native,WORK/('MODIFIED_'+role),modified_exe,role,modified_binding)
            before,after=base_future.result(),mod_future.result()
        assert all(before[key]==after[key] for key in keys)
        evidence['records'].append(dict(role=role,baseline=before,modified=after,compared_fields=keys,all_equal=True))
        evidence['pending'].remove(role)
        evidence.update(updated_utc=utc(),status='PASS_BOTH_ROLES_ACTUAL_FULL100' if not evidence['pending'] else 'V0_VERIFIED_V1_PENDING')
        save(AREA/'FULL100_INTERFACE_EQUIVALENCE.json',evidence)
        print('LOOP_SINGLE_WRITE_FULL100_EQUAL '+role+' retirement=identical interface=identical uart=identical cycles='+str(after['timed_cycles']),flush=True)
    assert assert_sources()==frozen
    assert digest(base_exe)==base_binding['executable_sha256'] and digest(modified_exe)==modified_binding['executable_sha256']
    print('LOOP_SINGLE_WRITE_FULL100_FINAL_PASS roles=2 actual_retirement_interface_uart=all_identical exact_firmware=True source=17/18',flush=True)

if __name__=='__main__':
    main()

from pathlib import Path
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
change=load(HERE/'CHANGE.json')
formal=load(HERE/'FORMAL_EQUIVALENCE.json')
four=load(HERE/'FOUR_STATE_EQUIVALENCE.json')
core=load(HERE/'CORE_VERIFICATION.json')
predictor=load(HERE/'PREDICTOR_CHECKS.json')
rollback=load(HERE/'ROLLBACK_RESULT.json')
assert formal['status']==four['status']==core['status']==predictor['status']=='PASS'
assert core['architecture_lines']==591 and core['modified_full_cycle_equal']
assert formal['sequential_induction_unbounded'] and formal['negative_control']['exit_status']==1
assert rollback['RestoredSHA256'].lower()==change['baseline_sha256'] and rollback['ExitStatus']==0
assert (HERE/'BASELINE_FILE.sv').read_text()==change['before']
assert (HERE/'MODIFIED_FILE.sv').read_text()==change['after']
assert sha(HERE/'rv32_btb.sv')==sha(HERE/'MODIFIED_FILE.sv')==change['modified_sha256']
build=ROOT/'work/sg25-loop-single-write-synth'
vm=build/'synthesis/synthesize/pds_soc_top_syn.vm'
vm_text=vm.read_text()
snr=(build/'synthesis/synthesize/pds_soc_top.snr').read_text()
array_cells={name:re.findall(r'(GTP_[A-Z0-9_]+)\s*/\*\s*\\?'+name+r'[\[\._][^*]+\*/',vm_text) for name in ('loop_count','loop_trip')}
assert not any(value.startswith('GTP_DFF') for cells in array_cells.values() for value in cells)
resource_lines=re.findall(r'^(?:Total LUTs:|Total Registers:)[^\r\n]*',snr,flags=re.M)
assert any('6134' in line for line in resource_lines) and any('2561' in line for line in resource_lines)
for folder,total in (('rtl',17),('physical_rtl',18)):
    directory=ROOT/'candidates/loop16_h4_single_write'/folder
    assert {p.name:sha(p) for p in directory.glob('*.sv')}==change[folder]
    assert len(list(directory.glob('*.sv')))==total
    for name,value in change[folder].items():
        if name!='rv32_btb.sv':assert sha(ROOT/'candidates/load_simple_loop16_h4'/folder/name)==value
assert {p.name:sha(p) for p in (build/'inputs/rtl').glob('*.sv')}==change['physical_rtl']
full100=load(HERE/'FULL100_INTERFACE_EQUIVALENCE.json') if (HERE/'FULL100_INTERFACE_EQUIVALENCE.json').exists() else dict(status='PENDING',pending=['V0','V1'])
summary=dict(status='FUNCTIONAL_PROOFS_READY_FULL100_PENDING' if full100['status']!='PASS_BOTH_ROLES_ACTUAL_FULL100' else 'FUNCTIONAL_AND_FULL100_EQUIVALENCE_PASS',
             changed_field=change['changed_field'],source_chain=change,
             core_BMR=core,loop_model_and_parameter_random=predictor,production_state_transition_and_induction=formal,four_state=four,rollback=rollback,
             vendor_synthesis=dict(build=str(build),netlist_sha256=sha(vm),resource_lines=resource_lines,array_cells=array_cells,
                                   baseline_LUT=6332,baseline_FF=2817,LUT=6134,FF=2561,LUT_reduction=198,FF_reduction=256),
             full100_interface_equivalence=full100,
             same_cycle_semantics_proven=True,all_loop_capacities_unchanged=True,modified_file_left_changed=True,
             restored_behavior='Actual rollback copy restores qualified H4 BTB b362; B/M/R core23 complete stdout, loop behavioral reference and parameter random interfaces match.',
             artifacts={name:str(HERE/name) for name in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')})
(HERE/'VERIFICATION.txt').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'VERIFICATION.txt')==summary
artifacts={name:dict(path=str(HERE/name),sha256=sha(HERE/name),bytes=len((HERE/name).read_bytes())) for name in summary['artifacts']}
(HERE/'FINAL_RECHECK.json').write_text(json.dumps(dict(status='PASS',artifacts=artifacts,source_sha256=change['modified_sha256'],result=summary['status'],source_snapshot=change['physical_rtl']),indent=2)+'\n',encoding='utf-8')
assert all(sha(HERE/name)==value['sha256'] for name,value in artifacts.items())
print('LOOP_SINGLE_WRITE_READY SAT=3 unbounded_induction=3 negative=rejected four_state=42343 core_BMR23=equal arrays_RAM=True LUT_reduction=198 FF_reduction=256 artifacts=reopened full100='+full100['status'],flush=True)

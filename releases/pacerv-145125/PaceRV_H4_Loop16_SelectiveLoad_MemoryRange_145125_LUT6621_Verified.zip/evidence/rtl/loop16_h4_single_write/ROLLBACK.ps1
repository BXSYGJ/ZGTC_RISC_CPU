﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetDirectory,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselineFile)
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
$OutputEncoding=[System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference='Stop'
try {
    $target=[System.IO.Path]::GetFullPath($TargetDirectory)
    $baseline=[System.IO.Path]::GetFullPath($BaselineFile)
    $destination=[System.IO.Path]::Combine($target,'rv32_btb.sv')
    if($destination -eq $baseline){throw 'Use an independent target directory'}
    if(-not(Test-Path -LiteralPath $target -PathType Container)){throw 'Target directory missing'}
    if((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne 'B362DEA594BA68F5EBA4274EE054A5EC4D09E57B2695C695F1B2BDF849E8ECA0'){throw 'Baseline hash mismatch'}
    Copy-Item -LiteralPath $baseline -Destination $destination -Force
    if((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne 'B362DEA594BA68F5EBA4274EE054A5EC4D09E57B2695C695F1B2BDF849E8ECA0'){throw 'Restore hash mismatch'}
    Write-Output 'LOOP_SINGLE_WRITE_ROLLBACK_PASS SHA256=B362DEA594BA68F5EBA4274EE054A5EC4D09E57B2695C695F1B2BDF849E8ECA0'
} catch {Write-Error $_;exit 1}

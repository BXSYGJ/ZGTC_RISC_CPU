`timescale 1ns/1ps
module history_default_tb #(parameter INDEX_BITS=3, ADDRESS_BITS=16, RETURN_STACK_DEPTH=1, HASH_INDEX=1);
reg clk=0,rst_n=0,invalidate=0;
reg [31:0] fetch_pc=0,update_pc=0,update_target=0,stack_push_address=0;
reg update_valid=0,update_taken=0,update_conditional=0,update_return=0,stack_push=0,stack_pop=0;
wire [3:0] taken,hit,available;
wire [31:0] target[0:3],ras[0:3];
wire [31:0] paired,ras_pair,default_pair,default_ras_pair;
reference_btb #(.HISTORY_BITS(4),.INDEX_BITS(INDEX_BITS),.ADDRESS_BITS(ADDRESS_BITS),.RETURN_STACK_DEPTH(RETURN_STACK_DEPTH),.HASH_INDEX(HASH_INDEX)) ref_dut(
.clk(clk),.rst_n(rst_n),.invalidate(invalidate),.fetch_pc(fetch_pc),.predicted_taken(taken[0]),.predicted_target(target[0]),.prediction_hit(hit[0]),.return_stack_available(available[0]),.return_stack_target(ras[0]),.update_valid(update_valid),.update_pc(update_pc),.update_target(update_target),.update_taken(update_taken),.update_conditional(update_conditional),.update_return(update_return),.stack_push(stack_push),.stack_pop(stack_pop),.stack_push_address(stack_push_address));
rv32_btb #(.INDEX_BITS(INDEX_BITS),.ADDRESS_BITS(ADDRESS_BITS),.RETURN_STACK_DEPTH(RETURN_STACK_DEPTH),.HASH_INDEX(HASH_INDEX)) mod_dut(
.clk(clk),.rst_n(rst_n),.invalidate(invalidate),.fetch_pc(fetch_pc),.predicted_taken(taken[1]),.predicted_target(target[1]),.prediction_hit(hit[1]),.return_stack_available(available[1]),.return_stack_target(ras[1]),.update_valid(update_valid),.update_pc(update_pc),.update_target(update_target),.update_taken(update_taken),.update_conditional(update_conditional),.update_return(update_return),.stack_push(stack_push),.stack_pop(stack_pop),.stack_push_address(stack_push_address));
rv32_btb #(.INDEX_BITS(INDEX_BITS),.ADDRESS_BITS(ADDRESS_BITS),.RETURN_STACK_DEPTH(RETURN_STACK_DEPTH),.HASH_INDEX(HASH_INDEX)) default_dut(
.clk(clk),.rst_n(rst_n),.invalidate(invalidate),.fetch_pc(fetch_pc),.predicted_taken(taken[2]),.predicted_target(target[2]),.prediction_hit(hit[2]),.return_stack_available(available[2]),.return_stack_target(ras[2]),.update_valid(update_valid),.update_pc(update_pc),.update_target(update_target),.update_taken(update_taken),.update_conditional(update_conditional),.update_return(update_return),.stack_push(stack_push),.stack_pop(stack_pop),.stack_push_address(stack_push_address));
rollback_btb #(.HISTORY_BITS(4),.INDEX_BITS(INDEX_BITS),.ADDRESS_BITS(ADDRESS_BITS),.RETURN_STACK_DEPTH(RETURN_STACK_DEPTH),.HASH_INDEX(HASH_INDEX)) rollback_dut(
.clk(clk),.rst_n(rst_n),.invalidate(invalidate),.fetch_pc(fetch_pc),.predicted_taken(taken[3]),.predicted_target(target[3]),.prediction_hit(hit[3]),.return_stack_available(available[3]),.return_stack_target(ras[3]),.update_valid(update_valid),.update_pc(update_pc),.update_target(update_target),.update_taken(update_taken),.update_conditional(update_conditional),.update_return(update_return),.stack_push(stack_push),.stack_pop(stack_pop),.stack_push_address(stack_push_address));
integer checks=0,hits=0,ras_checks=0,invalidates=0,rejected=0,i,j,k,phase,a,b,c; integer unknown_reset_writes=0;reg[3:0]four_values=4'bZX10;
reg [31:0] expected_pair,expected_ras,prior_pc=0;
function [31:0] compact(input [31:0] value);
begin compact=(ADDRESS_BITS==32 ? value : value&(32'hffffffff>>(32-ADDRESS_BITS)))&32'hfffffffe; end
endfunction
task check;
begin
expected_pair={target[0][31:2],2'b00}+32'd4;
expected_ras={ras[0][31:2],2'b00}+32'd4;
for(j=1;j<4;j=j+1) if({taken[j],hit[j],available[j],target[j],ras[j]} !== {taken[0],hit[0],available[0],target[0],ras[0]}) $fatal(1,"BTB_BASE_OUTPUT_CHANGED variant=%0d cycle=%0d",j,checks);
if(ref_dut.loop_valid !== mod_dut.loop_valid || ref_dut.loop_valid !== rollback_dut.loop_valid) $fatal(1,"LOOP_VALID_CHANGED");
for(k=0;k<16;k=k+1)begin
 if({ref_dut.loop_tag[k],ref_dut.loop_count[k],ref_dut.loop_trip[k],ref_dut.loop_confidence[k],ref_dut.loop_overflow[k],ref_dut.loop_direction[k],ref_dut.loop_ahead[k]} !==
    {mod_dut.loop_tag[k],mod_dut.loop_count[k],mod_dut.loop_trip[k],mod_dut.loop_confidence[k],mod_dut.loop_overflow[k],mod_dut.loop_direction[k],mod_dut.loop_ahead[k]})$fatal(1,"LOOP_ALL_STATE_CHANGED entry=%0d checks=%0d",k,checks);
 if({ref_dut.loop_tag[k],ref_dut.loop_count[k],ref_dut.loop_trip[k],ref_dut.loop_confidence[k],ref_dut.loop_overflow[k],ref_dut.loop_direction[k],ref_dut.loop_ahead[k]} !==
    {rollback_dut.loop_tag[k],rollback_dut.loop_count[k],rollback_dut.loop_trip[k],rollback_dut.loop_confidence[k],rollback_dut.loop_overflow[k],rollback_dut.loop_direction[k],rollback_dut.loop_ahead[k]})$fatal(1,"LOOP_ROLLBACK_STATE_CHANGED");
end

if(hit[0]===1'b1) begin
 hits=hits+1;
end
if(available[0]===1'b1) begin
 ras_checks=ras_checks+1;
end
checks=checks+1;
end endtask
task tick;
begin #2;check;clk=1;#1;check;clk=0;#1;end endtask
task train(input [31:0] pc_value,target_value,input is_return);
begin update_valid=1;update_conditional=0;update_taken=1;update_return=is_return;update_pc=pc_value;update_target=target_value;fetch_pc=pc_value;tick;update_valid=0;tick;
if(!hit[0])$fatal(1,"Directed training failed");end endtask
initial begin
tick;tick;rst_n=1;repeat((1<<INDEX_BITS)+2)tick;
train(32'h100,ADDRESS_BITS==32 ? 32'hfffffffc : 32'h0000fffc,0);
train(32'h100,ADDRESS_BITS==32 ? 32'hfffffffe : 32'h0000fffe,0);
stack_push=1;stack_push_address=32'hffffffff;tick;stack_push=0;train(32'h200,32'h40,1);
stack_pop=1;tick;stack_pop=0;
for(i=0;i<20000;i=i+1) begin
 invalidate=(i%4093)==0;
 if(invalidate)invalidates=invalidates+1;
 update_valid=($random&3)!=0;update_conditional=$random;update_taken=$random;update_return=$random;
 update_pc=compact($random);update_target=compact($random);
 if(i%503==0)update_target=ADDRESS_BITS==32 ? 32'hfffffffe : 32'h0000fffe;
 if(i%109==0)begin update_pc=update_pc|1;rejected=rejected+1;end
 fetch_pc=(i%3==0)?update_pc:prior_pc;
 prior_pc=update_pc;
 stack_push=($random&15)==0;stack_pop=($random&7)==0;stack_push_address=$random;
 tick;
end

// A binary asynchronous reset must leave data memories untouched and clear
// validity immediately, even while a write was otherwise eligible.
update_pc=32'h400;update_target=32'h380;fetch_pc=update_pc;update_valid=1;update_conditional=1;update_taken=1;update_return=0;invalidate=0;stack_push=0;stack_pop=0;
#1;rst_n=0;#1;check;if(mod_dut.loop_valid!==0)$fatal(1,"ASYNC_LOOP_VALID_RESET_FAILED");
update_valid=0;rst_n=1;repeat((1<<INDEX_BITS)+2)tick;
// Stabilize X/Z reset before enabling writes, then exercise the original
// procedural if chain at the clock edge. This exposes the &&-gate X mismatch.
for(phase=0;phase<2;phase=phase+1)begin
 update_valid=0;rst_n=phase==0 ? 1'bx:1'bz;#1;check;
 for(a=0;a<4;a=a+1)for(b=0;b<4;b=b+1)for(c=0;c<4;c=c+1)begin
  invalidate=four_values[a];update_valid=four_values[b];update_taken=four_values[c];
  update_pc=32'h400;update_target=32'h380;fetch_pc=update_pc;tick;
  if(invalidate===0 && update_valid===1 && ref_dut.train_update===1)unknown_reset_writes=unknown_reset_writes+1;
 end
 update_valid=0;invalidate=0;rst_n=1;repeat((1<<INDEX_BITS)+2)tick;
end
if(unknown_reset_writes<8)$fatal(1,"UNKNOWN_RESET_POSEDGE_COVERAGE_MISSING %0d",unknown_reset_writes);
$display("LOOP_DATA_FOUR_STATE_PASS all_arrays=7 entries=16 unknown_reset_posedge_writes=%0d checks=%0d async_reset=covered",unknown_reset_writes,checks);
if(hits<10 || (RETURN_STACK_DEPTH>0 && ras_checks<10))$fatal(1,"Insufficient predictor coverage");
$display("BTB_HISTORY_DEFAULT_EQ_PASS index=%0d address=%0d ras=%0d hash=%0d checks=%0d hits=%0d ras_checks=%0d invalidates=%0d invalid_updates=%0d",INDEX_BITS,ADDRESS_BITS,RETURN_STACK_DEPTH,HASH_INDEX,checks,hits,ras_checks,invalidates,rejected);
$finish;end
endmodule

from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
OLD=ROOT/'rtl_proposals/loop16_h4_single_write'
source=(OLD/'finalize_longs.py').read_text()
source=source.replace("IDENTITY='3acadd2d7307bf1a9afd7fd6e893801719cfd8ffab1b3b067b3b5e1e3bae4ded'","IDENTITY='5bfd35fb3ce5591c17d5b0f5a020662b3d4a7152b83cff437c7010a5f3be1778'")
source=source.replace('candidates/loop16_h4_single_write','candidates/loop16_h4_ram_memory_range').replace('sg25-loop-single-write-i6000-','sg30-ram-memory-range-i6000-')
source=source.replace("    short=next(row['modified'] for row in load(HERE/'FULL100_INTERFACE_EQUIVALENCE.json')['records'] if row['role']==role)\n",'')
source=source.replace("                          standard_short_score=short['coremark_per_mhz'],long_minus_short_score=raw['coremark_per_mhz']-short['coremark_per_mhz'],\n",'')
source=source.replace('LOOP_SINGLE_WRITE_LONG_FINAL_AUDIT','MEMORY_RANGE_LONG_FINAL_AUDIT')
(HERE/'finalize_longs.py').write_text(source,encoding='utf-8')
helper=(OLD/'finish_existing_longs.py').read_text().replace('sg25-loop-single-write-i6000-','sg30-ram-memory-range-i6000-').replace('SG25_EXISTING_','MEMORY_RANGE_EXISTING_')
(HERE/'finish_existing_longs.py').write_text(helper,encoding='utf-8')
monitor=(OLD/'monitor_longs.py').read_text().replace("sessions={'V0':49643,'V1':80420}","sessions={'V0':11449,'V1':85133}").replace('sg25-loop-single-write-i6000-','sg30-ram-memory-range-i6000-')
(HERE/'monitor_longs.py').write_text(monitor,encoding='utf-8')
print('MEMORY_RANGE_EXISTING_PROCESS_FOLLOWUP_READY launches_native=0')

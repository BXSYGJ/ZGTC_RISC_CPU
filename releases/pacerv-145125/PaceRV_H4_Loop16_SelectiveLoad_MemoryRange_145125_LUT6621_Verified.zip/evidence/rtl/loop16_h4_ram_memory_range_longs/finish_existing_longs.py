"""Finish auditing the two already authorized native runs; never launch a run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
utc=lambda:datetime.now(timezone.utc).isoformat()
output=HERE/'BACKGROUND_FINALIZATION_PROCESS.json'
lock=HERE/'BACKGROUND_FINALIZATION.lock'
with lock.open('x',encoding='utf-8') as stream:
    stream.write(str(os.getpid())+'\n')
expected={}
for role in ('V0','V1'):
    path=ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)
    receipt=load(path/'PROCESS.json')
    expected[role]=dict(native_pid=receipt['native_pid'],worker_pid=receipt['worker_pid'],started_utc=receipt['started_utc'],command=receipt['command'],path=str(path))
record=dict(status='WAITING_FOR_EXISTING_NATIVE_PROCESSES',pid=os.getpid(),started_utc=utc(),
            command=[sys.executable,'-I',str(Path(__file__).resolve())],existing_runs=expected,
            production_sources_changed=False,benchmarks_launched_or_restarted=False)
def save():
    output.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()
print('MEMORY_RANGE_EXISTING_RUN_FINALIZER_STARTED '+json.dumps(record,sort_keys=True),flush=True)
deadline=time.monotonic()+7200
try:
    while True:
        all_done=True
        for role,original in expected.items():
            target=Path(original['path'])
            current=load(target/'PROCESS.json')
            for key in ('native_pid','worker_pid','started_utc','command'):
                assert current[key]==original[key],'Existing run identity changed: '+role
            if current['status']=='FAILED':
                raise RuntimeError('Native process returned failure: '+role)
            proc=Path('/proc')/str(original['native_pid'])
            complete=(target/'RUN.json').exists() and (HERE/('LONG_'+role+'_RESULT.json')).exists()
            if not complete:
                all_done=False
                if proc.exists():
                    command=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace').strip()
                    assert command.startswith(original['command'][0]),'PID identity changed: '+role
                elif current['status']!='COMPLETED':
                    raise RuntimeError('Existing native process disappeared without completion receipt: '+role)
        if all_done:
            break
        assert time.monotonic()<deadline,'Existing process completion deadline exceeded'
        time.sleep(10)
    command=[sys.executable,'-I',str(HERE/'finalize_longs.py')]
    result=subprocess.run(command,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    assert result.returncode==0,result.stdout
    final=load(HERE/'LONG_FINAL_AUDIT.json')
    assert final['status']=='PASS_BOTH_ACTUAL6000_GT3P5' and not final['pending']
    record.update(status='COMPLETED_EXISTING_RUN_AUDIT_PASS',finished_utc=utc(),audit_command=command,
                  audit_literal_output=result.stdout,audit_exit_status=result.returncode,
                  audit_path=str(HERE/'LONG_FINAL_AUDIT.json'),audit_sha256=sha(HERE/'LONG_FINAL_AUDIT.json'))
    save()
    assert load(output)==record
    print('MEMORY_RANGE_EXISTING_RUN_FINALIZER_PASS actual6000=2 original_processes=unchanged audits=reopened new_benchmark_runs=0',flush=True)
except BaseException as error:
    record.update(status='FAILED_EXISTING_RUN_AUDIT',finished_utc=utc(),error=repr(error))
    save()
    raise

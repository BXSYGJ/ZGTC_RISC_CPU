"""Audit saved actual6000 UART/counter/model receipts, without launching work."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
IDENTITY='5bfd35fb3ce5591c17d5b0f5a020662b3d4a7152b83cff437c7010a5f3be1778'
FW={'V0':'941041b71bd0b8a3075bd3470fdd566605492f3ceb21ba8faea677dd230bc0cf','V1':'9f97816a605e829d4a9345a3c739cd25603a60c99d6555533a3876dccde655db'}
change=load(HERE/'CHANGE.json')
for folder,total in (('rtl',17),('physical_rtl',18)):
    actual={p.name:sha(p) for p in (ROOT/'candidates/loop16_h4_ram_memory_range'/folder).glob('*.sv')}
    assert len(actual)==total and actual==change[folder]
spec=importlib.util.spec_from_file_location('readonly_audit',ROOT/'scripts/audit_results.py')
audit=importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
completed=[]
pending=[]
for role in ('V0','V1'):
    target=ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)
    if not (target/'RUN.json').exists() or not (HERE/('LONG_'+role+'_RESULT.json')).exists():
        pending.append(role)
        continue
    raw=audit.audit_simulation(target)
    run=load(target/'RUN.json')
    process=load(target/'PROCESS.json')
    receipt=load(HERE/('LONG_'+role+'_RESULT.json'))
    reuse=load(target/'FIRMWARE_REUSE.json')
    binding=reuse['source_binding']
    assert raw['formal_ten_seconds'] and raw['iterations']==6000
    assert raw['rtl_sha256']==binding['rtl_sha256']==process['rtl_sha256']==IDENTITY
    assert raw['firmware_sha256']==FW[role]
    assert binding['rtl_17_sha256']==change['rtl'] and binding['physical_rtl_18_sha256']==change['physical_rtl']
    assert sha(Path(binding['executable']))==binding['executable_sha256']
    short_receipt=HERE/'SHORT_VERIFICATION_FROZEN.txt'
    if not short_receipt.exists():
        short_receipt=HERE/'VERIFICATION.txt'
    assert sha(short_receipt)==binding['short_verification_sha256']
    assert receipt['run']==run and receipt['run_json_sha256']==sha(target/'RUN.json')
    assert process['status']=='COMPLETED' and process['native_exit_status']==0
    assert receipt['process']==process
    original=ROOT/'work'/('cf4-loadsimple-tune5-i6000-'+role)
    for name in ('BUILD.json','firmware.hex','firmware.bin','firmware.elf','firmware.map','firmware.dis','compiler.log'):
        if (original/name).exists():
            assert (original/name).read_bytes()==(target/name).read_bytes()
    stdout=(target/'simulation.log').read_text()
    observer=re.search(r'OBSERVER cycles=(\d+) retired=(\d+) minimum_sp=(\d+)',stdout)
    assert observer is not None
    assert (int(observer[1]),int(observer[2]))==(raw['cycles'],raw['retired'])
    prior=load(ROOT/('rtl_proposals/load_simple_loop16_h4/LONG_'+role+'_RESULT.json'))['run']
    assert raw['cycles']==prior['timed_cycles'] and raw['retired']==prior['retired']
    completed.append(dict(role=role,audit=raw,process=process,source_binding=binding,
                          raw_UART_SHA256=sha(target/'uart.log'),raw_stdout_SHA256=sha(target/'simulation.log'),
                          run_receipt_SHA256=sha(target/'RUN.json'),worker_result_SHA256=sha(HERE/('LONG_'+role+'_RESULT.json')),
                          exact_cf4_firmware_and_build=True,raw_UART_observer_CSR_counters_match=True,qualified_H4_long_cycles_and_retired_equal=True))
status='PENDING_ACTUAL6000' if pending else ('PASS_BOTH_ACTUAL6000_GT3P5' if all(row['audit']['coremark_per_mhz']>3.5 for row in completed) else 'VALID_ACTUAL6000_BELOW3P5')
result=dict(status=status,updated_utc=datetime.now(timezone.utc).isoformat(),records=completed,pending=pending,
            source_chain=change,production_RTL_changed=False,processes_launched_or_restarted=False)
output=HERE/'LONG_FINAL_AUDIT.json'
output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert load(output)==result
print('MEMORY_RANGE_LONG_FINAL_AUDIT '+status+' completed='+str(len(completed))+' pending='+','.join(pending)+' RTL=17/18 reopened=1')

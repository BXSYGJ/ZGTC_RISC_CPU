"""Compact completed actual6000 evidence, retaining launch receipts unchanged."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ref=lambda p:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
launch=HERE/'LAUNCH_VERIFICATION_FROZEN.txt'
if not launch.exists():shutil.copy2(HERE/'VERIFICATION.txt',launch)
short_compat=HERE/'SHORT_VERIFICATION_FROZEN.txt'
if not short_compat.exists():shutil.copy2(launch,short_compat)
assert sha(short_compat)==sha(launch)
v=load(launch)
assert v['status']=='SOURCE_PROOFS_FROZEN_ACTUAL6000_AUTHORIZED'
frozen_audit=HERE/'LONG_FINAL_AUDIT_FROZEN.json'
if not frozen_audit.exists():shutil.copy2(HERE/'LONG_FINAL_AUDIT.json',frozen_audit)
audit=load(frozen_audit)
assert audit['status']=='PASS_BOTH_ACTUAL6000_GT3P5' and not audit['pending']
helper=load(HERE/'BACKGROUND_FINALIZATION_PROCESS.json')
assert helper['status']=='COMPLETED_EXISTING_RUN_AUDIT_PASS' and helper['audit_exit_status']==0
change=load(HERE/'SOURCE_CHANGE.json')
proof_source=ROOT/'rtl_proposals/loop16_h4_ram_memory_range'
source_check=load(HERE/'SOURCE_FINAL_RECHECK.json')
source_artifacts={name:ref(proof_source/name) for name in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')}
for name,item in source_artifacts.items():
    assert item['sha256']==source_check['artifacts'][name]['sha256']
source_verification=load(proof_source/'VERIFICATION.txt')
rollback=load(proof_source/'ROLLBACK_RESULT.json')
assert rollback['exit_status']==0 and rollback['restored_sha256']==source_verification['baseline_sha256']
source=ROOT/'candidates/loop16_h4_ram_memory_range'
for folder,total in (('rtl',17),('physical_rtl',18)):
    actual={p.name:sha(p) for p in (source/folder).glob('*.sv')}
    assert len(actual)==total and actual==change[folder]
records=[]
for row in audit['records']:
    role=row['role']
    target=ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)
    raw=row['audit']
    assert raw['coremark_per_mhz']>3.5 and raw['formal_ten_seconds'] and raw['seconds_at_145125MHz']>10
    assert raw['exit_status']==0 and row['qualified_H4_long_cycles_and_retired_equal']
    assert row['source_binding']['short_verification_sha256']==sha(launch)
    prior=load(ROOT/('rtl_proposals/load_simple_loop16_h4/LONG_'+role+'_RESULT.json'))['run']
    assert (raw['cycles'],raw['retired'])==(prior['timed_cycles'],prior['retired'])
    for name in ('BUILD.json','firmware.hex','firmware.bin','firmware.elf','firmware.map','firmware.dis','compiler.log'):
        original=ROOT/'work'/('cf4-loadsimple-tune5-i6000-'+role)/name
        if original.exists():assert original.read_bytes()==(target/name).read_bytes()
    records.append(dict(role=role,iterations=6000,clock_hz=145125000,timed_cycles=raw['cycles'],retired=raw['retired'],coremark_per_mhz=raw['coremark_per_mhz'],formal_seconds=raw['seconds_at_145125MHz'],
                        formal_over10_seconds=True,CRC=raw['crc_fields'],all_four_CRC_valid=True,UART_CSR_OBSERVER_equal=True,qualified_H4_cycles_and_retired_equal=True,
                        firmware_sha256=raw['firmware_sha256'],rtl_sha256=raw['rtl_sha256'],native_pid=row['process']['native_pid'],native_exit_status=row['process']['native_exit_status'],
                        process_status=row['process']['status'],original_process_finished_without_restart=True,
                        command=row['process']['command'],input_directory=str(target),literal_result='Correct operation validated. See README.md for run and reporting rules.',
                        observer_literal='OBSERVER cycles='+str(raw['cycles'])+' retired='+str(raw['retired'])+' minimum_sp=65152',
                        receipts={name:ref(target/name) for name in ('PROCESS.json','RUN.json','FIRMWARE_REUSE.json','BUILD.json','firmware.hex','uart.log','simulation.log')}))
physical=[]
for seed in (1,2,3):
    target=ROOT/'work'/('sg30-ram-memory-range-s'+str(seed))
    build=load(target/'BUILD_RESULT.json')
    assert {p.name:sha(p) for p in (target/'inputs/rtl').glob('*.sv')}==change['physical_rtl']
    timing=load(target/'TIMING_SUMMARY.json')
    assert build['Status']=='completed_timing_fail' and build['Timing']==timing and len(timing['Checks'])==10
    assert timing['ConfiguredCpuClockHz']==145125000 and timing['SetupUncertaintyNs']==0.150
    assert not timing['AllReportedChecksPass']
    rtr=target/'implementation/report_timing/pds_soc_top.rtr'
    assert sha(rtr)==timing['ReportSHA256'].lower()
    physical.append(dict(build=target.name,status=build['Status'],LUT=build['Resources']['LUT'],FF=build['Resources']['FF'],WNS_ns=timing['Checks']['Setup_Slow'][0]['WorstSlackNs'],
                         timing_checks_pass=False,all18_RTL_match_actual6000=True,clock_hz=145125000,setup_uncertainty_ns=0.150,
                         receipts={name:ref(target/name) for name in ('BUILD_RESULT.json','TIMING_SUMMARY.json','INPUT_HASHES.json')},raw_timing=ref(rtr)))
summary=dict(status='ACTUAL6000_BOTH_GT3P5_PHYSICAL_S1_S3_TIMING_FAIL',updated_utc=datetime.now(timezone.utc).isoformat(),
             launch_verification=ref(launch),source_snapshots=v['source_snapshots'],core_sha256=v['core_sha256'],btb_sha256=v['btb_sha256'],rtl17=change['rtl'],physical18=change['physical_rtl'],
             actual6000=records,physical=physical,raw_long_audit=ref(frozen_audit),original_helper_receipt=ref(HERE/'BACKGROUND_FINALIZATION_PROCESS.json'),
             changed_field=source_verification['changed_field'],source_four_artifacts=source_artifacts,
             existing_source_BMR=source_verification['core_tests'],existing_real_rollback=rollback,
             no_new_tests_or_benchmark_runs=True,no_production_RTL_changed=True,release_qualification='Experimental source with formal-duration performance pass; all three saved physical seeds fail timing.')
(HERE/'VERIFICATION.txt').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'VERIFICATION.txt')==summary
text=['SG30 memory-range actual6000 audit','',
      'Source core8AF95F / BTB13aa / cacheC9D73; exact17simulation and18physical RTL hashes match all three saved physical builds.',
      'Clock145125000Hz; setup uncertainty0.150ns. Exact original GCC10.2 cf4 firmware and all saved build artifacts reused byte-for-byte.','',
      '| Role | Cycles | Retired | CoreMark/MHz | Formal seconds | CRC list/matrix/state/final |','|---|---:|---:|---:|---:|---|']
for row in records:text.append('| '+row['role']+' | '+str(row['timed_cycles'])+' | '+str(row['retired'])+' | '+format(row['coremark_per_mhz'],'.12f')+' | '+format(row['formal_seconds'],'.9f')+' | '+','.join(row['CRC'])+' |')
text+=['','Both original native processes completed exit0; UART,CSR andOBSERVER counters agree; four CRC fields validate. Cycles andretired exactly equal qualified H4. No new run or restart was performed for this audit.','',
       '| Physical build | LUT | FF | WNS ns | Status |','|---|---:|---:|---:|---|']
for row in physical:text.append('| '+row['build']+' | '+str(row['LUT'])+' | '+str(row['FF'])+' | '+format(row['WNS_ns'],'.3f')+' | timing fail |')
text+=['','Current qualification: performance pass, physical timing fail. The qualified H4 release remains preserved.','',
       'All original receipts are unchanged. Launch verification is frozen separately; VERIFICATION.txt points to rawUART/log/process/model/source andphysical report hashes.','']
(HERE/'SUMMARY.md').write_text('\n'.join(text),encoding='utf-8')
recheck=dict(status='PASS',verification=ref(HERE/'VERIFICATION.txt'),summary=ref(HERE/'SUMMARY.md'),launch=ref(launch),long_audit=ref(frozen_audit),source_four_artifacts=source_artifacts,
             actual6000_roles=2,both_scores_gt3p5=True,both_formal_duration_gt10_seconds=True,all17_18_RTL_match=True,all_existing_physical_seeds_fail_timing=True,new_benchmark_runs=0)
(HERE/'FINAL_RECHECK.json').write_text(json.dumps(recheck,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'FINAL_RECHECK.json')==recheck
for key in ('verification','summary','launch','long_audit'):assert sha(Path(recheck[key]['path']))==recheck[key]['sha256']
for item in source_artifacts.values():assert sha(Path(item['path']))==item['sha256']
print('SG30_FINAL_EVIDENCE_PASS actual6000=2 both_gt3p5=True duration_gt10=True UART_CSR_OBSERVER_CRC=valid H4_cycles_retired=equal RTL17_18_physical_sources=equal timing_s1_s3=fail original_processes=completed new_runs=0 summary=reopened')

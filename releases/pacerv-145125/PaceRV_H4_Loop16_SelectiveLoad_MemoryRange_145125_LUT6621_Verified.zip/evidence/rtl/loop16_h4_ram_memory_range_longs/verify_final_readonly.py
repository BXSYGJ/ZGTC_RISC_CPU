"""Recompute the completed SG30 evidence without rewriting any receipt."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
final=load(HERE/'FINAL_RECHECK.json')
for key in ('verification','summary','launch','long_audit'):
    item=final[key]
    assert sha(Path(item['path']))==item['sha256']
for item in final['source_four_artifacts'].values():assert sha(Path(item['path']))==item['sha256']
verification=load(HERE/'VERIFICATION.txt')
audit=load(Path(final['long_audit']['path']))
change=load(HERE/'SOURCE_CHANGE.json')
assert audit['status']=='PASS_BOTH_ACTUAL6000_GT3P5' and not audit['pending']
spec=importlib.util.spec_from_file_location('saved_audit',ROOT/'scripts/audit_results.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
for folder,count in (('rtl',17),('physical_rtl',18)):
    current={p.name:sha(p) for p in (ROOT/'candidates/loop16_h4_ram_memory_range'/folder).glob('*.sv')}
    assert len(current)==count and current==change[folder]
for saved in audit['records']:
    role=saved['role']
    target=ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)
    fresh=module.audit_simulation(target)
    assert fresh==saved['audit']
    process=load(target/'PROCESS.json')
    run=load(target/'RUN.json')
    result=load(HERE/('LONG_'+role+'_RESULT.json'))
    assert process==result['process'] and run==result['run']
    assert process['status']=='COMPLETED' and process['native_exit_status']==fresh['exit_status']==0
    assert sha(target/'RUN.json')==result['run_json_sha256']
    assert sha(target/'uart.log')==saved['raw_UART_SHA256']
    assert sha(target/'simulation.log')==saved['raw_stdout_SHA256']
    binding=load(target/'FIRMWARE_REUSE.json')['source_binding']
    assert binding['rtl_17_sha256']==change['rtl'] and binding['physical_rtl_18_sha256']==change['physical_rtl']
    assert sha(Path(binding['executable']))==binding['executable_sha256']
    assert sha(HERE/'LAUNCH_VERIFICATION_FROZEN.txt')==binding['short_verification_sha256']
    original=ROOT/'work'/('cf4-loadsimple-tune5-i6000-'+role)
    for name in ('BUILD.json','firmware.hex','firmware.bin','firmware.elf','firmware.map','firmware.dis','compiler.log'):
        if (original/name).exists():assert (original/name).read_bytes()==(target/name).read_bytes()
    observer=re.search(r'OBSERVER cycles=(\d+) retired=(\d+) minimum_sp=(\d+)',(target/'simulation.log').read_text())
    assert observer is not None and (int(observer[1]),int(observer[2]))==(fresh['cycles'],fresh['retired'])
    qualified=load(ROOT/('rtl_proposals/load_simple_loop16_h4/LONG_'+role+'_RESULT.json'))['run']
    assert (fresh['cycles'],fresh['retired'])==(qualified['timed_cycles'],qualified['retired'])
    assert fresh['iterations']==6000 and fresh['coremark_per_mhz']==6000e6/fresh['cycles']>3.5
    assert fresh['seconds_at_145125MHz']==fresh['cycles']/145125000>10
    assert fresh['formal_ten_seconds']
    print('SG30_READONLY_ROLE_PASS role='+role+' cycles='+str(fresh['cycles'])+' retired='+str(fresh['retired'])+' score='+repr(fresh['coremark_per_mhz'])+' seconds='+repr(fresh['seconds_at_145125MHz'])+' CRC='+','.join(fresh['crc_fields'])+' exit=0 H4_cycles_retired=exact')
for physical in verification['physical']:
    for item in list(physical['receipts'].values())+[physical['raw_timing']]:assert sha(Path(item['path']))==item['sha256']
    target=ROOT/'work'/physical['build']
    assert {p.name:sha(p) for p in (target/'inputs/rtl').glob('*.sv')}==change['physical_rtl']
    assert load(target/'BUILD_RESULT.json')['Status']=='completed_timing_fail'
assert verification['existing_real_rollback']['exit_status']==0
assert verification['existing_real_rollback']['active_modified_sha256']==change['modified_sha256']
print('SG30_FINAL_READONLY_PASS original_processes=completed original35source=unchanged physical_source_bindings=exact firmware_bytes=original source_four_artifacts=reopened frozen_refs=valid timing_s1_s2_s3=FAIL new_runs=0 receipt_writes=0')

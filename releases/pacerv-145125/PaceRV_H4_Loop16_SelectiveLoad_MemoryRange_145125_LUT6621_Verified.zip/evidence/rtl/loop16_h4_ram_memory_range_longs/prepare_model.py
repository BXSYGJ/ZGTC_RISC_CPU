from pathlib import Path
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=load(HERE/'VERIFICATION.txt')
source=ROOT/'candidates/loop16_h4_ram_memory_range/rtl'
assert {p.name:sha(p) for p in source.glob('*.sv')}==v['rtl']
spec=importlib.util.spec_from_file_location('experiment',ROOT/'scripts/experiment.py')
e=importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)
executable,identity=e.simulator(source,load_bubble=1,threads=1)
assert identity==v['standard_simulation_rtl_identity']
result=dict(status='READY',executable=str(executable),executable_sha256=sha(executable),rtl_sha256=identity,model_build=load(executable.parent/'BUILD.json'),launch_verification_sha256=sha(HERE/'VERIFICATION.txt'))
(HERE/'MODEL_READY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'MODEL_READY.json')==result
print('MEMORY_RANGE_MODEL_READY source='+identity+' executable='+str(executable)+' sha256='+sha(executable))

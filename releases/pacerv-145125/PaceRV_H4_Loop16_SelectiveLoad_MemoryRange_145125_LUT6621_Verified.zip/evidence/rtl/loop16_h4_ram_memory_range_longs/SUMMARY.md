SG30 memory-range actual6000 audit

Source core8AF95F / BTB13aa / cacheC9D73; exact17simulation and18physical RTL hashes match all three saved physical builds.
Clock145125000Hz; setup uncertainty0.150ns. Exact original GCC10.2 cf4 firmware and all saved build artifacts reused byte-for-byte.

| Role | Cycles | Retired | CoreMark/MHz | Formal seconds | CRC list/matrix/state/final |
|---|---:|---:|---:|---:|---|
| V0 | 1712559880 | 1634152429 | 3.503527129224 | 11.800584875 | 0xe714,0x1fd7,0x8e3a,0xa14c |
| V1 | 1713586192 | 1634361529 | 3.501428774351 | 11.807656792 | 0xe3c1,0x0747,0x8d84,0x18e1 |

Both original native processes completed exit0; UART,CSR andOBSERVER counters agree; four CRC fields validate. Cycles andretired exactly equal qualified H4. No new run or restart was performed for this audit.

| Physical build | LUT | FF | WNS ns | Status |
|---|---:|---:|---:|---|
| sg30-ram-memory-range-s1 | 6763 | 2557 | -0.257 | timing fail |
| sg30-ram-memory-range-s2 | 6611 | 2557 | -0.005 | timing fail |
| sg30-ram-memory-range-s3 | 6675 | 2557 | -0.292 | timing fail |

Current qualification: performance pass, physical timing fail. The qualified H4 release remains preserved.

All original receipts are unchanged. Launch verification is frozen separately; VERIFICATION.txt points to rawUART/log/process/model/source andphysical report hashes.

from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
PARENT=ROOT/'rtl_proposals/loop16_h4_ram_memory_range'
SOURCE=ROOT/'candidates/loop16_h4_ram_memory_range'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert not (HERE/'VERIFICATION.txt').exists(),'Preserve existing launch evidence'
change=load(PARENT/'CHANGE.json')
check=load(PARENT/'FINAL_RECHECK.json')
assert check['status']=='READY_SOURCE_BOUND_PROOFS_PASS_PHYSICAL_PENDING'
assert check['core_BMR23_full_equal'] and check['architecture_lines']==591
assert check['production_source_SAT'] and check['negative_controls_rejected']
assert change['modified_sha256']=='8af95f92009be4979e23fa0bee77eff3bc6858357173470a0bdf7db75326c416'
for folder,total in (('rtl',17),('physical_rtl',18)):
    actual={p.name:sha(p) for p in (SOURCE/folder).glob('*.sv')}
    assert actual==change[folder] and len(actual)==total
    assert actual['rv32_btb.sv']=='13aa9b1196adc482149b3414f62d752e787ded7a9b0bf06438b28e9be8a563c8'
    assert actual['rv32_cache.sv']=='c9d73d59e80a70399df214dfbbe3316083e6df0d33974e1564795a4ae875d6c1'
recipe=load(ROOT/'recipe.json')['simulation']['argv']
files=[SOURCE/'rtl'/Path(x).name for x in recipe if '/simulation/inputs/rtl/' in x]
files+=[ROOT/x.split('{RELEASE}/')[1] for x in recipe if '/simulation/inputs/sim/' in x]
h=hashlib.sha256()
for p in files:h.update(p.name.encode());h.update(p.read_bytes())
h.update(b'1')
identity=h.hexdigest()
snapshots={}
for name in ('CHANGE.json','VERIFICATION.txt','FINAL_RECHECK.json'):
    destination=HERE/('SOURCE_'+name)
    shutil.copy2(PARENT/name,destination)
    snapshots[name]=dict(original_path=str(PARENT/name),snapshot_path=str(destination),sha256=sha(destination))
verification=dict(status='SOURCE_PROOFS_FROZEN_ACTUAL6000_AUTHORIZED',created_utc=datetime.now(timezone.utc).isoformat(),
                  source_directory=str(SOURCE),source_snapshots=snapshots,standard_simulation_rtl_identity=identity,
                  core_sha256=change['modified_sha256'],btb_sha256=change['parent_btb_sha256'],rtl=change['rtl'],physical_rtl=change['physical_rtl'],
                  functional_basis=dict(source_range_allwidth_SAT=True,exact_parent_target_keep_attribute=True,core23_complete_stdout_equal=True,ARCH_lines=591,
                                        parent13aa_all_state_loop_equivalence=True,parent13aa_actual6000_both_roles_gt3p5=True),
                  expected_H4_long_cycles_and_retired_must_match=True,roles=['V0','V1'],iterations=6000,firmware='Exact originalcf4 GCC10.2 tune5 bytes and BUILD receipts',
                  no_production_source_changed=True,no_source_owner_verification_changed=True)
(HERE/'VERIFICATION.txt').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
shutil.copy2(PARENT/'CHANGE.json',HERE/'CHANGE.json')
source=(ROOT/'rtl_proposals/loop16_h4_single_write/long_benchmark.py').read_text()
source=source.replace("SOURCE=ROOT/'candidates/loop16_h4_single_write/rtl'","SOURCE=ROOT/'candidates/loop16_h4_ram_memory_range/rtl'")
source=source.replace("IDENTITY=load(AREA/'FULL100_INTERFACE_EQUIVALENCE.json')['standard_simulation_rtl_identity']","IDENTITY=load(AREA/'VERIFICATION.txt')['standard_simulation_rtl_identity']")
start=source.index("assert load(AREA/'FINAL_RECHECK.json')['result']")
end=source.index('\ndef verify_sources():',start)
source=source[:start]+"assert load(AREA/'VERIFICATION.txt')['status']=='SOURCE_PROOFS_FROZEN_ACTUAL6000_AUTHORIZED'\n"+source[end:]
start=source.index("executable,identity=e.simulator(")
end=source.index("assert identity==IDENTITY",start)
source=source[:start]+"model=load(AREA/'MODEL_READY.json')\nexecutable=Path(model['executable'])\nidentity=model['rtl_sha256']\nassert sha(executable)==model['executable_sha256']\n"+source[end:]
source=source.replace("target=ROOT/'work'/('sg25-loop-single-write-i6000-'+role)","target=ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)")
source=source.replace('LOOP_SINGLE_WRITE_LONG','MEMORY_RANGE_LONG')
(HERE/'long_benchmark.py').write_text(source,encoding='utf-8')
print('MEMORY_RANGE_LONG_PREPARED source='+identity+' proofs=frozen firmware=exact_cf4 new_native_runs=not_started')

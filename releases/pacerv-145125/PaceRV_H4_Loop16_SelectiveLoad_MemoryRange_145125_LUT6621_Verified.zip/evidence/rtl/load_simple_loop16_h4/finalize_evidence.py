"""Merge completed evidence while retaining exact launch-time B/M/R receipts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
short_path=HERE/'SHORT_VERIFICATION_FROZEN.txt'
old_recheck_path=HERE/'SHORT_FINAL_RECHECK_FROZEN.json'
if not short_path.exists():
    old=load(HERE/'FINAL_RECHECK.json')
    assert sha(HERE/'VERIFICATION.txt')==old['artifacts']['VERIFICATION.txt']['sha256']
    shutil.copy2(HERE/'VERIFICATION.txt',short_path)
    shutil.copy2(HERE/'FINAL_RECHECK.json',old_recheck_path)
short=load(short_path)
old_recheck=load(old_recheck_path)
assert sha(short_path)==old_recheck['artifacts']['VERIFICATION.txt']['sha256']
longs=load(HERE/'LONG_FINAL_AUDIT.json')
physical=load(HERE/'QUALIFICATION-sg21-loop16-h4-s2.json')
assert longs['status']=='PASS_BOTH_ACTUAL6000_GT3P5' and not longs['pending']
assert physical['status']=='QUALIFIED_SAVED_PHYSICAL_AND_ACTUAL6000'
assert len(physical['timing_checks'])==10
change=load(HERE/'CHANGE.json')
for folder,total in (('rtl',17),('physical_rtl',18)):
    actual={p.name:sha(p) for p in (ROOT/'candidates/load_simple_loop16_h4'/folder).glob('*.sv')}
    assert len(actual)==total and actual==change[folder]
for role in ('V0','V1'):
    reuse=load(ROOT/('work/sg21-loop16-h4-i6000-'+role+'/FIRMWARE_REUSE.json'))
    assert reuse['source_binding']['short_verification_sha256']==sha(short_path)
current=dict(short)
current.update(status='QUALIFIED_ACTUAL6000_AND_PHYSICAL_S2_AREA_COMPARISON_PENDING',
               evidence_finalized_utc=datetime.now(timezone.utc).isoformat(),
               launch_time_short_verification=dict(path=str(short_path),sha256=sha(short_path),original_recheck=str(old_recheck_path),original_recheck_sha256=sha(old_recheck_path)),
               actual6000=longs,
               joint_physical_qualification=physical,
               final_source_snapshot=dict(rtl_17=change['rtl'],physical_rtl_18=change['physical_rtl'],retained_core_sha256=change['retained_core_sha256'],BTB_sha256=change['modified_btb_sha256'],cache_sha256=change['rtl']['rv32_cache.sv']),
               completion_state=dict(actual6000_roles_complete=2,both_actual6000_scores_exceed_3p5=True,formal_duration_pass_roles=2,qualified_actual_build='sg21-loop16-h4-s2',qualified_actual_LUT=6812,qualified_actual_FF=2813,qualified_actual_WNS_ns=0.008,qualified_actual_timing_sections=10,all_functional_and_rollback_proofs_complete=True,
                                     pending=['Root selects final physical build after the four already started area comparisons.'],
                                     root_area_comparisons=['seed3','seed4','seed2 packing0','seed2 packing2'],
                                     final_physical_selection_owner='root',new_tests_or_builds_launched_by_this_update=False),
               original_BMR_records_preserved=True,production_sources_changed_by_finalization=False)
for name in ('core','predictor','screens','source_chain','restored_behavior'):
    assert current[name]==short[name]
output=HERE/'VERIFICATION.txt'
output.write_text(json.dumps(current,indent=2)+'\n',encoding='utf-8')
assert load(output)==current
artifacts={name:dict(path=str(HERE/name),sha256=sha(HERE/name),bytes=len((HERE/name).read_bytes())) for name in current['artifacts']}
assert artifacts['MODIFIED_FILE.sv']['sha256']==change['modified_btb_sha256']
final=dict(status='PASS',artifacts=artifacts,source_snapshot=current['final_source_snapshot'],
           original_BMR_records_preserved=True,short_status=short['status'],short_scores=old_recheck['short_scores'],
           actual6000_status=longs['status'],actual6000_scores={r['role']:r['audit']['coremark_per_mhz'] for r in longs['records']},
           joint_physical_status=physical['status'],joint_physical_build='sg21-loop16-h4-s2',
           final_physical_selection_pending=current['completion_state']['pending'],
           historical_short_snapshot=dict(path=str(short_path),sha256=sha(short_path)),
           source_files_changed=False,new_tests_rerun=False)
(HERE/'FINAL_RECHECK.json').write_text(json.dumps(final,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'FINAL_RECHECK.json')==final
for name,item in artifacts.items():
    assert sha(HERE/name)==item['sha256']
update=dict(status='PASS',command=['python3','-I',str(Path(__file__).resolve())],input=dict(short_verification=str(short_path),long_audit=str(HERE/'LONG_FINAL_AUDIT.json'),physical_qualification=str(HERE/'QUALIFICATION-sg21-loop16-h4-s2.json')),
            verification_before_sha256=sha(short_path),verification_after_sha256=sha(output),recheck_before_sha256=sha(old_recheck_path),recheck_after_sha256=sha(HERE/'FINAL_RECHECK.json'),
            BMR_content_identical=True,production_RTL_identical=True,rollback_literal=short['core']['rollback']['LiteralOutput'],
            literal_output='H4_FINAL_EVIDENCE_PASS actual6000=2 both_gt3p5=True physical_s2=10/10 BMR=preserved source=unchanged final_area_selection=pending four_artifacts=reopened',exit_status=0)
(HERE/'FINAL_EVIDENCE_UPDATE.json').write_text(json.dumps(update,indent=2)+'\n',encoding='utf-8')
assert load(HERE/'FINAL_EVIDENCE_UPDATE.json')==update
print(update['literal_output'])

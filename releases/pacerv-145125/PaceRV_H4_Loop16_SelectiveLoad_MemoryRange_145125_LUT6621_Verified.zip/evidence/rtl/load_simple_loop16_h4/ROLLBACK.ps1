﻿#!/usr/bin/env pwsh
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetDirectory,[Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BaselineFile)
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
$OutputEncoding=[System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference='Stop'
try {
    $target=[System.IO.Path]::GetFullPath($TargetDirectory)
    $baseline=[System.IO.Path]::GetFullPath($BaselineFile)
    $destination=[System.IO.Path]::Combine($target,'rv32_btb.sv')
    if($destination -eq $baseline){throw 'Use an independent target directory'}
    if(-not(Test-Path -LiteralPath $target -PathType Container)){throw 'Target directory missing'}
    if((Get-FileHash -LiteralPath $baseline -Algorithm SHA256).Hash -ne '222223A16F58695FA149A0B709ACAEBFA2BAB479B0ACEA916DFEF76C9E8581BA'){throw 'Baseline hash mismatch'}
    Copy-Item -LiteralPath $baseline -Destination $destination -Force
    if((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne '222223A16F58695FA149A0B709ACAEBFA2BAB479B0ACEA916DFEF76C9E8581BA'){throw 'Restore hash mismatch'}
    Write-Output 'SL_LOOP16_ROLLBACK_PASS SHA256=222223A16F58695FA149A0B709ACAEBFA2BAB479B0ACEA916DFEF76C9E8581BA'
} catch {Write-Error $_;exit 1}

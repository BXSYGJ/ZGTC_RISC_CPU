"""Run once per role: actual 6000 iterations, exact saved cf4 tune5 firmware."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess

AREA=Path(__file__).resolve().parent
ROOT=AREA.parent.parent
SOURCE=ROOT/'candidates/load_simple_loop16_h4/rtl'
IDENTITY='c7ab29adf836d1f94a9b637d4e8489412774bef95f254fde386b63aa03e7f194'
FW_SHA={'V0':'941041b71bd0b8a3075bd3470fdd566605492f3ceb21ba8faea677dd230bc0cf','V1':'9f97816a605e829d4a9345a3c739cd25603a60c99d6555533a3876dccde655db'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
utc=lambda:datetime.now(timezone.utc).isoformat()
parser=argparse.ArgumentParser()
parser.add_argument('--role',choices=('V0','V1'),required=True)
args=parser.parse_args()
role=args.role
change=load(AREA/'CHANGE.json')
assert load(AREA/'FINAL_RECHECK.json')['short_status']=='FUNCTIONAL_PASS_SHORT_BOTH_GT3P5'
for test_role in ('V0','V1'):
    short=load(AREA/('SCREEN-MODIFIED-'+test_role+'.json'))
    assert short['coremark_per_mhz']>3.5 and all(short['checks'].values()) and short['rtl_sha256']==IDENTITY
def verify_sources():
    for folder,total in (('rtl',17),('physical_rtl',18)):
        directory=SOURCE.parent/folder
        assert len(list(directory.glob('*.sv')))==total
        assert {p.name:sha(p) for p in directory.glob('*.sv')}==change[folder]
verify_sources()
spec=importlib.util.spec_from_file_location('experiment',ROOT/'scripts/experiment.py')
e=importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)
executable,identity=e.simulator(SOURCE,load_bubble=1,threads=1)
assert identity==IDENTITY
binding=dict(executable=str(executable),executable_sha256=sha(executable),rtl_sha256=identity,
             rtl_17_sha256=change['rtl'],physical_rtl_18_sha256=change['physical_rtl'],
             model_build=load(executable.parent/'BUILD.json'),short_verification_sha256=sha(AREA/'VERIFICATION.txt'))
original=ROOT/'work'/('cf4-loadsimple-tune5-i6000-'+role)
target=ROOT/'work'/('sg21-loop16-h4-i6000-'+role)
assert not target.exists(),'Existing process/output directory prevents duplicate launch'
metadata=load(original/'BUILD.json')
assert metadata['role']==role and metadata['iterations']==6000
assert metadata['firmware_hex_sha256']==sha(original/'firmware.hex')==FW_SHA[role]
target.mkdir()
for name in ('BUILD.json','firmware.hex','firmware.bin','firmware.elf','firmware.map','firmware.dis','compiler.log'):
    if (original/name).is_file():
        shutil.copy2(original/name,target/name)
assert (target/'BUILD.json').read_bytes()==(original/'BUILD.json').read_bytes()
reuse=dict(original_run=str(original),target=str(target),firmware_sha256=sha(target/'firmware.hex'),
           build_json_sha256=sha(target/'BUILD.json'),exact_firmware_bytes=True,exact_build_receipt_bytes=True,
           compiler_flags_regenerated=False,worker_pid=os.getpid(),role=role,source_binding=binding)
(target/'FIRMWARE_REUSE.json').write_text(json.dumps(reuse,indent=2)+'\n',encoding='utf-8-sig')
record=dict(status='PREPARED',role=role,worker_pid=os.getpid(),prepared_utc=utc(),firmware_sha256=reuse['firmware_sha256'],rtl_sha256=identity)
(target/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8-sig')
def tracked_native_run(command,**kwargs):
    process=subprocess.Popen(command,**kwargs)
    record.update(status='RUNNING',native_pid=process.pid,command=command,cwd=str(kwargs.get('cwd',target)),started_utc=utc(),process_receipt=str(target/'PROCESS.json'))
    (target/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8-sig')
    print('SL_LOOP16_H4_LONG_NATIVE_STARTED '+json.dumps(record,sort_keys=True),flush=True)
    code=process.wait()
    record.update(status='COMPLETED' if code==0 else 'FAILED',native_exit_status=code,finished_utc=utc())
    (target/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8-sig')
    return subprocess.CompletedProcess(command,code)
e.subprocess.run=tracked_native_run
e.run(target,executable,identity,2400000000,1)
result=load(target/'RUN.json')
assert result['formal_ten_seconds'] and result['duration_at_145125MHz_seconds']>=10
assert all(result['checks'].values()) and result['exit_status']==0
assert result['crc_fields']=={'V0':['0xe714','0x1fd7','0x8e3a','0xa14c'],'V1':['0xe3c1','0x0747','0x8d84','0x18e1']}[role]
assert result['firmware']==metadata and result['rtl_sha256']==identity
verify_sources()
status='PASS_GT3P5' if result['coremark_per_mhz']>3.5 else 'VALID_ACTUAL6000_BELOW3P5'
receipt=dict(status=status,role=role,path=str(target),firmware_reuse=reuse,run_json_sha256=sha(target/'RUN.json'),process=load(target/'PROCESS.json'),run=result)
(AREA/('LONG_'+role+'_RESULT.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8-sig')
print('SL_LOOP16_H4_LONG_RESULT '+role+' status='+status+' cycles='+str(result['timed_cycles'])+' CM/MHz='+str(result['coremark_per_mhz'])+' seconds='+str(result['duration_at_145125MHz_seconds'])+' CRC='+','.join(result['crc_fields'])+' exit=0',flush=True)

from pathlib import Path
import difflib
import hashlib
import json
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
BASE=ROOT/'candidates/load_simple_loop16'
DEST=ROOT/'candidates/load_simple_loop16_h4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=(BASE/'rtl/rv32_btb.sv').read_text()
assert sha(BASE/'rtl/rv32_btb.sv')=='222223a16f58695fa149a0b709acaebfa2bab479b0acea916dfef76c9e8581ba'
assert old.count('parameter integer HISTORY_BITS=3,')==1
new=old.replace('parameter integer HISTORY_BITS=3,','parameter integer HISTORY_BITS=4,',1)
assert new.replace('parameter integer HISTORY_BITS=4,','parameter integer HISTORY_BITS=3,',1)==old
shutil.copy2(BASE/'rtl/rv32_btb.sv',HERE/'BASELINE_FILE.sv')
(HERE/'MODIFIED_FILE.sv').write_text(new,encoding='utf-8')
shutil.copy2(HERE/'MODIFIED_FILE.sv',HERE/'rv32_btb.sv')
(HERE/'DIFF_FILE.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='SL-Loop16-H3/rv32_btb.sv',tofile='SL-Loop16-H4/rv32_btb.sv')),encoding='utf-8')
change=dict(changed_field='Only BTB HISTORY_BITS default 3 -> 4; retain original Loop16 table and full SelectiveLoad ADD/XOR core.',
            baseline_btb_sha256=sha(HERE/'BASELINE_FILE.sv'),modified_btb_sha256=sha(HERE/'MODIFIED_FILE.sv'),
            retained_core_sha256=sha(BASE/'rtl/rv32_core.sv'),exact_inverse_parameter_text_equal=True,
            source_chain={'base':str(BASE),'original_selective_load':str(ROOT/'candidates/load_simple'),'original_loop16':str(ROOT/'candidates/id_equal_loop16')})
for folder,total in (('rtl',17),('physical_rtl',18)):
    directory=DEST/folder
    directory.mkdir(parents=True,exist_ok=True)
    for p in (BASE/folder).glob('*.sv'):
        shutil.copy2(HERE/'MODIFIED_FILE.sv' if p.name=='rv32_btb.sv' else p,directory/p.name)
    assert len(list(directory.glob('*.sv')))==total
    change[folder]={p.name:sha(p) for p in sorted(directory.glob('*.sv'))}
    assert all(p.name=='rv32_btb.sv' or p.read_bytes()==(BASE/folder/p.name).read_bytes() for p in directory.glob('*.sv'))
assert change['retained_core_sha256']=='5e81f9c56246e502b43c6a48c14342dbb16ac437788ac01d00a482d9a06ca84b'
source=ROOT/'rtl_proposals/load_simple_loop16'
shutil.copy2(source/'core_token_tb.sv',HERE/'core_token_tb.sv')
verify=(source/'verify.py').read_text().replace("BASE=ROOT/'candidates/load_simple'","BASE=ROOT/'candidates/load_simple_loop16'").replace("DEST=ROOT/'candidates/load_simple_loop16'","DEST=ROOT/'candidates/load_simple_loop16_h4'").replace("assert arch(receipts[0]['literal_output'])==arch(receipts[1]['literal_output'])","assert len(arch(receipts[0]['literal_output']))==591\nassert arch(receipts[0]['literal_output'])==arch(receipts[1]['literal_output'])")
(HERE/'verify.py').write_text(verify,encoding='utf-8')
screen=(source/'screen.py').read_text().replace('sg-loop16-sl-h6-baseline-i100-','sg-loop16-sl-h4-h3-baseline-i100-').replace('sg-loop16-sl-i100-','sg-loop16-sl-h4-i100-').replace("'load_simple' if args.baseline else 'load_simple_loop16'","'load_simple_loop16' if args.baseline else 'load_simple_loop16_h4'").replace('ex.simulator(rtl,1,2)','ex.simulator(rtl,1,1)')
(HERE/'screen.py').write_text(screen,encoding='utf-8')
rollback=(source/'ROLLBACK.sh').read_text(encoding='utf-8-sig').replace('47573AE5B351A71C6BC453901822CA8910E7696C170BCA71ECD77FB8EB5B0993',change['baseline_btb_sha256'].upper())
for name in ('ROLLBACK.sh','ROLLBACK.ps1'):
    (HERE/name).write_text(rollback,encoding='utf-8-sig')
shutil.copy2(source/'Test-Rollback.ps1',HERE/'Test-Rollback.ps1')
shutil.copy2(ROOT/'rtl_proposals/loop16/loop_predictor_tb.sv',HERE/'loop_predictor_tb.sv')
(HERE/'CHANGE.json').write_text(json.dumps(change,indent=2)+'\n',encoding='utf-8-sig')
print('SL_LOOP16_H4_PREPARED core='+change['retained_core_sha256']+' BTB='+change['modified_btb_sha256']+' frozen=17/18',flush=True)

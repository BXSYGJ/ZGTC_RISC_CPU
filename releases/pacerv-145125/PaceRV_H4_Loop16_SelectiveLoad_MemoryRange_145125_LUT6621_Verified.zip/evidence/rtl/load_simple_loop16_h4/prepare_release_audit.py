"""Read-only production/source audit and packaging requirements for H4 Loop16."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
change=load(HERE/'CHANGE.json')
before=(HERE/'BASELINE_FILE.sv').read_text()
after=(HERE/'MODIFIED_FILE.sv').read_text()
assert after.replace('parameter integer HISTORY_BITS=4,','parameter integer HISTORY_BITS=3,',1)==before
assert sha(HERE/'rv32_btb.sv')==sha(HERE/'MODIFIED_FILE.sv')==change['modified_btb_sha256']
assert sha(HERE/'BASELINE_FILE.sv')==change['baseline_btb_sha256']
assert sha(ROOT/'rtl_proposals/load_simple_loop16/MODIFIED_FILE.sv')==change['baseline_btb_sha256']
rollback=load(HERE/'ROLLBACK_RESULT.json')
assert rollback['ExitStatus']==0 and rollback['RestoredSHA256'].lower()==change['baseline_btb_sha256']
assert rollback['ActiveModifiedSHA256'].lower()==change['modified_btb_sha256']
assert sha(HERE/'rollback_sources/rv32_btb.sv')==change['baseline_btb_sha256']
core=load(HERE/'CORE_VERIFICATION.json')
predictor=load(HERE/'PREDICTOR_CHECKS.json')
assert core['modified_full_cycle_equal'] and core['architecture_lines']==591 and predictor['status']=='PASS'
assert len(predictor['tests'])==6
snapshots={}
for build in ('sg21-loop16-h4-synth','sg21-loop16-h4-s1','sg21-loop16-h4-s2'):
    directory=ROOT/'work'/build/'inputs/rtl'
    if directory.exists():
        actual={p.name:sha(p) for p in directory.glob('*.sv')}
        assert actual==change['physical_rtl'],build
        snapshots[build]=dict(path=str(directory),files=len(actual),hashes=actual)
source_proof=dict(exact_inverse=True,baseline_H3=sha(HERE/'BASELINE_FILE.sv'),modified_H4=sha(HERE/'MODIFIED_FILE.sv'),
                  retained_core=change['retained_core_sha256'],rollback=rollback,core_scenarios=23,architecture_lines=591,
                  core_full_stdout_BMR_equal=True,loop_model_variants=3,loop_model_checks_per_variant=3902,
                  explicit_H4_parameter_equivalence_configs=3,physical_input_snapshots=snapshots)
for folder,total in (('rtl',17),('physical_rtl',18)):
    directory=ROOT/'candidates/load_simple_loop16_h4'/folder
    actual={p.name:sha(p) for p in directory.glob('*.sv')}
    assert actual==change[folder] and len(actual)==total
source_proof['all_candidate_bindings_match']=True
performance=[]
for role in ('V0','V1'):
    h3=load(ROOT/('rtl_proposals/load_simple_loop16/SCREEN-MODIFIED-'+role+'.json'))
    h4=load(HERE/('SCREEN-MODIFIED-'+role+'.json'))
    h6=load(ROOT/('work/cf4-loadsimple-tune5-i100-'+role+'/RUN.json'))
    assert h3['firmware']['firmware_hex_sha256']==h4['firmware']['firmware_hex_sha256']==h6['firmware']['firmware_hex_sha256']
    assert h3['retired']==h4['retired']==h6['retired']
    events=lambda value:next(line for line in value['stdout'].splitlines() if line.startswith('EVENTS '))
    performance.append(dict(role=role,firmware_sha256=h4['firmware']['firmware_hex_sha256'],iterations=100,
                            same_firmware_bytes=True,same_timed_retired=h4['retired'],
                            H3=dict(cycles=h3['timed_cycles'],score=h3['coremark_per_mhz'],events=events(h3)),
                            H4=dict(cycles=h4['timed_cycles'],score=h4['coremark_per_mhz'],events=events(h4)),
                            H6=dict(cycles=h6['timed_cycles'],score=h6['coremark_per_mhz'],events=events(h6)),
                            H4_cycles_saved_from_H3=h3['timed_cycles']-h4['timed_cycles']))
tool_area=ROOT/'scripts/closure-packaging-quarter'
tool_hashes={p.name:sha(p) for p in tool_area.iterdir() if p.is_file()}
proof_text=(tool_area/'closure_proofs_quarter.py').read_text()
assert 'load_simple_loop16_h4' not in proof_text
requirements=dict(existing_packager=str(tool_area),existing_packager_files_sha256=tool_hashes,
                  current_BTB_17file_hash_binding=True,current_explicit_H4_BTB_provenance=False,
                  add_proposal='load_simple_loop16_h4',parent_proposal='load_simple_loop16',module='rv32_btb.sv',
                  proof_chain=['load_simple core ADD/XOR classification and arithmetic proofs','load_simple_loop16 exact donor BTB and unchanged 16/17 source bindings','load_simple_loop16_h4 sole HISTORY_BITS3->4 inverse, BMR core and predictor behavioral evidence','exact actual6000 V0/V1 model c7ab and saved cf4 firmware','selected physical snapshot, bitstream and all 10 timing report sections'],
                  required_new_files=['CHANGE.json','BASELINE_FILE.sv','MODIFIED_FILE.sv','rv32_btb.sv','DIFF_FILE.diff','VERIFICATION.txt','CORE_VERIFICATION.json','PREDICTOR_CHECKS.json','ROLLBACK_RESULT.json','ROLLBACK.sh','core_token_tb.sv','loop_predictor_tb.sv','history_default_tb.sv','reference_btb.sv','rollback_btb.sv','long_benchmark.py','LONG_V0_RESULT.json','LONG_V1_RESULT.json'],
                  existing_gates_to_preserve=['configured CPU145125000','setup uncertainty0.150ns','both6000 iterations','both formal durations>=10s','both actual scores>3.5','UART CRC and CSR/observer cycle/retirement equality','all10 raw timing sections PASS','exact17 sim/physical RTL hashes','firmware/source/bitstream/package hashes'],
                  performance_comparison='H4 changes prediction behavior. Compare raw saved cycles with independently recomputed score; do not require equal cycles to H6 or H3.',
                  tests_needed=['positive proof selection on actual H4 frozen snapshot','reject one changed BTB byte','reject HISTORY_BITS5 mutation','reject source/rollback hash mutation','reject missing BTB provenance in standalone verifier','reject failed actual timing','reject actual score<=3.5'])
processes={}
for role in ('V0','V1'):
    target=ROOT/'work'/('sg21-loop16-h4-i6000-'+role)
    processes[role]=load(target/'PROCESS.json')
result=dict(status='SOURCE_AND_PACKAGING_REQUIREMENTS_PREPARED',updated_utc=datetime.now(timezone.utc).isoformat(),source_proof=source_proof,
            performance_sources=performance,packaging_requirements=requirements,actual6000_processes=processes,
            production_RTL_modified=False,packager_modified=False)
output=HERE/'RELEASE_PREPARATION_AUDIT.json'
output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert load(output)==result
assert {p.name:sha(p) for p in tool_area.iterdir() if p.is_file()}==tool_hashes
print('H4_RELEASE_PREPARATION_PASS source_inverse=exact BMR_core23=equal predictor_tests=6 physical_snapshots='+str(len(snapshots))+' packaging_provenance_addition=BTB production_and_packager=unchanged reopened=1')

if __name__=='__main__':
    pass

`timescale 1ns/1ps
module loop_predictor_tb #(parameter integer LOOP_MODE=1);
    reg clk=0,rst_n=0,invalidate=0;
    always #5 clk=~clk;
    reg [31:0] fetch_pc=0,update_pc=0,update_target=0;
    reg update_valid=0,update_taken=0,update_conditional=1;
    wire taken,hit,stack_available;
    wire [31:0] target,stack_target;
    wire base_taken,base_hit,base_stack;
    wire [31:0] base_target,base_stack_target;
    integer checks=0,overrides=0,correct_exits=0,pending_checks=0;
    integer counts[0:15],trips[0:15],confidence[0:15];
    reg valid[0:15],overflow[0:15];
    reg [31:0] tags[0:15];
    rv32_btb #(.INDEX_BITS(8),.ADDRESS_BITS(16),.RETURN_STACK_DEPTH(1)) dut(
        .clk(clk),.rst_n(rst_n),.invalidate(invalidate),.fetch_pc(fetch_pc),
        .predicted_taken(taken),.predicted_target(target),.prediction_hit(hit),
        .return_stack_available(stack_available),.return_stack_target(stack_target),
        .update_valid(update_valid),.update_pc(update_pc),.update_target(update_target),
        .update_taken(update_taken),.update_conditional(update_conditional),
        .update_return(1'b0),.stack_push(1'b0),.stack_pop(1'b0),.stack_push_address(32'b0));
    baseline_btb #(.INDEX_BITS(8),.ADDRESS_BITS(16),.RETURN_STACK_DEPTH(1)) base(
        .clk(clk),.rst_n(rst_n),.invalidate(invalidate),.fetch_pc(fetch_pc),
        .predicted_taken(base_taken),.predicted_target(base_target),.prediction_hit(base_hit),
        .return_stack_available(base_stack),.return_stack_target(base_stack_target),
        .update_valid(update_valid),.update_pc(update_pc),.update_target(update_target),
        .update_taken(update_taken),.update_conditional(update_conditional),
        .update_return(1'b0),.stack_push(1'b0),.stack_pop(1'b0),.stack_push_address(32'b0));
    function automatic integer index_for(input [31:0] pc);
        reg [7:0] upper;
        begin upper=pc[16:9];index_for=(pc[8:1]^{upper[3:0],upper[7:4]})&15;end
    endfunction
    task automatic clear_model;
        integer index;
        begin
            for(index=0;index<16;index=index+1) begin
                valid[index]=0;counts[index]=0;trips[index]=0;
                confidence[index]=0;overflow[index]=0;tags[index]=0;
            end
        end
    endtask
    task automatic check_prediction;
        integer fi,ui,anticipated;
        reg use_loop,expected;
        begin
            #1;
            fi=index_for(fetch_pc);ui=index_for(update_pc);
            use_loop=valid[fi] && tags[fi]==fetch_pc && confidence[fi]>=2;
            expected=base_taken;
            if(LOOP_MODE!=0 && base_hit && dut.conditional[dut.fetch_index] && use_loop) begin
                anticipated=counts[fi];
                if(update_valid && !dut.clearing && !invalidate && update_conditional &&
                    update_target<update_pc && update_pc==fetch_pc && update_pc<65536 &&
                    update_target<65536 && !update_pc[0] && !update_target[0]) begin
                    anticipated=update_taken ? counts[fi]+1 : 0;
                    pending_checks=pending_checks+1;
                end
                expected=anticipated<trips[fi];
                overrides=overrides+1;
                if(!expected) correct_exits=correct_exits+1;
            end
            if(taken!==expected)
                $fatal(1,"Loop reference mismatch pc=%h count=%0d trip=%0d conf=%0d got=%b expected=%b",fetch_pc,counts[fi],trips[fi],confidence[fi],taken,expected);
            if(hit!==base_hit || target!==base_target || stack_available!==base_stack)
                $fatal(1,"Loop extension changed base tag/target/return stack behavior");
            checks=checks+1;
        end
    endtask
    task automatic step(input [31:0] fpc,upc,utarget,input uv,ut,uc,inv);
        integer ui;
        begin
            @(negedge clk);
            fetch_pc=fpc;update_pc=upc;update_target=utarget;
            update_valid=uv;update_taken=ut;update_conditional=uc;invalidate=inv;
            check_prediction();
            @(posedge clk);
            ui=index_for(upc);
            if(inv) clear_model();
            else if(uv && !dut.clearing && upc<65536 && utarget<65536 && !upc[0] && !utarget[0] && uc && utarget<upc) begin
                if(!valid[ui] || tags[ui]!=upc) begin
                    valid[ui]=1;tags[ui]=upc;counts[ui]=ut ? 1 : 0;
                    trips[ui]=0;confidence[ui]=0;overflow[ui]=0;
                end else if(ut) begin
                    if(counts[ui]==255) begin overflow[ui]=1;confidence[ui]=0;end
                    else counts[ui]=counts[ui]+1;
                end else begin
                    if(overflow[ui] || counts[ui]==0) begin trips[ui]=0;confidence[ui]=0;end
                    else begin
                        if(trips[ui]==counts[ui]) begin if(confidence[ui]<3) confidence[ui]=confidence[ui]+1;end
                        else confidence[ui]=0;
                        trips[ui]=counts[ui];
                    end
                    counts[ui]=0;overflow[ui]=0;
                end
            end
            #1;
        end
    endtask
    initial begin: run_cases
        integer iteration,length,branch,j;
        reg [31:0] pc;
        clear_model();repeat(3) @(negedge clk);rst_n=1;
        repeat(260) step(0,0,0,0,0,0,0);
        for(length=1;length<20;length=length+1) begin
            pc='h100+length*2;
            for(iteration=0;iteration<7;iteration=iteration+1) begin
                for(j=0;j<length;j=j+1) begin
                    step(pc,pc,pc-32,1,1,1,0);
                    step(pc,pc,pc-32,0,0,1,0);
                end
                step(pc,pc,pc-32,1,0,1,0);
                step(pc,pc,pc-32,0,0,1,0);
            end
        end
        // Same-index different tag replacement and a changed trip count.
        for(branch=0;branch<4;branch=branch+1) begin
            pc='h300+branch*32;
            for(iteration=0;iteration<6;iteration=iteration+1) begin
                for(j=0;j<5+branch;j=j+1) step(pc,pc,pc-16,1,1,1,0);
                step(pc,pc,pc-16,1,0,1,0);
            end
        end
        // Overflow, invalid/unaligned addresses, and forward/unconditional updates.
        for(j=0;j<270;j=j+1) step('h600,'h600,'h580,1,1,1,0);
        step('h600,'h600,'h580,1,0,1,0);
        step('h600,'h600,'h680,1,1,1,0);
        step('h600,'h600,'h580,1,1,0,0);
        step('h601,'h601,'h581,1,1,1,0);
        step('h10600,'h10600,'h10580,1,1,1,0);
        step('h100,'h100,'he0,1,1,1,1);
        repeat(260) step('h100,0,0,0,0,0,0);
        if(LOOP_MODE!=0 && (overrides<100 || correct_exits<10 || pending_checks<100)) $fatal(1,"Loop test coverage incomplete");
        $display("LOOP_PREDICTOR_PASS checks=%0d overrides=%0d exits=%0d pending=%0d mode=%0d",checks,overrides,correct_exits,pending_checks,LOOP_MODE);
        $finish;
    end
endmodule

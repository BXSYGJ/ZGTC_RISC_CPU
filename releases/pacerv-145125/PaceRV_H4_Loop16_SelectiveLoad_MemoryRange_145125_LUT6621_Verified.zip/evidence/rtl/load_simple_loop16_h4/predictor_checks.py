from pathlib import Path
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
receipts=[]
def run(command,label):
    value=subprocess.run(command,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(label+'.log')).write_text(value.stdout,encoding='utf-8')
    receipt=dict(command=command,input_directory=str(HERE),literal_output=value.stdout,exit_status=value.returncode)
    assert value.returncode==0,value.stdout[-3000:]
    return receipt

# Reuse the independent loop model: base local-run predictor and Loop16 must
# match tags, targets, RAS and predicted direction except model-authorized loops.
reference=(ROOT/'candidates/id_equal_history4/rtl/rv32_btb.sv').read_text()
for label,btb,hist in (('BASELINE',HERE/'BASELINE_FILE.sv',3),('MODIFIED',HERE/'MODIFIED_FILE.sv',4),('ROLLBACK',HERE/'rollback_sources/rv32_btb.sv',3)):
    ref=reference.replace('parameter integer HISTORY_BITS=4,','parameter integer HISTORY_BITS='+str(hist)+',',1).replace('module rv32_btb #(','module baseline_btb #(',1)
    (HERE/'baseline_btb.sv').write_text(ref,encoding='utf-8')
    compile=run(['iverilog','-g2012','-s','loop_predictor_tb','-o','loop-model.vvp','loop_predictor_tb.sv',str(btb),'baseline_btb.sv'],label.lower()+'-loop-model-compile')
    actual=run(['vvp','loop-model.vvp'],label.lower()+'-loop-model')
    assert 'LOOP_PREDICTOR_PASS' in actual['literal_output']
    receipts.append(dict(label=label,history_bits=hist,compile=compile,run=actual))
    print(label+' '+actual['literal_output'].splitlines()[0],flush=True)

# All three production source copies explicitly at H4 must give identical old
# ports every cycle, including unknown uninitialized targets and RAS pushes/pops.
original=(HERE/'BASELINE_FILE.sv').read_text().replace('module rv32_btb #(','module reference_btb #(',1)
restored=(HERE/'rollback_sources/rv32_btb.sv').read_text().replace('module rv32_btb #(','module rollback_btb #(',1)
(HERE/'reference_btb.sv').write_text(original,encoding='utf-8')
(HERE/'rollback_btb.sv').write_text(restored,encoding='utf-8')
tb=(ROOT/'rtl_proposals/timing_btb_paired_target/btb_pair_tb.sv').read_text()
tb=tb.replace('module btb_pair_tb #','module history_default_tb #')
tb=tb.replace('reference_btb #(.INDEX_BITS','reference_btb #(.HISTORY_BITS(4),.INDEX_BITS')
tb=tb.replace('rollback_btb #(.INDEX_BITS','rollback_btb #(.HISTORY_BITS(4),.INDEX_BITS')
tb=tb.replace('.PRECOMPUTE_TARGET_PAIR(1),','')
tb=re.sub(r',\.predicted_pair_target\([^)]*\),\.return_stack_pair_target\([^)]*\)','',tb)
lines=tb.splitlines()
lines=[line for line in lines if not ('if(default_pair' in line or 'if(paired' in line or 'if(ras_pair' in line or 'PAIR_WRAP_OR_COMPACT' in line or 'RAS_WRAP_FAILED' in line)]
tb='\n'.join(lines)+'\n'
tb=tb.replace('BTB_PAIR_SEQ_PASS','BTB_HISTORY_DEFAULT_EQ_PASS')
(HERE/'history_default_tb.sv').write_text(tb,encoding='utf-8')
for index,address,depth,hashing in ((4,16,0,0),(8,16,1,1),(4,32,4,1)):
    params={'INDEX_BITS':index,'ADDRESS_BITS':address,'RETURN_STACK_DEPTH':depth,'HASH_INDEX':hashing}
    command=['iverilog','-g2012','-s','history_default_tb']
    command+=['-Phistory_default_tb.'+key+'='+str(value) for key,value in params.items()]
    command+=['-o','history-default.vvp','history_default_tb.sv','reference_btb.sv','MODIFIED_FILE.sv','rollback_btb.sv']
    label='history-default-'+str(index)+'-'+str(address)+'-'+str(depth)+'-'+str(hashing)
    compiled=run(command,label+'-compile')
    actual=run(['vvp','history-default.vvp'],label)
    assert 'BTB_HISTORY_DEFAULT_EQ_PASS' in actual['literal_output']
    receipts.append(dict(label='H4_default_equals_original_explicit_H4',parameters=params,compile=compiled,run=actual))
    print(actual['literal_output'].splitlines()[0],flush=True)
(HERE/'PREDICTOR_CHECKS.json').write_text(json.dumps(dict(status='PASS',tests=receipts),indent=2)+'\n',encoding='utf-8')
print('SL_LOOP16_H4_PREDICTOR_PASS BMR_loop_model=3 H4_parameter_equivalence=3',flush=True)

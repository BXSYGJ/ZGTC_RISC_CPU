from pathlib import Path
import hashlib
import json
import math

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
change=load(HERE/'CHANGE.json')
core=load(HERE/'CORE_VERIFICATION.json')
predictor=load(HERE/'PREDICTOR_CHECKS.json')
assert core['architecture_lines']==591 and core['modified_full_cycle_equal']
assert predictor['status']=='PASS' and len(predictor['tests'])==6
old=(HERE/'BASELINE_FILE.sv').read_text()
new=(HERE/'MODIFIED_FILE.sv').read_text()
assert new.replace('parameter integer HISTORY_BITS=4,','parameter integer HISTORY_BITS=3,',1)==old
screens=[]
for role in ('V0','V1'):
    path=HERE/('SCREEN-MODIFIED-'+role+'.json')
    if not path.exists():
        continue
    baseline=load(ROOT/('rtl_proposals/load_simple_loop16/SCREEN-MODIFIED-'+role+'.json'))
    h6=load(ROOT/('work/cf4-loadsimple-tune5-i100-'+role+'/RUN.json'))
    modified=load(path)
    assert modified['firmware']['firmware_hex_sha256']==baseline['firmware']['firmware_hex_sha256']==h6['firmware']['firmware_hex_sha256']
    assert all(modified['checks'].values())
    screens.append(dict(role=role,baseline_H3=baseline,baseline_H6=h6,modified_H4=modified,
                        cycle_delta_H3=modified['timed_cycles']-baseline['timed_cycles'],
                        saving_required_to_exceed_3p5=max(0,modified['timed_cycles']-math.ceil(100e6/3.5)+1)))
assert screens
for folder in ('rtl','physical_rtl'):
    for name,expected in change[folder].items():
        assert sha(ROOT/'candidates/load_simple_loop16_h4'/folder/name)==expected
        if name!='rv32_btb.sv':
            assert sha(ROOT/'candidates/load_simple_loop16'/folder/name)==expected
summary=dict(status='FUNCTIONAL_PASS_V1_PENDING' if len(screens)<2 else ('FUNCTIONAL_PASS_SHORT_BOTH_GT3P5' if all(s['modified_H4']['coremark_per_mhz']>3.5 for s in screens) else 'FUNCTIONAL_PASS_SHORT_SCORE_BELOW_3P5'),
             changed_field=change['changed_field'],source_chain=change,core=core,predictor=predictor,screens=screens,
             full_ten_second_run_launched_by_this_script=False,PDS_launched_by_this_script=False,
             modified_btb_left_changed=sha(HERE/'MODIFIED_FILE.sv')==change['modified_btb_sha256'],
             restored_behavior='Actual rollback restores original H3 Loop16 BTB; all 23 core scenarios, complete 591 ARCH lines and complete core stdout match B/M/R. Independent loop behavior model passes both history widths.',
             artifacts={name:str(HERE/name) for name in ('MODIFIED_FILE.sv','DIFF_FILE.diff','VERIFICATION.txt','ROLLBACK.sh')})
(HERE/'VERIFICATION.txt').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
artifacts={name:dict(path=str(HERE/name),sha256=sha(HERE/name),bytes=len((HERE/name).read_bytes())) for name in summary['artifacts']}
assert load(HERE/'VERIFICATION.txt')==summary
(HERE/'FINAL_RECHECK.json').write_text(json.dumps(dict(status='PASS',artifacts=artifacts,short_status=summary['status'],short_scores={r['role']:r['modified_H4']['coremark_per_mhz'] for r in screens}),indent=2)+'\n',encoding='utf-8')
print('SL_LOOP16_H4_FINAL_PASS BMR_core23=equal ARCH=591 loop_model=3 predictor_parameter_configs=3 RTL=17/18 artifacts=reopened status='+summary['status'],flush=True)

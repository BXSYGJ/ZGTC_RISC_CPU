﻿param(
    [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$WorkspaceRoot,
    [ValidateNotNullOrEmpty()][string]$PdsRoot = 'D:/PDS_2022.2-SP6.4',
    [switch]$RunPds
)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.UTF8Encoding]::new($true)
$ErrorActionPreference = 'Stop'
try {
    $package = [System.IO.Path]::GetFullPath($PSScriptRoot)
    $workspace = [System.IO.Path]::GetFullPath($WorkspaceRoot)
    if (Test-Path -LiteralPath $workspace) { throw 'Use a new WorkspaceRoot.' }
    if ($workspace.StartsWith($package + [System.IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'WorkspaceRoot must be outside the package.' }
    [System.IO.Directory]::CreateDirectory($workspace) | Out-Null
    $checkpoint = [System.IO.Path]::Combine($workspace, 'checkpoint')
    $implementation = [System.IO.Path]::Combine($checkpoint, 'implementation')
    [System.IO.Directory]::CreateDirectory($implementation) | Out-Null
    Copy-Item -LiteralPath ([System.IO.Path]::Combine($package, 'physical_inputs')) -Destination ([System.IO.Path]::Combine($checkpoint, 'inputs')) -Recurse
    foreach ($name in @('BUILD_RESULT.json', 'INPUT_HASHES.json')) {
        Copy-Item -LiteralPath ([System.IO.Path]::Combine($package, 'evidence', 'physical', $name)) -Destination ([System.IO.Path]::Combine($checkpoint, $name))
    }
    foreach ($name in @('netlist.v', 'source.adf')) {
        Copy-Item -LiteralPath ([System.IO.Path]::Combine($package, 'evidence', 'physical', 'implementation', $name)) -Destination ([System.IO.Path]::Combine($implementation, $name))
    }
    $builder = [System.IO.Path]::Combine($package, 'tools', 'Build-PacePds.snapshot.ps1')
    $arguments = @{ ReleaseRoot=$package; Role='V0'; OutputDirectory=[System.IO.Path]::Combine($workspace, 'route'); PdsRoot=$PdsRoot; UartPins='LocalBoard'; Seed=2; LutCombineStrategy=1; PlcDecongestion=0; ReuseSynthesisBuild=$checkpoint }
    if (-not $RunPds) { $arguments.PrepareOnly=$true }
    & $builder @arguments
    if (-not $?) { throw 'Build-PacePds failed.' }
    Write-Output ('SG30_REBUILD_' + $(if ($RunPds) {'PDS_COMPLETED'} else {'PREPARE_PASS'}) + ' seed=2 packing=1 inputs=exact checkpoint=exact')
    exit 0
} catch { Write-Error $_; exit 1 }

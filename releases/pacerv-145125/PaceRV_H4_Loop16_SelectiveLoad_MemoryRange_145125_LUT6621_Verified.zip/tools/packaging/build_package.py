"""Create the exact qualified SG30 package from existing completed evidence; run no EDA/simulation."""
from pathlib import Path
import ast,hashlib,json,shutil,subprocess,zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
NAME='PaceRV_H4_Loop16_SelectiveLoad_MemoryRange_145125_LUT6621_Verified'
OUT=ROOT/'optimized_releases'/NAME
WORK=ROOT/'work/sg30-ram-memory-range-lut1-s2'
H4=ROOT/'optimized_releases/PaceRV_H4_Loop16_SelectiveLoad_145125_Verified_r2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def copy(source,relative):
    dest=OUT/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
    assert dest.read_bytes()==source.read_bytes()
def tree(source,relative,filter=None):
    for p in sorted(source.rglob('*')):
        if p.is_file() and (filter is None or filter(p)):
            copy(p,Path(relative)/p.relative_to(source))
def receipt(command,name):
    p=subprocess.run(command,cwd=HERE,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    (HERE/(name+'.log')).write_text(p.stdout,encoding='utf-8')
    value=dict(command=command,input=str(OUT),literal_output=p.stdout,exit_status=p.returncode)
    (HERE/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    assert p.returncode==0,p.stdout[-5000:]
    print(p.stdout.strip(),flush=True)
    return value

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    # Self-contained verifier embeds the strict original H4 donor verifier and timing parser.
    old=ROOT/'scripts/closure-packaging-loop16-h4'
    source=(old/'closure_proofs_h4.py').read_text(encoding='utf-8-sig')
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='parse_timing_report')
    parser=ast.get_source_segment(source,node)
    h4=(old/'h4_proof.py').read_text(encoding='utf-8-sig');h4=h4[h4.index("H6="):]
    verifier=(HERE/'verifier_template.py').read_text().replace('# EMBED_PARSE_TIMING',parser).replace('# EMBED_H4_PROOF',h4)
    (HERE/'verify_package_sg30.py').write_text(verifier,encoding='utf-8')
    copy(HERE/'verify_package_sg30.py','verify_package_sg30.py')
    copy(ROOT/'recipe.json','recipe.json')
    copy(WORK/'Build-PacePds.snapshot.ps1','tools/Build-PacePds.snapshot.ps1')
    copy(HERE/'Rebuild-Physical.ps1','Rebuild-Physical.ps1')
    tree(WORK/'inputs','physical_inputs')
    candidate=ROOT/'candidates/loop16_h4_ram_memory_range'
    tree(candidate/'rtl','simulation/rtl')
    recipe=load(ROOT/'recipe.json')
    for arg in recipe['simulation']['argv']:
        if '/simulation/inputs/sim/' in arg:
            copy(ROOT/arg.split('{RELEASE}/')[1],'simulation/sim/'+Path(arg).name)
    for role in ('V0','V1'):
        work=ROOT/'work'/('sg30-ram-memory-range-i6000-'+role)
        for p in sorted(work.iterdir()):
            if p.is_file():copy(p,'firmware/'+role+'/'+p.name)
        tree(ROOT/'firmware'/role/'inputs','firmware/'+role+'/inputs')
    for p in sorted(WORK.iterdir()):
        if p.is_file():copy(p,'evidence/physical/'+p.name)
    for p in sorted((WORK/'implementation').iterdir()):
        if p.is_file():copy(p,'evidence/physical/implementation/'+p.name)
    for relative in ['report_timing/pds_soc_top.rtr','report_timing/build.tcl','report_timing/run.log','place_route/pds_soc_top.prr','place_route/run.log','place_route/build.tcl','generate_bitstream/run.log']:
        p=WORK/'implementation'/relative
        if p.exists():copy(p,'evidence/physical/implementation/'+relative)
    physical=load(WORK/'BUILD_RESULT.json')
    copy(Path(physical['Bitstream']['Path']),'bitstreams/V0.sbit')
    # Preserve all original H4 provenance files, including H6/H3 donors and immutable short receipts.
    tree(H4/'evidence/rtl','evidence/rtl')
    for kind in ('rtl','constraints','fpga'):
        tree(H4/'physical_inputs'/kind,'evidence/ancestors/H4/'+kind)
    original=ROOT/'work/sg30-ram-memory-range-s2'
    tree(original/'inputs/constraints','evidence/ancestors/SG30s2/constraints')
    copy(original/'BUILD_RESULT.json','evidence/ancestors/SG30s2/BUILD_RESULT.json')
    copy(original/'INPUT_HASHES.json','evidence/ancestors/SG30s2/INPUT_HASHES.json')
    copy(original/'implementation/build.tcl','evidence/ancestors/SG30s2/build.tcl')
    # New source chain, current SG30 long binding, rollback source copies and complete textual logs.
    allowed={'.sv','.v','.py','.ps1','.sh','.diff','.json','.txt','.log','.md'}
    for proposal in ['loop16_h4_single_write','loop16_h4_ram_target_keep','loop16_h4_ram_memory_range','loop16_h4_ram_memory_range_longs']:
        base=ROOT/'rtl_proposals'/proposal
        tree(base,'evidence/rtl/'+proposal,lambda p:p.suffix.lower() in allowed and '__pycache__' not in p.parts)
    ev=ROOT/'evidence/selective_closure_20261118'
    for p in (ev/'packing1_transaction').iterdir():
        if p.is_file():copy(p,'evidence/packing1_transaction/'+p.name)
    for name in ['SELECTED_QUALIFIED_BASELINE.json']:
        copy(ev/name,'evidence/qualification/'+name)
    for name in ['SG30_LUT1_QUALIFICATION_AUDIT.json','SG30_LUT1_QUALIFICATION_AUDIT.md','sg30_lut1_qualification.py']:
        copy(ev/'review'/name,'evidence/qualification/'+name)
    # Checkpoints are copied with original bytes so reuse builds are fully preparable.
    assert sha(OUT/'evidence/physical/implementation/netlist.v')==physical['ReusedSynthesis']['NetlistSHA256'].lower()
    assert sha(OUT/'evidence/physical/implementation/source.adf')==physical['ReusedSynthesis']['DatabaseSHA256'].lower()
    readme=['# PaceRV H4 Loop16 SelectiveLoad MemoryRange — 6621 LUT','',
      '本包是新增的完整合格版本：145.125 MHz，setup uncertainty 0.150 ns，RV32IMC，PG2L200H-6FBB676。实际布局布线资源为 **6621 LUT / 2557 FF / 25 DRM36K / 4 APM / 1 GPLL**，全部十类内部时序检查通过，slow setup **+0.043 ns**。相较先前 H4 6812 LUT / 2813 FF，节省 191 LUT 与 256 FF。','',
      '| 实际 6000 次 RTL 运行 | Cycles | CoreMark/MHz | 145.125 MHz 计时 |','|---|---:|---:|---:|',
      '| V0 | 1712559880 | 3.503527129223651 | 11.800584875 秒 |',
      '| V1 | 1713586192 | 3.501428774351375 | 11.807656792 秒 |','',
      '两组 CRC、UART 计数与独立 observer 均通过，17 份公共 RTL 在仿真与物理构建中逐字节相同。保留完整 SelectiveLoad、H4 历史预测器和 16 项循环预测表；将循环 count/trip RAM 写口归并，并预计算完整地址范围后选择 memory redirect。物理配方为 seed=2、LUT combine strategy=1、dc_duplication=false。','',
      '`bitstreams/V0.sbit` 绑定包内 V0 固件；`firmware/V1/` 提供实际测试过的 V1 固件和运行证据。本包归档的成绩来自实际 RTL 仿真；本轮没有新增板上烧录或 UART 实测采样。','',
      '## 校验','',
      '在解压目录运行 Python 3（仅标准库）：','',
      '```powershell','python ./verify_package_sg30.py --root .','```','',
      '同一校验器支持 ZIP：`python ./verify_package_sg30.py --zip ./PaceRV_H4_Loop16_SelectiveLoad_MemoryRange_145125_LUT6621_Verified.zip`。它重新读取完整清单、实际长测、源身份、raw RTR/PRR、位流、约束和各级源变换/证明/回滚记录。','',
      '## 物理重建准备','',
      '包内提供原始 Build-PacePds 快照、完整 recipe.json、18 份物理 RTL、三份 FDC、PLL、V0 固件，以及原综合 netlist/ADF 检查点。以下入口在独立新目录准备相同 seed2/packing1 配方；默认只准备文件。Windows PowerShell 7：','',
      '```powershell',"pwsh -NoProfile -File ./Rebuild-Physical.ps1 -WorkspaceRoot ([IO.Path]::Combine($env:TEMP, 'PaceRV-SG30-Rebuild'))",'```','',
      '实际重建需本机安装 PDS 2022.2-SP6.4，使用一个新的 WorkspaceRoot，并显式添加 `-RunPds -PdsRoot <PDS安装目录>`。综合检查点与 RTL/FDC/固件均为此版本原始字节；布局布线的再运行结果应读取新报告验收。固件编译命令、工具版本与全部源码在 `firmware/V0`、`firmware/V1` 的 BUILD.json 和 inputs 中。仿真依赖的 vendor model、wrapper、observer 在 simulation/sim 中，原 recipe 和 PROCESS.json 保留实际调用。','',
      '## 证据导航','',
      '- `evidence/qualification/`：新 6621 选择及独立全资格审计。',
      '- `evidence/physical/`：实际 PDS invocation、输入哈希、TCL、检查点、raw timing/PRR 与执行日志。',
      '- `evidence/packing1_transaction/`：packing3→1 的单字段变更与独立副本回滚。',
      '- `evidence/rtl/`：H6→H3 donor→H4→single-write BTB，以及 SelectiveLoad→target_keep→memory_range core 的真实 source/proof/BMR/负控/回滚链。',
      '- 祖先报告中保留当时 `PHYSICAL_PENDING` 或旧 seed 失败状态；本包资格由后续 `sg30-ram-memory-range-lut1-s2` 的真实通过结果确定。','']
    (OUT/'README.md').write_text('\n'.join(readme),encoding='utf-8-sig')
    for name in ['build_package.py','verifier_template.py']:
        copy(HERE/name,'tools/packaging/'+name)
    files=[dict(path=p.relative_to(OUT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='MANIFEST.json']
    manifest=dict(schema='pacerv-sg30-qualified-release/v1',name=NAME,frequency_hz=145125000,setup_uncertainty_ns=0.15,resources=dict(LUT=6621,FF=2557,DRM36K=25,APM=4,GPLL=1),qualification='actual6000_both_gt3.5_and_all10_physical_checks_pass',physical_build='sg30-ram-memory-range-lut1-s2',files=files)
    (OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    receipt([sys.executable,str(HERE/'verify_package_sg30.py'),'--root',str(OUT)],'ROOT_VERIFICATION')
    dest=OUT.with_suffix('.zip')
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
    receipt([sys.executable,str(HERE/'verify_package_sg30.py'),'--zip',str(dest)],'ZIP_VERIFICATION')
    result=dict(status='PACKAGED_VERIFIED',root=str(OUT),zip=str(dest),zip_sha256=sha(dest),zip_bytes=dest.stat().st_size,manifest_files=len(files),zip_members=len(files)+1,verifier=str(HERE/'verify_package_sg30.py'),verifier_sha256=sha(HERE/'verify_package_sg30.py'),PDS_launched=0,simulation_launched=0)
    (HERE/'PACKAGE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    assert load(HERE/'PACKAGE_RESULT.json')==result
    print('SG30_ARCHIVE_READY files='+str(len(files))+' zip_bytes='+str(dest.stat().st_size)+' sha256='+sha(dest),flush=True)
if __name__=='__main__':
    import sys
    main()

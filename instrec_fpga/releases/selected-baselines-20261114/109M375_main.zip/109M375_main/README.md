# 109M375_main



原构建：D:\AAAFPGA\ZGTC_RISC_CPU_XSY\instrec_fpga\build\pacerv_shared_system\pds\full-20261114-021145-full

器件：PG2L100H-6IFBG676；系统频率：109375000 Hz。

直接使用本目录 instrec_top.sbit；inputs 是该位流对应的完整冻结源码、IP、HEX和约束。

INPUTS.json保存逐文件SHA256；TIMING.rtr保存原始最终时序报告。

SOURCE_BUILD_RECIPE.tcl保留原构建绝对路径，用于追溯原工程。

最终报告：slow setup -1.633 ns；slow hold -0.127 ns；fast hold -0.136 ns。

位流SHA256：bb484f2153523d8045631abe9d314e6ddffd658b01be0b35f2d76edc20d7f576

按用户要求选用已有版本，保留原时序违例记录。

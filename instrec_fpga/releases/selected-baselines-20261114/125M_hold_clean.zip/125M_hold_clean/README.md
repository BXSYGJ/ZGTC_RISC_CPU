# 125M_hold_clean



原构建：D:\AAAFPGA\ZGTC_RISC_CPU_XSY\instrec_fpga\build\pacerv_shared_system\pds\full-20261113-223256-full

器件：PG2L100H-6IFBG676；系统频率：125000000 Hz。

直接使用本目录 instrec_top.sbit；inputs 是该位流对应的完整冻结源码、IP、HEX和约束。

INPUTS.json保存逐文件SHA256；TIMING.rtr保存原始最终时序报告。

SOURCE_BUILD_RECIPE.tcl保留原构建绝对路径，用于追溯原工程。

最终报告：slow setup -1.414 ns；slow hold 0.052 ns；fast hold 0.0 ns。

位流SHA256：20bbda7e0194917111e76c7b797bc196bc8fdf6f02f00598f2eb297a6b76b157

按用户要求选用已有版本，保留原时序违例记录。

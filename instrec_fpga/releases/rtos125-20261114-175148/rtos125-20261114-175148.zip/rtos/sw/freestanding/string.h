#ifndef INSTREC_STRING_H
#define INSTREC_STRING_H
#include <stddef.h>
void *memcpy(void *destination, const void *source, size_t count);
void *memset(void *destination, int byte, size_t count);
int memcmp(const void *left, const void *right, size_t count);
#endif

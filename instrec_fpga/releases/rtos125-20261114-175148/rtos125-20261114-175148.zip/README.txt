125 MHz InstRec + FreeRTOS V11.3.3

Bitstream: instrec_top_rtos125.sbit
System clock: 125000000 Hz; RTOS tick: 1000 Hz; ROM/RAM: 16 KiB / 16 KiB.
The original audio/Mel/native 8-class NPU/HDMI pipeline is retained.
Source, complete frozen inputs, firmware ELF/HEX, original timing report and test evidence are included.
Run PDS from this directory with REBUILD.tcl to resolve relative ROM paths.
RTOS source and normal verification commands are documented in rtos/README.md; use those within the repository.
Timing values are retained verbatim in TIMING.rtr. No timing-closure claim is made.
Board testing has not run: the workstation did not enumerate FTDI/CP2102 devices at preflight.
Original 125 MHz rollback inputs remain in rtos/baseline125; PowerShell rollback entry is rtos/ROLLBACK.ps1.
